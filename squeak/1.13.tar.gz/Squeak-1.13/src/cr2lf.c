/* Line-end conversions.
 *
 * $Log$
 */

static char rcsid[]=
  "$Id$";

#include <stdio.h>
#include <fcntl.h>
#include <sys/param.h>

#define ERR(X)	{ perror(X); exit(1); }

#define BUFSIZE	8192

int inChar, outChar;
char *convName;

void convert(char *inFile)
{
  int	in, out, nRead;
  char	outFile[MAXPATHLEN];
  char 	buf[BUFSIZE];

  strcpy(outFile, inFile);
  strcat(outFile, ".");
  strcat(outFile, convName);

  if ((in= open(inFile, O_RDONLY)) < 0) ERR(inFile);
  if ((out= open(outFile, O_WRONLY | O_CREAT, 0644)) < 0) ERR(outFile);

  printf("%s: copying %s into %s\n", convName, inFile, outFile);

  while ((nRead= read(in, buf, BUFSIZE)) > 0)
    {
      int i;
      for (i= 0; i < nRead; i++)
	if (buf[i] == inChar)
	  buf[i]= outChar;
      if (write(out, buf, nRead) != nRead) ERR("write");
    }
  if (close(in) < 0) ERR(inFile);
  if (close(out) < 0) ERR(outFile);
}

int main(int argc, char **argv)
{
  int i;

  convName= *argv;

  if (!strcmp(convName, "cr2lf"))
    {
      inChar= '\r';
      outChar= '\n';
    }
  else if (!strcmp(convName, "lf2cr"))
    {
      inChar= '\n';
      outChar= '\r';
    }
  else
    {
      fprintf(stderr, "The name `%s' doesn't imply a cr/nl conversion\n", convName);
      exit(1);
    }

  for (i= 1; i < argc; i++)
    convert(argv[i]);

  return 0;
}
