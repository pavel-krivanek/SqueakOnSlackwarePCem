/* Automatically generated from Squeak on (10 October 1996 1:11:51 pm )*/

#include "sq.h"

#define true 1
#define false 0
#define null 0

/* Memory Access Macros */
#define byteAt(i) (*((unsigned char *) (i)))
#define byteAtput(i, val) (*((unsigned char *) (i)) = val)
#define floatAt(i) (*((double *) (i)))
#define floatAtput(i, val) (*((double *) (i)) = val)
#define longAt(i) (*((int *) (i)))
#define longAtput(i, val) (*((int *) (i)) = val)

/*** Imported Variables ***/
extern int stackPointer;
extern int successFlag;

/*** Variables ***/

/*** Function Prototypes ***/
int primFMSoundmixSampleCountintostartingAtpan(void);
int primPluckedSoundmixSampleCountintostartingAtpan(void);
int primWaveTableSoundmixSampleCountintostartingAtpan(void);

int primFMSoundmixSampleCountintostartingAtpan(void) {
    int rcvr;
    int n;
    short int *aSoundBuffer;
    int startIndex;
    int pan;
    int lastIndex;
    int i;
    int mySample;
    int sample;
    int channelIndex;
    short int *waveTable;
    int waveTableSize;
    int count;
    int amplitude;
    int increment;
    int index;
    int modulation;
    int offsetIncrement;
    int offsetIndex;

	rcvr = longAt(stackPointer - (4 * 4));
	n = checkedIntegerValueOf(longAt(stackPointer - (3 * 4)));
	aSoundBuffer = arrayValueOf(longAt(stackPointer - (2 * 4)));
	startIndex = checkedIntegerValueOf(longAt(stackPointer - (1 * 4)));
	pan = checkedIntegerValueOf(longAt(stackPointer - (0 * 4)));
	waveTable = fetchArrayofObject(1, rcvr);
	waveTableSize = fetchIntegerofObject(2, rcvr);
	count = fetchIntegerofObject(4, rcvr);
	amplitude = fetchIntegerofObject(6, rcvr);
	increment = fetchIntegerofObject(8, rcvr);
	index = fetchIntegerofObject(9, rcvr);
	modulation = fetchIntegerofObject(11, rcvr);
	offsetIncrement = fetchIntegerofObject(13, rcvr);
	offsetIndex = fetchIntegerofObject(14, rcvr);
	if (!(successFlag)) {
		return null;
	}
	lastIndex = (startIndex + n) - 1;
	for (i = startIndex; i <= lastIndex; i++) {
		mySample = (amplitude * (waveTable[index - 1])) / 1000;
		if (pan > 0) {
			channelIndex = 2 * i;
			sample = (aSoundBuffer[channelIndex - 1]) + ((mySample * pan) / 1000);
			if (sample > 32767) {
				sample = 32767;
			}
			if (sample < -32767) {
				sample = -32767;
			}
			aSoundBuffer[channelIndex - 1] = sample;
		}
		if (pan < 1000) {
			channelIndex = (2 * i) - 1;
			sample = (aSoundBuffer[channelIndex - 1]) + ((mySample * (1000 - pan)) / 1000);
			if (sample > 32767) {
				sample = 32767;
			}
			if (sample < -32767) {
				sample = -32767;
			}
			aSoundBuffer[channelIndex - 1] = sample;
		}
		index = (index + increment) + ((modulation * (waveTable[offsetIndex - 1])) / 1000000);
		if (index > waveTableSize) {
			index = index - waveTableSize;
		}
		if (index < 1) {
			index = index + waveTableSize;
		}
		offsetIndex = offsetIndex + offsetIncrement;
		if (offsetIndex > waveTableSize) {
			offsetIndex = offsetIndex - waveTableSize;
		}
	}
	count = count - n;
	storeIntegerofObjectwithValue(4, rcvr, count);
	storeIntegerofObjectwithValue(9, rcvr, index);
	storeIntegerofObjectwithValue(14, rcvr, offsetIndex);
	pop(4);
}

int primPluckedSoundmixSampleCountintostartingAtpan(void) {
    int rcvr;
    int n;
    short int *aSoundBuffer;
    int startIndex;
    int pan;
    int lastIndex;
    int thisIndex;
    int i;
    int nextIndex;
    int mySample;
    int channelIndex;
    int sample;
    int count;
    short int *ring;
    int ringSize;
    int ringIndx;

	rcvr = longAt(stackPointer - (4 * 4));
	n = checkedIntegerValueOf(longAt(stackPointer - (3 * 4)));
	aSoundBuffer = arrayValueOf(longAt(stackPointer - (2 * 4)));
	startIndex = checkedIntegerValueOf(longAt(stackPointer - (1 * 4)));
	pan = checkedIntegerValueOf(longAt(stackPointer - (0 * 4)));
	count = fetchIntegerofObject(2, rcvr);
	ring = fetchArrayofObject(4, rcvr);
	ringSize = fetchIntegerofObject(5, rcvr);
	ringIndx = fetchIntegerofObject(6, rcvr);
	if (!(successFlag)) {
		return null;
	}
	lastIndex = (startIndex + n) - 1;
	thisIndex = ringIndx;
	for (i = startIndex; i <= lastIndex; i++) {
		nextIndex = (thisIndex % ringSize) + 1;
		mySample = ((ring[thisIndex - 1]) + (ring[nextIndex - 1])) / 2;
		ring[thisIndex - 1] = mySample;
		thisIndex = nextIndex;
		if (pan > 0) {
			channelIndex = 2 * i;
			sample = (aSoundBuffer[channelIndex - 1]) + ((mySample * pan) / 1000);
			if (sample > 32767) {
				sample = 32767;
			}
			if (sample < -32767) {
				sample = -32767;
			}
			aSoundBuffer[channelIndex - 1] = sample;
		}
		if (pan < 1000) {
			channelIndex = (2 * i) - 1;
			sample = (aSoundBuffer[channelIndex - 1]) + ((mySample * (1000 - pan)) / 1000);
			if (sample > 32767) {
				sample = 32767;
			}
			if (sample < -32767) {
				sample = -32767;
			}
			aSoundBuffer[channelIndex - 1] = sample;
		}
	}
	ringIndx = nextIndex;
	count = count - n;
	storeIntegerofObjectwithValue(2, rcvr, count);
	storeIntegerofObjectwithValue(6, rcvr, ringIndx);
	pop(4);
}

int primWaveTableSoundmixSampleCountintostartingAtpan(void) {
    int rcvr;
    int n;
    short int *aSoundBuffer;
    int startIndex;
    int pan;
    int lastIndex;
    int i;
    int mySample;
    int channelIndex;
    int sample;
    short int *waveTable;
    int waveTableSize;
    int count;
    int amplitude;
    int increment;
    int index;

	rcvr = longAt(stackPointer - (4 * 4));
	n = checkedIntegerValueOf(longAt(stackPointer - (3 * 4)));
	aSoundBuffer = arrayValueOf(longAt(stackPointer - (2 * 4)));
	startIndex = checkedIntegerValueOf(longAt(stackPointer - (1 * 4)));
	pan = checkedIntegerValueOf(longAt(stackPointer - (0 * 4)));
	waveTable = fetchArrayofObject(1, rcvr);
	waveTableSize = fetchIntegerofObject(2, rcvr);
	count = fetchIntegerofObject(4, rcvr);
	amplitude = fetchIntegerofObject(6, rcvr);
	increment = fetchIntegerofObject(8, rcvr);
	index = fetchIntegerofObject(9, rcvr);
	if (!(successFlag)) {
		return null;
	}
	lastIndex = (startIndex + n) - 1;
	for (i = startIndex; i <= lastIndex; i++) {
		mySample = (amplitude * (waveTable[index - 1])) / 1000;
		if (pan > 0) {
			channelIndex = 2 * i;
			sample = (aSoundBuffer[channelIndex - 1]) + ((mySample * pan) / 1000);
			if (sample > 32767) {
				sample = 32767;
			}
			if (sample < -32767) {
				sample = -32767;
			}
			aSoundBuffer[channelIndex - 1] = sample;
		}
		if (pan < 1000) {
			channelIndex = (2 * i) - 1;
			sample = (aSoundBuffer[channelIndex - 1]) + ((mySample * (1000 - pan)) / 1000);
			if (sample > 32767) {
				sample = 32767;
			}
			if (sample < -32767) {
				sample = -32767;
			}
			aSoundBuffer[channelIndex - 1] = sample;
		}
		index = index + increment;
		if (index > waveTableSize) {
			index = index - waveTableSize;
		}
	}
	count = count - n;
	storeIntegerofObjectwithValue(4, rcvr, count);
	storeIntegerofObjectwithValue(9, rcvr, index);
	pop(4);
}
