/* This file is a heavily modified version of the file "sqMacWindow.c".
 *
 * Modifications by: Ian Piumarta (ian.piumarta@inria.fr)
 *
 * The original version of this file can be regenerated from the Squeak
 * image by executing:
 *
 * 	InterpreterSupportCode writeMacSourceFiles
 *
 * Last edited: Tue Nov  5 23:30:43 1996 by piumarta (Ian Piumarta) on prof
 *
 * $Log: sqXWindow.c,v $
 * Revision 1.3  1996/11/05  22:54:07  piumarta
 * Added support for using the X selection as the Squeak clipboard.
 *
 * Revision 1.2  1996/11/04  15:01:55  piumarta
 * Added code to find an 8-bit PseudoColor visual, and use it.
 *
 * Revision 1.1  1996/10/24  13:25:40  piumarta
 * Initial revision
 *
 */

static char rcsid[]=
  "$Id: sqXWindow.c,v 1.3 1996/11/05 22:54:07 piumarta Exp piumarta $";

#include "sq.h"

#include "sqUnixConfig.h"

#include <stdio.h>
#include <time.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/param.h>
#include <errno.h>


/*** Variables -- Imported from Virtual Machine ***/
extern unsigned char *memory;
extern int interruptPending;
extern int interruptCheckCounter;


/*** Variables -- image and path names ***/
#define IMAGE_NAME_SIZE MAXPATHLEN

char imageName[MAXPATHLEN+1];		/* full path to image */
char shortImageName[MAXPATHLEN+1];	/* just the base name */
char vmPath[MAXPATHLEN+1];		/* full path to interpreter's directory */


/*** Variables -- X11 Related ***/
#define xResourceClass	"Squeak"
#define xResourceName	"SqueakVM"
#define xWindowTitle	"SqueakVM"

char		*displayName= 0;	/* name of display, or 0 for $DISPLAY */
Display		*stDisplay= nil;	/* Squeak display */
Window		 stWindow= nil;		/* Squeak window */
GC		 stGC;			/* graphics context used for rendering */
Colormap	 stColormap= nil;	/* Squeak color map */
Visual		*stVisual;		/* any 8-bit PseudoColor visual */
int		 stVisualDepth;		/* the depth of the above visual (always 8) */
int		 stDisplayBitsIndex= 0;	/* last known oop of the VM's Display */
XImage		*stImage= 0;		/* ...and it's client-side pixmap */
char		*stPrimarySelection;	/* buffer holding selection */
int		 stPrimarySelectionSize;/* size of the previous buffer */
int		 stOwnsSelection= 0;	/* true if we own the X selection */
XColor		 stColorBlack;		/* black pixel value in stColormap */
XColor		 stColorWhite;		/* white pixel value in stColormap */
int		 savedWindowSize= 0;	/* initial size of window */
XPoint		 mousePosition;		/* position at last PointerMotion event */
Time		 stButtonTime;		/* time of last ButtonRelease (for SetSeln) */

/* we are interested in these events */
#define	EVENTMASK	ButtonPressMask | ButtonReleaseMask | \
			KeyPressMask | PointerMotionMask | \
			ExposureMask | EnterWindowMask | LeaveWindowMask

/* maximum input polling frequencey */
#define MAXPOLLSPERSEC	33

/* largest X selection which we will attempt to handle (bytes) */
#define MAX_SELECTION_SIZE	100*1024

/* longest we're prepared to wait for the selection owner to convert it (seconds) */
#define SELECTION_TIMEOUT	3

/*** Variables -- Event Recording ***/
#define KEYBUF_SIZE	64

int keyBuf[KEYBUF_SIZE];	/* circular buffer */
int keyBufGet= 0;		/* index of next item of keyBuf to read */
int keyBufPut= 0;		/* index of next item of keyBuf to write */
int keyBufOverflows= 0;	/* number of characters dropped */

int buttonState= 0;		/* mouse button and modifier state when mouse
				   button went down or 0 if not pressed */

#define ITIMER_INIT_SECS 31536000	/* 1 year of millisecond clock */

/* This table maps the X modifier key bits to 4 Squeak modifier
   bits. (The X caps lock key is ignored.  These bits are used only
   for mouse events: keyboard events are translated into the correct
   character by other means.  There is currently no way to generate
   the <command> modifier from X.)
	X bits:		<meta><control><shift-lock><shift>
	Squeak bits:	<command><option><control><shift>
*/
char modifierMap[16]= {
  0, 1, 0, 1, 2, 3, 2, 3, 4, 5, 4, 5, 6, 7, 6, 7
};

/* masks for the XButtonEvent modifier state */
#define MOD_SHIFT	1
#define MOD_CONTROL	4
#define MOD_META	8

/*** Functions ***/
int  HandleEvents(void);
void RecordFullPathForImageName(char *localImageName);
void SetColorEntry(int index, int red, int green, int blue);
void SetUpClipboard(void);
void SetUpPixmap(void);
void SetUpWindow(char *displayName);
void SetUpTimers(void);
void SetWindowSize(void);
void claimSelection(void);
void sendSelection(XSelectionRequestEvent *evt);
char *getSelection(void);

/*** VM Home Directory Path ***/

int vmPathSize(void)
{
  return strlen(vmPath);
}

int vmPathGetLength(int sqVMPathIndex, int length)
{
  char *stVMPath= (char *)sqVMPathIndex;
  int count, i;

  count= strlen(vmPath);
  count= (length < count) ? length : count;

  /* copy the file name into the Squeak string */
  for (i= 0; i < count; i++)
    stVMPath[i]= vmPath[i];

  return count;
}

/*** line-end conventions (mainly for converting the X selection) ***/

void st2ux(char *string)
{
  if (!string) return;
  while (*string)
    {
      if (*string == '\r')
	*string= '\n';
      string++;
    }
}

void ux2st(char *string)
{
  if (!string) return;
  while (*string)
    {
      if (*string == '\n')
	*string= '\r';
      string++;
    }
}

/*** X-related Functions ***/

void claimSelection(void)
{
  XSetSelectionOwner(stDisplay, XA_PRIMARY, stWindow, CurrentTime);
  stOwnsSelection= (XGetSelectionOwner(stDisplay, XA_PRIMARY) == stWindow);
}

void sendSelection(XSelectionRequestEvent *requestEv)
{
  XSelectionEvent notifyEv;

  /* this should REFUSE the selection if the target type isn't XA_STRING */

  st2ux(stPrimarySelection);

  XChangeProperty(requestEv->display,
		  requestEv->requestor,
		  requestEv->property,
		  requestEv->target,
		  8, PropModeReplace, stPrimarySelection,
		  (stPrimarySelection ? strlen(stPrimarySelection) : 0));

  ux2st(stPrimarySelection);

  notifyEv.type= SelectionNotify;
  notifyEv.display= requestEv->display;
  notifyEv.requestor= requestEv->requestor;
  notifyEv.selection= requestEv->selection;
  notifyEv.target= requestEv->target;
  notifyEv.time= requestEv->time;
  notifyEv.property= (requestEv->property == None)
    ? requestEv->target
    : requestEv->property;

  XSendEvent(requestEv->display, requestEv->requestor,
	     False, 0, (XEvent *)&notifyEv);

  XFlush(stDisplay);
}

char *getSelection(void)
{
  XEvent  ev;
  fd_set  fdMask;
  char	 *data;
		
  /* request the selection */
  XConvertSelection(stDisplay, XA_PRIMARY, XA_STRING, XA_STRING, stWindow, CurrentTime);

  /* wait for selection notification, ignoring (most) other events. */
  FD_ZERO(&fdMask);
  FD_SET(ConnectionNumber(stDisplay), &fdMask);

  do {
    if (XPending(stDisplay) == 0)
      {
	int status;
	struct timeval timeout= {SELECTION_TIMEOUT, 0};
	
	while ((status= select(FD_SETSIZE, &fdMask, 0, 0, &timeout)) < 0
	       && errno == EINTR);
	if (status < 0)
	  {
	    perror("select(stDisplay)");
	    return "";
	  }
	if (status == 0)
	  {
	    XBell(stDisplay, 0);
	    return "";
	  }
      }
    XNextEvent(stDisplay, &ev);
    /* this is necessary so that we can supply our own selection when we
       are the requestor -- this could (should) be optimised to return the
       stored selection value instead! */ 
    if (ev.type == SelectionRequest) sendSelection(&ev.xselectionrequest);
    } while (ev.type != SelectionNotify);

  /* check if the selection was refused */
  if (ev.xselection.property == None)
    {
      XBell(stDisplay, 0);
      return "";
    }
		
  /* get the value of the selection from the containing property */
  {
    Atom type;
    int format;
    unsigned long nitems, bytesAfter;
		
    XGetWindowProperty(stDisplay, ev.xselection.requestor, ev.xselection.property,
		       (long)0, (long)(MAX_SELECTION_SIZE/4),
		       False, AnyPropertyType,
		       &type, &format, &nitems, &bytesAfter,
		       (unsigned char **)&data);
    if (bytesAfter > 0)
      XBell(stDisplay, 0);
  }

  /* return the selection -- which must be XFreed() when no longer needed! */

  return data;
}

int HandleEvents(void)
{
  XEvent theEvent;
  int ok;

  /*  ok= XCheckWindowEvent(stDisplay, stWindow, EVENTMASK, &theEvent);*/
  ok= (XPending(stDisplay) > 0);
  if (ok)
    {
      XNextEvent(stDisplay, &theEvent);
      switch (theEvent.type)
	{
	case MotionNotify:
	  mousePosition.x= ((XMotionEvent *)&theEvent)->x;
	  mousePosition.y= ((XMotionEvent *)&theEvent)->y;
	  break;

	case ButtonPress:
	  recordMouseDown((XButtonEvent *)&theEvent);
	  return false;
	  break;

	case ButtonRelease:
	  recordModifierButtons((XButtonEvent *)&theEvent);
	  /* button up on "paste" causes a selection retrieval:
	     record the event time in case we need it later */
	  stButtonTime= ((XButtonEvent *)&theEvent)->time;
	  return false;
	  break;

	case KeyPress:
	  recordModifierButtons((XButtonEvent *)&theEvent);
	  recordKeystroke((XKeyEvent *)&theEvent);
	  /* a key bound to the paste operation causes a selection
	     retrieval: record the event time in case we need it later */
	  break;

	case EnterNotify:
	  XInstallColormap(stDisplay, stColormap);
	  break;

	case LeaveNotify:
	  XUninstallColormap(stDisplay, stColormap);
	  break;

	case SelectionClear:
	  stOwnsSelection= 0;
	  break;

	case SelectionRequest:
	  sendSelection(&theEvent.xselectionrequest);
	  break;

	case Expose:
#ifdef FULL_UPDATE_ON_EXPOSE
	  /* ignore it if there are other exposures upstream */
	  if (((XExposeEvent *)&theEvent)->count == 0)
	    fullDisplayUpdate();  /* this makes VM call ioShowDisplay */
#else
	  /* a modified copy of fullDisplayUpdate() which repaints
	     only the damaged parts of the window according to each
	     expose event on the queue.
	     Note: if the format of Form or Bitmap changes, or if
	     the special object index of Display is changed, this
	     version of the code WILL FAIL!  Otherwise it is to be
	     preferred. */
#  define longAt(i) (*((int *) (i)))
	  {
	    extern int specialObjectsOop;
	    extern int lengthOf(int);
	    int displayObj= longAt((specialObjectsOop + 4) + (14 * 4));
	    if ((((((unsigned)(longAt(displayObj))) >> 8) & 15) <= 4) &&
		((lengthOf(displayObj)) >= 4))
	      {
		int dispBits= longAt((displayObj + 4) + (0 * 4));
		int w= fetchIntegerofObject(1, displayObj);
		int h= fetchIntegerofObject(2, displayObj);
		int d= fetchIntegerofObject(3, displayObj);
		int dispBitsIndex= dispBits + 4;
		XExposeEvent *ev= (XExposeEvent *)&theEvent;
		ioShowDisplay(dispBitsIndex, w, h, d,
			      ev->x, ev->x + ev->width,
			      ev->y, ev->y + ev->height);
	      }
	  }
#  undef longAt
#endif
	  break;
	}
      /* with the right hook in the VM we could also treat StructureNotify here
	 to automatically restore the Display when the window size changes */
    }
  return ok;
}

void SetColorEntry(int index, int red, int green, int blue)
{
  XColor color;
  color.pixel= index;
  color.red= red;
  color.green= green;
  color.blue= blue;
  color.flags= DoRed|DoGreen|DoBlue;
  XStoreColor(stDisplay, stColormap, &color);
}

void SetUpPixmap(void)
{
  /* 1-bit colors (monochrome) */
  SetColorEntry(0, 65535, 65535, 65535);	/* white */
  SetColorEntry(1,     0,     0,     0);	/* black */

  /* additional colors for 2-bit color */
  SetColorEntry(2, 32768, 32768, 32768);	/* 50% gray */
  SetColorEntry(3, 65535, 65535,     0);	/* yellow */

  /* additional colors for 4-bit color */
  SetColorEntry( 4, 65535,     0,     0);	/* red */
  SetColorEntry( 5,     0, 65535,     0);	/* green */
  SetColorEntry( 6,     0,     0, 65535);	/* blue */
  SetColorEntry( 7,     0, 65535, 65535);	/* cyan */
  SetColorEntry( 8, 65535,     0, 65535);	/* magenta */
  SetColorEntry( 9,  8192,  8192,  8192);	/* 1/8 gray */
  SetColorEntry(10, 16384, 16384, 16384);	/* 2/8 gray */
  SetColorEntry(11, 24576, 24576, 24576);	/* 3/8 gray */
  SetColorEntry(12, 32768, 32768, 32768);	/* 4/8 gray */
  SetColorEntry(13, 40959, 40959, 40959);	/* 5/8 gray */
  SetColorEntry(14, 49151, 49151, 49151);	/* 6/8 gray */
  SetColorEntry(15, 57343, 57343, 57343);	/* 7/8 gray */

  /* additional colors for 8-bit color */
  /* 24 more shades of gray (does not repeat 1/8th increments) */
  SetColorEntry(16,  2048,  2048,  2048);	/*  1/32 gray */
  SetColorEntry(17,  4096,  4096,  4096);	/*  2/32 gray */
  SetColorEntry(18,  6144,  6144,  6144);	/*  3/32 gray */
  SetColorEntry(19, 10240, 10240, 10240);	/*  5/32 gray */
  SetColorEntry(20, 12288, 12288, 12288);	/*  6/32 gray */
  SetColorEntry(21, 14336, 14336, 14336);	/*  7/32 gray */
  SetColorEntry(22, 18432, 18432, 18432);	/*  9/32 gray */
  SetColorEntry(23, 20480, 20480, 20480);	/* 10/32 gray */
  SetColorEntry(24, 22528, 22528, 22528);	/* 11/32 gray */
  SetColorEntry(25, 26624, 26624, 26624);	/* 13/32 gray */
  SetColorEntry(26, 28672, 28672, 28672);	/* 14/32 gray */
  SetColorEntry(27, 30720, 30720, 30720);	/* 15/32 gray */
  SetColorEntry(28, 34815, 34815, 34815);	/* 17/32 gray */
  SetColorEntry(29, 36863, 36863, 36863);	/* 18/32 gray */
  SetColorEntry(30, 38911, 38911, 38911);	/* 19/32 gray */
  SetColorEntry(31, 43007, 43007, 43007);	/* 21/32 gray */
  SetColorEntry(32, 45055, 45055, 45055);	/* 22/32 gray */
  SetColorEntry(33, 47103, 47103, 47103);	/* 23/32 gray */
  SetColorEntry(34, 51199, 51199, 51199);	/* 25/32 gray */
  SetColorEntry(35, 53247, 53247, 53247);	/* 26/32 gray */
  SetColorEntry(36, 55295, 55295, 55295);	/* 27/32 gray */
  SetColorEntry(37, 59391, 59391, 59391);	/* 29/32 gray */
  SetColorEntry(38, 61439, 61439, 61439);	/* 30/32 gray */
  SetColorEntry(39, 63487, 63487, 63487);	/* 31/32 gray */

  /* The remainder of color table defines a color cube with six steps
     for each primary color. Note that the corners of this cube repeat
     previous colors, but simplifies the mapping between RGB colors and
     color map indices. This color cube spans indices 40 through 255.
     */
  {
    int r, g, b;

    for (r= 0; r < 6; r++)
      for (g= 0; g < 6; g++)
	for (b= 0; b < 6; b++)
	  {
	    int i= 40 + ((36 * r) + (6 * b) + g);
	    if (i > 255) error("index out of range in color table compuation");
	    SetColorEntry(i, (r * 65535) / 5, (g * 65535) / 5, (b * 65535) / 5);
	  }
  }

  /* initialise the black and white color values for cursor creation */
  stColorWhite.red= stColorWhite.green= stColorWhite.blue= 65535;
  if (XAllocColor(stDisplay, stColormap, &stColorWhite))
    fprintf(stderr, "failed to find white pixel in Squeak colormap\n");

  stColorBlack.red= stColorBlack.green= stColorBlack.blue= 0;
  if (XAllocColor(stDisplay, stColormap, &stColorBlack))
    fprintf(stderr, "failed to find black pixel in Squeak colormap\n");
}

void SetUpWindow(char *displayName)
{
  XRectangle windowBounds= { 44, 8, 640, 480 };  /* default window bounds */

  int right, bottom;

  stDisplay= XOpenDisplay(displayName);
  if (!stDisplay)
    {
      fprintf(stderr, "Could not open display '%s'.\n", XDisplayName(displayName));
      exit(1);
    }

  if (savedWindowSize != 0)
    {
      right=  windowBounds.x + ((unsigned) savedWindowSize >> 16);
      bottom= windowBounds.y + (savedWindowSize & 0xFFFF);
    }
  else
    {
      right= windowBounds.x + windowBounds.width;
      bottom= windowBounds.y + windowBounds.height;
    }

  /* minimum size is 64 x 64 */
  right= ( right > (windowBounds.x + 64)) ?  right : (windowBounds.x + 64);
  bottom= (bottom > (windowBounds.y + 64)) ? bottom : (windowBounds.y + 64);

  /* maximum bottom-right is screen bottom-right */
  right=  ( right <= DisplayWidth(stDisplay, DefaultScreen(stDisplay)))
    ?  right : (DisplayWidth(stDisplay, DefaultScreen(stDisplay))  - 8);
  bottom= (bottom <= DisplayHeight(stDisplay, DefaultScreen(stDisplay)))
    ? bottom : (DisplayHeight(stDisplay, DefaultScreen(stDisplay)) - 8);

  windowBounds.width= right - windowBounds.x;
  windowBounds.height= bottom - windowBounds.y;

  /* try to find an 8-bit PseudoColor visual */
  {
    XVisualInfo vInfo;
    if (!XMatchVisualInfo(stDisplay, DefaultScreen(stDisplay),
			  8, PseudoColor, &vInfo))
      {
	fprintf(stderr, "Could not find an 8-bit PseudoColor visual\n");
	exit(1);
      }
    stVisual= vInfo.visual;
    stVisualDepth= vInfo.depth;

    printf("Using visual id 0x%x:\n", vInfo.visualid);
    printf("  screen    %d\n", vInfo.screen);
    printf("  depth     %d\n", vInfo.depth);
    printf("  class     %d\n", vInfo.class);
    printf("  rgb masks %x %x %x\n", vInfo.red_mask, vInfo.green_mask, vInfo.blue_mask);
    printf("  cmap size %d\n", vInfo.colormap_size);
    printf("  bits/rgb  %d\n", vInfo.bits_per_rgb);
  }

  stColormap= XCreateColormap(stDisplay, DefaultRootWindow(stDisplay),
			      stVisual, AllocAll);

  /* create the window */
  {
    XSetWindowAttributes attributes;

    attributes.event_mask= EVENTMASK;	/* accept the interesting events */
    attributes.colormap= stColormap;	/* use our private colormap */
    attributes.background_pixel= 1;	/* black pixel, in our cmap */

    stWindow= XCreateWindow(stDisplay,
			    DefaultRootWindow(stDisplay),	/* parent */
			    windowBounds.x, windowBounds.y,
			    windowBounds.width, windowBounds.height,
			    0,			/* border width */
			    stVisualDepth,	/* depth */
			    InputOutput,
			    stVisual,
			    CWColormap|CWEventMask|CWBackPixel,
			    &attributes);
  }

  /* set the resource class and name */
  {
    XClassHint *classHints;

    classHints= XAllocClassHint();
    classHints->res_name= xResourceName;
    classHints->res_class= xResourceClass;
    XSetClassHint(stDisplay, stWindow, classHints);
    XFree(classHints);
  }

  /* set the window title */
  {
    XTextProperty textProperty;
    char *list[]= { xWindowTitle };

    if (!(XStringListToTextProperty(list, 1, &textProperty)))
      {
	fprintf(stderr, "failed to allocated X text property\n");
	exit(1);
      }
    XSetWMName(stDisplay, stWindow, &textProperty);
    XFree(textProperty.value);
  }

  /* create a suitable graphics context */
  {
    XGCValues gcValues;

    gcValues.function= GXcopy;
    gcValues.plane_mask= -1;
    gcValues.subwindow_mode= IncludeInferiors;
    gcValues.clip_x_origin= 0;
    gcValues.clip_y_origin= 0;
    gcValues.clip_mask= None;
    gcValues.foreground= BlackPixel(stDisplay, DefaultScreen(stDisplay));
    gcValues.background= WhitePixel(stDisplay, DefaultScreen(stDisplay));
    stGC= XCreateGC(stDisplay,
		    stWindow,
		    GCFunction | GCPlaneMask | GCSubwindowMode |
		    GCClipXOrigin | GCClipYOrigin | GCClipMask |
		    GCForeground | GCBackground,
		    &gcValues);
  }
}


void SetWindowSize(void)
{
  int width, height, maxWidth, maxHeight;

  if (savedWindowSize != 0)
    {
      width=  (unsigned)savedWindowSize >> 16;
      height= savedWindowSize & 0xFFFF;
    }
  else
    {
      width=  640;
      height= 480;
    }

  /* minimum size is 64 x 64 */
  width=  ( width > 64) ?   width : 64;
  height= (height > 64) ?  height : 64;

  /* maximum size is screen size */
  maxWidth=  (DisplayWidth(stDisplay, DefaultScreen(stDisplay)));
  maxHeight= (DisplayHeight(stDisplay, DefaultScreen(stDisplay)));
  width=  ( width <= maxWidth)  ?  width : maxWidth;
  height= (height <= maxHeight) ? height : maxHeight;

  XResizeWindow(stDisplay, stWindow, width, height);
}

/*** Event Recording Functions ***/

int recordKeystroke(XKeyEvent *theEvent)
{
  int keystate;

  unsigned char buf[32];
  int nConv;

  nConv= XLookupString(theEvent, buf, sizeof(buf), 0, 0);
  if (nConv == 0) return;

  keystate= (modifierMap[(theEvent->state) & 0xF] << 8) | buf[0];

  /* bug: the delete and interrupt keys should be read from the tty driver */
  
  if (buf[0] == 127)
    buf[0]= '\007';	/* DEL maps onto BS */

  if (buf[0] == 3)	/* use CTRL-C regardless of what the image wants */
    {
      /* Note: interrupt key is "meta"; it not reported as a keystroke */
      interruptPending= true;
      interruptCheckCounter= 0;
    }
  else
    {
      /* bug: this should be rewritten to cope with nConv > 1 */
      keyBuf[keyBufPut]= keystate;
      keyBufPut= (keyBufPut + 1) % KEYBUF_SIZE;
      if (keyBufGet == keyBufPut)
	{
	  /* buffer overflow; drop the last character */
	  keyBufGet= (keyBufGet + 1) % KEYBUF_SIZE;
	  keyBufOverflows++;
	}
    }
}

int recordMouseDown(XButtonEvent *theEvent)
{
  int stButtons= 0;

  switch (theEvent->button)
    {
    case 1: stButtons= 4; break;
    case 2: stButtons= 2; break;
    case 3: stButtons= 1; break;
    default: ioBeep(); break;
    }

  if (stButtons == 4)	/* red button honours the modifiers */
    {
      if (theEvent->state & MOD_CONTROL)
	stButtons= 2;	/* yellow button if CTRL down */
      else if (theEvent->state & MOD_META)
	stButtons= 1;	/* blue button if META down */
    }
  /* button state: low three bits are mouse buttons; next 4 bits are modifier bits */
  buttonState= (modifierMap[(theEvent->state) & 0xF] << 3) | (stButtons & 0x7);
}

/* both button and key events have the state member in the same place */
int recordModifierButtons(XButtonEvent *theEvent)
{
  int stButtons= 0;

  if (theEvent->type == ButtonPress)
    stButtons= buttonState & 0x7;
  else
    stButtons= 0;
  /* button state: low three bits are mouse buttons; next 4 bits are modifier bits */
  buttonState= (modifierMap[(theEvent->state) & 0xF] << 3) | (stButtons & 0x7);
}

/*** I/O Primitives ***/

int ioBeep(void)
{
  XBell(stDisplay, 0);	/* ring at default volume */
}

int ioGetButtonState(void)
{
  ioProcessEvents();  /* process all pending events */
  return buttonState;
}

int ioGetKeystroke(void)
{
  int keystate;

  ioProcessEvents();  /* process all pending events */
  if (keyBufGet == keyBufPut)
    return -1;  /* keystroke buffer is empty */

  keystate= keyBuf[keyBufGet];
  keyBufGet= (keyBufGet + 1) % KEYBUF_SIZE;
  /* set modifer bits in buttonState to reflect the last keystroke fetched */
  buttonState= ((keystate >> 5) & 0xF8) | (buttonState & 0x7);

  return keystate;
}

int ioMSecs()
{
  /* subtract the real-time interval timer from 1 year */
  struct itimerval iv;
  getitimer(ITIMER_REAL, &iv);
  /* millisecond resolution is available here on a lot of systems... */
  return
    (ITIMER_INIT_SECS-iv.it_value.tv_sec)*1000 + (1000000-iv.it_value.tv_usec)/1000;
}

int ioMousePoint(void)
{
  ioProcessEvents();  /* process all pending events */
  /* x is high 16 bits; y is low 16 bits */
  return (mousePosition.x << 16) | (mousePosition.y);
}

int ioPeekKeystroke(void)
{
  int keystate;

  ioProcessEvents();  /* process all pending events */

  if (keyBufGet == keyBufPut)
    return -1;  /* keystroke buffer is empty */

  keystate= keyBuf[keyBufGet];
  /* set modifer bits in buttonState to reflect the last keystroke peeked at */
  buttonState= ((keystate >> 5) & 0xF8) | (buttonState & 0x7);
  return keystate;
}

/* this should be rewritten to use SIGIO and/or the interval timers */
int ioProcessEvents(void)
{
  static unsigned long nextPollTick= 0;

  if ((unsigned long)ioMSecs() > nextPollTick)
    {
      /* time to process events! */
      while (HandleEvents())
	{
	  /* process all pending events */
	}
    /* wait a while before trying again */
      nextPollTick= ioMSecs() + (1000 / MAXPOLLSPERSEC);
    }
}

/* returns the size of the Squeak window */
int ioScreenSize(void)
{
  int w= 10, h= 10;

  if (stWindow != nil)
    {
      Window root;
      int x, y, b, d;
      XGetGeometry(stDisplay, stWindow, &root, &x, &y, &w, &h, &b, &d);
    }

  /* width must be a multiple of 4, or XPutImage goes gaga */
  if (w % 4)
    {
      w= (w / 4) * 4;
      XResizeWindow(stDisplay, stWindow, w, h);
    }

  return (w << 16) | (h & 0xFFFF);  /* w is high 16 bits; h is low 16 bits */
}

/* returns the local wall clock time */
int ioSeconds(void)
{
  extern int convertToSqueakTime(int unixTime);
  struct timeval tv;

  gettimeofday(&tv, 0);
#ifdef HAS_TIMEZONE
  return convertToSqueakTime(tv.tv_sec+timezone);
#else
  return convertToSqueakTime(tv.tv_sec+localtime(&tv.tv_sec)->tm_gmtoff);
#endif
}

static unsigned char swapBits(unsigned char in)
{
  unsigned char out= 0;
  int i;
  for (i= 0; i < 8; i++)
    {
      out= (out << 1) + (in & 1);
      in >>= 1;
    }
  return out;
}

int ioSetCursor(int cursorBitsIndex, int offsetX, int offsetY)
{
  unsigned char data[32], mask[32];	/* cursors are always 16x16 */
  int i;
  Cursor cursor;
  Pixmap dataPixmap, maskPixmap;

  for (i= 0; i < 16; i++)
    {
      data[i*2+0]= ((unsigned)checkedLongAt(cursorBitsIndex + (4 * i)) >> 24) & 0xFF;
      data[i*2+1]= ((unsigned)checkedLongAt(cursorBitsIndex + (4 * i)) >> 16) & 0xFF;
      mask[i*2+0]= ((unsigned)checkedLongAt(cursorBitsIndex + (4 * i)) >> 24) & 0xFF;
      mask[i*2+1]= ((unsigned)checkedLongAt(cursorBitsIndex + (4 * i)) >> 16) & 0xFF;
    }

  /*  if (BitmapBitOrder(stDisplay) == LSBFirst)*/
    {
      /* the bytes are always in the right order: swap only bits within bytes */
      char *dp= (char *)data;
      char *mp= (char *)mask;
      for (i= 0; i < 32; i++)
	{
	  dp[i]= swapBits(dp[i]);
	  mp[i]= swapBits(mp[i]);
	}
    }

  dataPixmap= XCreateBitmapFromData(stDisplay,
				    DefaultRootWindow(stDisplay),
				    (char *)data, 16, 16);

  maskPixmap= XCreateBitmapFromData(stDisplay,
				    DefaultRootWindow(stDisplay),
				    (char *)mask, 16, 16);

  cursor= XCreatePixmapCursor(stDisplay, dataPixmap, maskPixmap,
			      &stColorBlack, &stColorWhite,
			      -offsetX, -offsetY);

  XFreePixmap(stDisplay, dataPixmap);
  XFreePixmap(stDisplay, maskPixmap);

  if (cursor != None)
    XDefineCursor(stDisplay, stWindow, cursor);
}

int ioShowDisplay(int dispBitsIndex, int width, int height, int depth,
		  int affectedL, int affectedR, int affectedT, int affectedB)
{
  if (stWindow == nil)
    return;
  
  if (depth != 8)
    fprintf(stderr,
	    "ioShowDisplay %lx: w=%d, h=%d, d=%d (%d @ %d corner: %d @ %d)\n",
	    dispBitsIndex,
	    width, height, depth,
	    affectedL, affectedT,
	    affectedR, affectedB);

  if (dispBitsIndex != stDisplayBitsIndex)
    {
      if (stImage)
	{
	  stImage->data= 0;	/* don't you dare free() Display's Bitmap! */
	  XDestroyImage(stImage);
#ifdef HAS_LSB_FIRST
	  free((void *)stDisplayBitsIndex);
#endif
	}

      /* fails catastrophically if depth ~= 8 */
#ifdef HAS_LSB_FIRST
      stDisplayBitsIndex= (int)malloc(width*height*depth/8);
#else
      stDisplayBitsIndex= dispBitsIndex;
#endif
      stImage= XCreateImage(stDisplay,
			    stVisual,
			    stVisualDepth,
			    ZPixmap,
			    0,
			    (char *)stDisplayBitsIndex,
			    width,
			    height,
			    32,
			    0);
    }

  /* this can happen after resizing the window */
  if (affectedR > width) affectedR= width;
  if (affectedB > height) affectedB= height;

#ifdef HAS_LSB_FIRST
  /* copy affected region, correcting for byte order */
  {
    int scanLine;
    int firstWord;
    int lastWord;
    int line;
    extern int swapBytes(int);
    int pixPerWord;
    int pixPerM1;

    pixPerWord= 32/depth;
    pixPerM1= pixPerWord-1;
    scanLine= (width+pixPerM1) & ~pixPerM1;
    firstWord= (affectedL & ~pixPerM1) + scanLine*affectedT;
    lastWord= ((affectedR+pixPerM1) & ~pixPerM1) + scanLine*affectedT;

    for (line= affectedT; line < affectedB; line++)
      {
	register int *base= (int *)((int)stDisplayBitsIndex+firstWord);
	register int *out= (int *)((int)stDisplayBitsIndex+lastWord);
	register int *in= (int *)((int)dispBitsIndex+lastWord);
	while (--out >= base)
	  *out= swapBytes(*--in);
	firstWord+= scanLine;
	lastWord+= scanLine;
      }
  }
#endif

  XPutImage(stDisplay, stWindow, stGC, stImage,
	    affectedL, affectedT,	/* src_x, src_y */
	    affectedL, affectedT,	/* dst_x, dst_y */
	    affectedR-affectedL,	/* width */		
	    affectedB-affectedT);	/* height */
}

/*** Image File Naming ***/

void RecordFullPathForImageName(char *localImageName)
{
  int i;
  /* get canonical path to image */
  if (!realpath(localImageName, vmPath))
    {
      perror(vmPath);
      exit(1);
    }
  strcpy(imageName, vmPath);
  /* truncate vmPath to dirname */
  for (i= strlen(vmPath); i >= 0; i--)
    if ('/' == vmPath[i])
      {
	vmPath[i+1]= '\0';
	return;
      }
  /* this might just work in an emergency... */
  strcpy(imageName, vmPath);
}

int imageNameSize(void)
{
  return strlen(imageName);
}

int imageNameGetLength(int sqImageNameIndex, int length)
{
  char *sqImageName= (char *)sqImageNameIndex;
  int count, i;

  count= strlen(imageName);
  count= (length < count) ? length : count;

  /* copy the file name into the Squeak string */
  for (i= 0; i < count; i++)
    sqImageName[i]= imageName[i];

  return count;
}

int imageNamePutLength(int sqImageNameIndex, int length)
{
  char *sqImageName= (char *)sqImageNameIndex;
  int count, i;

  count= (IMAGE_NAME_SIZE < length) ? IMAGE_NAME_SIZE : length;

  /* copy the file name into a null-terminated C string */
  for (i= 0; i < count; i++)
    imageName[i]= sqImageName[i];

  imageName[count]= 0;

  return count;
}

/*** Timing support ***/

void SetUpTimers(void)
{
  struct itimerval iv;
  iv.it_interval.tv_sec= 0;
  iv.it_interval.tv_usec= 0;
  iv.it_value.tv_sec= ITIMER_INIT_SECS;
  iv.it_value.tv_usec= 0;
  setitimer(ITIMER_REAL, &iv, 0);
  /* the clock is now running down from 1 year towards zero... */
}

/*** X selection handling ***/

void SetUpClipboard(void)
{
  stPrimarySelection= 0;
  stPrimarySelectionSize= 0;
  stOwnsSelection= 0;
}

int clipboardSize(void)
{
  if (stOwnsSelection)
    return stPrimarySelection ? strlen(stPrimarySelection) : 0;
  return strlen(getSelection());
}

static void allocateSelectionBuffer(int count)
{
  if (count+1 > stPrimarySelectionSize)
    {
      if (stPrimarySelection)
	{
	  free(stPrimarySelection);
	  stPrimarySelection= 0;
	  stPrimarySelectionSize= 0;
	}
      if (!(stPrimarySelection= (char *)malloc(count+1)))
	{
	  fprintf(stderr, "failed to allocate X selection buffer\n");
	  return;
	}
      stPrimarySelectionSize= count;
    }
}

/* claim ownership of the X selection, providing the given string to requestors */
int clipboardWriteFromAt(int count, int byteArrayIndex, int startIndex)
{
  char *srcPtr, *dstPtr, *end;

  allocateSelectionBuffer(count);

  srcPtr= (char *)byteArrayIndex + startIndex;
  dstPtr= stPrimarySelection;
  end= srcPtr + count;
  while (srcPtr < end)
    *dstPtr++= *srcPtr++;

  *dstPtr= '\0';

  claimSelection();
}

/* transfer the X selection into the given byte array; optimise local requests */
int clipboardReadIntoAt(int count, int byteArrayIndex, int startIndex)
{
  long clipSize, charsToMove;
  char *srcPtr, *dstPtr, *end;

  if (!stOwnsSelection)
    {
      char *newSelection;
      int newSize;

      /* need to keep a separate selection buffer, or we wouldn't know if it
	 was allocated by us or by X */
      newSelection= getSelection();	/* definitely allocated by X... */
      newSize= strlen(newSelection);
      allocateSelectionBuffer(newSize);
      strcpy(stPrimarySelection, newSelection);
      XFree(newSelection);		/* ...so we need to XFree() it */
      ux2st(stPrimarySelection);
    }

  clipSize= clipboardSize();
  charsToMove= (count < clipSize) ? count : clipSize;

  srcPtr= (char *)stPrimarySelection;
  dstPtr= (char *)byteArrayIndex + startIndex;
  end= srcPtr + charsToMove;
  while (srcPtr < end)
    *dstPtr++= *srcPtr++;

  return charsToMove;
}

/*** Profiling ***/

int clearProfile(void) {}
int dumpProfile(void) {}
int startProfiling(void) {}
int stopProfiling(void) {}

/*** Command line ***/

void ParseArguments(int argc, char **argv)
{
  /* defaults */
  strcpy(shortImageName, "clone.image");

  argc--;
  argv++;	/* skip VM name */

  if (argc && !strcmp(*argv, "-display"))
    {
      argc--;	/* skip -display */
      argv++;
      if (!argc)
	{
	  fprintf(stderr, "which display do you want?\n");
	  exit(1);
	}
      displayName= *argv++;
      argc--;
    }

  if (argc)
    {
      strcpy(shortImageName, *argv);
      argc--;
      argv++;
    }

  if (argc)
    {
      fprintf(stderr, "options are: [-display <displayName>] [<imageName>]\n");
      exit(1);
    }
}

/*** Release ***/

void Cleanup(void)
{
  /* not all of these are essential, but they're polite... */
  if (stColormap) XFreeColormap(stDisplay, stColormap);
  if (stGC)	  XFreeGC(stDisplay, stGC);
  if (stWindow)	  XDestroyWindow(stDisplay, stWindow);
  if (stDisplay)  XCloseDisplay(stDisplay);
}

/*** Main ***/

void main(int argc, char **argv)
{
  /* release resources on exit */
#ifdef HAS_ON_EXIT
  on_exit(Cleanup);
#else
  atexit(Cleanup);
#endif

  /* initialisation */
  ParseArguments(argc, argv);
  SetUpClipboard();
  SetUpTimers();
  SetUpWindow(displayName);
  SetUpPixmap();
  sqFileInit();
  joystickInit();

  SetWindowSize();

  /* this is a misnomer now */
  RecordFullPathForImageName(shortImageName);

  /* check the interpreter's size assumptions for basic data types */
  if (sizeof(int) != 4)    error("This C compiler's integers are not 32 bits.");
  if (sizeof(double) != 8) error("This C compiler's floats are not 64 bits.");
  if (sizeof(time_t) != 4) error("This C compiler's time_t's are not 32 bits.");

  /* read the image file and allocate memory for Squeak heap */
  readImageFile(imageName);

  /* open the Squeak window. */
  XMapWindow(stDisplay, stWindow);

  /* run Squeak */
  interpret();
}
