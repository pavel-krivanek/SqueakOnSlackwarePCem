/* Identification of, and configuration for, various types of Unix platform.
 *
 * Author: Ian Piumarta (ian.piumarta@inria.fr)
 *
 * $Log: sqUnixConfig.h,v $
 * Revision 1.1  1996/10/24 13:23:50  piumarta
 * Initial revision
 *
 */

/* this file must define the following symbols if appropriate:

   HAS_D_NAMLEN		defined if struct dirent has d_namlen field 
   			and hence directory names are not null terminated.
			if underfined then directory names are null terminated.

   HAS_TIMEZONE		defined if the external variable timezone is available,
			conaining the local offset from GMT in seconds.
			if undefined then the tm structure must contain the
			same information in the tm_gmtoff field.

   HAS_ON_EXIT		defined if cleanup functions are declared with on_exit().
   			if undefined then cleanup functions are declared with
			atexit().

   HAS_MSB_FIRST	defined if the most significant byte is first in an int.
   HAS_LSB_FIRST	defined if the least significant byte is first in an int.
			(complains if neither of these are defined.)
*/

#if defined(sun) && (defined(sparc) || defined(__sparc))
# include <errno.h>
# ifdef ECHRNG					/* Sparc/Solaris */
#  undef  HAS_D_NAMLEN
#  define HAS_TIMEZONE
#  undef  HAS_ON_EXIT
#  define HAS_MSB_FIRST
# else						/* Sparc/SunOS */
#  define HAS_D_NAMLEN
#  undef  HAS_TIMEZONE
#  define HAS_ON_EXIT
#  define HAS_MSB_FIRST
# endif
#endif

#if defined(sun) && defined(i386)		/* iX86/Solaris */
# undef  HAS_D_NAMLEN
# define HAS_TIMEZONE
# undef  HAS_ON_EXIT
# define HAS_LSB_FIRST
#endif

#if defined(mips) || defined(__mips)
# if defined(_SYSTYPE_SVR4)			/* (SGI)/IRIX */
#  undef  HAS_D_NAMLEN
#  define HAS_TIMEZONE
#  undef  HAS_ON_EXIT
#  define HAS_MSB_FIRST
# endif
#endif

#if defined(linux)
# if defined(i386)				/* iX86/Linux */
#  undef  HAS_D_NAMLEN
#  define HAS_TIMEZONE
#  undef  HAS_ON_EXIT
#  define HAS_LSB_FIRST
# endif
#endif

#if defined(__alpha)				/* Alpha/OSF1 */
# define HAS_D_NAMLEN
# undef  HAS_TIMEZONE
# undef  HAS_ON_EXIT
# define HAS_LSB_FIRST
#endif

#if !defined(HAS_LSB_FIRST) && !defined(HAS_MSB_FIRST)
--> test for, and describe, your architecture here.
#endif
