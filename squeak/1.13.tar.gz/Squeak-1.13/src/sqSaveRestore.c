/* This file is a heavily modified version of the original "sqSaveRestore.c".
 *
 * Modifications by: Ian Piumarta (ian.piumarta@inria.fr)
 *
 * The original version of this file can be regenerated from the Squeak
 * image by executing:
 *
 * 	InterpreterSupportCode writeMacSourceFiles
 *
 * $Log: sqSaveRestore.c,v $
 * Revision 1.1  1996/10/24 13:21:38  piumarta
 * Initial revision
 *
 */

static char rcsid[]=
  "$Id: sqSaveRestore.c,v 1.1 1996/10/24 13:21:38 piumarta Exp piumarta $";

#include "sq.h"

/***
	Note: There is a slight asymmetry in error handling here. readImageFile is called
	only from C code at startup time. If it encounters problems, it reports an error
	and quits. If it returns, it is assumed to have succeeded. In contrast, writeImageFile
	is called from a primitive. If it fails, it prints an error, sets successFlag to
	false, and continues. This allows the user to correct the problem and try again.

***/

/*** imported variables (typically initialized by readImageFile, saved by writeImageFile) ***/

extern int endOfMemory, lastHash, memoryLimit, specialObjectsOop, successFlag;
extern unsigned char *memory;
extern int savedWindowSize;
extern char imageName[];

#define SEEK_SET	0
#define SEEK_REL	1
#define SEEK_END	2

int endsChanged= 0;	/* this is true if the image was saved on a machine
			   with a different byte order to the current platform */

/*** local functions ***/
int  nextWord(FILE *f);
int  nextWordPut(FILE *f, int word);
int  swapBytes(int word);
void reverseBytesInImage(int);
void reverseWordsInFloats(void);

int swapBytes(int word)
{
  int conv;
  unsigned char *cp= (unsigned char *)&conv, *wp= (unsigned char *)&word;

  cp[0]= wp[3];
  cp[1]= wp[2];
  cp[2]= wp[1];
  cp[3]= wp[0];
  return conv;
}

int nextWord(FILE *f) {
	int result, count;

	count = fread(&result, sizeof(int), 1, f);
	if (count != 1) {
		error("Read failed in nextWord");
	}

	return endsChanged ? swapBytes(result) : result;
}

int nextWordPut(FILE *f, int word) {
	int count;

	count = fwrite(&word, sizeof(int), 1, f);
	if (count != 1) {
		printf("Write failed in nextWordPut\n");
		return success(false);
	}
}

/*** image file read/write ***/

int readImageFile(char *imageFilename) {
	FILE	*f;
	int		version, headerSize, dataSize, oldBaseAddr, bytesToShift;
	int		availableMemory, minimumMemory, err, count;
	int		seekAdjust= 0;

	f = fopen(imageFilename, "r");
	if (f == NULL) {
		printf("Could not open the Squeak image file '%s'\n", imageFilename);
		exit(1);
	}

	version= nextWord(f);

	if (version != CURRENT_VERSION)
	  {
	    if ((version= swapBytes(version)) == CURRENT_VERSION)
	      endsChanged= 1;
	    else
	      {
		
		/* perhaps there's a resource fork to ignore? */
		seekAdjust= 512;
		if (fseek(f, seekAdjust, SEEK_SET))
		  error("Seek failed; bad image file, perhaps?");
		version= nextWord(f);
		if (version != CURRENT_VERSION)
		  {
		    if ((version= swapBytes(version)) == CURRENT_VERSION)
		      endsChanged= 1;
		    else
		      {
			printf("This interpreter (vers. %d) cannot read image file (vers. %d or %d)\n",
			       CURRENT_VERSION, version, swapBytes(version));
			error("Aborting...");
		      }
		  }
	      }
	  }

	headerSize		= nextWord(f);
	dataSize		= nextWord(f);
	oldBaseAddr		= nextWord(f);
	specialObjectsOop	= nextWord(f);
	lastHash		= nextWord(f);
	savedWindowSize		= nextWord(f);

	if (lastHash == 0) {
		/* lastHash wasn't stored (e.g. by the cloner); use 999 as the seed */
		lastHash = 999;
	}

	/* compute memory requirements and availability */
	minimumMemory = dataSize + 20000;
	availableMemory = dataSize + 4000000;	/* 4Mb of available image space */

	if (availableMemory < minimumMemory) {
		error("Could not allocate memory for the heap");
	}

	/* allocate a contiguous block of memory for the Squeak heap */
	memory = (unsigned char *)calloc(availableMemory, 1);
	if (memory == NULL) {
		error("Failed to allocate memory for the heap");
	}
	memoryLimit = (((int) memory) + availableMemory) - 24;  /* decrease memoryLimit a tad for safety */
	endOfMemory = ((int) memory) + dataSize;

	/* position file after the header */
	err = fseek(f, headerSize+seekAdjust, SEEK_SET);
	if (err) {
		error("Seek failed; bad image file, perhaps?");
	}

	/* read in the image */
	count = fread(memory, sizeof(unsigned char), dataSize, f);
	if (count != dataSize) {
		error("Read failed or premature end of image file");
	}

	fclose(f);

	/* compute difference between old and new memory base addresses */
	bytesToShift = ((int) memory) - oldBaseAddr;

	if (endsChanged)
	  /* reverse the byte order of words in the image */
	  reverseBytesInImage(bytesToShift);

	initializeInterpreter(bytesToShift);  /* adjusts all oops to new location */

	if (endsChanged)
	  /* reverse the word order in Floats */
	  reverseWordsInFloats();

	return dataSize;
}

int writeImageFile(int imageBytes) {
	int		headerSize = 64;  /* header size in bytes */
	int		err, count;
	FILE	*f;

	successFlag = true;

	f = fopen(imageName, "w");
	if (f == NULL) {
		printf("Could not open image file for writing: %s\n", imageName);
		return success(false);
	}

	nextWordPut(f, CURRENT_VERSION);
	nextWordPut(f, headerSize);
	nextWordPut(f, imageBytes);
	nextWordPut(f, (int) memory);
	nextWordPut(f, specialObjectsOop);
	nextWordPut(f, lastHash);
	nextWordPut(f, ioScreenSize());
	if (!successFlag) {
		return success(false);
	}

	/* position file after the header */
	err = fseek(f, headerSize, SEEK_SET);
	if (err) {
		printf("Seek failed in writeImageFile\n");
		return success(false);
	}

	/* write out the image */
	count = fwrite(memory, sizeof(unsigned char), imageBytes, f);
	if (count != imageBytes) {
		printf("Writing image file failed; disk full, perhaps?\n");
		return success(false);
	}

	err = fclose(f);
	if (err) {
		printf("Closing image file failed; disk full, perhaps?\n");
		return success(false);
	}
	dir_SetMacFileTypeAndCreator(imageName, strlen(imageName), "STim", "FAST");
}


/* reverse the byte order for each word in the image that is accessed
   as a 4-byte quantity; based on code stolen from the interpreter: this
   will FAIL if the format of objects or heap "chunks" is changed.
*/
void reverseBytesInImage(int bytesToShift)
{
  int *chunk;
  int *oop;

  for (chunk= (int *)memory; chunk < (int *)endOfMemory;)
    {
      int oopHeader;
      int oopHeaderType;
      int oopSize;

      chunk[0]= swapBytes(chunk[0]);
      oop= chunk;
      switch(chunk[0] & 3)	/* chunk header */
	{
	case 0:	/* two extension words */
	  chunk[2]= swapBytes(chunk[2]);
	  oop++;
	case 1:	/* one extension word */
	  chunk[1]= swapBytes(chunk[1]);
	  oop++;
	}

      /* the oop's base header is now correct */
      oopHeader= oop[0];
      oopHeaderType= oopHeader & 3;

      if (oopHeaderType == 2)
	oopSize= oopHeader & 0x1FFFFFFC;
      else if (oopHeaderType == 0)
	oopSize= (sizeHeader(oop)) & 0xFFFFFFFC;
      else
	oopSize= oopHeader & 0xFC;

      if (!isFreeObject(oop))
	{
	  /* we're only interested if it's words or pointers */
	  if (isWords(oop))
	    {
	      int lastIndex;
	      int i;

	      lastIndex= oopSize/4 - 1;
	      for (i= lastIndex; i > 0; i--)
		oop[i]= swapBytes(oop[i]);
	    }
	  else	/* assume pointers; fieldSize is 0 if not... */
	    {
	      int fmt;
	      int fieldSize;
	      int *fieldBase;
	      int *fieldAddr;

	      fieldBase= oop;

	      /* find the last pointer field and adjust the base if it's a method */
	      fmt= formatOf(oop);
	      if (fmt < 4)
		fieldSize= sizeBitsOfSafe(oop) - 4;
	      else if (fmt < 12)
		fieldSize= 0;
	      else
		{
		  /* it's a method */
		  int methodHeader;
		  methodHeader= oop[1]= swapBytes(oop[1]);
		  fieldBase++;
		  fieldSize= (((methodHeader >> 10) & 255) * 4) + 4;
		}
	      for (fieldAddr= oop+(fieldSize/4);
		   fieldAddr > fieldBase;
		   fieldAddr--)
		*fieldAddr= swapBytes(*fieldAddr);
	    }
	}
      chunk= oop + (oopSize/4);
    }
}


/* swap the order of the two words in all instances of Float.
   (by the time we do this the byte order is correct and all oops
   have been adjusted to real local addresses.)
 */
void reverseWordsInFloats(void)
{
  int oop;
  int classFloatOop;

  if (!endsChanged)
    return;

  classFloatOop= splObj(9);

  /* scan the object memory looking for Floats */
  for (oop= firstObject(); oop < endOfMemory; oop= objectAfter(oop))
    if (fetchClassOf(oop) == classFloatOop)
      {
	int *poop= (int *)oop;
	int tmp= poop[1];
	poop[1]= poop[2];
	poop[2]= tmp;
      }
}
