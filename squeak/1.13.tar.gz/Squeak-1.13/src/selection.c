/* selection handling design sketch.
 *
 * last edited: Tue Nov  5 17:44:07 1996 by piumarta (Ian Piumarta) on prof
 */


#define MAX_SELECTION_SIZE	100*1024	/* bytes */
#define SELECTION_TIMEOUT	3		/* seconds */


#include <stdio.h>
#include <string.h>
#include <sys/time.h>
#include <sys/types.h>
#include <errno.h>

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xatom.h>

#define PRINT(X...) fprintf(stderr, X)

Display	*dpy;
Window	 win;

char *stPrimarySelection= "This isn't a real selection: it's a fake
selection just for the sake of having something to supply.
";

void sendSelection(XEvent *ev)
{
  XSelectionEvent notifyEv;
  XSelectionRequestEvent *requestEv;

  requestEv= &ev->xselectionrequest;

  /* this should REFUSE the selection if the target type isn't XA_STRING */

  XChangeProperty(requestEv->display,
		  requestEv->requestor,
		  requestEv->property,
		  requestEv->target,
		  8, PropModeReplace, stPrimarySelection,
		  (stPrimarySelection ? strlen(stPrimarySelection) : 0));

  notifyEv.type= SelectionNotify;
  notifyEv.display= requestEv->display;
  notifyEv.requestor= requestEv->requestor;
  notifyEv.selection= requestEv->selection;
  notifyEv.target= requestEv->target;
  notifyEv.time= requestEv->time;
  notifyEv.property= (requestEv->property == None)
    ? requestEv->target
    : requestEv->property;

  XSendEvent(requestEv->display, requestEv->requestor,
	     False, 0, (XEvent *)&notifyEv);

  XFlush(dpy);
}

char *getSelection(void)
{
  XEvent	 ev;
  fd_set	 fdMask;
  unsigned char	*data;
		
  /* request the selection */
  XConvertSelection(dpy, XA_PRIMARY, XA_STRING, XA_STRING, win, CurrentTime);

  /* wait for selection notification, ignoring (most) other events. */
  FD_ZERO(&fdMask);
  FD_SET(ConnectionNumber(dpy), &fdMask);

  do {
    if (XPending(dpy) == 0)
      {
	int status;
	struct timeval timeout= {SELECTION_TIMEOUT, 0};
	
	while ((status= select(FD_SETSIZE, &fdMask, 0, 0, &timeout)) < 0
	       && errno == EINTR);
	if (status < 0)
	  {
	    perror("select(dpy)");
	    return 0;
	  }
	if (status == 0)
	  {
	    fprintf(stderr, "selection retrieval timed out\n");
	    XBell(dpy, 0);
	    return 0;
	  }
      }
    XNextEvent(dpy, &ev);
    /* this is necessary so that we can supply our own selection when we
       are the requestor -- this could (should) be optimised to return the
       stored selection value instead! */ 
    if (ev.type == SelectionRequest) sendSelection(&ev);
    } while (ev.type != SelectionNotify);

  /* check if the selection was refused */
  if (ev.xselection.property == None)
    {
      XBell(dpy, 0);
      return 0;
    }
		
  /* get the value of the selection from the containing property */
  {
    Atom type;
    int format;
    unsigned long nitems, bytesAfter;
		
    XGetWindowProperty(dpy, ev.xselection.requestor, ev.xselection.property,
		       (long)0, (long)(MAX_SELECTION_SIZE/4),
		       False, AnyPropertyType,
		       &type, &format, &nitems, &bytesAfter,
		       (unsigned char **)&data);
    if (bytesAfter > 0)
      XBell(dpy, 0);
  }

  /* return the selection -- which must be XFreed() when no longer needed! */
  return data;
}

main()
{
  if (!(dpy= XOpenDisplay(0)))
    {
      fprintf(stderr, "Failed to open display %s\n", XDisplayName(0));
      exit(1);
    }

  win= XCreateSimpleWindow(dpy, DefaultRootWindow(dpy),
			   0, 0, 100, 100,
			   0,
			   WhitePixel(dpy, DefaultScreen(dpy)),
			   WhitePixel(dpy, DefaultScreen(dpy)));

  XSelectInput(dpy, win, ButtonPressMask);

  XMapWindow(dpy, win);

  while (1)
  {
    XEvent ev;
    XNextEvent(dpy, &ev);
    switch (ev.type)
      {
      case SelectionRequest:
	{
	  sendSelection(&ev);
	  break;
	}
      case ButtonPress:
	{
	  switch (ev.xbutton.button)
	    {
	    case Button1:
	      {
		/* button 1 => claim selection */
		PRINT("claiming selection\n");
		XSetSelectionOwner(dpy, XA_PRIMARY, win, CurrentTime);
		if (XGetSelectionOwner(dpy, XA_PRIMARY) != win)
		  PRINT("FAILED to own selection\n");
		break;
	      }
	    case Button2:
	      {
		/* button 2 => print selection */
		char *data;
		PRINT("converting selection\n");
		data= getSelection();
		printf("%s", data);
		fflush(stdout);
		if (data) XFree(data);
		break;
	      }
	    case Button3:
	      {
		/* button 3 => exit */
		PRINT("bye\n");
		exit(0);
		break;
	      }
	    }
	}
      }
  }
}

