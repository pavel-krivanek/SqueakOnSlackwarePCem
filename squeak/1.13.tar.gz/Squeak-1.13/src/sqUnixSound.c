/* This file is a heavily modified version of the file "sqMacSound.c".
 *
 * Modifications by: Ian Piumarta (ian.piumarta@inria.fr)
 *
 * The original version of this file can be regenerated from the Squeak
 * image by executing:
 *
 * 	InterpreterSupportCode writeMacSourceFiles
 *
 * $Log: sqUnixSound.c,v $
 * Revision 1.1  1996/10/24 13:21:38  piumarta
 * Initial revision
 *
 */

static char rcsid[]=
  "$Id: sqUnixSound.c,v 1.1 1996/10/24 13:21:38 piumarta Exp piumarta $";

#include "sq.h"

/* Ignored for now: return values that make the VM think that sound is being played. */

/*** exported functions ***/

int snd_AvailableSpace(void)
{
  return 8192;
}

int snd_PlaySamplesFromAtLength(int frameCount, int arrayIndex, int startIndex)
{
  return frameCount;
}

int snd_PlaySilence(void)
{
  return 8192;
}

int snd_Start(int frameCount, int samplesPerSec, int stereo)
{
  return 1;
}

int snd_Stop(void)
{
  return 0;
}
