/* the beginnings of support for direct access to the standard Sun4
 * cgsix framebuffer.
 *
 * $Log$
 */

static char rcsid[]=
  "$Id$";



#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/mman.h>

#include <sys/ioccom.h>
#include <sun/fbio.h>

#include <sundev/cg6reg.h>

extern char *valloc(unsigned);

#define DEVICE "/dev/cgsix0"
#define CG6_MMAP_OFFSET 0x70000000
#define CG6_IMAGE_OFFSET 0x16000

#define ERR(X) { perror(X); exit(1); }

main()
{
  int cgsix, size;
  int xsize, ysize, zsize;
  struct fbtype type;
  struct cg6_info info;
  unsigned char *fb;
  int pagemask;

  if ((cgsix= open(DEVICE, O_RDWR)) < 0) ERR("open(cgsix)");

  if (ioctl(cgsix, FBIOGTYPE, &type)) ERR("ioctl(cgsix,GTYPE)");
  if (type.fb_type != FBTYPE_SUN4COLOR)
    {
      fprintf(stderr, "frame buffer type (%d) not recognised.\n",
	      type.fb_type);
      exit(1);
    }
  xsize= type.fb_width;		/* use the true pixel width */
  ysize= type.fb_height;	/* use the true pixel height */
  zsize= type.fb_depth;

  size= xsize*ysize+CG6_IMAGE_OFFSET;
  pagemask= getpagesize()-1;
  size= (size + pagemask) & ~pagemask;

  if ((int)(fb= mmap(0, size, PROT_READ | PROT_WRITE, MAP_SHARED,
		     cgsix, CG6_MMAP_OFFSET)) == -1)
    ERR("mmap("DEVICE")");

  fb+= CG6_IMAGE_OFFSET;

  printf(DEVICE": %dx%dx%d mapped at 0x%lx+%d\n",
	 xsize, ysize, zsize, fb, type.fb_size);

  /* write a bunch of stuff into the framebuffer */
  {
    int x, y;
    for (y= 0; y < ysize; y++)
      for (x= 0; x < xsize; x++)
	fb[x+y*xsize]= (x+y) & 0xFF;
  }
}
