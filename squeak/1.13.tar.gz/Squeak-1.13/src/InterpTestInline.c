/* Automatically generated from Squeak on (21 October 1996 4:45:09 pm )*/

#include "sq.h"

#define true 1
#define false 0
#define null 0

/* memory access macros */
#define byteAt(i) (*((unsigned char *) (i)))
#define byteAtput(i, val) (*((unsigned char *) (i)) = val)
/* #define floatAt(i) (*((double *) (i))) */
/* #define floatAtput(i, val) (*((double *) (i)) = val) */

typedef union {
  double value;
  struct {
    int first, second;
  } words;
} floatWords;

double floatAt(int i)
{
  floatWords conv;
  conv.words.first= *((int *)i);
  conv.words.second= *(((int *)i)+1);
  return conv.value;
}

double floatAtput(int i, double val)
{
  *((int *)i)= ((floatWords *)&val)->words.first;
  *(((int *)i)+1)= ((floatWords *)&val)->words.second;
  return val;
}

#define longAt(i) (*((int *) (i)))
#define longAtput(i, val) (*((int *) (i)) = val)

int printCallStack(void);
void error(char *s);
void error(char *s) {
	/* Print an error message and exit. */
	static int printingStack = false;

	printf("\n%s\n\n", s);
	if (!printingStack) {
		/* flag prevents recursive error when trying to print a broken stack */
		printingStack = true;
		printCallStack();
	}
	exit(-1);
}

/*** Variables ***/
int activeContext;
int affectedB;
int affectedL;
int affectedR;
int affectedT;
int allocationCount;
int argumentCount;
int bbH;
int bbW;
int bitBltOop;
int bitCount;
int checkAssertions;
int child;
int clipHeight;
int clipWidth;
int clipX;
int clipY;
int cmBitsPerColor;
int colorMap;
int combinationRule;
int compEnd;
int compStart;
int destBits;
int destDelta;
int destForm;
int destIndex;
int destPixSize;
int destRaster;
int destX;
int destY;
int dx;
int dy;
int endOfMemory;
int falseObj;
int field;
int freeBlock;
int freeLargeContexts;
int freeSmallContexts;
int fwdTableLast;
int fwdTableNext;
int halftoneBase;
int halftoneForm;
int halftoneHeight;
int hDir;
int height;
int instructionPointer;
int interpreterProxy;
int interruptCheckCounter;
int interruptKeycode;
int interruptPending;
int lastHash;
int lowSpaceThreshold;
int mask1;
int mask2;
int mcProbe;
unsigned char *memory;
int memoryLimit;
int messageSelector;
int method;
int methodCache[1537];
int newMethod;
int nextPollTick;
int nextWakeupTick;
int nilObj;
int noHalftone;
int noSource;
int nWords;
int parentField;
int pixPerWord;
int preload;
int primitiveIndex;
int receiver;
int reclaimableContextCount;
int remapBuffer[26];
int remapBufferCount;
int rootTable[1001];
int rootTableCount;
int scanDisplayFlag;
int scanRightX;
int scanStart;
int scanStop;
int scanStopArray;
int scanString;
int scanXTable;
int signalLowSpace;
int skew;
int sourceBits;
int sourceDelta;
int sourceForm;
int sourceIndex;
int sourcePixSize;
int sourceRaster;
int sourceX;
int sourceY;
int specialObjectsOop;
int srcBitIndex;
int srcHeight;
int srcWidth;
int stackPointer;
int stopCode;
int successFlag;
int sx;
int sy;
int theHomeContext;
int trueObj;
int vDir;
int width;
int youngStart;

/*** Function Prototypes ***/
int accessibleObjectAfter(int oop);
int aComment(void);
int activateNewMethod(void);
int addLastLinktoList(int proc, int aList);
int adjustAllOopsBy(int bytesToShift);
int adjustFieldsAndClassOfby(int oop, int offsetBytes);
int affectedBottom(void);
int affectedLeft(void);
int affectedRight(void);
int affectedTop(void);
int allAccessibleObjectsOkay(void);
int allocateheaderSizeh1h2h3fill(int byteSize, int hdrSize, int baseHeader, int classOop, int extendedSize, int fillWord);
int allocateChunk(int byteSize);
int allocateOrRecycleContext(int smallContextWanted);
int allYoungand(int array1, int array2);
int alphaBlendwith(int sourceWord, int destinationWord);
int areFloatsand(int oop1, int oop2);
int areIntegersand(int oop1, int oop2);
int argCount(void);
int argumentCountOf(int methodPointer);
int argumentCountOfBlock(int blockPointer);
void * arrayValueOf(int arrayOop);
int asciiDirectoryDelimiter(void);
int asciiOfCharacter(int characterObj);
int baseHeader(int oop);
int becomewith(int array1, int array2);
int beRootIfOld(int oop);
int beRootWhileForwarding(int oop);
int booleanValueOf(int obj);
int byteLengthOf(int oop);
int caller(void);
int cCode(int codeString);
int characterForAscii(int integerObj);
int checkAddress(int byteAddress);
int checkBooleanResultfrom(int result, int primIndex);
int checkedByteAt(int byteAddress);
int checkedByteAtput(int byteAddress, int byte);
int checkedIntegerValueOf(int intOop);
int checkedLongAt(int byteAddress);
int checkedLongAtput(int byteAddress, int a32BitInteger);
int checkForInterrupts(void);
int checkInstanceVariableBoundsOfin(int index, int object);
int checkIntegerResultfrom(int integerResult, int primIndex);
int checkSourceOverlap(void);
int chunkFromOop(int oop);
int classHeader(int oop);
int clearRootsTable(void);
int clipRange(void);
int commonAt(int stringy);
int commonAtPut(int stringy);
int compare31or32Bitsequal(int obj1, int obj2);
int containOnlyOopsand(int array1, int array2);
int copyBits(void);
int copyLoop(void);
int copyLoopNoSource(void);
int copyLoopPixMap(void);
int cr(void);
int createActualMessage(void);
int deltaFromtonSteps(int x1, int x2, int n);
int destMaskAndPointerInit(void);
int drawLoopXY(int xDelta, int yDelta);
int exchangeHashBitswith(int oop1, int oop2);
int executeNewMethod(void);
int externalSendSelectorargumentCount(int selector, int count);
int extraHeaderBytes(int oopOrChunk);
int failed(void);
int failSpecialPrim(int primIndex);
void * fetchArrayofObject(int fieldIndex, int objectPointer);
int fetchByteofObject(int byteIndex, int objectPointer);
int fetchClassOf(int oop);
int fetchContextRegisters(void);
double fetchFloatofObject(int fieldIndex, int objectPointer);
int fetchIntegerofObject(int fieldIndex, int objectPointer);
int fetchPointerofObject(int fieldIndex, int objectPointer);
int fetchWordofObject(int wordIndex, int objectPointer);
int fetchWordLengthOf(int objectPointer);
int fileRecordSize(void);
SQFile * fileValueOf(int objectPointer);
int findClassOfMethodforReceiver(int meth, int rcvr);
int findNewMethodInClass(int class);
int findSelectorOfMethodforReceiver(int meth, int rcvr);
int firstAccessibleObject(void);
int firstObject(void);
int fixedFieldsOf(int instPointer);
int floatObjectOf(int f);
double floatValueOf(int floatOop);
int formatOf(int oop);
int formatOfClass(int classPointer);
int fullCompaction(void);
int fullDisplayUpdate(void);
int fullGC(void);
int fwdBlockGet(void);
int fwdBlockValidate(int addr);
int fwdTableInit(void);
int getCurrentBytecode(void);
int hashBitsOf(int oop);
int headerOf(int methodPointer);
int headerType(int oop);
int ignoreSourceOrHalftone(int formPointer);
int incCompBody(void);
int incCompMakeFwd(void);
int incCompMove(int bytesFreed);
int incrementalCompaction(void);
int incrementalGC(void);
int initForwardBlockmappingto(int fwdBlock, int oop, int newOop);
int initialInstanceOf(int classPointer);
int initializeInterpreter(int bytesToShift);
int initializeMemoryFirstFree(int firstFree);
int initializeObjectMemory(int bytesToShift);
int instanceAfter(int objectPointer);
int instantiateClassindexableSize(int classPointer, int size);
int instantiateSmallClasssizeInBytesfill(int classPointer, int sizeInBytes, int fillValue);
int integerObjectOf(int value);
int integerValueOf(int objectPointer);
int interpret(void);
int isBytes(int oop);
int isEmptyList(int aLinkedList);
int isFreeObject(int oop);
int isIntegerObject(int objectPointer);
int isIntegerValue(int valueWord);
int isObjectForwarded(int oop);
int isPointers(int oop);
int isWords(int oop);
int isWordsOrBytes(int oop);
int lastPointerOf(int objectPointer);
int lastPointerWhileForwarding(int oop);
int lengthOf(int oop);
int literal(int offset);
int literalofMethod(int offset, int methodPointer);
int literalCountOf(int methodPointer);
int literalCountOfHeader(int headerPointer);
int loadBitBltFrom(int bbObj);
int loadInitialContext(void);
int loadScannerFromstartstopstringrightXstopArraydisplayFlag(int bbObj, int start, int stop, int string, int rightX, int stopArray, int displayFlag);
int lookupMethodInClass(int class);
int lookupMethodInDictionary(int dictionary);
int lowestFreeAfter(int chunk);
int makeDirEntryNamesizecreateDatemodDateisDirfileSize(char *entryName, int entryNameSize, int createDate, int modifiedDate, int dirFlag, int fileSize);
int makePointwithxValueyValue(int xValue, int yValue);
int mapInterpreterOops(void);
int mapPointersInObjectsFromto(int memStart, int memEnd);
int markAndTrace(int oop);
int markAndTraceInterpreterOops(void);
int markPhase(void);
int mergewith(int sourceWord, int destinationWord);
int methodClassOf(int methodPointer);
int newActiveContext(int aContext);
int newObjectHash(void);
int nilContextFields(void);
int nilObject(void);
int objectAfter(int oop);
int objectAfterWhileForwarding(int oop);
int okayActiveProcessStack(void);
int okayFields(int oop);
int okayInterpreterObjects(void);
int okayOop(int oop);
int okStreamArrayClass(int cl);
int oopFromChunk(int chunk);
int oopHasOkayClass(int oop);
int partitionedAddtonBitsnPartitions(int word1, int word2, int nBits, int nParts);
int partitionedANDtonBitsnPartitions(int word1, int word2, int nBits, int nParts);
int partitionedSubfromnBitsnPartitions(int word1, int word2, int nBits, int nParts);
int pickSourcePixelsnullMapsrcMaskdestMask(int nPix, int nullMap, int sourcePixMask, int destPixMask);
int pickSourcePixelssrcMaskdestMask(int nPix, int sourcePixMask, int destPixMask);
int pickSourcePixelsNullMapsrcMaskdestMask(int nPix, int sourcePixMask, int destPixMask);
int pickSourcePixelsRGBnullMapsrcMaskdestMask(int nPix, int nullMap, int sourcePixMask, int destPixMask);
int pixMaskwith(int sourceWord, int destinationWord);
int pixPaintwith(int sourceWord, int destinationWord);
int pop(int nItems);
double popFloat(void);
int popInteger(void);
int popPos32BitInteger(void);
int popRemappableOop(void);
int popStack(void);
int positive32BitIntegerFor(int integerValue);
int positive32BitValueOf(int integerPointer);
int possibleRootStoreIntovalue(int oop, int valueObj);
int postGCAction(void);
int prepareForwardingTableForBecomingwith(int array1, int array2);
int primIndex(void);
int primitiveAdd(void);
int primitiveArrayBecome(void);
int primitiveAsFloat(void);
int primitiveAsOop(void);
int primitiveAt(void);
int primitiveAtEnd(void);
int primitiveAtPut(void);
int primitiveBeCursor(void);
int primitiveBeDisplay(void);
int primitiveBeep(void);
int primitiveBitAnd(void);
int primitiveBitOr(void);
int primitiveBitShift(void);
int primitiveBitXor(void);
int primitiveBlockCopy(void);
int primitiveBytesLeft(void);
int primitiveClass(void);
int primitiveClipboardText(void);
int primitiveConstantFill(void);
int primitiveCopyBits(void);
int primitiveDirectoryCreate(void);
int primitiveDirectoryDelimitor(void);
int primitiveDirectoryLookup(void);
int primitiveDirectorySetMacTypeAndCreator(void);
int primitiveDiv(void);
int primitiveDivide(void);
int primitiveDrawLoop(void);
int primitiveEqual(void);
int primitiveEquivalent(void);
int primitiveExitToDebugger(void);
int primitiveExponent(void);
int primitiveFail(void);
int primitiveFileAtEnd(void);
int primitiveFileClose(void);
int primitiveFileDelete(void);
int primitiveFileGetPosition(void);
int primitiveFileOpen(void);
int primitiveFileRead(void);
int primitiveFileRename(void);
int primitiveFileSetPosition(void);
int primitiveFileSize(void);
int primitiveFileWrite(void);
int primitiveFloatAdd(void);
int primitiveFloatDivide(void);
int primitiveFloatEqual(void);
int primitiveFloatGreaterOrEqual(void);
int primitiveFloatGreaterThan(void);
int primitiveFloatLessOrEqual(void);
int primitiveFloatLessThan(void);
int primitiveFloatMultiply(void);
int primitiveFloatNotEqual(void);
int primitiveFloatSubtract(void);
int primitiveFlushCache(void);
int primitiveFractionalPart(void);
int primitiveFullGC(void);
int primitiveGreaterOrEqual(void);
int primitiveGreaterThan(void);
int primitiveImageName(void);
int primitiveIncrementalGC(void);
int primitiveIndexOf(int methodPointer);
int primitiveInputSemaphore(void);
int primitiveInputWord(void);
int primitiveInstVarAt(void);
int primitiveInstVarAtPut(void);
int primitiveInterruptSemaphore(void);
int primitiveKbdNext(void);
int primitiveKbdPeek(void);
int primitiveLessOrEqual(void);
int primitiveLessThan(void);
int primitiveLowSpaceSemaphore(void);
int primitiveMakePoint(void);
int primitiveMillisecondClock(void);
int primitiveMod(void);
int primitiveMouseButtons(void);
int primitiveMousePoint(void);
int primitiveMultiply(void);
int primitiveNew(void);
int primitiveNewMethod(void);
int primitiveNewWithArg(void);
int primitiveNext(void);
int primitiveNextInstance(void);
int primitiveNextObject(void);
int primitiveNextPut(void);
int primitiveNoop(void);
int primitiveNotEqual(void);
int primitiveObjectAt(void);
int primitiveObjectAtPut(void);
int primitiveObjectPointsTo(void);
int primitivePerform(void);
int primitivePerformWithArgs(void);
int primitivePointX(void);
int primitivePointY(void);
int primitiveQuit(void);
int primitiveQuo(void);
int primitiveReadJoystick(void);
int primitiveResponse(void);
int primitiveResume(void);
int primitiveScanCharacters(void);
int primitiveScreenSize(void);
int primitiveSecondsClock(void);
int primitiveSetInterruptKey(void);
int primitiveShortAt(void);
int primitiveShortAtPut(void);
int primitiveSignal(void);
int primitiveSignalAtBytesLeft(void);
int primitiveSignalAtMilliseconds(void);
int primitiveSize(void);
int primitiveSnapshot(void);
int primitiveSomeInstance(void);
int primitiveSomeObject(void);
int primitiveSoundAvailableSpace(void);
int primitiveSoundPlaySamples(void);
int primitiveSoundPlaySilence(void);
int primitiveSoundStart(void);
int primitiveSoundStop(void);
int primitiveSpecialObjectsOop(void);
int primitiveStringAt(void);
int primitiveStringAtPut(void);
int primitiveStringReplace(void);
int primitiveSubtract(void);
int primitiveSuspend(void);
int primitiveTimesTwoPower(void);
int primitiveTruncated(void);
int primitiveValue(void);
int primitiveValueWithArgs(void);
int primitiveVMPath(void);
int primitiveWait(void);
int primitiveWarpBits(void);
int print(char *s);
int printCallStack(void);
int printChar(int aByte);
int printNameOfClasscount(int classOop, int cnt);
int printNum(int n);
int printStringOf(int oop);
int push(int object);
int pushBool(int trueOrFalse);
int pushFloat(int f);
int pushInteger(int integerValue);
int pushRemappableOop(int oop);
int putToSleep(int aProcess);
int quickCheckForInterrupts(void);
int quickFetchIntegerofObject(int fieldIndex, int objectPointer);
int recycleContextIfPossible(int contextOop);
int remap(int oop);
int remapClassOf(int oop);
int remapFieldsAndClassOf(int oop);
int removeFirstLinkOfList(int aList);
int reportContexts(void);
int restoreHeaderOf(int oop);
int restoreHeadersAfterBecomingwith(int list1, int list2);
int resume(int aProcess);
int returnAtlastIndexlefttop(int stopIndex, int lastIndex, int left, int top);
int returnToActiveContext(int returnContext);
int returnValueto(int resultObj, int contextPointer);
int rgbAddwith(int sourceWord, int destinationWord);
int rgbDiffwith(int sourceWord, int destinationWord);
int rgbMapfromto(int sourcePixel, int nBitsIn, int nBitsOut);
int rgbSubwith(int sourceWord, int destinationWord);
int rightType(int headerWord);
int scanCharacters(void);
int schedulerPointer(void);
int sender(void);
int sendSelectorToClass(int classPointer);
int setInterpreter(int anInterpreter);
int setSizeOfFreeto(int chunk, int byteSize);
int showDisplayBits(void);
int signExtend16(int int16);
int sizeBitsOf(int oop);
int sizeBitsOfSafe(int oop);
int sizeHeader(int oop);
int sizeOfFree(int oop);
int smoothPixatXfyfdxhdyhdxvdyvpixPerWordpixelMasksourceMap(int n, int xf, int yf, int dxh, int dyh, int dxv, int dyv, int srcPixPerWord, int sourcePixMask, int sourceMap);
int sourcePixAtXypixPerWord(int x, int y, int srcPixPerWord);
int sourceSkewAndPointerInit(void);
int splObj(int index);
int stackIntegerValue(int offset);
int stackPointerIndex(void);
int stackTop(void);
int stackValue(int offset);
int startField(void);
int startObj(void);
int startOfMemory(void);
int stObjectat(int array, int index);
int stObjectatput(int array, int index, int value);
int stopReason(void);
int storeByteofObjectwithValue(int byteIndex, int objectPointer, int valueByte);
int storeContextRegisters(void);
int storeInstructionPointerValueinContext(int value, int contextPointer);
int storeIntegerofObjectwithValue(int fieldIndex, int objectPointer, int integerValue);
int storePointerofObjectwithValue(int fieldIndex, int objectPointer, int valuePointer);
int storePointerUncheckedofObjectwithValue(int wordIndex, int objectPointer, int valuePointer);
int storeStackPointerValueinContext(int value, int contextPointer);
int storeWordofObjectwithValue(int wordIndex, int objectPointer, int valueWord);
int stSizeOf(int oop);
int subscriptwith(int array, int index);
int subscriptwithstoring(int array, int index, int value);
int success(int successValue);
int sufficientSpaceAfterGC(int minFree);
int sufficientSpaceToAllocate(int bytes);
int sufficientSpaceToInstantiateindexableSize(int classOop, int size);
int superclassOf(int classPointer);
int sweepPhase(void);
int synchronousSignal(int aSemaphore);
int tallyIntoMap(int destinationWord);
int targetForm(void);
int temporary(int offset);
int transferfromIndexofObjecttoIndexofObject(int count, int firstFrom, int fromOop, int firstTo, int toOop);
int transferTo(int newProc);
int unknownBytecode(void);
int unPop(int nItems);
int upward(void);
int wakeHighestPriority(void);
int warpBits(void);
int warpLoop(void);
int warpSourcePixelsxDeltahyDeltahxDeltavyDeltavsmoothingsourceMap(int nPix, int xDeltah, int yDeltah, int xDeltav, int yDeltav, int n, int sourceMapOop);

int accessibleObjectAfter(int oop) {
    int obj;
    int sz;
    int header;
    int sz1;
    int header1;

	/* begin objectAfter: */
	if (checkAssertions) {
		if (oop >= endOfMemory) {
			error("no objects after the end of memory");
		}
	}
	if (((longAt(oop)) & 3) == 2) {
		sz1 = (longAt(oop)) & 536870908;
	} else {
		/* begin sizeBitsOf: */
		header1 = longAt(oop);
		if ((header1 & 3) == 0) {
			sz1 = (longAt(oop - 8)) & 4294967292;
			goto l2;
		} else {
			sz1 = header1 & 252;
			goto l2;
		}
	l2:	/* end sizeBitsOf: */;
	}
	obj = (oop + sz1) + (extraHeaderBytes(oop + sz1));
	while (obj < endOfMemory) {
		if (!(((longAt(obj)) & 3) == 2)) {
			return obj;
		}
		/* begin objectAfter: */
		if (checkAssertions) {
			if (obj >= endOfMemory) {
				error("no objects after the end of memory");
			}
		}
		if (((longAt(obj)) & 3) == 2) {
			sz = (longAt(obj)) & 536870908;
		} else {
			/* begin sizeBitsOf: */
			header = longAt(obj);
			if ((header & 3) == 0) {
				sz = (longAt(obj - 8)) & 4294967292;
				goto l1;
			} else {
				sz = header & 252;
				goto l1;
			}
		l1:	/* end sizeBitsOf: */;
		}
		obj = (obj + sz) + (extraHeaderBytes(obj + sz));
	}
	return null;
}

int aComment(void) {
}

int activateNewMethod(void) {
    int methodHeader;
    int smallContext;
    int newContext;
    int initialIP;
    int tempCount;
    int i;
    int contextEnd;
    int fromIndex;
    int toIndex;
    int lastFrom;
    int cntxt;
    int m;

	methodHeader = longAt((newMethod + 4) + (0 * 4));
	smallContext = ((((unsigned) methodHeader) >> 18) & 1) == 0;
	/* begin allocateOrRecycleContext: */
	if (smallContext) {
		if (freeSmallContexts != 1) {
			cntxt = freeSmallContexts;
			freeSmallContexts = longAt((cntxt + 4) + (0 * 4));
		} else {
			cntxt = instantiateSmallClasssizeInBytesfill(longAt((specialObjectsOop + 4) + (10 * 4)), 76, nilObj);
		}
	} else {
		if (freeLargeContexts != 1) {
			cntxt = freeLargeContexts;
			freeLargeContexts = longAt((cntxt + 4) + (0 * 4));
		} else {
			cntxt = instantiateSmallClasssizeInBytesfill(longAt((specialObjectsOop + 4) + (10 * 4)), 156, nilObj);
		}
	}
	newContext = cntxt;
	initialIP = ((1 + ((((unsigned) methodHeader) >> 10) & 255)) * 4) + 1;
	tempCount = (((unsigned) methodHeader) >> 19) & 63;
	longAtput((newContext + 4) + (0 * 4), activeContext);
	longAtput((newContext + 4) + (1 * 4), ((initialIP << 1) | 1));
	longAtput((newContext + 4) + (2 * 4), ((tempCount << 1) | 1));
	longAtput((newContext + 4) + (3 * 4), newMethod);
	/* begin transfer:fromIndex:ofObject:toIndex:ofObject: */
	fromIndex = (activeContext + 4) + (((((stackPointer - activeContext) - 4) / 4) - argumentCount) * 4);
	toIndex = (newContext + 4) + (5 * 4);
	lastFrom = fromIndex + ((argumentCount + 1) * 4);
	while (fromIndex < lastFrom) {
		longAtput(toIndex, longAt(fromIndex));
		fromIndex = fromIndex + 4;
		toIndex = toIndex + 4;
	}
	i = newContext + (((5 + argumentCount) + 2) * 4);
	if (smallContext) {
		contextEnd = newContext + 76;
	} else {
		contextEnd = newContext + 156;
	}
	while (i < contextEnd) {
		longAtput(i, nilObj);
		i = i + 4;
	}
	/* begin pop: */
	stackPointer = stackPointer - ((argumentCount + 1) * 4);
	reclaimableContextCount = reclaimableContextCount + 1;
	/* begin newActiveContext: */
	/* begin storeContextRegisters */
	longAtput((activeContext + 4) + (1 * 4), ((((instructionPointer - method) - (4 - 2)) << 1) | 1));
	longAtput((activeContext + 4) + (2 * 4), (((((((stackPointer - activeContext) - 4) / 4) - 6) + 1) << 1) | 1));
	activeContext = newContext;
	if (activeContext < youngStart) {
		beRootIfOld(activeContext);
	}
	/* begin fetchContextRegisters */
	m = longAt((activeContext + 4) + (3 * 4));
	if (((m & 1) == 1)) {
		theHomeContext = longAt((activeContext + 4) + (5 * 4));
		if (theHomeContext < youngStart) {
			beRootIfOld(theHomeContext);
		}
	} else {
		theHomeContext = activeContext;
	}
	receiver = longAt((theHomeContext + 4) + (5 * 4));
	method = longAt((theHomeContext + 4) + (3 * 4));
	instructionPointer = ((longAt((activeContext + 4) + (1 * 4))) >> 1);
	instructionPointer = ((method + instructionPointer) + 4) - 2;
	stackPointer = ((longAt((activeContext + 4) + (2 * 4))) >> 1);
	stackPointer = (activeContext + 4) + (((6 + stackPointer) - 1) * 4);
}

int addLastLinktoList(int proc, int aList) {
    int lastLink;

	if ((longAt((aList + 4) + (0 * 4))) == nilObj) {
		/* begin storePointer:ofObject:withValue: */
		if (aList < youngStart) {
			possibleRootStoreIntovalue(aList, proc);
		}
		longAtput((aList + 4) + (0 * 4), proc);
	} else {
		lastLink = longAt((aList + 4) + (1 * 4));
		/* begin storePointer:ofObject:withValue: */
		if (lastLink < youngStart) {
			possibleRootStoreIntovalue(lastLink, proc);
		}
		longAtput((lastLink + 4) + (0 * 4), proc);
	}
	/* begin storePointer:ofObject:withValue: */
	if (aList < youngStart) {
		possibleRootStoreIntovalue(aList, proc);
	}
	longAtput((aList + 4) + (1 * 4), proc);
	/* begin storePointer:ofObject:withValue: */
	if (proc < youngStart) {
		possibleRootStoreIntovalue(proc, aList);
	}
	longAtput((proc + 4) + (3 * 4), aList);
}

int adjustAllOopsBy(int bytesToShift) {
    int oop;
    int last;
    int fieldAddr;
    int fieldOop;
    int classHeader;
    int newClassOop;
    int chunk;
    int sz;
    int header;

	if (bytesToShift == 0) {
		return null;
	}
	/* begin oopFromChunk: */
	chunk = startOfMemory();
	oop = chunk + (extraHeaderBytes(chunk));
	while (oop < endOfMemory) {
		if (!(((longAt(oop)) & 3) == 2)) {
			/* begin adjustFieldsAndClassOf:by: */
			fieldAddr = oop + (lastPointerOf(oop));
			while (fieldAddr > oop) {
				fieldOop = longAt(fieldAddr);
				if (!(((fieldOop & 1) == 1))) {
					longAtput(fieldAddr, fieldOop + bytesToShift);
				}
				fieldAddr = fieldAddr - 4;
			}
			if (((longAt(oop)) & 3) != 3) {
				classHeader = longAt(oop - 4);
				newClassOop = (classHeader & 4294967292) + bytesToShift;
				longAtput(oop - 4, newClassOop | (classHeader & 3));
			}
		}
		last = oop;
		/* begin objectAfter: */
		if (checkAssertions) {
			if (oop >= endOfMemory) {
				error("no objects after the end of memory");
			}
		}
		if (((longAt(oop)) & 3) == 2) {
			sz = (longAt(oop)) & 536870908;
		} else {
			/* begin sizeBitsOf: */
			header = longAt(oop);
			if ((header & 3) == 0) {
				sz = (longAt(oop - 8)) & 4294967292;
				goto l1;
			} else {
				sz = header & 252;
				goto l1;
			}
		l1:	/* end sizeBitsOf: */;
		}
		oop = (oop + sz) + (extraHeaderBytes(oop + sz));
	}
}

int adjustFieldsAndClassOfby(int oop, int offsetBytes) {
    int fieldAddr;
    int fieldOop;
    int classHeader;
    int newClassOop;

	fieldAddr = oop + (lastPointerOf(oop));
	while (fieldAddr > oop) {
		fieldOop = longAt(fieldAddr);
		if (!(((fieldOop & 1) == 1))) {
			longAtput(fieldAddr, fieldOop + offsetBytes);
		}
		fieldAddr = fieldAddr - 4;
	}
	if (((longAt(oop)) & 3) != 3) {
		classHeader = longAt(oop - 4);
		newClassOop = (classHeader & 4294967292) + offsetBytes;
		longAtput(oop - 4, newClassOop | (classHeader & 3));
	}
}

int affectedBottom(void) {
	return affectedB;
}

int affectedLeft(void) {
	return affectedL;
}

int affectedRight(void) {
	return affectedR;
}

int affectedTop(void) {
	return affectedT;
}

int allAccessibleObjectsOkay(void) {
    int oop;
    int obj;
    int chunk;
    int sz;
    int header;

	/* begin firstAccessibleObject */
	/* begin oopFromChunk: */
	chunk = startOfMemory();
	obj = chunk + (extraHeaderBytes(chunk));
	while (obj < endOfMemory) {
		if (!(((longAt(obj)) & 3) == 2)) {
			oop = obj;
			goto l2;
		}
		/* begin objectAfter: */
		if (checkAssertions) {
			if (obj >= endOfMemory) {
				error("no objects after the end of memory");
			}
		}
		if (((longAt(obj)) & 3) == 2) {
			sz = (longAt(obj)) & 536870908;
		} else {
			/* begin sizeBitsOf: */
			header = longAt(obj);
			if ((header & 3) == 0) {
				sz = (longAt(obj - 8)) & 4294967292;
				goto l1;
			} else {
				sz = header & 252;
				goto l1;
			}
		l1:	/* end sizeBitsOf: */;
		}
		obj = (obj + sz) + (extraHeaderBytes(obj + sz));
	}
	error("heap is empty");
l2:	/* end firstAccessibleObject */;
	while (!(oop == null)) {
		okayFields(oop);
		oop = accessibleObjectAfter(oop);
	}
}

int allocateheaderSizeh1h2h3fill(int byteSize, int hdrSize, int baseHeader, int classOop, int extendedSize, int fillWord) {
    int newObj;
    int remappedClassOop;
    int end;
    int i;
    int oop;
    int enoughSpace;
    int newFreeSize;
    int newChunk;
    int minFree;

	if (hdrSize > 1) {
		/* begin pushRemappableOop: */
		remapBuffer[remapBufferCount = remapBufferCount + 1] = classOop;
	}
	/* begin allocateChunk: */
	if (allocationCount >= 4000) {
		incrementalGC();
	}
	/* begin sufficientSpaceToAllocate: */
	minFree = (lowSpaceThreshold + (byteSize + ((hdrSize - 1) * 4))) + 4;
	if (((longAt(freeBlock)) & 536870908) >= minFree) {
		enoughSpace = true;
		goto l1;
	} else {
		enoughSpace = sufficientSpaceAfterGC(minFree);
		goto l1;
	}
l1:	/* end sufficientSpaceToAllocate: */;
	if (!(enoughSpace)) {
		signalLowSpace = true;
		interruptCheckCounter = 0;
	}
	if (((longAt(freeBlock)) & 536870908) < ((byteSize + ((hdrSize - 1) * 4)) + 4)) {
		error("out of memory");
	}
	newFreeSize = ((longAt(freeBlock)) & 536870908) - (byteSize + ((hdrSize - 1) * 4));
	newChunk = freeBlock;
	freeBlock = freeBlock + (byteSize + ((hdrSize - 1) * 4));
	/* begin setSizeOfFree:to: */
	longAtput(freeBlock, (newFreeSize & 536870908) | 2);
	allocationCount = allocationCount + 1;
	newObj = newChunk;
	if (hdrSize > 1) {
		/* begin popRemappableOop */
		oop = remapBuffer[remapBufferCount];
		remapBufferCount = remapBufferCount - 1;
		remappedClassOop = oop;
	}
	if (hdrSize == 3) {
		longAtput(newObj, extendedSize | 0);
		longAtput(newObj + 4, remappedClassOop | 0);
		longAtput(newObj + 8, baseHeader | 0);
		newObj = newObj + 8;
	}
	if (hdrSize == 2) {
		longAtput(newObj, remappedClassOop | 1);
		longAtput(newObj + 4, baseHeader | 1);
		newObj = newObj + 4;
	}
	if (hdrSize == 1) {
		longAtput(newObj, baseHeader | 3);
	}
	end = newObj + byteSize;
	i = newObj + 4;
	while (i < end) {
		longAtput(i, fillWord);
		i = i + 4;
	}
	if (checkAssertions) {
		okayOop(newObj);
		oopHasOkayClass(newObj);
		if (!((objectAfter(newObj)) == freeBlock)) {
			error("allocate bug: did not set header of new oop correctly");
		}
		if (!((objectAfter(freeBlock)) == endOfMemory)) {
			error("allocate bug: did not set header of freeBlock correctly");
		}
	}
	return newObj;
}

int allocateChunk(int byteSize) {
    int enoughSpace;
    int newFreeSize;
    int newChunk;
    int minFree;

	if (allocationCount >= 4000) {
		incrementalGC();
	}
	/* begin sufficientSpaceToAllocate: */
	minFree = (lowSpaceThreshold + byteSize) + 4;
	if (((longAt(freeBlock)) & 536870908) >= minFree) {
		enoughSpace = true;
		goto l1;
	} else {
		enoughSpace = sufficientSpaceAfterGC(minFree);
		goto l1;
	}
l1:	/* end sufficientSpaceToAllocate: */;
	if (!(enoughSpace)) {
		signalLowSpace = true;
		interruptCheckCounter = 0;
	}
	if (((longAt(freeBlock)) & 536870908) < (byteSize + 4)) {
		error("out of memory");
	}
	newFreeSize = ((longAt(freeBlock)) & 536870908) - byteSize;
	newChunk = freeBlock;
	freeBlock = freeBlock + byteSize;
	/* begin setSizeOfFree:to: */
	longAtput(freeBlock, (newFreeSize & 536870908) | 2);
	allocationCount = allocationCount + 1;
	return newChunk;
}

int allocateOrRecycleContext(int smallContextWanted) {
    int cntxt;

	if (smallContextWanted) {
		if (freeSmallContexts != 1) {
			cntxt = freeSmallContexts;
			freeSmallContexts = longAt((cntxt + 4) + (0 * 4));
		} else {
			cntxt = instantiateSmallClasssizeInBytesfill(longAt((specialObjectsOop + 4) + (10 * 4)), 76, nilObj);
		}
	} else {
		if (freeLargeContexts != 1) {
			cntxt = freeLargeContexts;
			freeLargeContexts = longAt((cntxt + 4) + (0 * 4));
		} else {
			cntxt = instantiateSmallClasssizeInBytesfill(longAt((specialObjectsOop + 4) + (10 * 4)), 156, nilObj);
		}
	}
	return cntxt;
}

int allYoungand(int array1, int array2) {
    int fieldOffset;
    int fmt;
    int sz;
    int methodHeader;
    int header;
    int type;

	if (array1 < youngStart) {
		return false;
	}
	if (array2 < youngStart) {
		return false;
	}
	/* begin lastPointerOf: */
	fmt = (((unsigned) (longAt(array1))) >> 8) & 15;
	if (fmt < 4) {
		/* begin sizeBitsOfSafe: */
		header = longAt(array1);
		/* begin rightType: */
		if ((header & 252) == 0) {
			type = 0;
			goto l2;
		} else {
			if ((header & 126976) == 0) {
				type = 1;
				goto l2;
			} else {
				type = 3;
				goto l2;
			}
		}
	l2:	/* end rightType: */;
		if (type == 0) {
			sz = (longAt(array1 - 8)) & 4294967292;
			goto l3;
		} else {
			sz = header & 252;
			goto l3;
		}
	l3:	/* end sizeBitsOfSafe: */;
		fieldOffset = sz - 4;
		goto l1;
	}
	if (fmt < 12) {
		fieldOffset = 0;
		goto l1;
	}
	methodHeader = longAt(array1 + 4);
	fieldOffset = (((((unsigned) methodHeader) >> 10) & 255) * 4) + 4;
l1:	/* end lastPointerOf: */;
	while (fieldOffset >= 4) {
		if ((longAt(array1 + fieldOffset)) < youngStart) {
			return false;
		}
		if ((longAt(array2 + fieldOffset)) < youngStart) {
			return false;
		}
		fieldOffset = fieldOffset - 4;
	}
	return true;
}

int alphaBlendwith(int sourceWord, int destinationWord) {
    int alpha;
    int unAlpha;
    int colorMask;
    int result;
    int blend;
    int i;
    int shift;

	alpha = ((unsigned) sourceWord) >> 24;
	unAlpha = 255 - alpha;
	colorMask = 255;
	result = 0;
	for (i = 1; i <= 3; i += 1) {
		shift = (i - 1) * 8;
		blend = ((((((((unsigned) sourceWord) >> shift) & colorMask) * alpha) + (((((unsigned) destinationWord) >> shift) & colorMask) * unAlpha)) + 254) / 255) & colorMask;
		result = result | (blend << shift);
	}
	return result;
}

int areFloatsand(int oop1, int oop2) {
    int floatClass;
    int cl1;
    int cl2;
    int ccIndex;
    int ccIndex1;

	floatClass = longAt((specialObjectsOop + 4) + (9 * 4));
	/* begin fetchClassOf: */
	if (((oop1 & 1) == 1)) {
		cl1 = longAt((specialObjectsOop + 4) + (5 * 4));
		goto l1;
	}
	ccIndex = ((((unsigned) (longAt(oop1))) >> 12) & 31) - 1;
	if (ccIndex < 0) {
		cl1 = (longAt(oop1 - 4)) & 4294967292;
		goto l1;
	} else {
		cl1 = longAt(((longAt((specialObjectsOop + 4) + (28 * 4))) + 4) + (ccIndex * 4));
		goto l1;
	}
l1:	/* end fetchClassOf: */;
	/* begin fetchClassOf: */
	if (((oop2 & 1) == 1)) {
		cl2 = longAt((specialObjectsOop + 4) + (5 * 4));
		goto l2;
	}
	ccIndex1 = ((((unsigned) (longAt(oop2))) >> 12) & 31) - 1;
	if (ccIndex1 < 0) {
		cl2 = (longAt(oop2 - 4)) & 4294967292;
		goto l2;
	} else {
		cl2 = longAt(((longAt((specialObjectsOop + 4) + (28 * 4))) + 4) + (ccIndex1 * 4));
		goto l2;
	}
l2:	/* end fetchClassOf: */;
	return (cl1 == floatClass) && (cl2 == floatClass);
}

int areIntegersand(int oop1, int oop2) {
	return ((oop1 & oop2) & 1) != 0;
}

int argCount(void) {
	return argumentCount;
}

int argumentCountOf(int methodPointer) {
	return (((unsigned) (longAt((methodPointer + 4) + (0 * 4)))) >> 25) & 31;
}

int argumentCountOfBlock(int blockPointer) {
    int argCount;

	argCount = longAt((blockPointer + 4) + (3 * 4));
	if (((argCount & 1) == 1)) {
		return (argCount >> 1);
	} else {
		primitiveFail();
		return 0;
	}
}

void * arrayValueOf(int arrayOop) {
	if ((!(((arrayOop & 1) == 1))) && (isWordsOrBytes(arrayOop))) {
		return (void *) (arrayOop + 4);
	}
	primitiveFail();
}

int asciiDirectoryDelimiter(void) {
	return dir_Delimitor();
}

int asciiOfCharacter(int characterObj) {
    int successValue;

	/* begin success: */
	successValue = (fetchClassOf(characterObj)) == (longAt((specialObjectsOop + 4) + (19 * 4)));
	successFlag = successValue && successFlag;
	if (successFlag) {
		return longAt((characterObj + 4) + (0 * 4));
	} else {
		return 1;
	}
}

int baseHeader(int oop) {
	return longAt(oop);
}

int becomewith(int array1, int array2) {
    int fieldOffset;
    int oop1;
    int oop2;
    int fwdHeader;
    int fwdBlock;
    int fwdHeader1;
    int fwdBlock1;
    int hdr1;
    int hdr2;
    int fmt;
    int sz;
    int methodHeader;
    int header;
    int type;

	if (!((fetchClassOf(array1)) == (longAt((specialObjectsOop + 4) + (7 * 4))))) {
		return false;
	}
	if (!((fetchClassOf(array2)) == (longAt((specialObjectsOop + 4) + (7 * 4))))) {
		return false;
	}
	if (!((lastPointerOf(array1)) == (lastPointerOf(array2)))) {
		return false;
	}
	if (!(containOnlyOopsand(array1, array2))) {
		return false;
	}
	if (!(prepareForwardingTableForBecomingwith(array1, array2))) {
		return false;
	}
	if (allYoungand(array1, array2)) {
		mapPointersInObjectsFromto(youngStart, endOfMemory);
	} else {
		mapPointersInObjectsFromto(startOfMemory(), endOfMemory);
	}
	/* begin restoreHeadersAfterBecoming:with: */
	/* begin lastPointerOf: */
	fmt = (((unsigned) (longAt(array1))) >> 8) & 15;
	if (fmt < 4) {
		/* begin sizeBitsOfSafe: */
		header = longAt(array1);
		/* begin rightType: */
		if ((header & 252) == 0) {
			type = 0;
			goto l1;
		} else {
			if ((header & 126976) == 0) {
				type = 1;
				goto l1;
			} else {
				type = 3;
				goto l1;
			}
		}
	l1:	/* end rightType: */;
		if (type == 0) {
			sz = (longAt(array1 - 8)) & 4294967292;
			goto l2;
		} else {
			sz = header & 252;
			goto l2;
		}
	l2:	/* end sizeBitsOfSafe: */;
		fieldOffset = sz - 4;
		goto l3;
	}
	if (fmt < 12) {
		fieldOffset = 0;
		goto l3;
	}
	methodHeader = longAt(array1 + 4);
	fieldOffset = (((((unsigned) methodHeader) >> 10) & 255) * 4) + 4;
l3:	/* end lastPointerOf: */;
	while (fieldOffset >= 4) {
		oop1 = longAt(array1 + fieldOffset);
		oop2 = longAt(array2 + fieldOffset);
		/* begin restoreHeaderOf: */
		fwdHeader = longAt(oop1);
		fwdBlock = fwdHeader & 2147483644;
		if (checkAssertions) {
			if ((fwdHeader & 2147483648) == 0) {
				error("attempting to restore the header of an object that has no forwarding block");
			}
			/* begin fwdBlockValidate: */
			if (!((fwdBlock > endOfMemory) && ((fwdBlock <= fwdTableNext) && ((fwdBlock & 3) == 0)))) {
				error("invalid fwd table entry");
			}
		}
		longAtput(oop1, longAt(fwdBlock + 4));
		/* begin restoreHeaderOf: */
		fwdHeader1 = longAt(oop2);
		fwdBlock1 = fwdHeader1 & 2147483644;
		if (checkAssertions) {
			if ((fwdHeader1 & 2147483648) == 0) {
				error("attempting to restore the header of an object that has no forwarding block");
			}
			/* begin fwdBlockValidate: */
			if (!((fwdBlock1 > endOfMemory) && ((fwdBlock1 <= fwdTableNext) && ((fwdBlock1 & 3) == 0)))) {
				error("invalid fwd table entry");
			}
		}
		longAtput(oop2, longAt(fwdBlock1 + 4));
		/* begin exchangeHashBits:with: */
		hdr1 = longAt(oop1);
		hdr2 = longAt(oop2);
		longAtput(oop1, (hdr1 & 3758227455) | (hdr2 & 536739840));
		longAtput(oop2, (hdr2 & 3758227455) | (hdr1 & 536739840));
		fieldOffset = fieldOffset - 4;
	}
	initializeMemoryFirstFree(freeBlock);
	return true;
}

int beRootIfOld(int oop) {
    int header;

	if ((oop < youngStart) && (!(((oop & 1) == 1)))) {
		header = longAt(oop);
		if ((header & 1073741824) == 0) {
			if (rootTableCount < 1000) {
				rootTableCount = rootTableCount + 1;
				rootTable[rootTableCount] = oop;
				longAtput(oop, header | 1073741824);
			}
		}
	}
}

int beRootWhileForwarding(int oop) {
    int header;
    int forwarding;
    int fwdBlock;
    int newHeader;

	header = longAt(oop);
	if ((header & 2147483648) != 0) {
		forwarding = true;
		fwdBlock = header & 2147483644;
		if (checkAssertions) {
			/* begin fwdBlockValidate: */
			if (!((fwdBlock > endOfMemory) && ((fwdBlock <= fwdTableNext) && ((fwdBlock & 3) == 0)))) {
				error("invalid fwd table entry");
			}
		}
		header = longAt(fwdBlock + 4);
	} else {
		forwarding = false;
	}
	if ((header & 1073741824) == 0) {
		if (rootTableCount < 1000) {
			rootTableCount = rootTableCount + 1;
			rootTable[rootTableCount] = oop;
			newHeader = header | 1073741824;
			if (forwarding) {
				longAtput(fwdBlock + 4, newHeader);
			} else {
				longAtput(oop, newHeader);
			}
		}
	}
}

int booleanValueOf(int obj) {
	if (obj == trueObj) {
		return true;
	}
	if (obj == falseObj) {
		return false;
	}
	successFlag = false;
	return null;
}

int byteLengthOf(int oop) {
    int header;
    int sz;
    int fmt;

	header = longAt(oop);
	if ((header & 3) == 0) {
		sz = (longAt(oop - 8)) & 4294967292;
	} else {
		sz = header & 252;
	}
	fmt = (((unsigned) header) >> 8) & 15;
	if (fmt < 8) {
		return sz - 4;
	} else {
		return (sz - 4) - (fmt & 3);
	}
}

int caller(void) {
	return longAt((activeContext + 4) + (0 * 4));
}

int cCode(int codeString) {
	return codeString;
}

int characterForAscii(int integerObj) {
	return longAt(((longAt((specialObjectsOop + 4) + (24 * 4))) + 4) + (((integerObj >> 1)) * 4));
}

int checkAddress(int byteAddress) {
	if (byteAddress < (startOfMemory())) {
		error("bad address: negative");
	}
	if (byteAddress >= memoryLimit) {
		error("bad address: past end of heap");
	}
}

int checkBooleanResultfrom(int result, int primIndex) {
	if (successFlag) {
		/* begin pushBool: */
		if (result) {
			/* begin push: */
			longAtput(stackPointer = stackPointer + 4, trueObj);
		} else {
			/* begin push: */
			longAtput(stackPointer = stackPointer + 4, falseObj);
		}
	} else {
		/* begin unPop: */
		stackPointer = stackPointer + (2 * 4);
		failSpecialPrim(primIndex);
	}
}

int checkedByteAt(int byteAddress) {
	/* begin checkAddress: */
	if (byteAddress < (startOfMemory())) {
		error("bad address: negative");
	}
	if (byteAddress >= memoryLimit) {
		error("bad address: past end of heap");
	}
	return byteAt(byteAddress);
}

int checkedByteAtput(int byteAddress, int byte) {
	/* begin checkAddress: */
	if (byteAddress < (startOfMemory())) {
		error("bad address: negative");
	}
	if (byteAddress >= memoryLimit) {
		error("bad address: past end of heap");
	}
	byteAtput(byteAddress, byte);
}

int checkedIntegerValueOf(int intOop) {
	if (((intOop & 1) == 1)) {
		return (intOop >> 1);
	} else {
		primitiveFail();
		return 0;
	}
}

int checkedLongAt(int byteAddress) {
	/* begin checkAddress: */
	if (byteAddress < (startOfMemory())) {
		error("bad address: negative");
	}
	if (byteAddress >= memoryLimit) {
		error("bad address: past end of heap");
	}
	/* begin checkAddress: */
	if ((byteAddress + 3) < (startOfMemory())) {
		error("bad address: negative");
	}
	if ((byteAddress + 3) >= memoryLimit) {
		error("bad address: past end of heap");
	}
	return longAt(byteAddress);
}

int checkedLongAtput(int byteAddress, int a32BitInteger) {
	/* begin checkAddress: */
	if (byteAddress < (startOfMemory())) {
		error("bad address: negative");
	}
	if (byteAddress >= memoryLimit) {
		error("bad address: past end of heap");
	}
	/* begin checkAddress: */
	if ((byteAddress + 3) < (startOfMemory())) {
		error("bad address: negative");
	}
	if ((byteAddress + 3) >= memoryLimit) {
		error("bad address: past end of heap");
	}
	longAtput(byteAddress, a32BitInteger);
}

int checkForInterrupts(void) {
    int sema;
    int now;

	if (signalLowSpace) {
		signalLowSpace = false;
		lowSpaceThreshold = 0;
		sema = longAt((specialObjectsOop + 4) + (17 * 4));
		if (!(sema == nilObj)) {
			return synchronousSignal(sema);
		}
	}
	now = ioMSecs();
	if (now >= nextPollTick) {
		ioProcessEvents();
		nextPollTick = now + 500;
	}
	if (interruptPending) {
		interruptPending = false;
		sema = longAt((specialObjectsOop + 4) + (30 * 4));
		if (!(sema == nilObj)) {
			return synchronousSignal(sema);
		}
	}
	if ((nextWakeupTick != 0) && (now >= nextWakeupTick)) {
		nextWakeupTick = 0;
		sema = longAt((specialObjectsOop + 4) + (29 * 4));
		if (!(sema == nilObj)) {
			return synchronousSignal(sema);
		}
	}
}

int checkInstanceVariableBoundsOfin(int index, int object) {
    int successValue;

	/* begin success: */
	successFlag = (index >= 1) && successFlag;
	/* begin success: */
	successValue = index <= (lengthOf(object));
	successFlag = successValue && successFlag;
}

int checkIntegerResultfrom(int integerResult, int primIndex) {
	if (successFlag && ((integerResult >= -1073741824) && (integerResult < 1073741824))) {
		/* begin pushInteger: */
		/* begin push: */
		longAtput(stackPointer = stackPointer + 4, ((integerResult << 1) | 1));
	} else {
		/* begin unPop: */
		stackPointer = stackPointer + (2 * 4);
		failSpecialPrim(primIndex);
	}
}

int checkSourceOverlap(void) {
    int t;

	if ((sourceForm == destForm) && (dy >= sy)) {
		if (dy > sy) {
			vDir = -1;
			sy = (sy + bbH) - 1;
			dy = (dy + bbH) - 1;
		} else {
			if (dx > sx) {
				hDir = -1;
				sx = (sx + bbW) - 1;
				dx = (dx + bbW) - 1;
				if (nWords > 1) {
					t = mask1;
					mask1 = mask2;
					mask2 = t;
				}
			}
		}
		destIndex = (destBits + 4) + (((dy * destRaster) + (dx / pixPerWord)) * 4);
		destDelta = 4 * ((destRaster * vDir) - (nWords * hDir));
	}
}

int chunkFromOop(int oop) {
	return oop - (extraHeaderBytes(oop));
}

int classHeader(int oop) {
	return longAt(oop - 4);
}

int clearRootsTable(void) {
    int i;
    int oop;

	for (i = 1; i <= rootTableCount; i += 1) {
		oop = rootTable[i];
		longAtput(oop, (longAt(oop)) & 3221225471);
		rootTable[i] = 0;
	}
	rootTableCount = 0;
}

int clipRange(void) {
	if (destX >= clipX) {
		sx = sourceX;
		dx = destX;
		bbW = width;
	} else {
		sx = sourceX + (clipX - destX);
		bbW = width - (clipX - destX);
		dx = clipX;
	}
	if ((dx + bbW) > (clipX + clipWidth)) {
		bbW = bbW - ((dx + bbW) - (clipX + clipWidth));
	}
	if (destY >= clipY) {
		sy = sourceY;
		dy = destY;
		bbH = height;
	} else {
		sy = (sourceY + clipY) - destY;
		bbH = height - (clipY - destY);
		dy = clipY;
	}
	if ((dy + bbH) > (clipY + clipHeight)) {
		bbH = bbH - ((dy + bbH) - (clipY + clipHeight));
	}
	if (noSource) {
		return null;
	}
	if (sx < 0) {
		dx = dx - sx;
		bbW = bbW + sx;
		sx = 0;
	}
	if ((sx + bbW) > srcWidth) {
		bbW = bbW - ((sx + bbW) - srcWidth);
	}
	if (sy < 0) {
		dy = dy - sy;
		bbH = bbH + sy;
		sy = 0;
	}
	if ((sy + bbH) > srcHeight) {
		bbH = bbH - ((sy + bbH) - srcHeight);
	}
}

int commonAt(int stringy) {
    int index;
    int array;
    int result;
    int integerPointer;
    int top;
    int top1;
    int fixedFields;
    int totalLength;
    int i;
    int successValue;
    int header;
    int sz;
    int fmt;
    int fmt1;
    int byteVal;
    int classPointer;
    int fmt2;
    int ccIndex;

	/* begin popInteger */
	/* begin popStack */
	top = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	integerPointer = top;
	if (((integerPointer & 1) == 1)) {
		index = (integerPointer >> 1);
		goto l1;
	} else {
		successFlag = false;
		index = 1;
		goto l1;
	}
l1:	/* end popInteger */;
	/* begin popStack */
	top1 = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	array = top1;
	/* begin success: */
	successFlag = (!(((array & 1) == 1))) && successFlag;
	if (successFlag) {
		/* begin stObject:at: */
		/* begin fixedFieldsOf: */
		/* begin fetchClassOf: */
		if (((array & 1) == 1)) {
			classPointer = longAt((specialObjectsOop + 4) + (5 * 4));
			goto l2;
		}
		ccIndex = ((((unsigned) (longAt(array))) >> 12) & 31) - 1;
		if (ccIndex < 0) {
			classPointer = (longAt(array - 4)) & 4294967292;
			goto l2;
		} else {
			classPointer = longAt(((longAt((specialObjectsOop + 4) + (28 * 4))) + 4) + (ccIndex * 4));
			goto l2;
		}
	l2:	/* end fetchClassOf: */;
		fmt2 = (longAt((classPointer + 4) + (2 * 4))) - 1;
		fixedFields = ((((unsigned) fmt2) >> 2) & 63) - 1;
		/* begin lengthOf: */
		header = longAt(array);
		if ((header & 3) == 0) {
			sz = (longAt(array - 8)) & 4294967292;
		} else {
			sz = header & 252;
		}
		fmt = (((unsigned) header) >> 8) & 15;
		if (fmt < 8) {
			totalLength = (sz - 4) / 4;
			goto l3;
		} else {
			totalLength = (sz - 4) - (fmt & 3);
			goto l3;
		}
	l3:	/* end lengthOf: */;
		i = index + fixedFields;
		/* begin success: */
		successValue = (index >= 1) && (i <= totalLength);
		successFlag = successValue && successFlag;
		if (successFlag) {
			/* begin subscript:with: */
			fmt1 = (((unsigned) (longAt(array))) >> 8) & 15;
			if (fmt1 < 4) {
				result = longAt((array + 4) + ((i - 1) * 4));
				goto l4;
			}
			if (fmt1 < 8) {
				result = positive32BitIntegerFor(longAt((array + 4) + ((i - 1) * 4)));
				goto l4;
			}
			byteVal = byteAt((array + 4) + (i - 1));
			result = ((byteVal << 1) | 1);
			goto l4;
		} else {
			result = nilObj;
			goto l4;
		}
	l4:	/* end stObject:at: */;
	}
	if (successFlag) {
		if (stringy) {
			/* begin push: */
			longAtput(stackPointer = stackPointer + 4, longAt(((longAt((specialObjectsOop + 4) + (24 * 4))) + 4) + (((result >> 1)) * 4)));
		} else {
			/* begin push: */
			longAtput(stackPointer = stackPointer + 4, result);
		}
	} else {
		/* begin unPop: */
		stackPointer = stackPointer + (2 * 4);
		if (stringy) {
			failSpecialPrim(63);
		} else {
			failSpecialPrim(60);
		}
	}
}

int commonAtPut(int stringy) {
    int index;
    int array;
    int value;
    int storeVal;
    int top;
    int top1;
    int integerPointer;
    int top2;
    int successValue;
    int fixedFields;
    int totalLength;
    int i;
    int successValue2;
    int header;
    int sz;
    int fmt;
    int classPointer;
    int fmt1;
    int fmt2;
    int byte;
    int bitValue;
    int successValue1;
    int ccIndex;

	/* begin popStack */
	top = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	value = top;
	/* begin popInteger */
	/* begin popStack */
	top2 = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	integerPointer = top2;
	if (((integerPointer & 1) == 1)) {
		index = (integerPointer >> 1);
		goto l1;
	} else {
		successFlag = false;
		index = 1;
		goto l1;
	}
l1:	/* end popInteger */;
	/* begin popStack */
	top1 = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	array = top1;
	if (stringy) {
		/* begin asciiOfCharacter: */
		/* begin success: */
		successValue = (fetchClassOf(value)) == (longAt((specialObjectsOop + 4) + (19 * 4)));
		successFlag = successValue && successFlag;
		if (successFlag) {
			storeVal = longAt((value + 4) + (0 * 4));
			goto l2;
		} else {
			storeVal = 1;
			goto l2;
		}
	l2:	/* end asciiOfCharacter: */;
	} else {
		storeVal = value;
	}
	/* begin stObject:at:put: */
	/* begin fixedFieldsOf: */
	/* begin fetchClassOf: */
	if (((array & 1) == 1)) {
		classPointer = longAt((specialObjectsOop + 4) + (5 * 4));
		goto l3;
	}
	ccIndex = ((((unsigned) (longAt(array))) >> 12) & 31) - 1;
	if (ccIndex < 0) {
		classPointer = (longAt(array - 4)) & 4294967292;
		goto l3;
	} else {
		classPointer = longAt(((longAt((specialObjectsOop + 4) + (28 * 4))) + 4) + (ccIndex * 4));
		goto l3;
	}
l3:	/* end fetchClassOf: */;
	fmt1 = (longAt((classPointer + 4) + (2 * 4))) - 1;
	fixedFields = ((((unsigned) fmt1) >> 2) & 63) - 1;
	/* begin lengthOf: */
	header = longAt(array);
	if ((header & 3) == 0) {
		sz = (longAt(array - 8)) & 4294967292;
	} else {
		sz = header & 252;
	}
	fmt = (((unsigned) header) >> 8) & 15;
	if (fmt < 8) {
		totalLength = (sz - 4) / 4;
		goto l4;
	} else {
		totalLength = (sz - 4) - (fmt & 3);
		goto l4;
	}
l4:	/* end lengthOf: */;
	i = index + fixedFields;
	/* begin success: */
	successValue2 = (index >= 1) && (i <= totalLength);
	successFlag = successValue2 && successFlag;
	if (successFlag) {
		/* begin subscript:with:storing: */
		fmt2 = (((unsigned) (longAt(array))) >> 8) & 15;
		if (fmt2 < 4) {
			/* begin storePointer:ofObject:withValue: */
			if (array < youngStart) {
				possibleRootStoreIntovalue(array, storeVal);
			}
			longAtput((array + 4) + ((i - 1) * 4), storeVal);
			goto l5;
		}
		if (fmt2 < 8) {
			bitValue = positive32BitValueOf(storeVal);
			if (successFlag) {
				longAtput((array + 4) + ((i - 1) * 4), bitValue);
			}
			goto l5;
		}
		/* begin success: */
		successFlag = (((storeVal & 1) == 1)) && successFlag;
		byte = (storeVal >> 1);
		/* begin success: */
		successValue1 = (byte >= 0) && (byte <= 255);
		successFlag = successValue1 && successFlag;
		if (successFlag) {
			byteAtput((array + 4) + (i - 1), byte);
		}
	l5:	/* end subscript:with:storing: */;
	}
	if (successFlag) {
		/* begin push: */
		longAtput(stackPointer = stackPointer + 4, value);
	} else {
		/* begin unPop: */
		stackPointer = stackPointer + (3 * 4);
		if (stringy) {
			failSpecialPrim(64);
		} else {
			failSpecialPrim(61);
		}
	}
}

int compare31or32Bitsequal(int obj1, int obj2) {
	if ((((obj1 & 1) == 1)) && (((obj2 & 1) == 1))) {
		return obj1 == obj2;
	}
	return (positive32BitValueOf(obj1)) == (positive32BitValueOf(obj2));
}

int containOnlyOopsand(int array1, int array2) {
    int fieldOffset;
    int fmt;
    int sz;
    int methodHeader;
    int header;
    int type;

	/* begin lastPointerOf: */
	fmt = (((unsigned) (longAt(array1))) >> 8) & 15;
	if (fmt < 4) {
		/* begin sizeBitsOfSafe: */
		header = longAt(array1);
		/* begin rightType: */
		if ((header & 252) == 0) {
			type = 0;
			goto l2;
		} else {
			if ((header & 126976) == 0) {
				type = 1;
				goto l2;
			} else {
				type = 3;
				goto l2;
			}
		}
	l2:	/* end rightType: */;
		if (type == 0) {
			sz = (longAt(array1 - 8)) & 4294967292;
			goto l3;
		} else {
			sz = header & 252;
			goto l3;
		}
	l3:	/* end sizeBitsOfSafe: */;
		fieldOffset = sz - 4;
		goto l1;
	}
	if (fmt < 12) {
		fieldOffset = 0;
		goto l1;
	}
	methodHeader = longAt(array1 + 4);
	fieldOffset = (((((unsigned) methodHeader) >> 10) & 255) * 4) + 4;
l1:	/* end lastPointerOf: */;
	while (fieldOffset >= 4) {
		if ((((longAt(array1 + fieldOffset)) & 1) == 1)) {
			return false;
		}
		if ((((longAt(array2 + fieldOffset)) & 1) == 1)) {
			return false;
		}
		fieldOffset = fieldOffset - 4;
	}
	return true;
}

int copyBits(void) {
    int dWid;
    int sxLowBits;
    int dxLowBits;
    int pixPerM1;
    int t;
    int integerValue;

	clipRange();
	if ((bbW <= 0) || (bbH <= 0)) {
		affectedL = affectedR = affectedT = affectedB = 0;
		return null;
	}
	destMaskAndPointerInit();
	bitCount = 0;
	if (noSource) {
		copyLoopNoSource();
	} else {
		/* begin checkSourceOverlap */
		if ((sourceForm == destForm) && (dy >= sy)) {
			if (dy > sy) {
				vDir = -1;
				sy = (sy + bbH) - 1;
				dy = (dy + bbH) - 1;
			} else {
				if (dx > sx) {
					hDir = -1;
					sx = (sx + bbW) - 1;
					dx = (dx + bbW) - 1;
					if (nWords > 1) {
						t = mask1;
						mask1 = mask2;
						mask2 = t;
					}
				}
			}
			destIndex = (destBits + 4) + (((dy * destRaster) + (dx / pixPerWord)) * 4);
			destDelta = 4 * ((destRaster * vDir) - (nWords * hDir));
		}
		if ((sourcePixSize != destPixSize) || (colorMap != nilObj)) {
			copyLoopPixMap();
		} else {
			/* begin sourceSkewAndPointerInit */
			pixPerM1 = pixPerWord - 1;
			sxLowBits = sx & pixPerM1;
			dxLowBits = dx & pixPerM1;
			if (hDir > 0) {
				dWid = ((bbW < (pixPerWord - dxLowBits)) ? bbW : (pixPerWord - dxLowBits));
				preload = (sxLowBits + dWid) > pixPerM1;
			} else {
				dWid = ((bbW < (dxLowBits + 1)) ? bbW : (dxLowBits + 1));
				preload = ((sxLowBits - dWid) + 1) < 0;
			}
			skew = (sxLowBits - dxLowBits) * destPixSize;
			if (preload) {
				if (skew < 0) {
					skew = skew + 32;
				} else {
					skew = skew - 32;
				}
			}
			sourceIndex = (sourceBits + 4) + (((sy * sourceRaster) + (sx / (32 / sourcePixSize))) * 4);
			sourceDelta = 4 * ((sourceRaster * vDir) - (nWords * hDir));
			if (preload) {
				sourceDelta = sourceDelta - (4 * hDir);
			}
			copyLoop();
		}
	}
	if (combinationRule == 22) {
		affectedL = affectedR = affectedT = affectedB = 0;
		/* begin pop: */
		stackPointer = stackPointer - (1 * 4);
		/* begin pushInteger: */
		integerValue = bitCount;
		/* begin push: */
		longAtput(stackPointer = stackPointer + 4, ((integerValue << 1) | 1));
		return null;
	}
	if (hDir > 0) {
		affectedL = dx;
		affectedR = dx + bbW;
	} else {
		affectedL = dx - bbW;
		affectedR = dx;
	}
	if (vDir > 0) {
		affectedT = dy;
		affectedB = dy + bbH;
	} else {
		affectedT = dy - bbH;
		affectedB = dy;
	}
}

int copyLoop(void) {
    int prevWord;
    int thisWord;
    int skewWord;
    int halftoneWord;
    int mergeWord;
    int hInc;
    int y;
    int i;
    int word;
    int unskew;
    int skewMask;
    int notSkewMask;
    int destinationWord;
    int destinationWord1;
    int destinationWord2;

	hInc = hDir * 4;
	if (skew == -32) {
		skew = unskew = skewMask = 0;
	} else {
		if (skew < 0) {
			unskew = skew + 32;
			skewMask = 4294967295 << (0 - skew);
		} else {
			if (skew == 0) {
				unskew = 0;
				skewMask = 4294967295;
			} else {
				unskew = skew - 32;
				skewMask = ((unsigned) 4294967295) >> skew;
			}
		}
	}
	notSkewMask = ~skewMask;
	if (noHalftone) {
		halftoneWord = 4294967295;
		halftoneHeight = 0;
	} else {
		halftoneWord = longAt(halftoneBase);
	}
	y = dy;
	for (i = 1; i <= bbH; i += 1) {
		if (halftoneHeight > 1) {
			halftoneWord = longAt(halftoneBase + ((y % halftoneHeight) * 4));
			y = y + vDir;
		}
		if (preload) {
			prevWord = longAt(sourceIndex);
			sourceIndex = sourceIndex + hInc;
		} else {
			prevWord = 0;
		}
		thisWord = longAt(sourceIndex);
		skewWord = (((unskew < 0) ? ((unsigned) (prevWord & notSkewMask) >> -unskew) : ((unsigned) (prevWord & notSkewMask) << unskew))) | (((skew < 0) ? ((unsigned) (thisWord & skewMask) >> -skew) : ((unsigned) (thisWord & skewMask) << skew)));
		prevWord = thisWord;
		sourceIndex = sourceIndex + hInc;
		/* begin merge:with: */
		destinationWord2 = longAt(destIndex);
		if (combinationRule < 16) {
			if (combinationRule < 8) {
				if (combinationRule < 4) {
					if (combinationRule < 2) {
						if (combinationRule < 1) {
							mergeWord = 0;
							goto l3;
						} else {
							mergeWord = (skewWord & halftoneWord) & destinationWord2;
							goto l3;
						}
					} else {
						if (combinationRule < 3) {
							mergeWord = (skewWord & halftoneWord) & (~destinationWord2);
							goto l3;
						} else {
							mergeWord = skewWord & halftoneWord;
							goto l3;
						}
					}
				} else {
					if (combinationRule < 6) {
						if (combinationRule < 5) {
							mergeWord = (~(skewWord & halftoneWord)) & destinationWord2;
							goto l3;
						} else {
							mergeWord = destinationWord2;
							goto l3;
						}
					} else {
						if (combinationRule < 7) {
							mergeWord = (skewWord & halftoneWord) ^ destinationWord2;
							goto l3;
						} else {
							mergeWord = (skewWord & halftoneWord) | destinationWord2;
							goto l3;
						}
					}
				}
			} else {
				if (combinationRule < 12) {
					if (combinationRule < 10) {
						if (combinationRule < 9) {
							mergeWord = (~(skewWord & halftoneWord)) & (~destinationWord2);
							goto l3;
						} else {
							mergeWord = (~(skewWord & halftoneWord)) ^ destinationWord2;
							goto l3;
						}
					} else {
						if (combinationRule < 11) {
							mergeWord = ~destinationWord2;
							goto l3;
						} else {
							mergeWord = (skewWord & halftoneWord) | (~destinationWord2);
							goto l3;
						}
					}
				} else {
					if (combinationRule < 14) {
						if (combinationRule < 13) {
							mergeWord = ~(skewWord & halftoneWord);
							goto l3;
						} else {
							mergeWord = (~(skewWord & halftoneWord)) | destinationWord2;
							goto l3;
						}
					} else {
						if (combinationRule < 15) {
							mergeWord = (~(skewWord & halftoneWord)) | (~destinationWord2);
							goto l3;
						} else {
							mergeWord = destinationWord2;
							goto l3;
						}
					}
				}
			}
		} else {
			if (combinationRule < 24) {
				if (combinationRule < 20) {
					if (combinationRule < 18) {
						if (combinationRule < 17) {
							mergeWord = destinationWord2;
							goto l3;
						} else {
							mergeWord = destinationWord2;
							goto l3;
						}
					} else {
						if (combinationRule < 19) {
							mergeWord = (skewWord & halftoneWord) + destinationWord2;
							goto l3;
						} else {
							mergeWord = (skewWord & halftoneWord) - destinationWord2;
							goto l3;
						}
					}
				} else {
					if (combinationRule < 22) {
						if (combinationRule < 21) {
							mergeWord = rgbAddwith(skewWord & halftoneWord, destinationWord2);
							goto l3;
						} else {
							mergeWord = rgbSubwith(skewWord & halftoneWord, destinationWord2);
							goto l3;
						}
					} else {
						if (combinationRule < 23) {
							mergeWord = rgbDiffwith(skewWord & halftoneWord, destinationWord2);
							goto l3;
						} else {
							mergeWord = tallyIntoMap(destinationWord2);
							goto l3;
						}
					}
				}
			} else {
				if (combinationRule < 28) {
					if (combinationRule < 26) {
						if (combinationRule < 25) {
							mergeWord = alphaBlendwith(skewWord & halftoneWord, destinationWord2);
							goto l3;
						} else {
							mergeWord = pixPaintwith(skewWord & halftoneWord, destinationWord2);
							goto l3;
						}
					} else {
						if (combinationRule < 27) {
							mergeWord = pixMaskwith(skewWord & halftoneWord, destinationWord2);
							goto l3;
						} else {
							mergeWord = destinationWord2;
							goto l3;
						}
					}
				} else {
					if (combinationRule < 30) {
						if (combinationRule < 29) {
							mergeWord = destinationWord2;
							goto l3;
						} else {
							mergeWord = destinationWord2;
							goto l3;
						}
					} else {
						if (combinationRule < 31) {
							mergeWord = destinationWord2;
							goto l3;
						} else {
							mergeWord = destinationWord2;
							goto l3;
						}
					}
				}
			}
		}
	l3:	/* end merge:with: */;
		longAtput(destIndex, (mask1 & mergeWord) | ((~mask1) & (longAt(destIndex))));
		destIndex = destIndex + hInc;
		if (combinationRule == 3) {
			for (word = 2; word <= (nWords - 1); word += 1) {
				thisWord = longAt(sourceIndex);
				skewWord = (((unskew < 0) ? ((unsigned) (prevWord & notSkewMask) >> -unskew) : ((unsigned) (prevWord & notSkewMask) << unskew))) | (((skew < 0) ? ((unsigned) (thisWord & skewMask) >> -skew) : ((unsigned) (thisWord & skewMask) << skew)));
				prevWord = thisWord;
				sourceIndex = sourceIndex + hInc;
				longAtput(destIndex, skewWord & halftoneWord);
				destIndex = destIndex + hInc;
			}
		} else {
			for (word = 2; word <= (nWords - 1); word += 1) {
				thisWord = longAt(sourceIndex);
				skewWord = (((unskew < 0) ? ((unsigned) (prevWord & notSkewMask) >> -unskew) : ((unsigned) (prevWord & notSkewMask) << unskew))) | (((skew < 0) ? ((unsigned) (thisWord & skewMask) >> -skew) : ((unsigned) (thisWord & skewMask) << skew)));
				prevWord = thisWord;
				sourceIndex = sourceIndex + hInc;
				/* begin merge:with: */
				destinationWord = longAt(destIndex);
				if (combinationRule < 16) {
					if (combinationRule < 8) {
						if (combinationRule < 4) {
							if (combinationRule < 2) {
								if (combinationRule < 1) {
									mergeWord = 0;
									goto l1;
								} else {
									mergeWord = (skewWord & halftoneWord) & destinationWord;
									goto l1;
								}
							} else {
								if (combinationRule < 3) {
									mergeWord = (skewWord & halftoneWord) & (~destinationWord);
									goto l1;
								} else {
									mergeWord = skewWord & halftoneWord;
									goto l1;
								}
							}
						} else {
							if (combinationRule < 6) {
								if (combinationRule < 5) {
									mergeWord = (~(skewWord & halftoneWord)) & destinationWord;
									goto l1;
								} else {
									mergeWord = destinationWord;
									goto l1;
								}
							} else {
								if (combinationRule < 7) {
									mergeWord = (skewWord & halftoneWord) ^ destinationWord;
									goto l1;
								} else {
									mergeWord = (skewWord & halftoneWord) | destinationWord;
									goto l1;
								}
							}
						}
					} else {
						if (combinationRule < 12) {
							if (combinationRule < 10) {
								if (combinationRule < 9) {
									mergeWord = (~(skewWord & halftoneWord)) & (~destinationWord);
									goto l1;
								} else {
									mergeWord = (~(skewWord & halftoneWord)) ^ destinationWord;
									goto l1;
								}
							} else {
								if (combinationRule < 11) {
									mergeWord = ~destinationWord;
									goto l1;
								} else {
									mergeWord = (skewWord & halftoneWord) | (~destinationWord);
									goto l1;
								}
							}
						} else {
							if (combinationRule < 14) {
								if (combinationRule < 13) {
									mergeWord = ~(skewWord & halftoneWord);
									goto l1;
								} else {
									mergeWord = (~(skewWord & halftoneWord)) | destinationWord;
									goto l1;
								}
							} else {
								if (combinationRule < 15) {
									mergeWord = (~(skewWord & halftoneWord)) | (~destinationWord);
									goto l1;
								} else {
									mergeWord = destinationWord;
									goto l1;
								}
							}
						}
					}
				} else {
					if (combinationRule < 24) {
						if (combinationRule < 20) {
							if (combinationRule < 18) {
								if (combinationRule < 17) {
									mergeWord = destinationWord;
									goto l1;
								} else {
									mergeWord = destinationWord;
									goto l1;
								}
							} else {
								if (combinationRule < 19) {
									mergeWord = (skewWord & halftoneWord) + destinationWord;
									goto l1;
								} else {
									mergeWord = (skewWord & halftoneWord) - destinationWord;
									goto l1;
								}
							}
						} else {
							if (combinationRule < 22) {
								if (combinationRule < 21) {
									mergeWord = rgbAddwith(skewWord & halftoneWord, destinationWord);
									goto l1;
								} else {
									mergeWord = rgbSubwith(skewWord & halftoneWord, destinationWord);
									goto l1;
								}
							} else {
								if (combinationRule < 23) {
									mergeWord = rgbDiffwith(skewWord & halftoneWord, destinationWord);
									goto l1;
								} else {
									mergeWord = tallyIntoMap(destinationWord);
									goto l1;
								}
							}
						}
					} else {
						if (combinationRule < 28) {
							if (combinationRule < 26) {
								if (combinationRule < 25) {
									mergeWord = alphaBlendwith(skewWord & halftoneWord, destinationWord);
									goto l1;
								} else {
									mergeWord = pixPaintwith(skewWord & halftoneWord, destinationWord);
									goto l1;
								}
							} else {
								if (combinationRule < 27) {
									mergeWord = pixMaskwith(skewWord & halftoneWord, destinationWord);
									goto l1;
								} else {
									mergeWord = destinationWord;
									goto l1;
								}
							}
						} else {
							if (combinationRule < 30) {
								if (combinationRule < 29) {
									mergeWord = destinationWord;
									goto l1;
								} else {
									mergeWord = destinationWord;
									goto l1;
								}
							} else {
								if (combinationRule < 31) {
									mergeWord = destinationWord;
									goto l1;
								} else {
									mergeWord = destinationWord;
									goto l1;
								}
							}
						}
					}
				}
			l1:	/* end merge:with: */;
				longAtput(destIndex, mergeWord);
				destIndex = destIndex + hInc;
			}
		}
		if (nWords > 1) {
			thisWord = longAt(sourceIndex);
			skewWord = (((unskew < 0) ? ((unsigned) (prevWord & notSkewMask) >> -unskew) : ((unsigned) (prevWord & notSkewMask) << unskew))) | (((skew < 0) ? ((unsigned) (thisWord & skewMask) >> -skew) : ((unsigned) (thisWord & skewMask) << skew)));
			prevWord = thisWord;
			sourceIndex = sourceIndex + hInc;
			/* begin merge:with: */
			destinationWord1 = longAt(destIndex);
			if (combinationRule < 16) {
				if (combinationRule < 8) {
					if (combinationRule < 4) {
						if (combinationRule < 2) {
							if (combinationRule < 1) {
								mergeWord = 0;
								goto l2;
							} else {
								mergeWord = (skewWord & halftoneWord) & destinationWord1;
								goto l2;
							}
						} else {
							if (combinationRule < 3) {
								mergeWord = (skewWord & halftoneWord) & (~destinationWord1);
								goto l2;
							} else {
								mergeWord = skewWord & halftoneWord;
								goto l2;
							}
						}
					} else {
						if (combinationRule < 6) {
							if (combinationRule < 5) {
								mergeWord = (~(skewWord & halftoneWord)) & destinationWord1;
								goto l2;
							} else {
								mergeWord = destinationWord1;
								goto l2;
							}
						} else {
							if (combinationRule < 7) {
								mergeWord = (skewWord & halftoneWord) ^ destinationWord1;
								goto l2;
							} else {
								mergeWord = (skewWord & halftoneWord) | destinationWord1;
								goto l2;
							}
						}
					}
				} else {
					if (combinationRule < 12) {
						if (combinationRule < 10) {
							if (combinationRule < 9) {
								mergeWord = (~(skewWord & halftoneWord)) & (~destinationWord1);
								goto l2;
							} else {
								mergeWord = (~(skewWord & halftoneWord)) ^ destinationWord1;
								goto l2;
							}
						} else {
							if (combinationRule < 11) {
								mergeWord = ~destinationWord1;
								goto l2;
							} else {
								mergeWord = (skewWord & halftoneWord) | (~destinationWord1);
								goto l2;
							}
						}
					} else {
						if (combinationRule < 14) {
							if (combinationRule < 13) {
								mergeWord = ~(skewWord & halftoneWord);
								goto l2;
							} else {
								mergeWord = (~(skewWord & halftoneWord)) | destinationWord1;
								goto l2;
							}
						} else {
							if (combinationRule < 15) {
								mergeWord = (~(skewWord & halftoneWord)) | (~destinationWord1);
								goto l2;
							} else {
								mergeWord = destinationWord1;
								goto l2;
							}
						}
					}
				}
			} else {
				if (combinationRule < 24) {
					if (combinationRule < 20) {
						if (combinationRule < 18) {
							if (combinationRule < 17) {
								mergeWord = destinationWord1;
								goto l2;
							} else {
								mergeWord = destinationWord1;
								goto l2;
							}
						} else {
							if (combinationRule < 19) {
								mergeWord = (skewWord & halftoneWord) + destinationWord1;
								goto l2;
							} else {
								mergeWord = (skewWord & halftoneWord) - destinationWord1;
								goto l2;
							}
						}
					} else {
						if (combinationRule < 22) {
							if (combinationRule < 21) {
								mergeWord = rgbAddwith(skewWord & halftoneWord, destinationWord1);
								goto l2;
							} else {
								mergeWord = rgbSubwith(skewWord & halftoneWord, destinationWord1);
								goto l2;
							}
						} else {
							if (combinationRule < 23) {
								mergeWord = rgbDiffwith(skewWord & halftoneWord, destinationWord1);
								goto l2;
							} else {
								mergeWord = tallyIntoMap(destinationWord1);
								goto l2;
							}
						}
					}
				} else {
					if (combinationRule < 28) {
						if (combinationRule < 26) {
							if (combinationRule < 25) {
								mergeWord = alphaBlendwith(skewWord & halftoneWord, destinationWord1);
								goto l2;
							} else {
								mergeWord = pixPaintwith(skewWord & halftoneWord, destinationWord1);
								goto l2;
							}
						} else {
							if (combinationRule < 27) {
								mergeWord = pixMaskwith(skewWord & halftoneWord, destinationWord1);
								goto l2;
							} else {
								mergeWord = destinationWord1;
								goto l2;
							}
						}
					} else {
						if (combinationRule < 30) {
							if (combinationRule < 29) {
								mergeWord = destinationWord1;
								goto l2;
							} else {
								mergeWord = destinationWord1;
								goto l2;
							}
						} else {
							if (combinationRule < 31) {
								mergeWord = destinationWord1;
								goto l2;
							} else {
								mergeWord = destinationWord1;
								goto l2;
							}
						}
					}
				}
			}
		l2:	/* end merge:with: */;
			longAtput(destIndex, (mask2 & mergeWord) | ((~mask2) & (longAt(destIndex))));
			destIndex = destIndex + hInc;
		}
		sourceIndex = sourceIndex + sourceDelta;
		destIndex = destIndex + destDelta;
	}
}

int copyLoopNoSource(void) {
    int halftoneWord;
    int mergeWord;
    int i;
    int word;
    int destinationWord;
    int destinationWord1;
    int destinationWord2;

	for (i = 1; i <= bbH; i += 1) {
		if (noHalftone) {
			halftoneWord = 4294967295;
		} else {
			halftoneWord = longAt(halftoneBase + ((((dy + i) - 1) % halftoneHeight) * 4));
		}
		/* begin merge:with: */
		destinationWord2 = longAt(destIndex);
		if (combinationRule < 16) {
			if (combinationRule < 8) {
				if (combinationRule < 4) {
					if (combinationRule < 2) {
						if (combinationRule < 1) {
							mergeWord = 0;
							goto l3;
						} else {
							mergeWord = halftoneWord & destinationWord2;
							goto l3;
						}
					} else {
						if (combinationRule < 3) {
							mergeWord = halftoneWord & (~destinationWord2);
							goto l3;
						} else {
							mergeWord = halftoneWord;
							goto l3;
						}
					}
				} else {
					if (combinationRule < 6) {
						if (combinationRule < 5) {
							mergeWord = (~halftoneWord) & destinationWord2;
							goto l3;
						} else {
							mergeWord = destinationWord2;
							goto l3;
						}
					} else {
						if (combinationRule < 7) {
							mergeWord = halftoneWord ^ destinationWord2;
							goto l3;
						} else {
							mergeWord = halftoneWord | destinationWord2;
							goto l3;
						}
					}
				}
			} else {
				if (combinationRule < 12) {
					if (combinationRule < 10) {
						if (combinationRule < 9) {
							mergeWord = (~halftoneWord) & (~destinationWord2);
							goto l3;
						} else {
							mergeWord = (~halftoneWord) ^ destinationWord2;
							goto l3;
						}
					} else {
						if (combinationRule < 11) {
							mergeWord = ~destinationWord2;
							goto l3;
						} else {
							mergeWord = halftoneWord | (~destinationWord2);
							goto l3;
						}
					}
				} else {
					if (combinationRule < 14) {
						if (combinationRule < 13) {
							mergeWord = ~halftoneWord;
							goto l3;
						} else {
							mergeWord = (~halftoneWord) | destinationWord2;
							goto l3;
						}
					} else {
						if (combinationRule < 15) {
							mergeWord = (~halftoneWord) | (~destinationWord2);
							goto l3;
						} else {
							mergeWord = destinationWord2;
							goto l3;
						}
					}
				}
			}
		} else {
			if (combinationRule < 24) {
				if (combinationRule < 20) {
					if (combinationRule < 18) {
						if (combinationRule < 17) {
							mergeWord = destinationWord2;
							goto l3;
						} else {
							mergeWord = destinationWord2;
							goto l3;
						}
					} else {
						if (combinationRule < 19) {
							mergeWord = halftoneWord + destinationWord2;
							goto l3;
						} else {
							mergeWord = halftoneWord - destinationWord2;
							goto l3;
						}
					}
				} else {
					if (combinationRule < 22) {
						if (combinationRule < 21) {
							mergeWord = rgbAddwith(halftoneWord, destinationWord2);
							goto l3;
						} else {
							mergeWord = rgbSubwith(halftoneWord, destinationWord2);
							goto l3;
						}
					} else {
						if (combinationRule < 23) {
							mergeWord = rgbDiffwith(halftoneWord, destinationWord2);
							goto l3;
						} else {
							mergeWord = tallyIntoMap(destinationWord2);
							goto l3;
						}
					}
				}
			} else {
				if (combinationRule < 28) {
					if (combinationRule < 26) {
						if (combinationRule < 25) {
							mergeWord = alphaBlendwith(halftoneWord, destinationWord2);
							goto l3;
						} else {
							mergeWord = pixPaintwith(halftoneWord, destinationWord2);
							goto l3;
						}
					} else {
						if (combinationRule < 27) {
							mergeWord = pixMaskwith(halftoneWord, destinationWord2);
							goto l3;
						} else {
							mergeWord = destinationWord2;
							goto l3;
						}
					}
				} else {
					if (combinationRule < 30) {
						if (combinationRule < 29) {
							mergeWord = destinationWord2;
							goto l3;
						} else {
							mergeWord = destinationWord2;
							goto l3;
						}
					} else {
						if (combinationRule < 31) {
							mergeWord = destinationWord2;
							goto l3;
						} else {
							mergeWord = destinationWord2;
							goto l3;
						}
					}
				}
			}
		}
	l3:	/* end merge:with: */;
		longAtput(destIndex, (mask1 & mergeWord) | ((~mask1) & (longAt(destIndex))));
		destIndex = destIndex + 4;
		if (combinationRule == 3) {
			for (word = 2; word <= (nWords - 1); word += 1) {
				longAtput(destIndex, halftoneWord);
				destIndex = destIndex + 4;
			}
		} else {
			for (word = 2; word <= (nWords - 1); word += 1) {
				/* begin merge:with: */
				destinationWord = longAt(destIndex);
				if (combinationRule < 16) {
					if (combinationRule < 8) {
						if (combinationRule < 4) {
							if (combinationRule < 2) {
								if (combinationRule < 1) {
									mergeWord = 0;
									goto l1;
								} else {
									mergeWord = halftoneWord & destinationWord;
									goto l1;
								}
							} else {
								if (combinationRule < 3) {
									mergeWord = halftoneWord & (~destinationWord);
									goto l1;
								} else {
									mergeWord = halftoneWord;
									goto l1;
								}
							}
						} else {
							if (combinationRule < 6) {
								if (combinationRule < 5) {
									mergeWord = (~halftoneWord) & destinationWord;
									goto l1;
								} else {
									mergeWord = destinationWord;
									goto l1;
								}
							} else {
								if (combinationRule < 7) {
									mergeWord = halftoneWord ^ destinationWord;
									goto l1;
								} else {
									mergeWord = halftoneWord | destinationWord;
									goto l1;
								}
							}
						}
					} else {
						if (combinationRule < 12) {
							if (combinationRule < 10) {
								if (combinationRule < 9) {
									mergeWord = (~halftoneWord) & (~destinationWord);
									goto l1;
								} else {
									mergeWord = (~halftoneWord) ^ destinationWord;
									goto l1;
								}
							} else {
								if (combinationRule < 11) {
									mergeWord = ~destinationWord;
									goto l1;
								} else {
									mergeWord = halftoneWord | (~destinationWord);
									goto l1;
								}
							}
						} else {
							if (combinationRule < 14) {
								if (combinationRule < 13) {
									mergeWord = ~halftoneWord;
									goto l1;
								} else {
									mergeWord = (~halftoneWord) | destinationWord;
									goto l1;
								}
							} else {
								if (combinationRule < 15) {
									mergeWord = (~halftoneWord) | (~destinationWord);
									goto l1;
								} else {
									mergeWord = destinationWord;
									goto l1;
								}
							}
						}
					}
				} else {
					if (combinationRule < 24) {
						if (combinationRule < 20) {
							if (combinationRule < 18) {
								if (combinationRule < 17) {
									mergeWord = destinationWord;
									goto l1;
								} else {
									mergeWord = destinationWord;
									goto l1;
								}
							} else {
								if (combinationRule < 19) {
									mergeWord = halftoneWord + destinationWord;
									goto l1;
								} else {
									mergeWord = halftoneWord - destinationWord;
									goto l1;
								}
							}
						} else {
							if (combinationRule < 22) {
								if (combinationRule < 21) {
									mergeWord = rgbAddwith(halftoneWord, destinationWord);
									goto l1;
								} else {
									mergeWord = rgbSubwith(halftoneWord, destinationWord);
									goto l1;
								}
							} else {
								if (combinationRule < 23) {
									mergeWord = rgbDiffwith(halftoneWord, destinationWord);
									goto l1;
								} else {
									mergeWord = tallyIntoMap(destinationWord);
									goto l1;
								}
							}
						}
					} else {
						if (combinationRule < 28) {
							if (combinationRule < 26) {
								if (combinationRule < 25) {
									mergeWord = alphaBlendwith(halftoneWord, destinationWord);
									goto l1;
								} else {
									mergeWord = pixPaintwith(halftoneWord, destinationWord);
									goto l1;
								}
							} else {
								if (combinationRule < 27) {
									mergeWord = pixMaskwith(halftoneWord, destinationWord);
									goto l1;
								} else {
									mergeWord = destinationWord;
									goto l1;
								}
							}
						} else {
							if (combinationRule < 30) {
								if (combinationRule < 29) {
									mergeWord = destinationWord;
									goto l1;
								} else {
									mergeWord = destinationWord;
									goto l1;
								}
							} else {
								if (combinationRule < 31) {
									mergeWord = destinationWord;
									goto l1;
								} else {
									mergeWord = destinationWord;
									goto l1;
								}
							}
						}
					}
				}
			l1:	/* end merge:with: */;
				longAtput(destIndex, mergeWord);
				destIndex = destIndex + 4;
			}
		}
		if (nWords > 1) {
			/* begin merge:with: */
			destinationWord1 = longAt(destIndex);
			if (combinationRule < 16) {
				if (combinationRule < 8) {
					if (combinationRule < 4) {
						if (combinationRule < 2) {
							if (combinationRule < 1) {
								mergeWord = 0;
								goto l2;
							} else {
								mergeWord = halftoneWord & destinationWord1;
								goto l2;
							}
						} else {
							if (combinationRule < 3) {
								mergeWord = halftoneWord & (~destinationWord1);
								goto l2;
							} else {
								mergeWord = halftoneWord;
								goto l2;
							}
						}
					} else {
						if (combinationRule < 6) {
							if (combinationRule < 5) {
								mergeWord = (~halftoneWord) & destinationWord1;
								goto l2;
							} else {
								mergeWord = destinationWord1;
								goto l2;
							}
						} else {
							if (combinationRule < 7) {
								mergeWord = halftoneWord ^ destinationWord1;
								goto l2;
							} else {
								mergeWord = halftoneWord | destinationWord1;
								goto l2;
							}
						}
					}
				} else {
					if (combinationRule < 12) {
						if (combinationRule < 10) {
							if (combinationRule < 9) {
								mergeWord = (~halftoneWord) & (~destinationWord1);
								goto l2;
							} else {
								mergeWord = (~halftoneWord) ^ destinationWord1;
								goto l2;
							}
						} else {
							if (combinationRule < 11) {
								mergeWord = ~destinationWord1;
								goto l2;
							} else {
								mergeWord = halftoneWord | (~destinationWord1);
								goto l2;
							}
						}
					} else {
						if (combinationRule < 14) {
							if (combinationRule < 13) {
								mergeWord = ~halftoneWord;
								goto l2;
							} else {
								mergeWord = (~halftoneWord) | destinationWord1;
								goto l2;
							}
						} else {
							if (combinationRule < 15) {
								mergeWord = (~halftoneWord) | (~destinationWord1);
								goto l2;
							} else {
								mergeWord = destinationWord1;
								goto l2;
							}
						}
					}
				}
			} else {
				if (combinationRule < 24) {
					if (combinationRule < 20) {
						if (combinationRule < 18) {
							if (combinationRule < 17) {
								mergeWord = destinationWord1;
								goto l2;
							} else {
								mergeWord = destinationWord1;
								goto l2;
							}
						} else {
							if (combinationRule < 19) {
								mergeWord = halftoneWord + destinationWord1;
								goto l2;
							} else {
								mergeWord = halftoneWord - destinationWord1;
								goto l2;
							}
						}
					} else {
						if (combinationRule < 22) {
							if (combinationRule < 21) {
								mergeWord = rgbAddwith(halftoneWord, destinationWord1);
								goto l2;
							} else {
								mergeWord = rgbSubwith(halftoneWord, destinationWord1);
								goto l2;
							}
						} else {
							if (combinationRule < 23) {
								mergeWord = rgbDiffwith(halftoneWord, destinationWord1);
								goto l2;
							} else {
								mergeWord = tallyIntoMap(destinationWord1);
								goto l2;
							}
						}
					}
				} else {
					if (combinationRule < 28) {
						if (combinationRule < 26) {
							if (combinationRule < 25) {
								mergeWord = alphaBlendwith(halftoneWord, destinationWord1);
								goto l2;
							} else {
								mergeWord = pixPaintwith(halftoneWord, destinationWord1);
								goto l2;
							}
						} else {
							if (combinationRule < 27) {
								mergeWord = pixMaskwith(halftoneWord, destinationWord1);
								goto l2;
							} else {
								mergeWord = destinationWord1;
								goto l2;
							}
						}
					} else {
						if (combinationRule < 30) {
							if (combinationRule < 29) {
								mergeWord = destinationWord1;
								goto l2;
							} else {
								mergeWord = destinationWord1;
								goto l2;
							}
						} else {
							if (combinationRule < 31) {
								mergeWord = destinationWord1;
								goto l2;
							} else {
								mergeWord = destinationWord1;
								goto l2;
							}
						}
					}
				}
			}
		l2:	/* end merge:with: */;
			longAtput(destIndex, (mask2 & mergeWord) | ((~mask2) & (longAt(destIndex))));
			destIndex = destIndex + 4;
		}
		destIndex = destIndex + destDelta;
	}
}

int copyLoopPixMap(void) {
    int skewWord;
    int halftoneWord;
    int mergeWord;
    int i;
    int word;
    int destMask;
    int srcPixPerWord;
    int scrStartBits;
    int nSourceIncs;
    int startBits;
    int endBits;
    int sourcePixMask;
    int destPixMask;
    int nullMap;
    int nPix;
    int nPix1;
    int destinationWord;
    int sourceWord;
    int destWord;
    int sourcePix;
    int destPix;
    int i1;
    int mask;
    int d;
    int srcPix;
    int destPix1;
    int mask3;
    int d1;
    int srcPix1;
    int destPix2;
    int mask4;
    int d2;
    int srcPix2;
    int destPix3;
    int mask5;
    int d3;
    int srcPix3;
    int destPix4;
    int sourceWord1;
    int destWord1;
    int sourcePix1;
    int i2;
    int sourceWord2;
    int destWord2;
    int sourcePix2;
    int destPix5;
    int i3;
    int sourceWord3;
    int destWord3;
    int sourcePix3;
    int destPix6;
    int i4;
    int mask6;
    int d4;
    int srcPix4;
    int destPix11;
    int mask31;
    int d11;
    int srcPix11;
    int destPix21;
    int mask41;
    int d21;
    int srcPix21;
    int destPix31;
    int mask51;
    int d31;
    int srcPix31;
    int destPix41;
    int sourceWord4;
    int destWord4;
    int sourcePix4;
    int i5;
    int sourceWord5;
    int destWord5;
    int sourcePix5;
    int destPix7;
    int i6;
    int sourceWord6;
    int destWord6;
    int sourcePix6;
    int destPix8;
    int i7;
    int mask7;
    int d5;
    int srcPix5;
    int destPix12;
    int mask32;
    int d12;
    int srcPix12;
    int destPix22;
    int mask42;
    int d22;
    int srcPix22;
    int destPix32;
    int mask52;
    int d32;
    int srcPix32;
    int destPix42;
    int sourceWord7;
    int destWord7;
    int sourcePix7;
    int i8;
    int sourceWord8;
    int destWord8;
    int sourcePix8;
    int destPix9;
    int i9;
    int sourceWord9;
    int destWord9;
    int sourcePix9;
    int destPix10;
    int i10;
    int mask8;
    int d6;
    int srcPix6;
    int destPix13;
    int mask33;
    int d13;
    int srcPix13;
    int destPix23;
    int mask43;
    int d23;
    int srcPix23;
    int destPix33;
    int mask53;
    int d33;
    int srcPix33;
    int destPix43;
    int sourceWord10;
    int destWord10;
    int sourcePix10;
    int i11;
    int sourceWord11;
    int destWord11;
    int sourcePix11;
    int destPix14;
    int i12;

	srcPixPerWord = 32 / sourcePixSize;
	sourcePixMask = (((sourcePixSize < 0) ? ((unsigned) 1 >> -sourcePixSize) : ((unsigned) 1 << sourcePixSize))) - 1;
	destPixMask = (((destPixSize < 0) ? ((unsigned) 1 >> -destPixSize) : ((unsigned) 1 << destPixSize))) - 1;
	nullMap = colorMap == nilObj;
	sourceIndex = (sourceBits + 4) + (((sy * sourceRaster) + (sx / srcPixPerWord)) * 4);
	scrStartBits = srcPixPerWord - (sx & (srcPixPerWord - 1));
	if (bbW < scrStartBits) {
		nSourceIncs = 0;
	} else {
		nSourceIncs = ((bbW - scrStartBits) / srcPixPerWord) + 1;
	}
	sourceDelta = (sourceRaster - nSourceIncs) * 4;
	startBits = pixPerWord - (dx & (pixPerWord - 1));
	endBits = (((dx + bbW) - 1) & (pixPerWord - 1)) + 1;
	for (i = 1; i <= bbH; i += 1) {
		if (noHalftone) {
			halftoneWord = 4294967295;
		} else {
			halftoneWord = longAt(halftoneBase + ((((dy + i) - 1) % halftoneHeight) * 4));
		}
		srcBitIndex = (sx & (srcPixPerWord - 1)) * sourcePixSize;
		destMask = mask1;
		if (bbW < startBits) {
			/* begin pickSourcePixels:nullMap:srcMask:destMask: */
			nPix = bbW;
			if (sourcePixSize >= 16) {
				/* begin pickSourcePixelsRGB:nullMap:srcMask:destMask: */
				sourceWord = longAt(sourceIndex);
				destWord = 0;
				for (i1 = 1; i1 <= nPix; i1 += 1) {
					sourcePix = (((unsigned) sourceWord) >> ((32 - sourcePixSize) - srcBitIndex)) & sourcePixMask;
					if (nullMap) {
						if (sourcePixSize == 16) {
							/* begin rgbMap:from:to: */
							if ((d = 8 - 5) > 0) {
								mask = (1 << 5) - 1;
								srcPix = sourcePix << d;
								mask = mask << d;
								destPix1 = srcPix & mask;
								mask = mask << 8;
								srcPix = srcPix << d;
								destPix = (destPix1 + (srcPix & mask)) + ((srcPix << d) & (mask << 8));
								goto l6;
							} else {
								if (d == 0) {
									destPix = sourcePix;
									goto l6;
								}
								d = 5 - 8;
								mask = (1 << 8) - 1;
								srcPix = ((unsigned) sourcePix) >> d;
								destPix1 = srcPix & mask;
								mask = mask << 8;
								srcPix = ((unsigned) srcPix) >> d;
								destPix = (destPix1 + (srcPix & mask)) + ((((unsigned) srcPix) >> d) & (mask << 8));
								goto l6;
							}
						l6:	/* end rgbMap:from:to: */;
						} else {
							/* begin rgbMap:from:to: */
							if ((d1 = 5 - 8) > 0) {
								mask3 = (1 << 8) - 1;
								srcPix1 = sourcePix << d1;
								mask3 = mask3 << d1;
								destPix2 = srcPix1 & mask3;
								mask3 = mask3 << 5;
								srcPix1 = srcPix1 << d1;
								destPix = (destPix2 + (srcPix1 & mask3)) + ((srcPix1 << d1) & (mask3 << 5));
								goto l7;
							} else {
								if (d1 == 0) {
									destPix = sourcePix;
									goto l7;
								}
								d1 = 8 - 5;
								mask3 = (1 << 5) - 1;
								srcPix1 = ((unsigned) sourcePix) >> d1;
								destPix2 = srcPix1 & mask3;
								mask3 = mask3 << 5;
								srcPix1 = ((unsigned) srcPix1) >> d1;
								destPix = (destPix2 + (srcPix1 & mask3)) + ((((unsigned) srcPix1) >> d1) & (mask3 << 5));
								goto l7;
							}
						l7:	/* end rgbMap:from:to: */;
						}
					} else {
						if (sourcePixSize == 16) {
							/* begin rgbMap:from:to: */
							if ((d2 = cmBitsPerColor - 5) > 0) {
								mask4 = (1 << 5) - 1;
								srcPix2 = sourcePix << d2;
								mask4 = mask4 << d2;
								destPix3 = srcPix2 & mask4;
								mask4 = mask4 << cmBitsPerColor;
								srcPix2 = srcPix2 << d2;
								sourcePix = (destPix3 + (srcPix2 & mask4)) + ((srcPix2 << d2) & (mask4 << cmBitsPerColor));
								goto l8;
							} else {
								if (d2 == 0) {
									sourcePix = sourcePix;
									goto l8;
								}
								d2 = 5 - cmBitsPerColor;
								mask4 = (1 << cmBitsPerColor) - 1;
								srcPix2 = ((unsigned) sourcePix) >> d2;
								destPix3 = srcPix2 & mask4;
								mask4 = mask4 << cmBitsPerColor;
								srcPix2 = ((unsigned) srcPix2) >> d2;
								sourcePix = (destPix3 + (srcPix2 & mask4)) + ((((unsigned) srcPix2) >> d2) & (mask4 << cmBitsPerColor));
								goto l8;
							}
						l8:	/* end rgbMap:from:to: */;
						} else {
							/* begin rgbMap:from:to: */
							if ((d3 = cmBitsPerColor - 8) > 0) {
								mask5 = (1 << 8) - 1;
								srcPix3 = sourcePix << d3;
								mask5 = mask5 << d3;
								destPix4 = srcPix3 & mask5;
								mask5 = mask5 << cmBitsPerColor;
								srcPix3 = srcPix3 << d3;
								sourcePix = (destPix4 + (srcPix3 & mask5)) + ((srcPix3 << d3) & (mask5 << cmBitsPerColor));
								goto l9;
							} else {
								if (d3 == 0) {
									sourcePix = sourcePix;
									goto l9;
								}
								d3 = 8 - cmBitsPerColor;
								mask5 = (1 << cmBitsPerColor) - 1;
								srcPix3 = ((unsigned) sourcePix) >> d3;
								destPix4 = srcPix3 & mask5;
								mask5 = mask5 << cmBitsPerColor;
								srcPix3 = ((unsigned) srcPix3) >> d3;
								sourcePix = (destPix4 + (srcPix3 & mask5)) + ((((unsigned) srcPix3) >> d3) & (mask5 << cmBitsPerColor));
								goto l9;
							}
						l9:	/* end rgbMap:from:to: */;
						}
						destPix = (longAt((colorMap + 4) + (sourcePix * 4))) & destPixMask;
					}
					destWord = (destWord << destPixSize) | destPix;
					if ((srcBitIndex = srcBitIndex + sourcePixSize) > 31) {
						srcBitIndex = srcBitIndex - 32;
						sourceIndex = sourceIndex + 4;
						sourceWord = longAt(sourceIndex);
					}
				}
				skewWord = destWord;
				goto l1;
			}
			if (nullMap) {
				/* begin pickSourcePixelsNullMap:srcMask:destMask: */
				sourceWord1 = longAt(sourceIndex);
				destWord1 = 0;
				for (i2 = 1; i2 <= nPix; i2 += 1) {
					sourcePix1 = (((unsigned) sourceWord1) >> ((32 - sourcePixSize) - srcBitIndex)) & sourcePixMask;
					destWord1 = (destWord1 << destPixSize) | (sourcePix1 & destPixMask);
					if ((srcBitIndex = srcBitIndex + sourcePixSize) > 31) {
						srcBitIndex = srcBitIndex - 32;
						sourceIndex = sourceIndex + 4;
						sourceWord1 = longAt(sourceIndex);
					}
				}
				skewWord = destWord1;
				goto l1;
			}
			/* begin pickSourcePixels:srcMask:destMask: */
			sourceWord2 = longAt(sourceIndex);
			destWord2 = 0;
			for (i3 = 1; i3 <= nPix; i3 += 1) {
				sourcePix2 = (((unsigned) sourceWord2) >> ((32 - sourcePixSize) - srcBitIndex)) & sourcePixMask;
				destPix5 = (longAt((colorMap + 4) + (sourcePix2 * 4))) & destPixMask;
				destWord2 = (destWord2 << destPixSize) | destPix5;
				if ((srcBitIndex = srcBitIndex + sourcePixSize) > 31) {
					srcBitIndex = srcBitIndex - 32;
					sourceIndex = sourceIndex + 4;
					sourceWord2 = longAt(sourceIndex);
				}
			}
			skewWord = destWord2;
		l1:	/* end pickSourcePixels:nullMap:srcMask:destMask: */;
			skewWord = ((((startBits - bbW) * destPixSize) < 0) ? ((unsigned) skewWord >> -((startBits - bbW) * destPixSize)) : ((unsigned) skewWord << ((startBits - bbW) * destPixSize)));
		} else {
			/* begin pickSourcePixels:nullMap:srcMask:destMask: */
			if (sourcePixSize >= 16) {
				/* begin pickSourcePixelsRGB:nullMap:srcMask:destMask: */
				sourceWord3 = longAt(sourceIndex);
				destWord3 = 0;
				for (i4 = 1; i4 <= startBits; i4 += 1) {
					sourcePix3 = (((unsigned) sourceWord3) >> ((32 - sourcePixSize) - srcBitIndex)) & sourcePixMask;
					if (nullMap) {
						if (sourcePixSize == 16) {
							/* begin rgbMap:from:to: */
							if ((d4 = 8 - 5) > 0) {
								mask6 = (1 << 5) - 1;
								srcPix4 = sourcePix3 << d4;
								mask6 = mask6 << d4;
								destPix11 = srcPix4 & mask6;
								mask6 = mask6 << 8;
								srcPix4 = srcPix4 << d4;
								destPix6 = (destPix11 + (srcPix4 & mask6)) + ((srcPix4 << d4) & (mask6 << 8));
								goto l10;
							} else {
								if (d4 == 0) {
									destPix6 = sourcePix3;
									goto l10;
								}
								d4 = 5 - 8;
								mask6 = (1 << 8) - 1;
								srcPix4 = ((unsigned) sourcePix3) >> d4;
								destPix11 = srcPix4 & mask6;
								mask6 = mask6 << 8;
								srcPix4 = ((unsigned) srcPix4) >> d4;
								destPix6 = (destPix11 + (srcPix4 & mask6)) + ((((unsigned) srcPix4) >> d4) & (mask6 << 8));
								goto l10;
							}
						l10:	/* end rgbMap:from:to: */;
						} else {
							/* begin rgbMap:from:to: */
							if ((d11 = 5 - 8) > 0) {
								mask31 = (1 << 8) - 1;
								srcPix11 = sourcePix3 << d11;
								mask31 = mask31 << d11;
								destPix21 = srcPix11 & mask31;
								mask31 = mask31 << 5;
								srcPix11 = srcPix11 << d11;
								destPix6 = (destPix21 + (srcPix11 & mask31)) + ((srcPix11 << d11) & (mask31 << 5));
								goto l11;
							} else {
								if (d11 == 0) {
									destPix6 = sourcePix3;
									goto l11;
								}
								d11 = 8 - 5;
								mask31 = (1 << 5) - 1;
								srcPix11 = ((unsigned) sourcePix3) >> d11;
								destPix21 = srcPix11 & mask31;
								mask31 = mask31 << 5;
								srcPix11 = ((unsigned) srcPix11) >> d11;
								destPix6 = (destPix21 + (srcPix11 & mask31)) + ((((unsigned) srcPix11) >> d11) & (mask31 << 5));
								goto l11;
							}
						l11:	/* end rgbMap:from:to: */;
						}
					} else {
						if (sourcePixSize == 16) {
							/* begin rgbMap:from:to: */
							if ((d21 = cmBitsPerColor - 5) > 0) {
								mask41 = (1 << 5) - 1;
								srcPix21 = sourcePix3 << d21;
								mask41 = mask41 << d21;
								destPix31 = srcPix21 & mask41;
								mask41 = mask41 << cmBitsPerColor;
								srcPix21 = srcPix21 << d21;
								sourcePix3 = (destPix31 + (srcPix21 & mask41)) + ((srcPix21 << d21) & (mask41 << cmBitsPerColor));
								goto l12;
							} else {
								if (d21 == 0) {
									sourcePix3 = sourcePix3;
									goto l12;
								}
								d21 = 5 - cmBitsPerColor;
								mask41 = (1 << cmBitsPerColor) - 1;
								srcPix21 = ((unsigned) sourcePix3) >> d21;
								destPix31 = srcPix21 & mask41;
								mask41 = mask41 << cmBitsPerColor;
								srcPix21 = ((unsigned) srcPix21) >> d21;
								sourcePix3 = (destPix31 + (srcPix21 & mask41)) + ((((unsigned) srcPix21) >> d21) & (mask41 << cmBitsPerColor));
								goto l12;
							}
						l12:	/* end rgbMap:from:to: */;
						} else {
							/* begin rgbMap:from:to: */
							if ((d31 = cmBitsPerColor - 8) > 0) {
								mask51 = (1 << 8) - 1;
								srcPix31 = sourcePix3 << d31;
								mask51 = mask51 << d31;
								destPix41 = srcPix31 & mask51;
								mask51 = mask51 << cmBitsPerColor;
								srcPix31 = srcPix31 << d31;
								sourcePix3 = (destPix41 + (srcPix31 & mask51)) + ((srcPix31 << d31) & (mask51 << cmBitsPerColor));
								goto l13;
							} else {
								if (d31 == 0) {
									sourcePix3 = sourcePix3;
									goto l13;
								}
								d31 = 8 - cmBitsPerColor;
								mask51 = (1 << cmBitsPerColor) - 1;
								srcPix31 = ((unsigned) sourcePix3) >> d31;
								destPix41 = srcPix31 & mask51;
								mask51 = mask51 << cmBitsPerColor;
								srcPix31 = ((unsigned) srcPix31) >> d31;
								sourcePix3 = (destPix41 + (srcPix31 & mask51)) + ((((unsigned) srcPix31) >> d31) & (mask51 << cmBitsPerColor));
								goto l13;
							}
						l13:	/* end rgbMap:from:to: */;
						}
						destPix6 = (longAt((colorMap + 4) + (sourcePix3 * 4))) & destPixMask;
					}
					destWord3 = (destWord3 << destPixSize) | destPix6;
					if ((srcBitIndex = srcBitIndex + sourcePixSize) > 31) {
						srcBitIndex = srcBitIndex - 32;
						sourceIndex = sourceIndex + 4;
						sourceWord3 = longAt(sourceIndex);
					}
				}
				skewWord = destWord3;
				goto l2;
			}
			if (nullMap) {
				/* begin pickSourcePixelsNullMap:srcMask:destMask: */
				sourceWord4 = longAt(sourceIndex);
				destWord4 = 0;
				for (i5 = 1; i5 <= startBits; i5 += 1) {
					sourcePix4 = (((unsigned) sourceWord4) >> ((32 - sourcePixSize) - srcBitIndex)) & sourcePixMask;
					destWord4 = (destWord4 << destPixSize) | (sourcePix4 & destPixMask);
					if ((srcBitIndex = srcBitIndex + sourcePixSize) > 31) {
						srcBitIndex = srcBitIndex - 32;
						sourceIndex = sourceIndex + 4;
						sourceWord4 = longAt(sourceIndex);
					}
				}
				skewWord = destWord4;
				goto l2;
			}
			/* begin pickSourcePixels:srcMask:destMask: */
			sourceWord5 = longAt(sourceIndex);
			destWord5 = 0;
			for (i6 = 1; i6 <= startBits; i6 += 1) {
				sourcePix5 = (((unsigned) sourceWord5) >> ((32 - sourcePixSize) - srcBitIndex)) & sourcePixMask;
				destPix7 = (longAt((colorMap + 4) + (sourcePix5 * 4))) & destPixMask;
				destWord5 = (destWord5 << destPixSize) | destPix7;
				if ((srcBitIndex = srcBitIndex + sourcePixSize) > 31) {
					srcBitIndex = srcBitIndex - 32;
					sourceIndex = sourceIndex + 4;
					sourceWord5 = longAt(sourceIndex);
				}
			}
			skewWord = destWord5;
		l2:	/* end pickSourcePixels:nullMap:srcMask:destMask: */;
		}
		for (word = 1; word <= nWords; word += 1) {
			/* begin merge:with: */
			destinationWord = (longAt(destIndex)) & destMask;
			if (combinationRule < 16) {
				if (combinationRule < 8) {
					if (combinationRule < 4) {
						if (combinationRule < 2) {
							if (combinationRule < 1) {
								mergeWord = 0;
								goto l5;
							} else {
								mergeWord = (skewWord & halftoneWord) & destinationWord;
								goto l5;
							}
						} else {
							if (combinationRule < 3) {
								mergeWord = (skewWord & halftoneWord) & (~destinationWord);
								goto l5;
							} else {
								mergeWord = skewWord & halftoneWord;
								goto l5;
							}
						}
					} else {
						if (combinationRule < 6) {
							if (combinationRule < 5) {
								mergeWord = (~(skewWord & halftoneWord)) & destinationWord;
								goto l5;
							} else {
								mergeWord = destinationWord;
								goto l5;
							}
						} else {
							if (combinationRule < 7) {
								mergeWord = (skewWord & halftoneWord) ^ destinationWord;
								goto l5;
							} else {
								mergeWord = (skewWord & halftoneWord) | destinationWord;
								goto l5;
							}
						}
					}
				} else {
					if (combinationRule < 12) {
						if (combinationRule < 10) {
							if (combinationRule < 9) {
								mergeWord = (~(skewWord & halftoneWord)) & (~destinationWord);
								goto l5;
							} else {
								mergeWord = (~(skewWord & halftoneWord)) ^ destinationWord;
								goto l5;
							}
						} else {
							if (combinationRule < 11) {
								mergeWord = ~destinationWord;
								goto l5;
							} else {
								mergeWord = (skewWord & halftoneWord) | (~destinationWord);
								goto l5;
							}
						}
					} else {
						if (combinationRule < 14) {
							if (combinationRule < 13) {
								mergeWord = ~(skewWord & halftoneWord);
								goto l5;
							} else {
								mergeWord = (~(skewWord & halftoneWord)) | destinationWord;
								goto l5;
							}
						} else {
							if (combinationRule < 15) {
								mergeWord = (~(skewWord & halftoneWord)) | (~destinationWord);
								goto l5;
							} else {
								mergeWord = destinationWord;
								goto l5;
							}
						}
					}
				}
			} else {
				if (combinationRule < 24) {
					if (combinationRule < 20) {
						if (combinationRule < 18) {
							if (combinationRule < 17) {
								mergeWord = destinationWord;
								goto l5;
							} else {
								mergeWord = destinationWord;
								goto l5;
							}
						} else {
							if (combinationRule < 19) {
								mergeWord = (skewWord & halftoneWord) + destinationWord;
								goto l5;
							} else {
								mergeWord = (skewWord & halftoneWord) - destinationWord;
								goto l5;
							}
						}
					} else {
						if (combinationRule < 22) {
							if (combinationRule < 21) {
								mergeWord = rgbAddwith(skewWord & halftoneWord, destinationWord);
								goto l5;
							} else {
								mergeWord = rgbSubwith(skewWord & halftoneWord, destinationWord);
								goto l5;
							}
						} else {
							if (combinationRule < 23) {
								mergeWord = rgbDiffwith(skewWord & halftoneWord, destinationWord);
								goto l5;
							} else {
								mergeWord = tallyIntoMap(destinationWord);
								goto l5;
							}
						}
					}
				} else {
					if (combinationRule < 28) {
						if (combinationRule < 26) {
							if (combinationRule < 25) {
								mergeWord = alphaBlendwith(skewWord & halftoneWord, destinationWord);
								goto l5;
							} else {
								mergeWord = pixPaintwith(skewWord & halftoneWord, destinationWord);
								goto l5;
							}
						} else {
							if (combinationRule < 27) {
								mergeWord = pixMaskwith(skewWord & halftoneWord, destinationWord);
								goto l5;
							} else {
								mergeWord = destinationWord;
								goto l5;
							}
						}
					} else {
						if (combinationRule < 30) {
							if (combinationRule < 29) {
								mergeWord = destinationWord;
								goto l5;
							} else {
								mergeWord = destinationWord;
								goto l5;
							}
						} else {
							if (combinationRule < 31) {
								mergeWord = destinationWord;
								goto l5;
							} else {
								mergeWord = destinationWord;
								goto l5;
							}
						}
					}
				}
			}
		l5:	/* end merge:with: */;
			longAtput(destIndex, (destMask & mergeWord) | ((~destMask) & (longAt(destIndex))));
			destIndex = destIndex + 4;
			if (word >= (nWords - 1)) {
				if (!(word == nWords)) {
					destMask = mask2;
					/* begin pickSourcePixels:nullMap:srcMask:destMask: */
					if (sourcePixSize >= 16) {
						/* begin pickSourcePixelsRGB:nullMap:srcMask:destMask: */
						sourceWord6 = longAt(sourceIndex);
						destWord6 = 0;
						for (i7 = 1; i7 <= endBits; i7 += 1) {
							sourcePix6 = (((unsigned) sourceWord6) >> ((32 - sourcePixSize) - srcBitIndex)) & sourcePixMask;
							if (nullMap) {
								if (sourcePixSize == 16) {
									/* begin rgbMap:from:to: */
									if ((d5 = 8 - 5) > 0) {
										mask7 = (1 << 5) - 1;
										srcPix5 = sourcePix6 << d5;
										mask7 = mask7 << d5;
										destPix12 = srcPix5 & mask7;
										mask7 = mask7 << 8;
										srcPix5 = srcPix5 << d5;
										destPix8 = (destPix12 + (srcPix5 & mask7)) + ((srcPix5 << d5) & (mask7 << 8));
										goto l14;
									} else {
										if (d5 == 0) {
											destPix8 = sourcePix6;
											goto l14;
										}
										d5 = 5 - 8;
										mask7 = (1 << 8) - 1;
										srcPix5 = ((unsigned) sourcePix6) >> d5;
										destPix12 = srcPix5 & mask7;
										mask7 = mask7 << 8;
										srcPix5 = ((unsigned) srcPix5) >> d5;
										destPix8 = (destPix12 + (srcPix5 & mask7)) + ((((unsigned) srcPix5) >> d5) & (mask7 << 8));
										goto l14;
									}
								l14:	/* end rgbMap:from:to: */;
								} else {
									/* begin rgbMap:from:to: */
									if ((d12 = 5 - 8) > 0) {
										mask32 = (1 << 8) - 1;
										srcPix12 = sourcePix6 << d12;
										mask32 = mask32 << d12;
										destPix22 = srcPix12 & mask32;
										mask32 = mask32 << 5;
										srcPix12 = srcPix12 << d12;
										destPix8 = (destPix22 + (srcPix12 & mask32)) + ((srcPix12 << d12) & (mask32 << 5));
										goto l15;
									} else {
										if (d12 == 0) {
											destPix8 = sourcePix6;
											goto l15;
										}
										d12 = 8 - 5;
										mask32 = (1 << 5) - 1;
										srcPix12 = ((unsigned) sourcePix6) >> d12;
										destPix22 = srcPix12 & mask32;
										mask32 = mask32 << 5;
										srcPix12 = ((unsigned) srcPix12) >> d12;
										destPix8 = (destPix22 + (srcPix12 & mask32)) + ((((unsigned) srcPix12) >> d12) & (mask32 << 5));
										goto l15;
									}
								l15:	/* end rgbMap:from:to: */;
								}
							} else {
								if (sourcePixSize == 16) {
									/* begin rgbMap:from:to: */
									if ((d22 = cmBitsPerColor - 5) > 0) {
										mask42 = (1 << 5) - 1;
										srcPix22 = sourcePix6 << d22;
										mask42 = mask42 << d22;
										destPix32 = srcPix22 & mask42;
										mask42 = mask42 << cmBitsPerColor;
										srcPix22 = srcPix22 << d22;
										sourcePix6 = (destPix32 + (srcPix22 & mask42)) + ((srcPix22 << d22) & (mask42 << cmBitsPerColor));
										goto l16;
									} else {
										if (d22 == 0) {
											sourcePix6 = sourcePix6;
											goto l16;
										}
										d22 = 5 - cmBitsPerColor;
										mask42 = (1 << cmBitsPerColor) - 1;
										srcPix22 = ((unsigned) sourcePix6) >> d22;
										destPix32 = srcPix22 & mask42;
										mask42 = mask42 << cmBitsPerColor;
										srcPix22 = ((unsigned) srcPix22) >> d22;
										sourcePix6 = (destPix32 + (srcPix22 & mask42)) + ((((unsigned) srcPix22) >> d22) & (mask42 << cmBitsPerColor));
										goto l16;
									}
								l16:	/* end rgbMap:from:to: */;
								} else {
									/* begin rgbMap:from:to: */
									if ((d32 = cmBitsPerColor - 8) > 0) {
										mask52 = (1 << 8) - 1;
										srcPix32 = sourcePix6 << d32;
										mask52 = mask52 << d32;
										destPix42 = srcPix32 & mask52;
										mask52 = mask52 << cmBitsPerColor;
										srcPix32 = srcPix32 << d32;
										sourcePix6 = (destPix42 + (srcPix32 & mask52)) + ((srcPix32 << d32) & (mask52 << cmBitsPerColor));
										goto l17;
									} else {
										if (d32 == 0) {
											sourcePix6 = sourcePix6;
											goto l17;
										}
										d32 = 8 - cmBitsPerColor;
										mask52 = (1 << cmBitsPerColor) - 1;
										srcPix32 = ((unsigned) sourcePix6) >> d32;
										destPix42 = srcPix32 & mask52;
										mask52 = mask52 << cmBitsPerColor;
										srcPix32 = ((unsigned) srcPix32) >> d32;
										sourcePix6 = (destPix42 + (srcPix32 & mask52)) + ((((unsigned) srcPix32) >> d32) & (mask52 << cmBitsPerColor));
										goto l17;
									}
								l17:	/* end rgbMap:from:to: */;
								}
								destPix8 = (longAt((colorMap + 4) + (sourcePix6 * 4))) & destPixMask;
							}
							destWord6 = (destWord6 << destPixSize) | destPix8;
							if ((srcBitIndex = srcBitIndex + sourcePixSize) > 31) {
								srcBitIndex = srcBitIndex - 32;
								sourceIndex = sourceIndex + 4;
								sourceWord6 = longAt(sourceIndex);
							}
						}
						skewWord = destWord6;
						goto l3;
					}
					if (nullMap) {
						/* begin pickSourcePixelsNullMap:srcMask:destMask: */
						sourceWord7 = longAt(sourceIndex);
						destWord7 = 0;
						for (i8 = 1; i8 <= endBits; i8 += 1) {
							sourcePix7 = (((unsigned) sourceWord7) >> ((32 - sourcePixSize) - srcBitIndex)) & sourcePixMask;
							destWord7 = (destWord7 << destPixSize) | (sourcePix7 & destPixMask);
							if ((srcBitIndex = srcBitIndex + sourcePixSize) > 31) {
								srcBitIndex = srcBitIndex - 32;
								sourceIndex = sourceIndex + 4;
								sourceWord7 = longAt(sourceIndex);
							}
						}
						skewWord = destWord7;
						goto l3;
					}
					/* begin pickSourcePixels:srcMask:destMask: */
					sourceWord8 = longAt(sourceIndex);
					destWord8 = 0;
					for (i9 = 1; i9 <= endBits; i9 += 1) {
						sourcePix8 = (((unsigned) sourceWord8) >> ((32 - sourcePixSize) - srcBitIndex)) & sourcePixMask;
						destPix9 = (longAt((colorMap + 4) + (sourcePix8 * 4))) & destPixMask;
						destWord8 = (destWord8 << destPixSize) | destPix9;
						if ((srcBitIndex = srcBitIndex + sourcePixSize) > 31) {
							srcBitIndex = srcBitIndex - 32;
							sourceIndex = sourceIndex + 4;
							sourceWord8 = longAt(sourceIndex);
						}
					}
					skewWord = destWord8;
				l3:	/* end pickSourcePixels:nullMap:srcMask:destMask: */;
					skewWord = ((((pixPerWord - endBits) * destPixSize) < 0) ? ((unsigned) skewWord >> -((pixPerWord - endBits) * destPixSize)) : ((unsigned) skewWord << ((pixPerWord - endBits) * destPixSize)));
				}
			} else {
				destMask = 4294967295;
				/* begin pickSourcePixels:nullMap:srcMask:destMask: */
				nPix1 = pixPerWord;
				if (sourcePixSize >= 16) {
					/* begin pickSourcePixelsRGB:nullMap:srcMask:destMask: */
					sourceWord9 = longAt(sourceIndex);
					destWord9 = 0;
					for (i10 = 1; i10 <= nPix1; i10 += 1) {
						sourcePix9 = (((unsigned) sourceWord9) >> ((32 - sourcePixSize) - srcBitIndex)) & sourcePixMask;
						if (nullMap) {
							if (sourcePixSize == 16) {
								/* begin rgbMap:from:to: */
								if ((d6 = 8 - 5) > 0) {
									mask8 = (1 << 5) - 1;
									srcPix6 = sourcePix9 << d6;
									mask8 = mask8 << d6;
									destPix13 = srcPix6 & mask8;
									mask8 = mask8 << 8;
									srcPix6 = srcPix6 << d6;
									destPix10 = (destPix13 + (srcPix6 & mask8)) + ((srcPix6 << d6) & (mask8 << 8));
									goto l18;
								} else {
									if (d6 == 0) {
										destPix10 = sourcePix9;
										goto l18;
									}
									d6 = 5 - 8;
									mask8 = (1 << 8) - 1;
									srcPix6 = ((unsigned) sourcePix9) >> d6;
									destPix13 = srcPix6 & mask8;
									mask8 = mask8 << 8;
									srcPix6 = ((unsigned) srcPix6) >> d6;
									destPix10 = (destPix13 + (srcPix6 & mask8)) + ((((unsigned) srcPix6) >> d6) & (mask8 << 8));
									goto l18;
								}
							l18:	/* end rgbMap:from:to: */;
							} else {
								/* begin rgbMap:from:to: */
								if ((d13 = 5 - 8) > 0) {
									mask33 = (1 << 8) - 1;
									srcPix13 = sourcePix9 << d13;
									mask33 = mask33 << d13;
									destPix23 = srcPix13 & mask33;
									mask33 = mask33 << 5;
									srcPix13 = srcPix13 << d13;
									destPix10 = (destPix23 + (srcPix13 & mask33)) + ((srcPix13 << d13) & (mask33 << 5));
									goto l19;
								} else {
									if (d13 == 0) {
										destPix10 = sourcePix9;
										goto l19;
									}
									d13 = 8 - 5;
									mask33 = (1 << 5) - 1;
									srcPix13 = ((unsigned) sourcePix9) >> d13;
									destPix23 = srcPix13 & mask33;
									mask33 = mask33 << 5;
									srcPix13 = ((unsigned) srcPix13) >> d13;
									destPix10 = (destPix23 + (srcPix13 & mask33)) + ((((unsigned) srcPix13) >> d13) & (mask33 << 5));
									goto l19;
								}
							l19:	/* end rgbMap:from:to: */;
							}
						} else {
							if (sourcePixSize == 16) {
								/* begin rgbMap:from:to: */
								if ((d23 = cmBitsPerColor - 5) > 0) {
									mask43 = (1 << 5) - 1;
									srcPix23 = sourcePix9 << d23;
									mask43 = mask43 << d23;
									destPix33 = srcPix23 & mask43;
									mask43 = mask43 << cmBitsPerColor;
									srcPix23 = srcPix23 << d23;
									sourcePix9 = (destPix33 + (srcPix23 & mask43)) + ((srcPix23 << d23) & (mask43 << cmBitsPerColor));
									goto l20;
								} else {
									if (d23 == 0) {
										sourcePix9 = sourcePix9;
										goto l20;
									}
									d23 = 5 - cmBitsPerColor;
									mask43 = (1 << cmBitsPerColor) - 1;
									srcPix23 = ((unsigned) sourcePix9) >> d23;
									destPix33 = srcPix23 & mask43;
									mask43 = mask43 << cmBitsPerColor;
									srcPix23 = ((unsigned) srcPix23) >> d23;
									sourcePix9 = (destPix33 + (srcPix23 & mask43)) + ((((unsigned) srcPix23) >> d23) & (mask43 << cmBitsPerColor));
									goto l20;
								}
							l20:	/* end rgbMap:from:to: */;
							} else {
								/* begin rgbMap:from:to: */
								if ((d33 = cmBitsPerColor - 8) > 0) {
									mask53 = (1 << 8) - 1;
									srcPix33 = sourcePix9 << d33;
									mask53 = mask53 << d33;
									destPix43 = srcPix33 & mask53;
									mask53 = mask53 << cmBitsPerColor;
									srcPix33 = srcPix33 << d33;
									sourcePix9 = (destPix43 + (srcPix33 & mask53)) + ((srcPix33 << d33) & (mask53 << cmBitsPerColor));
									goto l21;
								} else {
									if (d33 == 0) {
										sourcePix9 = sourcePix9;
										goto l21;
									}
									d33 = 8 - cmBitsPerColor;
									mask53 = (1 << cmBitsPerColor) - 1;
									srcPix33 = ((unsigned) sourcePix9) >> d33;
									destPix43 = srcPix33 & mask53;
									mask53 = mask53 << cmBitsPerColor;
									srcPix33 = ((unsigned) srcPix33) >> d33;
									sourcePix9 = (destPix43 + (srcPix33 & mask53)) + ((((unsigned) srcPix33) >> d33) & (mask53 << cmBitsPerColor));
									goto l21;
								}
							l21:	/* end rgbMap:from:to: */;
							}
							destPix10 = (longAt((colorMap + 4) + (sourcePix9 * 4))) & destPixMask;
						}
						destWord9 = (destWord9 << destPixSize) | destPix10;
						if ((srcBitIndex = srcBitIndex + sourcePixSize) > 31) {
							srcBitIndex = srcBitIndex - 32;
							sourceIndex = sourceIndex + 4;
							sourceWord9 = longAt(sourceIndex);
						}
					}
					skewWord = destWord9;
					goto l4;
				}
				if (nullMap) {
					/* begin pickSourcePixelsNullMap:srcMask:destMask: */
					sourceWord10 = longAt(sourceIndex);
					destWord10 = 0;
					for (i11 = 1; i11 <= nPix1; i11 += 1) {
						sourcePix10 = (((unsigned) sourceWord10) >> ((32 - sourcePixSize) - srcBitIndex)) & sourcePixMask;
						destWord10 = (destWord10 << destPixSize) | (sourcePix10 & destPixMask);
						if ((srcBitIndex = srcBitIndex + sourcePixSize) > 31) {
							srcBitIndex = srcBitIndex - 32;
							sourceIndex = sourceIndex + 4;
							sourceWord10 = longAt(sourceIndex);
						}
					}
					skewWord = destWord10;
					goto l4;
				}
				/* begin pickSourcePixels:srcMask:destMask: */
				sourceWord11 = longAt(sourceIndex);
				destWord11 = 0;
				for (i12 = 1; i12 <= nPix1; i12 += 1) {
					sourcePix11 = (((unsigned) sourceWord11) >> ((32 - sourcePixSize) - srcBitIndex)) & sourcePixMask;
					destPix14 = (longAt((colorMap + 4) + (sourcePix11 * 4))) & destPixMask;
					destWord11 = (destWord11 << destPixSize) | destPix14;
					if ((srcBitIndex = srcBitIndex + sourcePixSize) > 31) {
						srcBitIndex = srcBitIndex - 32;
						sourceIndex = sourceIndex + 4;
						sourceWord11 = longAt(sourceIndex);
					}
				}
				skewWord = destWord11;
			l4:	/* end pickSourcePixels:nullMap:srcMask:destMask: */;
			}
		}
		sourceIndex = sourceIndex + sourceDelta;
		destIndex = destIndex + destDelta;
	}
}

int cr(void) {
	printf("\n");
}

int createActualMessage(void) {
    int argumentArray;
    int message;
    int oop;
    int valuePointer;
    int fromIndex;
    int toIndex;
    int lastFrom;

	argumentArray = instantiateClassindexableSize(longAt((specialObjectsOop + 4) + (7 * 4)), argumentCount);
	/* begin pushRemappableOop: */
	remapBuffer[remapBufferCount = remapBufferCount + 1] = argumentArray;
	message = instantiateClassindexableSize(longAt((specialObjectsOop + 4) + (15 * 4)), 0);
	/* begin popRemappableOop */
	oop = remapBuffer[remapBufferCount];
	remapBufferCount = remapBufferCount - 1;
	argumentArray = oop;
	if (argumentArray < youngStart) {
		beRootIfOld(argumentArray);
	}
	/* begin storePointer:ofObject:withValue: */
	valuePointer = messageSelector;
	if (message < youngStart) {
		possibleRootStoreIntovalue(message, valuePointer);
	}
	longAtput((message + 4) + (0 * 4), valuePointer);
	/* begin storePointer:ofObject:withValue: */
	if (message < youngStart) {
		possibleRootStoreIntovalue(message, argumentArray);
	}
	longAtput((message + 4) + (1 * 4), argumentArray);
	/* begin transfer:fromIndex:ofObject:toIndex:ofObject: */
	fromIndex = (activeContext + 4) + (((((stackPointer - activeContext) - 4) / 4) - (argumentCount - 1)) * 4);
	toIndex = (argumentArray + 4) + (0 * 4);
	lastFrom = fromIndex + (argumentCount * 4);
	while (fromIndex < lastFrom) {
		longAtput(toIndex, longAt(fromIndex));
		fromIndex = fromIndex + 4;
		toIndex = toIndex + 4;
	}
	/* begin pop: */
	stackPointer = stackPointer - (argumentCount * 4);
	/* begin push: */
	longAtput(stackPointer = stackPointer + 4, message);
	argumentCount = 1;
}

int deltaFromtonSteps(int x1, int x2, int n) {
    int delta;

	delta = x2 - x1;
	if (delta > 0) {
		return (delta - 1) / n;
	} else {
		if (delta == 0) {
			return 0;
		} else {
			return (delta + 2) / n;
		}
	}
}

int destMaskAndPointerInit(void) {
    int startBits;
    int pixPerM1;
    int endBits;

	pixPerM1 = pixPerWord - 1;
	startBits = pixPerWord - (dx & pixPerM1);
	mask1 = ((unsigned) 4294967295) >> (32 - (startBits * destPixSize));
	endBits = (((dx + bbW) - 1) & pixPerM1) + 1;
	mask2 = 4294967295 << (32 - (endBits * destPixSize));
	if (bbW < startBits) {
		mask1 = mask1 & mask2;
		mask2 = 0;
		nWords = 1;
	} else {
		nWords = (((bbW - startBits) + pixPerM1) / pixPerWord) + 1;
	}
	hDir = vDir = 1;
	destIndex = (destBits + 4) + (((dy * destRaster) + (dx / pixPerWord)) * 4);
	destDelta = 4 * ((destRaster * vDir) - (nWords * hDir));
}

int drawLoopXY(int xDelta, int yDelta) {
    int dx1;
    int dy1;
    int px;
    int py;
    int P;
    int affL;
    int affR;
    int affT;
    int affB;
    int i;
    int objectPointer;
    int integerValue;
    int objectPointer1;
    int integerValue1;

	if (xDelta > 0) {
		dx1 = 1;
	} else {
		if (xDelta == 0) {
			dx1 = 0;
		} else {
			dx1 = -1;
		}
	}
	if (yDelta > 0) {
		dy1 = 1;
	} else {
		if (yDelta == 0) {
			dy1 = 0;
		} else {
			dy1 = -1;
		}
	}
	px = abs(yDelta);
	py = abs(xDelta);
	copyBits();
	affL = affectedL;
	affR = affectedR;
	affT = affectedT;
	affB = affectedB;
	if (py > px) {
		P = py / 2;
		for (i = 1; i <= py; i += 1) {
			destX = destX + dx1;
			if ((P = P - px) < 0) {
				destY = destY + dy1;
				P = P + py;
			}
			copyBits();
		}
	} else {
		P = px / 2;
		for (i = 1; i <= px; i += 1) {
			destY = destY + dy1;
			if ((P = P - py) < 0) {
				destX = destX + dx1;
				P = P + px;
			}
			copyBits();
		}
	}
	affectedL = ((affL < affectedL) ? affL : affectedL);
	affectedR = ((affR < affectedR) ? affectedR : affR);
	affectedT = ((affT < affectedT) ? affT : affectedT);
	affectedB = ((affB < affectedB) ? affectedB : affB);
	/* begin storeInteger:ofObject:withValue: */
	objectPointer = bitBltOop;
	integerValue = destX;
	if ((integerValue >= -1073741824) && (integerValue < 1073741824)) {
		longAtput((objectPointer + 4) + (4 * 4), ((integerValue << 1) | 1));
	} else {
		primitiveFail();
	}
	/* begin storeInteger:ofObject:withValue: */
	objectPointer1 = bitBltOop;
	integerValue1 = destY;
	if ((integerValue1 >= -1073741824) && (integerValue1 < 1073741824)) {
		longAtput((objectPointer1 + 4) + (5 * 4), ((integerValue1 << 1) | 1));
	} else {
		primitiveFail();
	}
}

int exchangeHashBitswith(int oop1, int oop2) {
    int hdr1;
    int hdr2;

	hdr1 = longAt(oop1);
	hdr2 = longAt(oop2);
	longAtput(oop1, (hdr1 & 3758227455) | (hdr2 & 536739840));
	longAtput(oop2, (hdr2 & 3758227455) | (hdr1 & 536739840));
}

int executeNewMethod(void) {
	if ((primitiveIndex == 0) || (!(primitiveResponse()))) {
		activateNewMethod();
		/* begin quickCheckForInterrupts */
		if ((interruptCheckCounter = interruptCheckCounter - 1) <= 0) {
			interruptCheckCounter = 1000;
			checkForInterrupts();
		}
	}
}

int externalSendSelectorargumentCount(int selector, int count) {
    int rcvrClass;
    int ccIndex;
    int hash;
    int probe;
    int p;

	messageSelector = selector;
	argumentCount = count;
	/* begin fetchClassOf: */
	if ((((longAt(stackPointer - (argumentCount * 4))) & 1) == 1)) {
		rcvrClass = longAt((specialObjectsOop + 4) + (5 * 4));
		goto l1;
	}
	ccIndex = ((((unsigned) (longAt(longAt(stackPointer - (argumentCount * 4))))) >> 12) & 31) - 1;
	if (ccIndex < 0) {
		rcvrClass = (longAt((longAt(stackPointer - (argumentCount * 4))) - 4)) & 4294967292;
		goto l1;
	} else {
		rcvrClass = longAt(((longAt((specialObjectsOop + 4) + (28 * 4))) + 4) + (ccIndex * 4));
		goto l1;
	}
l1:	/* end fetchClassOf: */;
	/* begin sendSelectorToClass: */
	/* begin findNewMethodInClass: */
	hash = ((unsigned) (messageSelector ^ rcvrClass)) >> 2;
	for (p = 0; p <= (3 - 1); p += 1) {
		probe = ((((unsigned) hash) >> p) & 511) + 1;
		if (((methodCache[probe]) == messageSelector) && ((methodCache[probe + 512]) == rcvrClass)) {
			newMethod = methodCache[(probe + 512) + 512];
			primitiveIndex = (((unsigned) (longAt((newMethod + 4) + (0 * 4)))) >> 1) & 511;
			goto l2;
		}
	}
	lookupMethodInClass(rcvrClass);
	mcProbe = (mcProbe + 1) % 3;
	probe = ((((unsigned) hash) >> (mcProbe * 3)) & 511) + 1;
	methodCache[probe] = messageSelector;
	methodCache[probe + 512] = rcvrClass;
	methodCache[(probe + 512) + 512] = newMethod;
l2:	/* end findNewMethodInClass: */;
	/* begin executeNewMethod */
	if ((primitiveIndex == 0) || (!(primitiveResponse()))) {
		activateNewMethod();
		/* begin quickCheckForInterrupts */
		if ((interruptCheckCounter = interruptCheckCounter - 1) <= 0) {
			interruptCheckCounter = 1000;
			checkForInterrupts();
		}
	}
}

int extraHeaderBytes(int oopOrChunk) {
    int type;

	type = (longAt(oopOrChunk)) & 3;
	if (type > 1) {
		return 0;
	}
	if (type == 1) {
		return 4;
	}
	if (type == 0) {
		return 8;
	}
}

int failed(void) {
	return !successFlag;
}

int failSpecialPrim(int primIndex) {
    int bytecode;
    int selectorIndex;
    int newReceiver;
    int rcvrClass;
    int ccIndex;
    int hash;
    int probe;
    int p;

	bytecode = byteAt(instructionPointer);
	if ((bytecode < 176) || (bytecode > 207)) {
		return primitiveFail();
	}
	selectorIndex = (bytecode - 176) * 2;
	messageSelector = longAt(((longAt((specialObjectsOop + 4) + (23 * 4))) + 4) + (selectorIndex * 4));
	argumentCount = ((longAt(((longAt((specialObjectsOop + 4) + (23 * 4))) + 4) + ((selectorIndex + 1) * 4))) >> 1);
	newReceiver = longAt(stackPointer - (argumentCount * 4));
	/* begin fetchClassOf: */
	if (((newReceiver & 1) == 1)) {
		rcvrClass = longAt((specialObjectsOop + 4) + (5 * 4));
		goto l1;
	}
	ccIndex = ((((unsigned) (longAt(newReceiver))) >> 12) & 31) - 1;
	if (ccIndex < 0) {
		rcvrClass = (longAt(newReceiver - 4)) & 4294967292;
		goto l1;
	} else {
		rcvrClass = longAt(((longAt((specialObjectsOop + 4) + (28 * 4))) + 4) + (ccIndex * 4));
		goto l1;
	}
l1:	/* end fetchClassOf: */;
	/* begin findNewMethodInClass: */
	hash = ((unsigned) (messageSelector ^ rcvrClass)) >> 2;
	for (p = 0; p <= (3 - 1); p += 1) {
		probe = ((((unsigned) hash) >> p) & 511) + 1;
		if (((methodCache[probe]) == messageSelector) && ((methodCache[probe + 512]) == rcvrClass)) {
			newMethod = methodCache[(probe + 512) + 512];
			primitiveIndex = (((unsigned) (longAt((newMethod + 4) + (0 * 4)))) >> 1) & 511;
			goto l2;
		}
	}
	lookupMethodInClass(rcvrClass);
	mcProbe = (mcProbe + 1) % 3;
	probe = ((((unsigned) hash) >> (mcProbe * 3)) & 511) + 1;
	methodCache[probe] = messageSelector;
	methodCache[probe + 512] = rcvrClass;
	methodCache[(probe + 512) + 512] = newMethod;
l2:	/* end findNewMethodInClass: */;
	if ((primitiveIndex > 37) && (primitiveIndex != primIndex)) {
		/* begin executeNewMethod */
		if ((primitiveIndex == 0) || (!(primitiveResponse()))) {
			activateNewMethod();
			/* begin quickCheckForInterrupts */
			if ((interruptCheckCounter = interruptCheckCounter - 1) <= 0) {
				interruptCheckCounter = 1000;
				checkForInterrupts();
			}
		}
	} else {
		activateNewMethod();
	}
}

void * fetchArrayofObject(int fieldIndex, int objectPointer) {
    int arrayOop;

	arrayOop = longAt((objectPointer + 4) + (fieldIndex * 4));
	return arrayValueOf(arrayOop);
}

int fetchByteofObject(int byteIndex, int objectPointer) {
	return byteAt((objectPointer + 4) + byteIndex);
}

int fetchClassOf(int oop) {
    int ccIndex;

	if (((oop & 1) == 1)) {
		return longAt((specialObjectsOop + 4) + (5 * 4));
	}
	ccIndex = ((((unsigned) (longAt(oop))) >> 12) & 31) - 1;
	if (ccIndex < 0) {
		return (longAt(oop - 4)) & 4294967292;
	} else {
		return longAt(((longAt((specialObjectsOop + 4) + (28 * 4))) + 4) + (ccIndex * 4));
	}
}

int fetchContextRegisters(void) {
    int m;

	m = longAt((activeContext + 4) + (3 * 4));
	if (((m & 1) == 1)) {
		theHomeContext = longAt((activeContext + 4) + (5 * 4));
		if (theHomeContext < youngStart) {
			beRootIfOld(theHomeContext);
		}
	} else {
		theHomeContext = activeContext;
	}
	receiver = longAt((theHomeContext + 4) + (5 * 4));
	method = longAt((theHomeContext + 4) + (3 * 4));
	instructionPointer = ((longAt((activeContext + 4) + (1 * 4))) >> 1);
	instructionPointer = ((method + instructionPointer) + 4) - 2;
	stackPointer = ((longAt((activeContext + 4) + (2 * 4))) >> 1);
	stackPointer = (activeContext + 4) + (((6 + stackPointer) - 1) * 4);
}

double fetchFloatofObject(int fieldIndex, int objectPointer) {
    int floatOop;
    int cl;
    int ccIndex;

	floatOop = longAt((objectPointer + 4) + (fieldIndex * 4));
	/* begin floatValueOf: */
	/* begin fetchClassOf: */
	if (((floatOop & 1) == 1)) {
		cl = longAt((specialObjectsOop + 4) + (5 * 4));
		goto l1;
	}
	ccIndex = ((((unsigned) (longAt(floatOop))) >> 12) & 31) - 1;
	if (ccIndex < 0) {
		cl = (longAt(floatOop - 4)) & 4294967292;
		goto l1;
	} else {
		cl = longAt(((longAt((specialObjectsOop + 4) + (28 * 4))) + 4) + (ccIndex * 4));
		goto l1;
	}
l1:	/* end fetchClassOf: */;
	/* begin success: */
	successFlag = (cl == (longAt((specialObjectsOop + 4) + (9 * 4)))) && successFlag;
	if (successFlag) {
		return floatAt(floatOop + 4);
	}
	return 0.0;
}

int fetchIntegerofObject(int fieldIndex, int objectPointer) {
    int intOop;

	intOop = longAt((objectPointer + 4) + (fieldIndex * 4));
	if (((intOop & 1) == 1)) {
		return (intOop >> 1);
	} else {
		primitiveFail();
		return 0;
	}
}

int fetchPointerofObject(int fieldIndex, int objectPointer) {
	return longAt((objectPointer + 4) + (fieldIndex * 4));
}

int fetchWordofObject(int wordIndex, int objectPointer) {
	return longAt((objectPointer + 4) + (wordIndex * 4));
}

int fetchWordLengthOf(int objectPointer) {
    int sz;
    int header;

	/* begin sizeBitsOf: */
	header = longAt(objectPointer);
	if ((header & 3) == 0) {
		sz = (longAt(objectPointer - 8)) & 4294967292;
		goto l1;
	} else {
		sz = header & 252;
		goto l1;
	}
l1:	/* end sizeBitsOf: */;
	return (sz - 4) / 4;
}

int fileRecordSize(void) {
	return sizeof(SQFile);
}

SQFile * fileValueOf(int objectPointer) {
    int fileIndex;
    int successValue;

	/* begin success: */
	successValue = (((((unsigned) (longAt(objectPointer))) >> 8) & 15) >= 8) && ((lengthOf(objectPointer)) == (fileRecordSize()));
	successFlag = successValue && successFlag;
	if (successFlag) {
		fileIndex = objectPointer + 4;
		return (SQFile *) fileIndex;
	} else {
		return null;
	}
}

int findClassOfMethodforReceiver(int meth, int rcvr) {
    int currClass;
    int classDict;
    int classDictSize;
    int methodArray;
    int i;
    int done;
    int ccIndex;
    int ccIndex1;

	/* begin fetchClassOf: */
	if (((rcvr & 1) == 1)) {
		currClass = longAt((specialObjectsOop + 4) + (5 * 4));
		goto l1;
	}
	ccIndex = ((((unsigned) (longAt(rcvr))) >> 12) & 31) - 1;
	if (ccIndex < 0) {
		currClass = (longAt(rcvr - 4)) & 4294967292;
		goto l1;
	} else {
		currClass = longAt(((longAt((specialObjectsOop + 4) + (28 * 4))) + 4) + (ccIndex * 4));
		goto l1;
	}
l1:	/* end fetchClassOf: */;
	done = false;
	while (!(done)) {
		classDict = longAt((currClass + 4) + (1 * 4));
		classDictSize = fetchWordLengthOf(classDict);
		methodArray = longAt((classDict + 4) + (1 * 4));
		i = 0;
		while (i < (classDictSize - 2)) {
			if (meth == (longAt((methodArray + 4) + (i * 4)))) {
				return currClass;
			}
			i = i + 1;
		}
		currClass = longAt((currClass + 4) + (0 * 4));
		done = currClass == nilObj;
	}
	/* begin fetchClassOf: */
	if (((rcvr & 1) == 1)) {
		return longAt((specialObjectsOop + 4) + (5 * 4));
	}
	ccIndex1 = ((((unsigned) (longAt(rcvr))) >> 12) & 31) - 1;
	if (ccIndex1 < 0) {
		return (longAt(rcvr - 4)) & 4294967292;
	} else {
		return longAt(((longAt((specialObjectsOop + 4) + (28 * 4))) + 4) + (ccIndex1 * 4));
	}
	return null;
}

int findNewMethodInClass(int class) {
    int hash;
    int probe;
    int p;

	hash = ((unsigned) (messageSelector ^ class)) >> 2;
	for (p = 0; p <= (3 - 1); p += 1) {
		probe = ((((unsigned) hash) >> p) & 511) + 1;
		if (((methodCache[probe]) == messageSelector) && ((methodCache[probe + 512]) == class)) {
			newMethod = methodCache[(probe + 512) + 512];
			primitiveIndex = (((unsigned) (longAt((newMethod + 4) + (0 * 4)))) >> 1) & 511;
			return null;
		}
	}
	lookupMethodInClass(class);
	mcProbe = (mcProbe + 1) % 3;
	probe = ((((unsigned) hash) >> (mcProbe * 3)) & 511) + 1;
	methodCache[probe] = messageSelector;
	methodCache[probe + 512] = class;
	methodCache[(probe + 512) + 512] = newMethod;
}

int findSelectorOfMethodforReceiver(int meth, int rcvr) {
    int currClass;
    int done;
    int classDict;
    int classDictSize;
    int methodArray;
    int i;
    int ccIndex;

	/* begin fetchClassOf: */
	if (((rcvr & 1) == 1)) {
		currClass = longAt((specialObjectsOop + 4) + (5 * 4));
		goto l1;
	}
	ccIndex = ((((unsigned) (longAt(rcvr))) >> 12) & 31) - 1;
	if (ccIndex < 0) {
		currClass = (longAt(rcvr - 4)) & 4294967292;
		goto l1;
	} else {
		currClass = longAt(((longAt((specialObjectsOop + 4) + (28 * 4))) + 4) + (ccIndex * 4));
		goto l1;
	}
l1:	/* end fetchClassOf: */;
	done = false;
	while (!(done)) {
		classDict = longAt((currClass + 4) + (1 * 4));
		classDictSize = fetchWordLengthOf(classDict);
		methodArray = longAt((classDict + 4) + (1 * 4));
		i = 0;
		while (i <= (classDictSize - 2)) {
			if (meth == (longAt((methodArray + 4) + (i * 4)))) {
				return longAt((classDict + 4) + ((i + 2) * 4));
			}
			i = i + 1;
		}
		currClass = longAt((currClass + 4) + (0 * 4));
		done = currClass == nilObj;
	}
	return longAt((specialObjectsOop + 4) + (20 * 4));
}

int firstAccessibleObject(void) {
    int obj;
    int chunk;
    int sz;
    int header;

	/* begin oopFromChunk: */
	chunk = startOfMemory();
	obj = chunk + (extraHeaderBytes(chunk));
	while (obj < endOfMemory) {
		if (!(((longAt(obj)) & 3) == 2)) {
			return obj;
		}
		/* begin objectAfter: */
		if (checkAssertions) {
			if (obj >= endOfMemory) {
				error("no objects after the end of memory");
			}
		}
		if (((longAt(obj)) & 3) == 2) {
			sz = (longAt(obj)) & 536870908;
		} else {
			/* begin sizeBitsOf: */
			header = longAt(obj);
			if ((header & 3) == 0) {
				sz = (longAt(obj - 8)) & 4294967292;
				goto l1;
			} else {
				sz = header & 252;
				goto l1;
			}
		l1:	/* end sizeBitsOf: */;
		}
		obj = (obj + sz) + (extraHeaderBytes(obj + sz));
	}
	error("heap is empty");
}

int firstObject(void) {
    int chunk;

	/* begin oopFromChunk: */
	chunk = startOfMemory();
	return chunk + (extraHeaderBytes(chunk));
}

int fixedFieldsOf(int instPointer) {
    int classPointer;
    int fmt;
    int ccIndex;

	/* begin fetchClassOf: */
	if (((instPointer & 1) == 1)) {
		classPointer = longAt((specialObjectsOop + 4) + (5 * 4));
		goto l1;
	}
	ccIndex = ((((unsigned) (longAt(instPointer))) >> 12) & 31) - 1;
	if (ccIndex < 0) {
		classPointer = (longAt(instPointer - 4)) & 4294967292;
		goto l1;
	} else {
		classPointer = longAt(((longAt((specialObjectsOop + 4) + (28 * 4))) + 4) + (ccIndex * 4));
		goto l1;
	}
l1:	/* end fetchClassOf: */;
	fmt = (longAt((classPointer + 4) + (2 * 4))) - 1;
	return ((((unsigned) fmt) >> 2) & 63) - 1;
}

int floatObjectOf(int f) {
    int newFloat;

	newFloat = instantiateSmallClasssizeInBytesfill(longAt((specialObjectsOop + 4) + (9 * 4)), 12, 0);
	floatAtput(newFloat + 4, f);
	return newFloat;
}

double floatValueOf(int floatOop) {
    int cl;
    int ccIndex;

	/* begin fetchClassOf: */
	if (((floatOop & 1) == 1)) {
		cl = longAt((specialObjectsOop + 4) + (5 * 4));
		goto l1;
	}
	ccIndex = ((((unsigned) (longAt(floatOop))) >> 12) & 31) - 1;
	if (ccIndex < 0) {
		cl = (longAt(floatOop - 4)) & 4294967292;
		goto l1;
	} else {
		cl = longAt(((longAt((specialObjectsOop + 4) + (28 * 4))) + 4) + (ccIndex * 4));
		goto l1;
	}
l1:	/* end fetchClassOf: */;
	/* begin success: */
	successFlag = (cl == (longAt((specialObjectsOop + 4) + (9 * 4)))) && successFlag;
	if (successFlag) {
		return floatAt(floatOop + 4);
	}
	return 0.0;
}

int formatOf(int oop) {
	return (((unsigned) (longAt(oop))) >> 8) & 15;
}

int formatOfClass(int classPointer) {
	return (longAt((classPointer + 4) + (2 * 4))) - 1;
}

int fullCompaction(void) {
	compStart = lowestFreeAfter(startOfMemory());
	if (compStart == freeBlock) {
		return initializeMemoryFirstFree(freeBlock);
	}
	while (compStart < freeBlock) {
		compStart = incCompBody();
	}
}

int fullDisplayUpdate(void) {
    int displayObj;
    int dispBits;
    int w;
    int h;
    int dispBitsIndex;
    int d;

	displayObj = longAt((specialObjectsOop + 4) + (14 * 4));
	if ((((((unsigned) (longAt(displayObj))) >> 8) & 15) <= 4) && ((lengthOf(displayObj)) >= 4)) {
		dispBits = longAt((displayObj + 4) + (0 * 4));
		w = fetchIntegerofObject(1, displayObj);
		h = fetchIntegerofObject(2, displayObj);
		d = fetchIntegerofObject(3, displayObj);
		dispBitsIndex = dispBits + 4;
		ioShowDisplay(dispBitsIndex, w, h, d, 0, w, 0, h);
	}
}

int fullGC(void) {
    int i;
    int oop;

	/* begin clearRootsTable */
	for (i = 1; i <= rootTableCount; i += 1) {
		oop = rootTable[i];
		longAtput(oop, (longAt(oop)) & 3221225471);
		rootTable[i] = 0;
	}
	rootTableCount = 0;
	youngStart = startOfMemory();
	markPhase();
	sweepPhase();
	/* begin fullCompaction */
	compStart = lowestFreeAfter(startOfMemory());
	if (compStart == freeBlock) {
		initializeMemoryFirstFree(freeBlock);
		goto l1;
	}
	while (compStart < freeBlock) {
		compStart = incCompBody();
	}
l1:	/* end fullCompaction */;
	allocationCount = 0;
	youngStart = freeBlock;
	/* begin postGCAction */
	if (activeContext < youngStart) {
		beRootIfOld(activeContext);
	}
	if (theHomeContext < youngStart) {
		beRootIfOld(theHomeContext);
	}
}

int fwdBlockGet(void) {
	fwdTableNext = fwdTableNext + 8;
	if (fwdTableNext <= fwdTableLast) {
		return fwdTableNext;
	} else {
		return null;
	}
}

int fwdBlockValidate(int addr) {
	if (!((addr > endOfMemory) && ((addr <= fwdTableNext) && ((addr & 3) == 0)))) {
		error("invalid fwd table entry");
	}
}

int fwdTableInit(void) {
	/* begin setSizeOfFree:to: */
	longAtput(freeBlock, (4 & 536870908) | 2);
	endOfMemory = freeBlock + 4;
	/* begin setSizeOfFree:to: */
	longAtput(endOfMemory, (4 & 536870908) | 2);
	fwdTableNext = endOfMemory + 4;
	fwdTableLast = memoryLimit - 8;
	if (checkAssertions && ((fwdTableLast & 2147483648) != 0)) {
		error("fwd table must be in low half of the 32-bit address space");
	}
	return (fwdTableLast - fwdTableNext) / 8;
}

int getCurrentBytecode(void) {
	return byteAt(instructionPointer);
}

int hashBitsOf(int oop) {
	return (((unsigned) (longAt(oop))) >> 17) & 4095;
}

int headerOf(int methodPointer) {
	return longAt((methodPointer + 4) + (0 * 4));
}

int headerType(int oop) {
	return (longAt(oop)) & 3;
}

int ignoreSourceOrHalftone(int formPointer) {
	if (formPointer == nilObj) {
		return true;
	}
	if (combinationRule == 0) {
		return true;
	}
	if (combinationRule == 5) {
		return true;
	}
	if (combinationRule == 10) {
		return true;
	}
	if (combinationRule == 15) {
		return true;
	}
	return false;
}

int incCompBody(void) {
    int bytesFreed;
    int bytesFreed1;
    int oop;
    int fwdBlock;
    int newOop;
    int originalHeader;
    int originalHeaderType;
    int chunk;
    int oop1;
    int next;
    int fwdBlock1;
    int newOop1;
    int header;
    int bytesToMove;
    int firstWord;
    int lastWord;
    int w;
    int newFreeChunk;
    int sz;
    int header1;
    int chunk2;
    int chunk1;
    int header2;
    int fwdBlock2;
    int realHeader;
    int sz2;
    int sz1;
    int header11;
    int header3;
    int fwdBlock3;
    int realHeader1;
    int sz3;
    int sz11;
    int header12;

	fwdTableInit();
	/* begin incCompMakeFwd */
	bytesFreed1 = 0;
	/* begin oopFromChunk: */
	chunk = compStart;
	oop = chunk + (extraHeaderBytes(chunk));
	while (oop < endOfMemory) {
		if (((longAt(oop)) & 3) == 2) {
			bytesFreed1 = bytesFreed1 + ((longAt(oop)) & 536870908);
		} else {
			/* begin fwdBlockGet */
			fwdTableNext = fwdTableNext + 8;
			if (fwdTableNext <= fwdTableLast) {
				fwdBlock = fwdTableNext;
				goto l1;
			} else {
				fwdBlock = null;
				goto l1;
			}
		l1:	/* end fwdBlockGet */;
			if (fwdBlock == null) {
				compEnd = oop - (extraHeaderBytes(oop));
				bytesFreed = bytesFreed1;
				goto l2;
			}
			newOop = oop - bytesFreed1;
			/* begin initForwardBlock:mapping:to: */
			originalHeader = longAt(oop);
			if (checkAssertions) {
				if (fwdBlock == null) {
					error("ran out of forwarding blocks in become");
				}
				if ((originalHeader & 2147483648) != 0) {
					error("object already has a forwarding table entry");
				}
			}
			originalHeaderType = originalHeader & 3;
			longAtput(fwdBlock, newOop);
			longAtput(fwdBlock + 4, originalHeader);
			longAtput(oop, fwdBlock | (2147483648 | originalHeaderType));
		}
		/* begin objectAfterWhileForwarding: */
		header2 = longAt(oop);
		if ((header2 & 2147483648) == 0) {
			/* begin objectAfter: */
			if (checkAssertions) {
				if (oop >= endOfMemory) {
					error("no objects after the end of memory");
				}
			}
			if (((longAt(oop)) & 3) == 2) {
				sz1 = (longAt(oop)) & 536870908;
			} else {
				/* begin sizeBitsOf: */
				header11 = longAt(oop);
				if ((header11 & 3) == 0) {
					sz1 = (longAt(oop - 8)) & 4294967292;
					goto l4;
				} else {
					sz1 = header11 & 252;
					goto l4;
				}
			l4:	/* end sizeBitsOf: */;
			}
			oop = (oop + sz1) + (extraHeaderBytes(oop + sz1));
			goto l5;
		}
		fwdBlock2 = header2 & 2147483644;
		if (checkAssertions) {
			/* begin fwdBlockValidate: */
			if (!((fwdBlock2 > endOfMemory) && ((fwdBlock2 <= fwdTableNext) && ((fwdBlock2 & 3) == 0)))) {
				error("invalid fwd table entry");
			}
		}
		realHeader = longAt(fwdBlock2 + 4);
		if ((realHeader & 3) == 0) {
			sz2 = (longAt(oop - 8)) & 268435452;
		} else {
			sz2 = realHeader & 252;
		}
		oop = (oop + sz2) + (extraHeaderBytes(oop + sz2));
	l5:	/* end objectAfterWhileForwarding: */;
	}
	compEnd = endOfMemory;
	bytesFreed = bytesFreed1;
l2:	/* end incCompMakeFwd */;
	mapPointersInObjectsFromto(youngStart, endOfMemory);
	/* begin incCompMove: */
	newOop1 = null;
	/* begin oopFromChunk: */
	chunk1 = compStart;
	oop1 = chunk1 + (extraHeaderBytes(chunk1));
	while (oop1 < compEnd) {
		/* begin objectAfterWhileForwarding: */
		header3 = longAt(oop1);
		if ((header3 & 2147483648) == 0) {
			/* begin objectAfter: */
			if (checkAssertions) {
				if (oop1 >= endOfMemory) {
					error("no objects after the end of memory");
				}
			}
			if (((longAt(oop1)) & 3) == 2) {
				sz11 = (longAt(oop1)) & 536870908;
			} else {
				/* begin sizeBitsOf: */
				header12 = longAt(oop1);
				if ((header12 & 3) == 0) {
					sz11 = (longAt(oop1 - 8)) & 4294967292;
					goto l6;
				} else {
					sz11 = header12 & 252;
					goto l6;
				}
			l6:	/* end sizeBitsOf: */;
			}
			next = (oop1 + sz11) + (extraHeaderBytes(oop1 + sz11));
			goto l7;
		}
		fwdBlock3 = header3 & 2147483644;
		if (checkAssertions) {
			/* begin fwdBlockValidate: */
			if (!((fwdBlock3 > endOfMemory) && ((fwdBlock3 <= fwdTableNext) && ((fwdBlock3 & 3) == 0)))) {
				error("invalid fwd table entry");
			}
		}
		realHeader1 = longAt(fwdBlock3 + 4);
		if ((realHeader1 & 3) == 0) {
			sz3 = (longAt(oop1 - 8)) & 268435452;
		} else {
			sz3 = realHeader1 & 252;
		}
		next = (oop1 + sz3) + (extraHeaderBytes(oop1 + sz3));
	l7:	/* end objectAfterWhileForwarding: */;
		if (!(((longAt(oop1)) & 3) == 2)) {
			fwdBlock1 = (longAt(oop1)) & 2147483644;
			if (checkAssertions) {
				/* begin fwdBlockValidate: */
				if (!((fwdBlock1 > endOfMemory) && ((fwdBlock1 <= fwdTableNext) && ((fwdBlock1 & 3) == 0)))) {
					error("invalid fwd table entry");
				}
			}
			newOop1 = longAt(fwdBlock1);
			header = longAt(fwdBlock1 + 4);
			longAtput(oop1, header);
			bytesToMove = oop1 - newOop1;
			/* begin sizeBitsOf: */
			header1 = longAt(oop1);
			if ((header1 & 3) == 0) {
				sz = (longAt(oop1 - 8)) & 4294967292;
				goto l3;
			} else {
				sz = header1 & 252;
				goto l3;
			}
		l3:	/* end sizeBitsOf: */;
			firstWord = oop1 - (extraHeaderBytes(oop1));
			lastWord = (oop1 + sz) - 4;
			for (w = firstWord; w <= lastWord; w += 4) {
				longAtput(w - bytesToMove, longAt(w));
			}
		}
		oop1 = next;
	}
	if (newOop1 == null) {
		/* begin oopFromChunk: */
		chunk2 = compStart;
		oop1 = chunk2 + (extraHeaderBytes(chunk2));
		if ((((longAt(oop1)) & 3) == 2) && ((objectAfter(oop1)) == (oopFromChunk(compEnd)))) {
			newFreeChunk = oop1;
		} else {
			newFreeChunk = freeBlock;
		}
	} else {
		newFreeChunk = newOop1 + (sizeBitsOf(newOop1));
		/* begin setSizeOfFree:to: */
		longAtput(newFreeChunk, (bytesFreed & 536870908) | 2);
	}
	if (checkAssertions) {
		if (!((objectAfter(newFreeChunk)) == (oopFromChunk(compEnd)))) {
			error("problem creating free chunk after compaction");
		}
	}
	if ((objectAfter(newFreeChunk)) == endOfMemory) {
		initializeMemoryFirstFree(newFreeChunk);
	} else {
		initializeMemoryFirstFree(freeBlock);
	}
	return newFreeChunk;
}

int incCompMakeFwd(void) {
    int bytesFreed;
    int oop;
    int fwdBlock;
    int newOop;
    int originalHeader;
    int originalHeaderType;
    int chunk;
    int header;
    int fwdBlock1;
    int realHeader;
    int sz;
    int sz1;
    int header1;

	bytesFreed = 0;
	/* begin oopFromChunk: */
	chunk = compStart;
	oop = chunk + (extraHeaderBytes(chunk));
	while (oop < endOfMemory) {
		if (((longAt(oop)) & 3) == 2) {
			bytesFreed = bytesFreed + ((longAt(oop)) & 536870908);
		} else {
			/* begin fwdBlockGet */
			fwdTableNext = fwdTableNext + 8;
			if (fwdTableNext <= fwdTableLast) {
				fwdBlock = fwdTableNext;
				goto l1;
			} else {
				fwdBlock = null;
				goto l1;
			}
		l1:	/* end fwdBlockGet */;
			if (fwdBlock == null) {
				compEnd = oop - (extraHeaderBytes(oop));
				return bytesFreed;
			}
			newOop = oop - bytesFreed;
			/* begin initForwardBlock:mapping:to: */
			originalHeader = longAt(oop);
			if (checkAssertions) {
				if (fwdBlock == null) {
					error("ran out of forwarding blocks in become");
				}
				if ((originalHeader & 2147483648) != 0) {
					error("object already has a forwarding table entry");
				}
			}
			originalHeaderType = originalHeader & 3;
			longAtput(fwdBlock, newOop);
			longAtput(fwdBlock + 4, originalHeader);
			longAtput(oop, fwdBlock | (2147483648 | originalHeaderType));
		}
		/* begin objectAfterWhileForwarding: */
		header = longAt(oop);
		if ((header & 2147483648) == 0) {
			/* begin objectAfter: */
			if (checkAssertions) {
				if (oop >= endOfMemory) {
					error("no objects after the end of memory");
				}
			}
			if (((longAt(oop)) & 3) == 2) {
				sz1 = (longAt(oop)) & 536870908;
			} else {
				/* begin sizeBitsOf: */
				header1 = longAt(oop);
				if ((header1 & 3) == 0) {
					sz1 = (longAt(oop - 8)) & 4294967292;
					goto l2;
				} else {
					sz1 = header1 & 252;
					goto l2;
				}
			l2:	/* end sizeBitsOf: */;
			}
			oop = (oop + sz1) + (extraHeaderBytes(oop + sz1));
			goto l3;
		}
		fwdBlock1 = header & 2147483644;
		if (checkAssertions) {
			/* begin fwdBlockValidate: */
			if (!((fwdBlock1 > endOfMemory) && ((fwdBlock1 <= fwdTableNext) && ((fwdBlock1 & 3) == 0)))) {
				error("invalid fwd table entry");
			}
		}
		realHeader = longAt(fwdBlock1 + 4);
		if ((realHeader & 3) == 0) {
			sz = (longAt(oop - 8)) & 268435452;
		} else {
			sz = realHeader & 252;
		}
		oop = (oop + sz) + (extraHeaderBytes(oop + sz));
	l3:	/* end objectAfterWhileForwarding: */;
	}
	compEnd = endOfMemory;
	return bytesFreed;
}

int incCompMove(int bytesFreed) {
    int oop;
    int next;
    int fwdBlock;
    int newOop;
    int header;
    int bytesToMove;
    int firstWord;
    int lastWord;
    int w;
    int newFreeChunk;
    int sz;
    int header1;
    int chunk;
    int chunk1;
    int header2;
    int fwdBlock1;
    int realHeader;
    int sz2;
    int sz1;
    int header11;

	newOop = null;
	/* begin oopFromChunk: */
	chunk1 = compStart;
	oop = chunk1 + (extraHeaderBytes(chunk1));
	while (oop < compEnd) {
		/* begin objectAfterWhileForwarding: */
		header2 = longAt(oop);
		if ((header2 & 2147483648) == 0) {
			/* begin objectAfter: */
			if (checkAssertions) {
				if (oop >= endOfMemory) {
					error("no objects after the end of memory");
				}
			}
			if (((longAt(oop)) & 3) == 2) {
				sz1 = (longAt(oop)) & 536870908;
			} else {
				/* begin sizeBitsOf: */
				header11 = longAt(oop);
				if ((header11 & 3) == 0) {
					sz1 = (longAt(oop - 8)) & 4294967292;
					goto l2;
				} else {
					sz1 = header11 & 252;
					goto l2;
				}
			l2:	/* end sizeBitsOf: */;
			}
			next = (oop + sz1) + (extraHeaderBytes(oop + sz1));
			goto l3;
		}
		fwdBlock1 = header2 & 2147483644;
		if (checkAssertions) {
			/* begin fwdBlockValidate: */
			if (!((fwdBlock1 > endOfMemory) && ((fwdBlock1 <= fwdTableNext) && ((fwdBlock1 & 3) == 0)))) {
				error("invalid fwd table entry");
			}
		}
		realHeader = longAt(fwdBlock1 + 4);
		if ((realHeader & 3) == 0) {
			sz2 = (longAt(oop - 8)) & 268435452;
		} else {
			sz2 = realHeader & 252;
		}
		next = (oop + sz2) + (extraHeaderBytes(oop + sz2));
	l3:	/* end objectAfterWhileForwarding: */;
		if (!(((longAt(oop)) & 3) == 2)) {
			fwdBlock = (longAt(oop)) & 2147483644;
			if (checkAssertions) {
				/* begin fwdBlockValidate: */
				if (!((fwdBlock > endOfMemory) && ((fwdBlock <= fwdTableNext) && ((fwdBlock & 3) == 0)))) {
					error("invalid fwd table entry");
				}
			}
			newOop = longAt(fwdBlock);
			header = longAt(fwdBlock + 4);
			longAtput(oop, header);
			bytesToMove = oop - newOop;
			/* begin sizeBitsOf: */
			header1 = longAt(oop);
			if ((header1 & 3) == 0) {
				sz = (longAt(oop - 8)) & 4294967292;
				goto l1;
			} else {
				sz = header1 & 252;
				goto l1;
			}
		l1:	/* end sizeBitsOf: */;
			firstWord = oop - (extraHeaderBytes(oop));
			lastWord = (oop + sz) - 4;
			for (w = firstWord; w <= lastWord; w += 4) {
				longAtput(w - bytesToMove, longAt(w));
			}
		}
		oop = next;
	}
	if (newOop == null) {
		/* begin oopFromChunk: */
		chunk = compStart;
		oop = chunk + (extraHeaderBytes(chunk));
		if ((((longAt(oop)) & 3) == 2) && ((objectAfter(oop)) == (oopFromChunk(compEnd)))) {
			newFreeChunk = oop;
		} else {
			newFreeChunk = freeBlock;
		}
	} else {
		newFreeChunk = newOop + (sizeBitsOf(newOop));
		/* begin setSizeOfFree:to: */
		longAtput(newFreeChunk, (bytesFreed & 536870908) | 2);
	}
	if (checkAssertions) {
		if (!((objectAfter(newFreeChunk)) == (oopFromChunk(compEnd)))) {
			error("problem creating free chunk after compaction");
		}
	}
	if ((objectAfter(newFreeChunk)) == endOfMemory) {
		initializeMemoryFirstFree(newFreeChunk);
	} else {
		initializeMemoryFirstFree(freeBlock);
	}
	return newFreeChunk;
}

int incrementalCompaction(void) {
	if (compStart == freeBlock) {
		initializeMemoryFirstFree(freeBlock);
	} else {
		incCompBody();
	}
}

int incrementalGC(void) {
    int survivorCount;
    int i;
    int oop;

	if (rootTableCount >= 1000) {
		return fullGC();
	}
	markPhase();
	survivorCount = sweepPhase();
	/* begin incrementalCompaction */
	if (compStart == freeBlock) {
		initializeMemoryFirstFree(freeBlock);
	} else {
		incCompBody();
	}
	allocationCount = 0;
	if (survivorCount > 2000) {
		/* begin clearRootsTable */
		for (i = 1; i <= rootTableCount; i += 1) {
			oop = rootTable[i];
			longAtput(oop, (longAt(oop)) & 3221225471);
			rootTable[i] = 0;
		}
		rootTableCount = 0;
		youngStart = freeBlock;
	}
	/* begin postGCAction */
	if (activeContext < youngStart) {
		beRootIfOld(activeContext);
	}
	if (theHomeContext < youngStart) {
		beRootIfOld(theHomeContext);
	}
}

int initForwardBlockmappingto(int fwdBlock, int oop, int newOop) {
    int originalHeader;
    int originalHeaderType;

	originalHeader = longAt(oop);
	if (checkAssertions) {
		if (fwdBlock == null) {
			error("ran out of forwarding blocks in become");
		}
		if ((originalHeader & 2147483648) != 0) {
			error("object already has a forwarding table entry");
		}
	}
	originalHeaderType = originalHeader & 3;
	longAtput(fwdBlock, newOop);
	longAtput(fwdBlock + 4, originalHeader);
	longAtput(oop, fwdBlock | (2147483648 | originalHeaderType));
}

int initialInstanceOf(int classPointer) {
    int thisObj;
    int thisClass;
    int ccIndex;
    int obj;
    int chunk;
    int sz;
    int header;

	/* begin firstAccessibleObject */
	/* begin oopFromChunk: */
	chunk = startOfMemory();
	obj = chunk + (extraHeaderBytes(chunk));
	while (obj < endOfMemory) {
		if (!(((longAt(obj)) & 3) == 2)) {
			thisObj = obj;
			goto l3;
		}
		/* begin objectAfter: */
		if (checkAssertions) {
			if (obj >= endOfMemory) {
				error("no objects after the end of memory");
			}
		}
		if (((longAt(obj)) & 3) == 2) {
			sz = (longAt(obj)) & 536870908;
		} else {
			/* begin sizeBitsOf: */
			header = longAt(obj);
			if ((header & 3) == 0) {
				sz = (longAt(obj - 8)) & 4294967292;
				goto l2;
			} else {
				sz = header & 252;
				goto l2;
			}
		l2:	/* end sizeBitsOf: */;
		}
		obj = (obj + sz) + (extraHeaderBytes(obj + sz));
	}
	error("heap is empty");
l3:	/* end firstAccessibleObject */;
	while (!(thisObj == null)) {
		/* begin fetchClassOf: */
		if (((thisObj & 1) == 1)) {
			thisClass = longAt((specialObjectsOop + 4) + (5 * 4));
			goto l1;
		}
		ccIndex = ((((unsigned) (longAt(thisObj))) >> 12) & 31) - 1;
		if (ccIndex < 0) {
			thisClass = (longAt(thisObj - 4)) & 4294967292;
			goto l1;
		} else {
			thisClass = longAt(((longAt((specialObjectsOop + 4) + (28 * 4))) + 4) + (ccIndex * 4));
			goto l1;
		}
	l1:	/* end fetchClassOf: */;
		if (thisClass == classPointer) {
			return thisObj;
		}
		thisObj = accessibleObjectAfter(thisObj);
	}
	return nilObj;
}

int initializeInterpreter(int bytesToShift) {
    int sched;
    int proc;
    int m;

	initializeObjectMemory(bytesToShift);
	activeContext = nilObj;
	theHomeContext = nilObj;
	method = nilObj;
	receiver = nilObj;
	messageSelector = nilObj;
	newMethod = nilObj;
	primitiveFlushCache();
	/* begin loadInitialContext */
	sched = longAt(((longAt((specialObjectsOop + 4) + (3 * 4))) + 4) + (1 * 4));
	proc = longAt((sched + 4) + (1 * 4));
	activeContext = longAt((proc + 4) + (1 * 4));
	if (activeContext < youngStart) {
		beRootIfOld(activeContext);
	}
	/* begin fetchContextRegisters */
	m = longAt((activeContext + 4) + (3 * 4));
	if (((m & 1) == 1)) {
		theHomeContext = longAt((activeContext + 4) + (5 * 4));
		if (theHomeContext < youngStart) {
			beRootIfOld(theHomeContext);
		}
	} else {
		theHomeContext = activeContext;
	}
	receiver = longAt((theHomeContext + 4) + (5 * 4));
	method = longAt((theHomeContext + 4) + (3 * 4));
	instructionPointer = ((longAt((activeContext + 4) + (1 * 4))) >> 1);
	instructionPointer = ((method + instructionPointer) + 4) - 2;
	stackPointer = ((longAt((activeContext + 4) + (2 * 4))) >> 1);
	stackPointer = (activeContext + 4) + (((6 + stackPointer) - 1) * 4);
	reclaimableContextCount = 0;
	interruptCheckCounter = 0;
	nextPollTick = 0;
	nextWakeupTick = 0;
	interruptKeycode = 2094;
	interruptPending = false;
}

int initializeMemoryFirstFree(int firstFree) {
    int fwdBlockBytes;

	fwdBlockBytes = 16000;
	if (!((memoryLimit - fwdBlockBytes) >= (firstFree + 4))) {
		fwdBlockBytes = memoryLimit - (firstFree + 4);
	}
	endOfMemory = memoryLimit - fwdBlockBytes;
	freeBlock = firstFree;
	/* begin setSizeOfFree:to: */
	longAtput(freeBlock, ((endOfMemory - firstFree) & 536870908) | 2);
	/* begin setSizeOfFree:to: */
	longAtput(endOfMemory, (4 & 536870908) | 2);
	if (checkAssertions) {
		if (!((freeBlock < endOfMemory) && (endOfMemory < memoryLimit))) {
			error("error in free space computation");
		}
		if (!((oopFromChunk(endOfMemory)) == endOfMemory)) {
			error("header format must have changed");
		}
		if (!((objectAfter(freeBlock)) == endOfMemory)) {
			error("free block not properly initialized");
		}
	}
}

int initializeObjectMemory(int bytesToShift) {
    int oop;
    int last;
    int fieldAddr;
    int fieldOop;
    int classHeader;
    int newClassOop;
    int chunk;
    int sz;
    int header;

	checkAssertions = false;
	youngStart = endOfMemory;
	initializeMemoryFirstFree(endOfMemory);
	/* begin adjustAllOopsBy: */
	if (bytesToShift == 0) {
		goto l2;
	}
	/* begin oopFromChunk: */
	chunk = startOfMemory();
	oop = chunk + (extraHeaderBytes(chunk));
	while (oop < endOfMemory) {
		if (!(((longAt(oop)) & 3) == 2)) {
			/* begin adjustFieldsAndClassOf:by: */
			fieldAddr = oop + (lastPointerOf(oop));
			while (fieldAddr > oop) {
				fieldOop = longAt(fieldAddr);
				if (!(((fieldOop & 1) == 1))) {
					longAtput(fieldAddr, fieldOop + bytesToShift);
				}
				fieldAddr = fieldAddr - 4;
			}
			if (((longAt(oop)) & 3) != 3) {
				classHeader = longAt(oop - 4);
				newClassOop = (classHeader & 4294967292) + bytesToShift;
				longAtput(oop - 4, newClassOop | (classHeader & 3));
			}
		}
		last = oop;
		/* begin objectAfter: */
		if (checkAssertions) {
			if (oop >= endOfMemory) {
				error("no objects after the end of memory");
			}
		}
		if (((longAt(oop)) & 3) == 2) {
			sz = (longAt(oop)) & 536870908;
		} else {
			/* begin sizeBitsOf: */
			header = longAt(oop);
			if ((header & 3) == 0) {
				sz = (longAt(oop - 8)) & 4294967292;
				goto l1;
			} else {
				sz = header & 252;
				goto l1;
			}
		l1:	/* end sizeBitsOf: */;
		}
		oop = (oop + sz) + (extraHeaderBytes(oop + sz));
	}
l2:	/* end adjustAllOopsBy: */;
	specialObjectsOop = specialObjectsOop + bytesToShift;
	nilObj = longAt((specialObjectsOop + 4) + (0 * 4));
	falseObj = longAt((specialObjectsOop + 4) + (1 * 4));
	trueObj = longAt((specialObjectsOop + 4) + (2 * 4));
	rootTableCount = 0;
	child = 0;
	field = 0;
	parentField = 0;
	freeLargeContexts = 1;
	freeSmallContexts = 1;
	allocationCount = 0;
	lowSpaceThreshold = 0;
	signalLowSpace = false;
	compStart = 0;
	compEnd = 0;
	fwdTableNext = 0;
	fwdTableLast = 0;
	remapBufferCount = 0;
}

int instanceAfter(int objectPointer) {
    int classPointer;
    int thisObj;
    int thisClass;
    int ccIndex;
    int ccIndex1;

	/* begin fetchClassOf: */
	if (((objectPointer & 1) == 1)) {
		classPointer = longAt((specialObjectsOop + 4) + (5 * 4));
		goto l2;
	}
	ccIndex1 = ((((unsigned) (longAt(objectPointer))) >> 12) & 31) - 1;
	if (ccIndex1 < 0) {
		classPointer = (longAt(objectPointer - 4)) & 4294967292;
		goto l2;
	} else {
		classPointer = longAt(((longAt((specialObjectsOop + 4) + (28 * 4))) + 4) + (ccIndex1 * 4));
		goto l2;
	}
l2:	/* end fetchClassOf: */;
	thisObj = accessibleObjectAfter(objectPointer);
	while (!(thisObj == null)) {
		/* begin fetchClassOf: */
		if (((thisObj & 1) == 1)) {
			thisClass = longAt((specialObjectsOop + 4) + (5 * 4));
			goto l1;
		}
		ccIndex = ((((unsigned) (longAt(thisObj))) >> 12) & 31) - 1;
		if (ccIndex < 0) {
			thisClass = (longAt(thisObj - 4)) & 4294967292;
			goto l1;
		} else {
			thisClass = longAt(((longAt((specialObjectsOop + 4) + (28 * 4))) + 4) + (ccIndex * 4));
			goto l1;
		}
	l1:	/* end fetchClassOf: */;
		if (thisClass == classPointer) {
			return thisObj;
		}
		thisObj = accessibleObjectAfter(thisObj);
	}
	return nilObj;
}

int instantiateClassindexableSize(int classPointer, int size) {
    int hash;
    int header1;
    int header2;
    int cClass;
    int byteSize;
    int format;
    int inc;
    int binc;
    int header3;
    int hdrSize;
    int fillWord;
    int newObj;
    int newObj1;
    int remappedClassOop;
    int end;
    int i;
    int oop;
    int enoughSpace;
    int newFreeSize;
    int newChunk;
    int minFree;

	if (checkAssertions) {
		if (size < 0) {
			error("cannot have a negative indexable field count");
		}
	}
	/* begin newObjectHash */
	lastHash = (13849 + (27181 * lastHash)) & 65535;
	hash = lastHash & 4095;
	header1 = (longAt((classPointer + 4) + (2 * 4))) - 1;
	header1 = header1 | ((hash << 17) & 536739840);
	header2 = classPointer;
	header3 = 0;
	cClass = header1 & 126976;
	byteSize = header1 & 252;
	format = (((unsigned) header1) >> 8) & 15;
	if (format < 8) {
		inc = size * 4;
	} else {
		inc = (size + 3) & 536870908;
		binc = 3 - ((size + 3) & 3);
		header1 = header1 | (binc << 8);
	}
	if ((byteSize + inc) > 255) {
		header3 = byteSize + inc;
		header1 = header1 - byteSize;
	} else {
		header1 = header1 + inc;
	}
	byteSize = byteSize + inc;
	if (header3 > 0) {
		hdrSize = 3;
	} else {
		if (cClass == 0) {
			hdrSize = 2;
		} else {
			hdrSize = 1;
		}
	}
	if (format < 4) {
		fillWord = nilObj;
	} else {
		fillWord = 0;
	}
	/* begin allocate:headerSize:h1:h2:h3:fill: */
	if (hdrSize > 1) {
		/* begin pushRemappableOop: */
		remapBuffer[remapBufferCount = remapBufferCount + 1] = header2;
	}
	/* begin allocateChunk: */
	if (allocationCount >= 4000) {
		incrementalGC();
	}
	/* begin sufficientSpaceToAllocate: */
	minFree = (lowSpaceThreshold + (byteSize + ((hdrSize - 1) * 4))) + 4;
	if (((longAt(freeBlock)) & 536870908) >= minFree) {
		enoughSpace = true;
		goto l1;
	} else {
		enoughSpace = sufficientSpaceAfterGC(minFree);
		goto l1;
	}
l1:	/* end sufficientSpaceToAllocate: */;
	if (!(enoughSpace)) {
		signalLowSpace = true;
		interruptCheckCounter = 0;
	}
	if (((longAt(freeBlock)) & 536870908) < ((byteSize + ((hdrSize - 1) * 4)) + 4)) {
		error("out of memory");
	}
	newFreeSize = ((longAt(freeBlock)) & 536870908) - (byteSize + ((hdrSize - 1) * 4));
	newChunk = freeBlock;
	freeBlock = freeBlock + (byteSize + ((hdrSize - 1) * 4));
	/* begin setSizeOfFree:to: */
	longAtput(freeBlock, (newFreeSize & 536870908) | 2);
	allocationCount = allocationCount + 1;
	newObj1 = newChunk;
	if (hdrSize > 1) {
		/* begin popRemappableOop */
		oop = remapBuffer[remapBufferCount];
		remapBufferCount = remapBufferCount - 1;
		remappedClassOop = oop;
	}
	if (hdrSize == 3) {
		longAtput(newObj1, header3 | 0);
		longAtput(newObj1 + 4, remappedClassOop | 0);
		longAtput(newObj1 + 8, header1 | 0);
		newObj1 = newObj1 + 8;
	}
	if (hdrSize == 2) {
		longAtput(newObj1, remappedClassOop | 1);
		longAtput(newObj1 + 4, header1 | 1);
		newObj1 = newObj1 + 4;
	}
	if (hdrSize == 1) {
		longAtput(newObj1, header1 | 3);
	}
	end = newObj1 + byteSize;
	i = newObj1 + 4;
	while (i < end) {
		longAtput(i, fillWord);
		i = i + 4;
	}
	if (checkAssertions) {
		okayOop(newObj1);
		oopHasOkayClass(newObj1);
		if (!((objectAfter(newObj1)) == freeBlock)) {
			error("allocate bug: did not set header of new oop correctly");
		}
		if (!((objectAfter(freeBlock)) == endOfMemory)) {
			error("allocate bug: did not set header of freeBlock correctly");
		}
	}
	newObj = newObj1;
	return newObj;
}

int instantiateSmallClasssizeInBytesfill(int classPointer, int sizeInBytes, int fillValue) {
    int hash;
    int header1;
    int header2;
    int hdrSize;
    int newObj;
    int remappedClassOop;
    int end;
    int i;
    int oop;
    int enoughSpace;
    int newFreeSize;
    int newChunk;
    int minFree;

	/* begin newObjectHash */
	lastHash = (13849 + (27181 * lastHash)) & 65535;
	hash = lastHash & 4095;
	header1 = ((hash << 17) & 536739840) | ((longAt((classPointer + 4) + (2 * 4))) - 1);
	header1 = header1 + (sizeInBytes - (header1 & 252));
	header2 = classPointer;
	if ((header1 & 126976) == 0) {
		hdrSize = 2;
	} else {
		hdrSize = 1;
	}
	/* begin allocate:headerSize:h1:h2:h3:fill: */
	if (hdrSize > 1) {
		/* begin pushRemappableOop: */
		remapBuffer[remapBufferCount = remapBufferCount + 1] = header2;
	}
	/* begin allocateChunk: */
	if (allocationCount >= 4000) {
		incrementalGC();
	}
	/* begin sufficientSpaceToAllocate: */
	minFree = (lowSpaceThreshold + (sizeInBytes + ((hdrSize - 1) * 4))) + 4;
	if (((longAt(freeBlock)) & 536870908) >= minFree) {
		enoughSpace = true;
		goto l1;
	} else {
		enoughSpace = sufficientSpaceAfterGC(minFree);
		goto l1;
	}
l1:	/* end sufficientSpaceToAllocate: */;
	if (!(enoughSpace)) {
		signalLowSpace = true;
		interruptCheckCounter = 0;
	}
	if (((longAt(freeBlock)) & 536870908) < ((sizeInBytes + ((hdrSize - 1) * 4)) + 4)) {
		error("out of memory");
	}
	newFreeSize = ((longAt(freeBlock)) & 536870908) - (sizeInBytes + ((hdrSize - 1) * 4));
	newChunk = freeBlock;
	freeBlock = freeBlock + (sizeInBytes + ((hdrSize - 1) * 4));
	/* begin setSizeOfFree:to: */
	longAtput(freeBlock, (newFreeSize & 536870908) | 2);
	allocationCount = allocationCount + 1;
	newObj = newChunk;
	if (hdrSize > 1) {
		/* begin popRemappableOop */
		oop = remapBuffer[remapBufferCount];
		remapBufferCount = remapBufferCount - 1;
		remappedClassOop = oop;
	}
	if (hdrSize == 3) {
		longAtput(newObj, 0 | 0);
		longAtput(newObj + 4, remappedClassOop | 0);
		longAtput(newObj + 8, header1 | 0);
		newObj = newObj + 8;
	}
	if (hdrSize == 2) {
		longAtput(newObj, remappedClassOop | 1);
		longAtput(newObj + 4, header1 | 1);
		newObj = newObj + 4;
	}
	if (hdrSize == 1) {
		longAtput(newObj, header1 | 3);
	}
	end = newObj + sizeInBytes;
	i = newObj + 4;
	while (i < end) {
		longAtput(i, fillValue);
		i = i + 4;
	}
	if (checkAssertions) {
		okayOop(newObj);
		oopHasOkayClass(newObj);
		if (!((objectAfter(newObj)) == freeBlock)) {
			error("allocate bug: did not set header of new oop correctly");
		}
		if (!((objectAfter(freeBlock)) == endOfMemory)) {
			error("allocate bug: did not set header of freeBlock correctly");
		}
	}
	return newObj;
}

int integerObjectOf(int value) {
	if (value < 0) {
		return ((2147483648 + value) << 1) + 1;
	} else {
		return (value << 1) + 1;
	}
}

int integerValueOf(int objectPointer) {
	if ((objectPointer & 2147483648) != 0) {
		return ((((unsigned) (objectPointer & 2147483647)) >> 1) - 1073741823) - 1;
	} else {
		return ((unsigned) objectPointer) >> 1;
	}
}

int interpret(void) {
    int localSP;
    int localIP;
    int currentBytecode;
    int t1;
    int t2;
    int t3;
    int t4;
    int t5;
    int t6;
    int t7;
    int t8;
    int t9;
    int t10;
    int t11;
    int t12;
    int t13;
    int t14;
    int t15;
    int t16;

	/* begin internalizeIPandSP */
	localIP = instructionPointer;
	localSP = stackPointer;
	while (true) {
		currentBytecode = byteAt(++localIP);
		switch (currentBytecode) {
		case 0:
			/* pushReceiverVariableBytecode */
			/* begin pushReceiverVariable: */
			/* begin internalPush: */
			longAtput(localSP = localSP + 4, longAt((receiver + 4) + ((0 & 15) * 4)));
			break;
		case 1:
			/* pushReceiverVariableBytecode */
			/* begin pushReceiverVariable: */
			/* begin internalPush: */
			longAtput(localSP = localSP + 4, longAt((receiver + 4) + ((1 & 15) * 4)));
			break;
		case 2:
			/* pushReceiverVariableBytecode */
			/* begin pushReceiverVariable: */
			/* begin internalPush: */
			longAtput(localSP = localSP + 4, longAt((receiver + 4) + ((2 & 15) * 4)));
			break;
		case 3:
			/* pushReceiverVariableBytecode */
			/* begin pushReceiverVariable: */
			/* begin internalPush: */
			longAtput(localSP = localSP + 4, longAt((receiver + 4) + ((3 & 15) * 4)));
			break;
		case 4:
			/* pushReceiverVariableBytecode */
			/* begin pushReceiverVariable: */
			/* begin internalPush: */
			longAtput(localSP = localSP + 4, longAt((receiver + 4) + ((4 & 15) * 4)));
			break;
		case 5:
			/* pushReceiverVariableBytecode */
			/* begin pushReceiverVariable: */
			/* begin internalPush: */
			longAtput(localSP = localSP + 4, longAt((receiver + 4) + ((5 & 15) * 4)));
			break;
		case 6:
			/* pushReceiverVariableBytecode */
			/* begin pushReceiverVariable: */
			/* begin internalPush: */
			longAtput(localSP = localSP + 4, longAt((receiver + 4) + ((6 & 15) * 4)));
			break;
		case 7:
			/* pushReceiverVariableBytecode */
			/* begin pushReceiverVariable: */
			/* begin internalPush: */
			longAtput(localSP = localSP + 4, longAt((receiver + 4) + ((7 & 15) * 4)));
			break;
		case 8:
			/* pushReceiverVariableBytecode */
			/* begin pushReceiverVariable: */
			/* begin internalPush: */
			longAtput(localSP = localSP + 4, longAt((receiver + 4) + ((8 & 15) * 4)));
			break;
		case 9:
			/* pushReceiverVariableBytecode */
			/* begin pushReceiverVariable: */
			/* begin internalPush: */
			longAtput(localSP = localSP + 4, longAt((receiver + 4) + ((9 & 15) * 4)));
			break;
		case 10:
			/* pushReceiverVariableBytecode */
			/* begin pushReceiverVariable: */
			/* begin internalPush: */
			longAtput(localSP = localSP + 4, longAt((receiver + 4) + ((10 & 15) * 4)));
			break;
		case 11:
			/* pushReceiverVariableBytecode */
			/* begin pushReceiverVariable: */
			/* begin internalPush: */
			longAtput(localSP = localSP + 4, longAt((receiver + 4) + ((11 & 15) * 4)));
			break;
		case 12:
			/* pushReceiverVariableBytecode */
			/* begin pushReceiverVariable: */
			/* begin internalPush: */
			longAtput(localSP = localSP + 4, longAt((receiver + 4) + ((12 & 15) * 4)));
			break;
		case 13:
			/* pushReceiverVariableBytecode */
			/* begin pushReceiverVariable: */
			/* begin internalPush: */
			longAtput(localSP = localSP + 4, longAt((receiver + 4) + ((13 & 15) * 4)));
			break;
		case 14:
			/* pushReceiverVariableBytecode */
			/* begin pushReceiverVariable: */
			/* begin internalPush: */
			longAtput(localSP = localSP + 4, longAt((receiver + 4) + ((14 & 15) * 4)));
			break;
		case 15:
			/* pushReceiverVariableBytecode */
			/* begin pushReceiverVariable: */
			/* begin internalPush: */
			longAtput(localSP = localSP + 4, longAt((receiver + 4) + ((15 & 15) * 4)));
			break;
		case 16:
			/* pushTemporaryVariableBytecode */
			/* begin pushTemporaryVariable: */
			/* begin internalPush: */
			longAtput(localSP = localSP + 4, longAt((theHomeContext + 4) + (((16 & 15) + 6) * 4)));
			break;
		case 17:
			/* pushTemporaryVariableBytecode */
			/* begin pushTemporaryVariable: */
			/* begin internalPush: */
			longAtput(localSP = localSP + 4, longAt((theHomeContext + 4) + (((17 & 15) + 6) * 4)));
			break;
		case 18:
			/* pushTemporaryVariableBytecode */
			/* begin pushTemporaryVariable: */
			/* begin internalPush: */
			longAtput(localSP = localSP + 4, longAt((theHomeContext + 4) + (((18 & 15) + 6) * 4)));
			break;
		case 19:
			/* pushTemporaryVariableBytecode */
			/* begin pushTemporaryVariable: */
			/* begin internalPush: */
			longAtput(localSP = localSP + 4, longAt((theHomeContext + 4) + (((19 & 15) + 6) * 4)));
			break;
		case 20:
			/* pushTemporaryVariableBytecode */
			/* begin pushTemporaryVariable: */
			/* begin internalPush: */
			longAtput(localSP = localSP + 4, longAt((theHomeContext + 4) + (((20 & 15) + 6) * 4)));
			break;
		case 21:
			/* pushTemporaryVariableBytecode */
			/* begin pushTemporaryVariable: */
			/* begin internalPush: */
			longAtput(localSP = localSP + 4, longAt((theHomeContext + 4) + (((21 & 15) + 6) * 4)));
			break;
		case 22:
			/* pushTemporaryVariableBytecode */
			/* begin pushTemporaryVariable: */
			/* begin internalPush: */
			longAtput(localSP = localSP + 4, longAt((theHomeContext + 4) + (((22 & 15) + 6) * 4)));
			break;
		case 23:
			/* pushTemporaryVariableBytecode */
			/* begin pushTemporaryVariable: */
			/* begin internalPush: */
			longAtput(localSP = localSP + 4, longAt((theHomeContext + 4) + (((23 & 15) + 6) * 4)));
			break;
		case 24:
			/* pushTemporaryVariableBytecode */
			/* begin pushTemporaryVariable: */
			/* begin internalPush: */
			longAtput(localSP = localSP + 4, longAt((theHomeContext + 4) + (((24 & 15) + 6) * 4)));
			break;
		case 25:
			/* pushTemporaryVariableBytecode */
			/* begin pushTemporaryVariable: */
			/* begin internalPush: */
			longAtput(localSP = localSP + 4, longAt((theHomeContext + 4) + (((25 & 15) + 6) * 4)));
			break;
		case 26:
			/* pushTemporaryVariableBytecode */
			/* begin pushTemporaryVariable: */
			/* begin internalPush: */
			longAtput(localSP = localSP + 4, longAt((theHomeContext + 4) + (((26 & 15) + 6) * 4)));
			break;
		case 27:
			/* pushTemporaryVariableBytecode */
			/* begin pushTemporaryVariable: */
			/* begin internalPush: */
			longAtput(localSP = localSP + 4, longAt((theHomeContext + 4) + (((27 & 15) + 6) * 4)));
			break;
		case 28:
			/* pushTemporaryVariableBytecode */
			/* begin pushTemporaryVariable: */
			/* begin internalPush: */
			longAtput(localSP = localSP + 4, longAt((theHomeContext + 4) + (((28 & 15) + 6) * 4)));
			break;
		case 29:
			/* pushTemporaryVariableBytecode */
			/* begin pushTemporaryVariable: */
			/* begin internalPush: */
			longAtput(localSP = localSP + 4, longAt((theHomeContext + 4) + (((29 & 15) + 6) * 4)));
			break;
		case 30:
			/* pushTemporaryVariableBytecode */
			/* begin pushTemporaryVariable: */
			/* begin internalPush: */
			longAtput(localSP = localSP + 4, longAt((theHomeContext + 4) + (((30 & 15) + 6) * 4)));
			break;
		case 31:
			/* pushTemporaryVariableBytecode */
			/* begin pushTemporaryVariable: */
			/* begin internalPush: */
			longAtput(localSP = localSP + 4, longAt((theHomeContext + 4) + (((31 & 15) + 6) * 4)));
			break;
		case 32:
			/* pushLiteralConstantBytecode */
			/* begin pushLiteralConstant: */
			/* begin internalPush: */
			longAtput(localSP = localSP + 4, longAt((method + 4) + (((32 & 31) + 1) * 4)));
			break;
		case 33:
			/* pushLiteralConstantBytecode */
			/* begin pushLiteralConstant: */
			/* begin internalPush: */
			longAtput(localSP = localSP + 4, longAt((method + 4) + (((33 & 31) + 1) * 4)));
			break;
		case 34:
			/* pushLiteralConstantBytecode */
			/* begin pushLiteralConstant: */
			/* begin internalPush: */
			longAtput(localSP = localSP + 4, longAt((method + 4) + (((34 & 31) + 1) * 4)));
			break;
		case 35:
			/* pushLiteralConstantBytecode */
			/* begin pushLiteralConstant: */
			/* begin internalPush: */
			longAtput(localSP = localSP + 4, longAt((method + 4) + (((35 & 31) + 1) * 4)));
			break;
		case 36:
			/* pushLiteralConstantBytecode */
			/* begin pushLiteralConstant: */
			/* begin internalPush: */
			longAtput(localSP = localSP + 4, longAt((method + 4) + (((36 & 31) + 1) * 4)));
			break;
		case 37:
			/* pushLiteralConstantBytecode */
			/* begin pushLiteralConstant: */
			/* begin internalPush: */
			longAtput(localSP = localSP + 4, longAt((method + 4) + (((37 & 31) + 1) * 4)));
			break;
		case 38:
			/* pushLiteralConstantBytecode */
			/* begin pushLiteralConstant: */
			/* begin internalPush: */
			longAtput(localSP = localSP + 4, longAt((method + 4) + (((38 & 31) + 1) * 4)));
			break;
		case 39:
			/* pushLiteralConstantBytecode */
			/* begin pushLiteralConstant: */
			/* begin internalPush: */
			longAtput(localSP = localSP + 4, longAt((method + 4) + (((39 & 31) + 1) * 4)));
			break;
		case 40:
			/* pushLiteralConstantBytecode */
			/* begin pushLiteralConstant: */
			/* begin internalPush: */
			longAtput(localSP = localSP + 4, longAt((method + 4) + (((40 & 31) + 1) * 4)));
			break;
		case 41:
			/* pushLiteralConstantBytecode */
			/* begin pushLiteralConstant: */
			/* begin internalPush: */
			longAtput(localSP = localSP + 4, longAt((method + 4) + (((41 & 31) + 1) * 4)));
			break;
		case 42:
			/* pushLiteralConstantBytecode */
			/* begin pushLiteralConstant: */
			/* begin internalPush: */
			longAtput(localSP = localSP + 4, longAt((method + 4) + (((42 & 31) + 1) * 4)));
			break;
		case 43:
			/* pushLiteralConstantBytecode */
			/* begin pushLiteralConstant: */
			/* begin internalPush: */
			longAtput(localSP = localSP + 4, longAt((method + 4) + (((43 & 31) + 1) * 4)));
			break;
		case 44:
			/* pushLiteralConstantBytecode */
			/* begin pushLiteralConstant: */
			/* begin internalPush: */
			longAtput(localSP = localSP + 4, longAt((method + 4) + (((44 & 31) + 1) * 4)));
			break;
		case 45:
			/* pushLiteralConstantBytecode */
			/* begin pushLiteralConstant: */
			/* begin internalPush: */
			longAtput(localSP = localSP + 4, longAt((method + 4) + (((45 & 31) + 1) * 4)));
			break;
		case 46:
			/* pushLiteralConstantBytecode */
			/* begin pushLiteralConstant: */
			/* begin internalPush: */
			longAtput(localSP = localSP + 4, longAt((method + 4) + (((46 & 31) + 1) * 4)));
			break;
		case 47:
			/* pushLiteralConstantBytecode */
			/* begin pushLiteralConstant: */
			/* begin internalPush: */
			longAtput(localSP = localSP + 4, longAt((method + 4) + (((47 & 31) + 1) * 4)));
			break;
		case 48:
			/* pushLiteralConstantBytecode */
			/* begin pushLiteralConstant: */
			/* begin internalPush: */
			longAtput(localSP = localSP + 4, longAt((method + 4) + (((48 & 31) + 1) * 4)));
			break;
		case 49:
			/* pushLiteralConstantBytecode */
			/* begin pushLiteralConstant: */
			/* begin internalPush: */
			longAtput(localSP = localSP + 4, longAt((method + 4) + (((49 & 31) + 1) * 4)));
			break;
		case 50:
			/* pushLiteralConstantBytecode */
			/* begin pushLiteralConstant: */
			/* begin internalPush: */
			longAtput(localSP = localSP + 4, longAt((method + 4) + (((50 & 31) + 1) * 4)));
			break;
		case 51:
			/* pushLiteralConstantBytecode */
			/* begin pushLiteralConstant: */
			/* begin internalPush: */
			longAtput(localSP = localSP + 4, longAt((method + 4) + (((51 & 31) + 1) * 4)));
			break;
		case 52:
			/* pushLiteralConstantBytecode */
			/* begin pushLiteralConstant: */
			/* begin internalPush: */
			longAtput(localSP = localSP + 4, longAt((method + 4) + (((52 & 31) + 1) * 4)));
			break;
		case 53:
			/* pushLiteralConstantBytecode */
			/* begin pushLiteralConstant: */
			/* begin internalPush: */
			longAtput(localSP = localSP + 4, longAt((method + 4) + (((53 & 31) + 1) * 4)));
			break;
		case 54:
			/* pushLiteralConstantBytecode */
			/* begin pushLiteralConstant: */
			/* begin internalPush: */
			longAtput(localSP = localSP + 4, longAt((method + 4) + (((54 & 31) + 1) * 4)));
			break;
		case 55:
			/* pushLiteralConstantBytecode */
			/* begin pushLiteralConstant: */
			/* begin internalPush: */
			longAtput(localSP = localSP + 4, longAt((method + 4) + (((55 & 31) + 1) * 4)));
			break;
		case 56:
			/* pushLiteralConstantBytecode */
			/* begin pushLiteralConstant: */
			/* begin internalPush: */
			longAtput(localSP = localSP + 4, longAt((method + 4) + (((56 & 31) + 1) * 4)));
			break;
		case 57:
			/* pushLiteralConstantBytecode */
			/* begin pushLiteralConstant: */
			/* begin internalPush: */
			longAtput(localSP = localSP + 4, longAt((method + 4) + (((57 & 31) + 1) * 4)));
			break;
		case 58:
			/* pushLiteralConstantBytecode */
			/* begin pushLiteralConstant: */
			/* begin internalPush: */
			longAtput(localSP = localSP + 4, longAt((method + 4) + (((58 & 31) + 1) * 4)));
			break;
		case 59:
			/* pushLiteralConstantBytecode */
			/* begin pushLiteralConstant: */
			/* begin internalPush: */
			longAtput(localSP = localSP + 4, longAt((method + 4) + (((59 & 31) + 1) * 4)));
			break;
		case 60:
			/* pushLiteralConstantBytecode */
			/* begin pushLiteralConstant: */
			/* begin internalPush: */
			longAtput(localSP = localSP + 4, longAt((method + 4) + (((60 & 31) + 1) * 4)));
			break;
		case 61:
			/* pushLiteralConstantBytecode */
			/* begin pushLiteralConstant: */
			/* begin internalPush: */
			longAtput(localSP = localSP + 4, longAt((method + 4) + (((61 & 31) + 1) * 4)));
			break;
		case 62:
			/* pushLiteralConstantBytecode */
			/* begin pushLiteralConstant: */
			/* begin internalPush: */
			longAtput(localSP = localSP + 4, longAt((method + 4) + (((62 & 31) + 1) * 4)));
			break;
		case 63:
			/* pushLiteralConstantBytecode */
			/* begin pushLiteralConstant: */
			/* begin internalPush: */
			longAtput(localSP = localSP + 4, longAt((method + 4) + (((63 & 31) + 1) * 4)));
			break;
		case 64:
			/* pushLiteralVariableBytecode */
			/* begin pushLiteralVariable: */
			/* begin internalPush: */
			longAtput(localSP = localSP + 4, longAt(((longAt((method + 4) + (((64 & 31) + 1) * 4))) + 4) + (1 * 4)));
			break;
		case 65:
			/* pushLiteralVariableBytecode */
			/* begin pushLiteralVariable: */
			/* begin internalPush: */
			longAtput(localSP = localSP + 4, longAt(((longAt((method + 4) + (((65 & 31) + 1) * 4))) + 4) + (1 * 4)));
			break;
		case 66:
			/* pushLiteralVariableBytecode */
			/* begin pushLiteralVariable: */
			/* begin internalPush: */
			longAtput(localSP = localSP + 4, longAt(((longAt((method + 4) + (((66 & 31) + 1) * 4))) + 4) + (1 * 4)));
			break;
		case 67:
			/* pushLiteralVariableBytecode */
			/* begin pushLiteralVariable: */
			/* begin internalPush: */
			longAtput(localSP = localSP + 4, longAt(((longAt((method + 4) + (((67 & 31) + 1) * 4))) + 4) + (1 * 4)));
			break;
		case 68:
			/* pushLiteralVariableBytecode */
			/* begin pushLiteralVariable: */
			/* begin internalPush: */
			longAtput(localSP = localSP + 4, longAt(((longAt((method + 4) + (((68 & 31) + 1) * 4))) + 4) + (1 * 4)));
			break;
		case 69:
			/* pushLiteralVariableBytecode */
			/* begin pushLiteralVariable: */
			/* begin internalPush: */
			longAtput(localSP = localSP + 4, longAt(((longAt((method + 4) + (((69 & 31) + 1) * 4))) + 4) + (1 * 4)));
			break;
		case 70:
			/* pushLiteralVariableBytecode */
			/* begin pushLiteralVariable: */
			/* begin internalPush: */
			longAtput(localSP = localSP + 4, longAt(((longAt((method + 4) + (((70 & 31) + 1) * 4))) + 4) + (1 * 4)));
			break;
		case 71:
			/* pushLiteralVariableBytecode */
			/* begin pushLiteralVariable: */
			/* begin internalPush: */
			longAtput(localSP = localSP + 4, longAt(((longAt((method + 4) + (((71 & 31) + 1) * 4))) + 4) + (1 * 4)));
			break;
		case 72:
			/* pushLiteralVariableBytecode */
			/* begin pushLiteralVariable: */
			/* begin internalPush: */
			longAtput(localSP = localSP + 4, longAt(((longAt((method + 4) + (((72 & 31) + 1) * 4))) + 4) + (1 * 4)));
			break;
		case 73:
			/* pushLiteralVariableBytecode */
			/* begin pushLiteralVariable: */
			/* begin internalPush: */
			longAtput(localSP = localSP + 4, longAt(((longAt((method + 4) + (((73 & 31) + 1) * 4))) + 4) + (1 * 4)));
			break;
		case 74:
			/* pushLiteralVariableBytecode */
			/* begin pushLiteralVariable: */
			/* begin internalPush: */
			longAtput(localSP = localSP + 4, longAt(((longAt((method + 4) + (((74 & 31) + 1) * 4))) + 4) + (1 * 4)));
			break;
		case 75:
			/* pushLiteralVariableBytecode */
			/* begin pushLiteralVariable: */
			/* begin internalPush: */
			longAtput(localSP = localSP + 4, longAt(((longAt((method + 4) + (((75 & 31) + 1) * 4))) + 4) + (1 * 4)));
			break;
		case 76:
			/* pushLiteralVariableBytecode */
			/* begin pushLiteralVariable: */
			/* begin internalPush: */
			longAtput(localSP = localSP + 4, longAt(((longAt((method + 4) + (((76 & 31) + 1) * 4))) + 4) + (1 * 4)));
			break;
		case 77:
			/* pushLiteralVariableBytecode */
			/* begin pushLiteralVariable: */
			/* begin internalPush: */
			longAtput(localSP = localSP + 4, longAt(((longAt((method + 4) + (((77 & 31) + 1) * 4))) + 4) + (1 * 4)));
			break;
		case 78:
			/* pushLiteralVariableBytecode */
			/* begin pushLiteralVariable: */
			/* begin internalPush: */
			longAtput(localSP = localSP + 4, longAt(((longAt((method + 4) + (((78 & 31) + 1) * 4))) + 4) + (1 * 4)));
			break;
		case 79:
			/* pushLiteralVariableBytecode */
			/* begin pushLiteralVariable: */
			/* begin internalPush: */
			longAtput(localSP = localSP + 4, longAt(((longAt((method + 4) + (((79 & 31) + 1) * 4))) + 4) + (1 * 4)));
			break;
		case 80:
			/* pushLiteralVariableBytecode */
			/* begin pushLiteralVariable: */
			/* begin internalPush: */
			longAtput(localSP = localSP + 4, longAt(((longAt((method + 4) + (((80 & 31) + 1) * 4))) + 4) + (1 * 4)));
			break;
		case 81:
			/* pushLiteralVariableBytecode */
			/* begin pushLiteralVariable: */
			/* begin internalPush: */
			longAtput(localSP = localSP + 4, longAt(((longAt((method + 4) + (((81 & 31) + 1) * 4))) + 4) + (1 * 4)));
			break;
		case 82:
			/* pushLiteralVariableBytecode */
			/* begin pushLiteralVariable: */
			/* begin internalPush: */
			longAtput(localSP = localSP + 4, longAt(((longAt((method + 4) + (((82 & 31) + 1) * 4))) + 4) + (1 * 4)));
			break;
		case 83:
			/* pushLiteralVariableBytecode */
			/* begin pushLiteralVariable: */
			/* begin internalPush: */
			longAtput(localSP = localSP + 4, longAt(((longAt((method + 4) + (((83 & 31) + 1) * 4))) + 4) + (1 * 4)));
			break;
		case 84:
			/* pushLiteralVariableBytecode */
			/* begin pushLiteralVariable: */
			/* begin internalPush: */
			longAtput(localSP = localSP + 4, longAt(((longAt((method + 4) + (((84 & 31) + 1) * 4))) + 4) + (1 * 4)));
			break;
		case 85:
			/* pushLiteralVariableBytecode */
			/* begin pushLiteralVariable: */
			/* begin internalPush: */
			longAtput(localSP = localSP + 4, longAt(((longAt((method + 4) + (((85 & 31) + 1) * 4))) + 4) + (1 * 4)));
			break;
		case 86:
			/* pushLiteralVariableBytecode */
			/* begin pushLiteralVariable: */
			/* begin internalPush: */
			longAtput(localSP = localSP + 4, longAt(((longAt((method + 4) + (((86 & 31) + 1) * 4))) + 4) + (1 * 4)));
			break;
		case 87:
			/* pushLiteralVariableBytecode */
			/* begin pushLiteralVariable: */
			/* begin internalPush: */
			longAtput(localSP = localSP + 4, longAt(((longAt((method + 4) + (((87 & 31) + 1) * 4))) + 4) + (1 * 4)));
			break;
		case 88:
			/* pushLiteralVariableBytecode */
			/* begin pushLiteralVariable: */
			/* begin internalPush: */
			longAtput(localSP = localSP + 4, longAt(((longAt((method + 4) + (((88 & 31) + 1) * 4))) + 4) + (1 * 4)));
			break;
		case 89:
			/* pushLiteralVariableBytecode */
			/* begin pushLiteralVariable: */
			/* begin internalPush: */
			longAtput(localSP = localSP + 4, longAt(((longAt((method + 4) + (((89 & 31) + 1) * 4))) + 4) + (1 * 4)));
			break;
		case 90:
			/* pushLiteralVariableBytecode */
			/* begin pushLiteralVariable: */
			/* begin internalPush: */
			longAtput(localSP = localSP + 4, longAt(((longAt((method + 4) + (((90 & 31) + 1) * 4))) + 4) + (1 * 4)));
			break;
		case 91:
			/* pushLiteralVariableBytecode */
			/* begin pushLiteralVariable: */
			/* begin internalPush: */
			longAtput(localSP = localSP + 4, longAt(((longAt((method + 4) + (((91 & 31) + 1) * 4))) + 4) + (1 * 4)));
			break;
		case 92:
			/* pushLiteralVariableBytecode */
			/* begin pushLiteralVariable: */
			/* begin internalPush: */
			longAtput(localSP = localSP + 4, longAt(((longAt((method + 4) + (((92 & 31) + 1) * 4))) + 4) + (1 * 4)));
			break;
		case 93:
			/* pushLiteralVariableBytecode */
			/* begin pushLiteralVariable: */
			/* begin internalPush: */
			longAtput(localSP = localSP + 4, longAt(((longAt((method + 4) + (((93 & 31) + 1) * 4))) + 4) + (1 * 4)));
			break;
		case 94:
			/* pushLiteralVariableBytecode */
			/* begin pushLiteralVariable: */
			/* begin internalPush: */
			longAtput(localSP = localSP + 4, longAt(((longAt((method + 4) + (((94 & 31) + 1) * 4))) + 4) + (1 * 4)));
			break;
		case 95:
			/* pushLiteralVariableBytecode */
			/* begin pushLiteralVariable: */
			/* begin internalPush: */
			longAtput(localSP = localSP + 4, longAt(((longAt((method + 4) + (((95 & 31) + 1) * 4))) + 4) + (1 * 4)));
			break;
		case 96:
			/* storeAndPopReceiverVariableBytecode */
			/* begin storePointer:ofObject:withValue: */
			t1 = 96 & 7;
			t2 = receiver;
			t3 = longAt(localSP);
			if (t2 < youngStart) {
				possibleRootStoreIntovalue(t2, t3);
			}
			longAtput((t2 + 4) + (t1 * 4), t3);
			/* begin internalPop: */
			localSP = localSP - (1 * 4);
			break;
		case 97:
			/* storeAndPopReceiverVariableBytecode */
			/* begin storePointer:ofObject:withValue: */
			t1 = 97 & 7;
			t2 = receiver;
			t3 = longAt(localSP);
			if (t2 < youngStart) {
				possibleRootStoreIntovalue(t2, t3);
			}
			longAtput((t2 + 4) + (t1 * 4), t3);
			/* begin internalPop: */
			localSP = localSP - (1 * 4);
			break;
		case 98:
			/* storeAndPopReceiverVariableBytecode */
			/* begin storePointer:ofObject:withValue: */
			t1 = 98 & 7;
			t2 = receiver;
			t3 = longAt(localSP);
			if (t2 < youngStart) {
				possibleRootStoreIntovalue(t2, t3);
			}
			longAtput((t2 + 4) + (t1 * 4), t3);
			/* begin internalPop: */
			localSP = localSP - (1 * 4);
			break;
		case 99:
			/* storeAndPopReceiverVariableBytecode */
			/* begin storePointer:ofObject:withValue: */
			t1 = 99 & 7;
			t2 = receiver;
			t3 = longAt(localSP);
			if (t2 < youngStart) {
				possibleRootStoreIntovalue(t2, t3);
			}
			longAtput((t2 + 4) + (t1 * 4), t3);
			/* begin internalPop: */
			localSP = localSP - (1 * 4);
			break;
		case 100:
			/* storeAndPopReceiverVariableBytecode */
			/* begin storePointer:ofObject:withValue: */
			t1 = 100 & 7;
			t2 = receiver;
			t3 = longAt(localSP);
			if (t2 < youngStart) {
				possibleRootStoreIntovalue(t2, t3);
			}
			longAtput((t2 + 4) + (t1 * 4), t3);
			/* begin internalPop: */
			localSP = localSP - (1 * 4);
			break;
		case 101:
			/* storeAndPopReceiverVariableBytecode */
			/* begin storePointer:ofObject:withValue: */
			t1 = 101 & 7;
			t2 = receiver;
			t3 = longAt(localSP);
			if (t2 < youngStart) {
				possibleRootStoreIntovalue(t2, t3);
			}
			longAtput((t2 + 4) + (t1 * 4), t3);
			/* begin internalPop: */
			localSP = localSP - (1 * 4);
			break;
		case 102:
			/* storeAndPopReceiverVariableBytecode */
			/* begin storePointer:ofObject:withValue: */
			t1 = 102 & 7;
			t2 = receiver;
			t3 = longAt(localSP);
			if (t2 < youngStart) {
				possibleRootStoreIntovalue(t2, t3);
			}
			longAtput((t2 + 4) + (t1 * 4), t3);
			/* begin internalPop: */
			localSP = localSP - (1 * 4);
			break;
		case 103:
			/* storeAndPopReceiverVariableBytecode */
			/* begin storePointer:ofObject:withValue: */
			t1 = 103 & 7;
			t2 = receiver;
			t3 = longAt(localSP);
			if (t2 < youngStart) {
				possibleRootStoreIntovalue(t2, t3);
			}
			longAtput((t2 + 4) + (t1 * 4), t3);
			/* begin internalPop: */
			localSP = localSP - (1 * 4);
			break;
		case 104:
			/* storeAndPopTemporaryVariableBytecode */
			longAtput((theHomeContext + 4) + (((104 & 7) + 6) * 4), longAt(localSP));
			/* begin internalPop: */
			localSP = localSP - (1 * 4);
			break;
		case 105:
			/* storeAndPopTemporaryVariableBytecode */
			longAtput((theHomeContext + 4) + (((105 & 7) + 6) * 4), longAt(localSP));
			/* begin internalPop: */
			localSP = localSP - (1 * 4);
			break;
		case 106:
			/* storeAndPopTemporaryVariableBytecode */
			longAtput((theHomeContext + 4) + (((106 & 7) + 6) * 4), longAt(localSP));
			/* begin internalPop: */
			localSP = localSP - (1 * 4);
			break;
		case 107:
			/* storeAndPopTemporaryVariableBytecode */
			longAtput((theHomeContext + 4) + (((107 & 7) + 6) * 4), longAt(localSP));
			/* begin internalPop: */
			localSP = localSP - (1 * 4);
			break;
		case 108:
			/* storeAndPopTemporaryVariableBytecode */
			longAtput((theHomeContext + 4) + (((108 & 7) + 6) * 4), longAt(localSP));
			/* begin internalPop: */
			localSP = localSP - (1 * 4);
			break;
		case 109:
			/* storeAndPopTemporaryVariableBytecode */
			longAtput((theHomeContext + 4) + (((109 & 7) + 6) * 4), longAt(localSP));
			/* begin internalPop: */
			localSP = localSP - (1 * 4);
			break;
		case 110:
			/* storeAndPopTemporaryVariableBytecode */
			longAtput((theHomeContext + 4) + (((110 & 7) + 6) * 4), longAt(localSP));
			/* begin internalPop: */
			localSP = localSP - (1 * 4);
			break;
		case 111:
			/* storeAndPopTemporaryVariableBytecode */
			longAtput((theHomeContext + 4) + (((111 & 7) + 6) * 4), longAt(localSP));
			/* begin internalPop: */
			localSP = localSP - (1 * 4);
			break;
		case 112:
			/* pushReceiverBytecode */
			/* begin internalPush: */
			longAtput(localSP = localSP + 4, receiver);
			break;
		case 113:
			/* pushConstantTrueBytecode */
			/* begin internalPush: */
			longAtput(localSP = localSP + 4, trueObj);
			break;
		case 114:
			/* pushConstantFalseBytecode */
			/* begin internalPush: */
			longAtput(localSP = localSP + 4, falseObj);
			break;
		case 115:
			/* pushConstantNilBytecode */
			/* begin internalPush: */
			longAtput(localSP = localSP + 4, nilObj);
			break;
		case 116:
			/* pushConstantMinusOneBytecode */
			/* begin internalPush: */
			longAtput(localSP = localSP + 4, 4294967295);
			break;
		case 117:
			/* pushConstantZeroBytecode */
			/* begin internalPush: */
			longAtput(localSP = localSP + 4, 1);
			break;
		case 118:
			/* pushConstantOneBytecode */
			/* begin internalPush: */
			longAtput(localSP = localSP + 4, 3);
			break;
		case 119:
			/* pushConstantTwoBytecode */
			/* begin internalPush: */
			longAtput(localSP = localSP + 4, 5);
			break;
		case 120:
			/* returnReceiver */
			/* begin externalizeIPandSP */
			instructionPointer = localIP;
			stackPointer = localSP;
			returnValueto(receiver, longAt((theHomeContext + 4) + (0 * 4)));
			/* begin internalizeIPandSP */
			localIP = instructionPointer;
			localSP = stackPointer;
			break;
		case 121:
			/* returnTrue */
			/* begin externalizeIPandSP */
			instructionPointer = localIP;
			stackPointer = localSP;
			returnValueto(trueObj, longAt((theHomeContext + 4) + (0 * 4)));
			/* begin internalizeIPandSP */
			localIP = instructionPointer;
			localSP = stackPointer;
			break;
		case 122:
			/* returnFalse */
			/* begin externalizeIPandSP */
			instructionPointer = localIP;
			stackPointer = localSP;
			returnValueto(falseObj, longAt((theHomeContext + 4) + (0 * 4)));
			/* begin internalizeIPandSP */
			localIP = instructionPointer;
			localSP = stackPointer;
			break;
		case 123:
			/* returnNil */
			/* begin externalizeIPandSP */
			instructionPointer = localIP;
			stackPointer = localSP;
			returnValueto(nilObj, longAt((theHomeContext + 4) + (0 * 4)));
			/* begin internalizeIPandSP */
			localIP = instructionPointer;
			localSP = stackPointer;
			break;
		case 124:
			/* returnTopFromMethod */
			/* begin externalizeIPandSP */
			instructionPointer = localIP;
			stackPointer = localSP;
			returnValueto(popStack(), longAt((theHomeContext + 4) + (0 * 4)));
			/* begin internalizeIPandSP */
			localIP = instructionPointer;
			localSP = stackPointer;
			break;
		case 125:
			/* returnTopFromBlock */
			/* begin externalizeIPandSP */
			instructionPointer = localIP;
			stackPointer = localSP;
			returnValueto(popStack(), longAt((activeContext + 4) + (0 * 4)));
			/* begin internalizeIPandSP */
			localIP = instructionPointer;
			localSP = stackPointer;
			break;
		case 126:
		case 127:
			/* unknownBytecode */
			error("Unknown bytecode");
			break;
		case 128:
			/* extendedPushBytecode */
			t1 = byteAt(++localIP);
			t2 = (((unsigned) t1) >> 6) & 3;
			t3 = t1 & 63;
			if (t2 == 0) {
				/* begin pushReceiverVariable: */
				/* begin internalPush: */
				longAtput(localSP = localSP + 4, longAt((receiver + 4) + (t3 * 4)));
				goto l1;
			}
			if (t2 == 1) {
				/* begin pushTemporaryVariable: */
				/* begin internalPush: */
				longAtput(localSP = localSP + 4, longAt((theHomeContext + 4) + ((t3 + 6) * 4)));
				goto l1;
			}
			if (t2 == 2) {
				/* begin pushLiteralConstant: */
				/* begin internalPush: */
				longAtput(localSP = localSP + 4, longAt((method + 4) + ((t3 + 1) * 4)));
				goto l1;
			}
			if (t2 == 3) {
				/* begin pushLiteralVariable: */
				/* begin internalPush: */
				longAtput(localSP = localSP + 4, longAt(((longAt((method + 4) + ((t3 + 1) * 4))) + 4) + (1 * 4)));
				goto l1;
			}
		l1:	/* end case */;
			break;
		case 129:
			/* extendedStoreBytecode */
			t1 = byteAt(++localIP);
			t2 = (((unsigned) t1) >> 6) & 3;
			t3 = t1 & 63;
			if (t2 == 0) {
				/* begin storePointer:ofObject:withValue: */
				t5 = receiver;
				t6 = longAt(localSP);
				if (t5 < youngStart) {
					possibleRootStoreIntovalue(t5, t6);
				}
				longAtput((t5 + 4) + (t3 * 4), t6);
				goto l2;
			}
			if (t2 == 1) {
				longAtput((theHomeContext + 4) + ((t3 + 6) * 4), longAt(localSP));
				goto l2;
			}
			if (t2 == 2) {
				error("illegal store");
			}
			if (t2 == 3) {
				t4 = longAt((method + 4) + ((t3 + 1) * 4));
				/* begin storePointer:ofObject:withValue: */
				t7 = longAt(localSP);
				if (t4 < youngStart) {
					possibleRootStoreIntovalue(t4, t7);
				}
				longAtput((t4 + 4) + (1 * 4), t7);
				goto l2;
			}
		l2:	/* end case */;
			break;
		case 130:
			/* extendedStoreAndPopBytecode */
			/* begin extendedStoreBytecode */
			t1 = byteAt(++localIP);
			t2 = (((unsigned) t1) >> 6) & 3;
			t3 = t1 & 63;
			if (t2 == 0) {
				/* begin storePointer:ofObject:withValue: */
				t5 = receiver;
				t6 = longAt(localSP);
				if (t5 < youngStart) {
					possibleRootStoreIntovalue(t5, t6);
				}
				longAtput((t5 + 4) + (t3 * 4), t6);
				goto l3;
			}
			if (t2 == 1) {
				longAtput((theHomeContext + 4) + ((t3 + 6) * 4), longAt(localSP));
				goto l3;
			}
			if (t2 == 2) {
				error("illegal store");
			}
			if (t2 == 3) {
				t4 = longAt((method + 4) + ((t3 + 1) * 4));
				/* begin storePointer:ofObject:withValue: */
				t7 = longAt(localSP);
				if (t4 < youngStart) {
					possibleRootStoreIntovalue(t4, t7);
				}
				longAtput((t4 + 4) + (1 * 4), t7);
				goto l3;
			}
		l3:	/* end extendedStoreBytecode */;
			/* begin popStackBytecode */
			/* begin internalPop: */
			localSP = localSP - (1 * 4);
			break;
		case 131:
			/* singleExtendedSendBytecode */
			t1 = byteAt(++localIP);
			t2 = t1 & 31;
			/* begin internalSendSelector:argumentCount: */
			t3 = longAt((method + 4) + ((t2 + 1) * 4));
			messageSelector = t3;
			argumentCount = ((unsigned) t1) >> 5;
			/* begin fetchClassOf: */
			if ((((longAt(localSP - (argumentCount * 4))) & 1) == 1)) {
				t4 = longAt((specialObjectsOop + 4) + (5 * 4));
				goto l4;
			}
			t5 = ((((unsigned) (longAt(longAt(localSP - (argumentCount * 4))))) >> 12) & 31) - 1;
			if (t5 < 0) {
				t4 = (longAt((longAt(localSP - (argumentCount * 4))) - 4)) & 4294967292;
				goto l4;
			} else {
				t4 = longAt(((longAt((specialObjectsOop + 4) + (28 * 4))) + 4) + (t5 * 4));
				goto l4;
			}
		l4:	/* end fetchClassOf: */;
			/* begin externalizeIPandSP */
			instructionPointer = localIP;
			stackPointer = localSP;
			/* begin sendSelectorToClass: */
			/* begin findNewMethodInClass: */
			t6 = ((unsigned) (messageSelector ^ t4)) >> 2;
			for (t8 = 0; t8 <= (3 - 1); t8 += 1) {
				t7 = ((((unsigned) t6) >> t8) & 511) + 1;
				if (((methodCache[t7]) == messageSelector) && ((methodCache[t7 + 512]) == t4)) {
					newMethod = methodCache[(t7 + 512) + 512];
					primitiveIndex = (((unsigned) (longAt((newMethod + 4) + (0 * 4)))) >> 1) & 511;
					goto l5;
				}
			}
			lookupMethodInClass(t4);
			mcProbe = (mcProbe + 1) % 3;
			t7 = ((((unsigned) t6) >> (mcProbe * 3)) & 511) + 1;
			methodCache[t7] = messageSelector;
			methodCache[t7 + 512] = t4;
			methodCache[(t7 + 512) + 512] = newMethod;
		l5:	/* end findNewMethodInClass: */;
			/* begin executeNewMethod */
			if ((primitiveIndex == 0) || (!(primitiveResponse()))) {
				activateNewMethod();
				/* begin quickCheckForInterrupts */
				if ((interruptCheckCounter = interruptCheckCounter - 1) <= 0) {
					interruptCheckCounter = 1000;
					checkForInterrupts();
				}
			}
			/* begin internalizeIPandSP */
			localIP = instructionPointer;
			localSP = stackPointer;
			break;
		case 132:
			/* doubleExtendedDoAnythingBytecode */
			t1 = byteAt(++localIP);
			t2 = byteAt(++localIP);
			t3 = ((unsigned) t1) >> 5;
			if (t3 == 0) {
				/* begin externalizeIPandSP */
				instructionPointer = localIP;
				stackPointer = localSP;
				externalSendSelectorargumentCount(longAt((method + 4) + ((t2 + 1) * 4)), t1 & 31);
				/* begin internalizeIPandSP */
				localIP = instructionPointer;
				localSP = stackPointer;
				goto l6;
			}
			if (t3 == 1) {
				messageSelector = longAt((method + 4) + ((t2 + 1) * 4));
				argumentCount = t1 & 31;
				/* begin externalizeIPandSP */
				instructionPointer = localIP;
				stackPointer = localSP;
				/* begin sendSelectorToClass: */
				/* begin superclassOf: */
				/* begin methodClassOf: */
				t15 = (((unsigned) (longAt((method + 4) + (0 * 4)))) >> 10) & 255;
				t16 = longAt((method + 4) + (((t15 - 1) + 1) * 4));
				t14 = longAt((t16 + 4) + (1 * 4));
				t10 = longAt((t14 + 4) + (0 * 4));
				/* begin findNewMethodInClass: */
				t11 = ((unsigned) (messageSelector ^ t10)) >> 2;
				for (t13 = 0; t13 <= (3 - 1); t13 += 1) {
					t12 = ((((unsigned) t11) >> t13) & 511) + 1;
					if (((methodCache[t12]) == messageSelector) && ((methodCache[t12 + 512]) == t10)) {
						newMethod = methodCache[(t12 + 512) + 512];
						primitiveIndex = (((unsigned) (longAt((newMethod + 4) + (0 * 4)))) >> 1) & 511;
						goto l7;
					}
				}
				lookupMethodInClass(t10);
				mcProbe = (mcProbe + 1) % 3;
				t12 = ((((unsigned) t11) >> (mcProbe * 3)) & 511) + 1;
				methodCache[t12] = messageSelector;
				methodCache[t12 + 512] = t10;
				methodCache[(t12 + 512) + 512] = newMethod;
			l7:	/* end findNewMethodInClass: */;
				/* begin executeNewMethod */
				if ((primitiveIndex == 0) || (!(primitiveResponse()))) {
					activateNewMethod();
					/* begin quickCheckForInterrupts */
					if ((interruptCheckCounter = interruptCheckCounter - 1) <= 0) {
						interruptCheckCounter = 1000;
						checkForInterrupts();
					}
				}
				/* begin internalizeIPandSP */
				localIP = instructionPointer;
				localSP = stackPointer;
				goto l6;
			}
			if (t3 == 2) {
				/* begin pushReceiverVariable: */
				/* begin internalPush: */
				longAtput(localSP = localSP + 4, longAt((receiver + 4) + (t2 * 4)));
				goto l6;
			}
			if (t3 == 3) {
				/* begin pushLiteralConstant: */
				/* begin internalPush: */
				longAtput(localSP = localSP + 4, longAt((method + 4) + ((t2 + 1) * 4)));
				goto l6;
			}
			if (t3 == 4) {
				/* begin pushLiteralVariable: */
				/* begin internalPush: */
				longAtput(localSP = localSP + 4, longAt(((longAt((method + 4) + ((t2 + 1) * 4))) + 4) + (1 * 4)));
				goto l6;
			}
			if (t3 == 5) {
				/* begin storePointer:ofObject:withValue: */
				t5 = receiver;
				t6 = longAt(localSP);
				if (t5 < youngStart) {
					possibleRootStoreIntovalue(t5, t6);
				}
				longAtput((t5 + 4) + (t2 * 4), t6);
				goto l6;
			}
			if (t3 == 6) {
				t4 = longAt(localSP);
				/* begin internalPop: */
				localSP = localSP - (1 * 4);
				/* begin storePointer:ofObject:withValue: */
				t7 = receiver;
				if (t7 < youngStart) {
					possibleRootStoreIntovalue(t7, t4);
				}
				longAtput((t7 + 4) + (t2 * 4), t4);
				goto l6;
			}
			if (t3 == 7) {
				/* begin storePointer:ofObject:withValue: */
				t8 = longAt((method + 4) + ((t2 + 1) * 4));
				t9 = longAt(localSP);
				if (t8 < youngStart) {
					possibleRootStoreIntovalue(t8, t9);
				}
				longAtput((t8 + 4) + (1 * 4), t9);
				goto l6;
			}
		l6:	/* end case */;
			break;
		case 133:
			/* singleExtendedSuperBytecode */
			t1 = byteAt(++localIP);
			argumentCount = ((unsigned) t1) >> 5;
			t2 = t1 & 31;
			messageSelector = longAt((method + 4) + ((t2 + 1) * 4));
			/* begin externalizeIPandSP */
			instructionPointer = localIP;
			stackPointer = localSP;
			/* begin sendSelectorToClass: */
			/* begin superclassOf: */
			/* begin methodClassOf: */
			t8 = (((unsigned) (longAt((method + 4) + (0 * 4)))) >> 10) & 255;
			t9 = longAt((method + 4) + (((t8 - 1) + 1) * 4));
			t7 = longAt((t9 + 4) + (1 * 4));
			t3 = longAt((t7 + 4) + (0 * 4));
			/* begin findNewMethodInClass: */
			t4 = ((unsigned) (messageSelector ^ t3)) >> 2;
			for (t6 = 0; t6 <= (3 - 1); t6 += 1) {
				t5 = ((((unsigned) t4) >> t6) & 511) + 1;
				if (((methodCache[t5]) == messageSelector) && ((methodCache[t5 + 512]) == t3)) {
					newMethod = methodCache[(t5 + 512) + 512];
					primitiveIndex = (((unsigned) (longAt((newMethod + 4) + (0 * 4)))) >> 1) & 511;
					goto l8;
				}
			}
			lookupMethodInClass(t3);
			mcProbe = (mcProbe + 1) % 3;
			t5 = ((((unsigned) t4) >> (mcProbe * 3)) & 511) + 1;
			methodCache[t5] = messageSelector;
			methodCache[t5 + 512] = t3;
			methodCache[(t5 + 512) + 512] = newMethod;
		l8:	/* end findNewMethodInClass: */;
			/* begin executeNewMethod */
			if ((primitiveIndex == 0) || (!(primitiveResponse()))) {
				activateNewMethod();
				/* begin quickCheckForInterrupts */
				if ((interruptCheckCounter = interruptCheckCounter - 1) <= 0) {
					interruptCheckCounter = 1000;
					checkForInterrupts();
				}
			}
			/* begin internalizeIPandSP */
			localIP = instructionPointer;
			localSP = stackPointer;
			break;
		case 134:
			/* secondExtendedSendBytecode */
			t1 = byteAt(++localIP);
			t2 = t1 & 63;
			/* begin internalSendSelector:argumentCount: */
			t3 = longAt((method + 4) + ((t2 + 1) * 4));
			messageSelector = t3;
			argumentCount = ((unsigned) t1) >> 6;
			/* begin fetchClassOf: */
			if ((((longAt(localSP - (argumentCount * 4))) & 1) == 1)) {
				t4 = longAt((specialObjectsOop + 4) + (5 * 4));
				goto l9;
			}
			t5 = ((((unsigned) (longAt(longAt(localSP - (argumentCount * 4))))) >> 12) & 31) - 1;
			if (t5 < 0) {
				t4 = (longAt((longAt(localSP - (argumentCount * 4))) - 4)) & 4294967292;
				goto l9;
			} else {
				t4 = longAt(((longAt((specialObjectsOop + 4) + (28 * 4))) + 4) + (t5 * 4));
				goto l9;
			}
		l9:	/* end fetchClassOf: */;
			/* begin externalizeIPandSP */
			instructionPointer = localIP;
			stackPointer = localSP;
			/* begin sendSelectorToClass: */
			/* begin findNewMethodInClass: */
			t6 = ((unsigned) (messageSelector ^ t4)) >> 2;
			for (t8 = 0; t8 <= (3 - 1); t8 += 1) {
				t7 = ((((unsigned) t6) >> t8) & 511) + 1;
				if (((methodCache[t7]) == messageSelector) && ((methodCache[t7 + 512]) == t4)) {
					newMethod = methodCache[(t7 + 512) + 512];
					primitiveIndex = (((unsigned) (longAt((newMethod + 4) + (0 * 4)))) >> 1) & 511;
					goto l10;
				}
			}
			lookupMethodInClass(t4);
			mcProbe = (mcProbe + 1) % 3;
			t7 = ((((unsigned) t6) >> (mcProbe * 3)) & 511) + 1;
			methodCache[t7] = messageSelector;
			methodCache[t7 + 512] = t4;
			methodCache[(t7 + 512) + 512] = newMethod;
		l10:	/* end findNewMethodInClass: */;
			/* begin executeNewMethod */
			if ((primitiveIndex == 0) || (!(primitiveResponse()))) {
				activateNewMethod();
				/* begin quickCheckForInterrupts */
				if ((interruptCheckCounter = interruptCheckCounter - 1) <= 0) {
					interruptCheckCounter = 1000;
					checkForInterrupts();
				}
			}
			/* begin internalizeIPandSP */
			localIP = instructionPointer;
			localSP = stackPointer;
			break;
		case 135:
			/* popStackBytecode */
			/* begin internalPop: */
			localSP = localSP - (1 * 4);
			break;
		case 136:
			/* duplicateTopBytecode */
			/* begin internalPush: */
			t1 = longAt(localSP);
			longAtput(localSP = localSP + 4, t1);
			break;
		case 137:
			/* pushActiveContextBytecode */
			reclaimableContextCount = 0;
			/* begin internalPush: */
			longAtput(localSP = localSP + 4, activeContext);
			break;
		case 138:
			/* unknownBytecode */
			error("Unknown bytecode");
			break;
		case 139:
			/* unknownBytecode */
			error("Unknown bytecode");
			break;
		case 140:
			/* unknownBytecode */
			error("Unknown bytecode");
			break;
		case 141:
			/* unknownBytecode */
			error("Unknown bytecode");
			break;
		case 142:
			/* unknownBytecode */
			error("Unknown bytecode");
			break;
		case 143:
			/* unknownBytecode */
			error("Unknown bytecode");
			break;
		case 144:
			/* shortUnconditionalJump */
			/* begin jump: */
			localIP = localIP + ((144 & 7) + 1);
			break;
		case 145:
			/* shortUnconditionalJump */
			/* begin jump: */
			localIP = localIP + ((145 & 7) + 1);
			break;
		case 146:
			/* shortUnconditionalJump */
			/* begin jump: */
			localIP = localIP + ((146 & 7) + 1);
			break;
		case 147:
			/* shortUnconditionalJump */
			/* begin jump: */
			localIP = localIP + ((147 & 7) + 1);
			break;
		case 148:
			/* shortUnconditionalJump */
			/* begin jump: */
			localIP = localIP + ((148 & 7) + 1);
			break;
		case 149:
			/* shortUnconditionalJump */
			/* begin jump: */
			localIP = localIP + ((149 & 7) + 1);
			break;
		case 150:
			/* shortUnconditionalJump */
			/* begin jump: */
			localIP = localIP + ((150 & 7) + 1);
			break;
		case 151:
			/* shortUnconditionalJump */
			/* begin jump: */
			localIP = localIP + ((151 & 7) + 1);
			break;
		case 152:
			/* shortConditionalJump */
			/* begin jumplfFalseBy: */
			t1 = (152 & 7) + 1;
			t2 = longAt(localSP);
			/* begin internalPop: */
			localSP = localSP - (1 * 4);
			if (t2 == falseObj) {
				/* begin jump: */
				localIP = localIP + t1;
			} else {
				if (!(t2 == trueObj)) {
					/* begin externalizeIPandSP */
					instructionPointer = localIP;
					stackPointer = localSP;
					/* begin unPop: */
					stackPointer = stackPointer + (1 * 4);
					externalSendSelectorargumentCount(longAt((specialObjectsOop + 4) + (25 * 4)), 0);
					/* begin internalizeIPandSP */
					localIP = instructionPointer;
					localSP = stackPointer;
				}
			}
			break;
		case 153:
			/* shortConditionalJump */
			/* begin jumplfFalseBy: */
			t1 = (153 & 7) + 1;
			t2 = longAt(localSP);
			/* begin internalPop: */
			localSP = localSP - (1 * 4);
			if (t2 == falseObj) {
				/* begin jump: */
				localIP = localIP + t1;
			} else {
				if (!(t2 == trueObj)) {
					/* begin externalizeIPandSP */
					instructionPointer = localIP;
					stackPointer = localSP;
					/* begin unPop: */
					stackPointer = stackPointer + (1 * 4);
					externalSendSelectorargumentCount(longAt((specialObjectsOop + 4) + (25 * 4)), 0);
					/* begin internalizeIPandSP */
					localIP = instructionPointer;
					localSP = stackPointer;
				}
			}
			break;
		case 154:
			/* shortConditionalJump */
			/* begin jumplfFalseBy: */
			t1 = (154 & 7) + 1;
			t2 = longAt(localSP);
			/* begin internalPop: */
			localSP = localSP - (1 * 4);
			if (t2 == falseObj) {
				/* begin jump: */
				localIP = localIP + t1;
			} else {
				if (!(t2 == trueObj)) {
					/* begin externalizeIPandSP */
					instructionPointer = localIP;
					stackPointer = localSP;
					/* begin unPop: */
					stackPointer = stackPointer + (1 * 4);
					externalSendSelectorargumentCount(longAt((specialObjectsOop + 4) + (25 * 4)), 0);
					/* begin internalizeIPandSP */
					localIP = instructionPointer;
					localSP = stackPointer;
				}
			}
			break;
		case 155:
			/* shortConditionalJump */
			/* begin jumplfFalseBy: */
			t1 = (155 & 7) + 1;
			t2 = longAt(localSP);
			/* begin internalPop: */
			localSP = localSP - (1 * 4);
			if (t2 == falseObj) {
				/* begin jump: */
				localIP = localIP + t1;
			} else {
				if (!(t2 == trueObj)) {
					/* begin externalizeIPandSP */
					instructionPointer = localIP;
					stackPointer = localSP;
					/* begin unPop: */
					stackPointer = stackPointer + (1 * 4);
					externalSendSelectorargumentCount(longAt((specialObjectsOop + 4) + (25 * 4)), 0);
					/* begin internalizeIPandSP */
					localIP = instructionPointer;
					localSP = stackPointer;
				}
			}
			break;
		case 156:
			/* shortConditionalJump */
			/* begin jumplfFalseBy: */
			t1 = (156 & 7) + 1;
			t2 = longAt(localSP);
			/* begin internalPop: */
			localSP = localSP - (1 * 4);
			if (t2 == falseObj) {
				/* begin jump: */
				localIP = localIP + t1;
			} else {
				if (!(t2 == trueObj)) {
					/* begin externalizeIPandSP */
					instructionPointer = localIP;
					stackPointer = localSP;
					/* begin unPop: */
					stackPointer = stackPointer + (1 * 4);
					externalSendSelectorargumentCount(longAt((specialObjectsOop + 4) + (25 * 4)), 0);
					/* begin internalizeIPandSP */
					localIP = instructionPointer;
					localSP = stackPointer;
				}
			}
			break;
		case 157:
			/* shortConditionalJump */
			/* begin jumplfFalseBy: */
			t1 = (157 & 7) + 1;
			t2 = longAt(localSP);
			/* begin internalPop: */
			localSP = localSP - (1 * 4);
			if (t2 == falseObj) {
				/* begin jump: */
				localIP = localIP + t1;
			} else {
				if (!(t2 == trueObj)) {
					/* begin externalizeIPandSP */
					instructionPointer = localIP;
					stackPointer = localSP;
					/* begin unPop: */
					stackPointer = stackPointer + (1 * 4);
					externalSendSelectorargumentCount(longAt((specialObjectsOop + 4) + (25 * 4)), 0);
					/* begin internalizeIPandSP */
					localIP = instructionPointer;
					localSP = stackPointer;
				}
			}
			break;
		case 158:
			/* shortConditionalJump */
			/* begin jumplfFalseBy: */
			t1 = (158 & 7) + 1;
			t2 = longAt(localSP);
			/* begin internalPop: */
			localSP = localSP - (1 * 4);
			if (t2 == falseObj) {
				/* begin jump: */
				localIP = localIP + t1;
			} else {
				if (!(t2 == trueObj)) {
					/* begin externalizeIPandSP */
					instructionPointer = localIP;
					stackPointer = localSP;
					/* begin unPop: */
					stackPointer = stackPointer + (1 * 4);
					externalSendSelectorargumentCount(longAt((specialObjectsOop + 4) + (25 * 4)), 0);
					/* begin internalizeIPandSP */
					localIP = instructionPointer;
					localSP = stackPointer;
				}
			}
			break;
		case 159:
			/* shortConditionalJump */
			/* begin jumplfFalseBy: */
			t1 = (159 & 7) + 1;
			t2 = longAt(localSP);
			/* begin internalPop: */
			localSP = localSP - (1 * 4);
			if (t2 == falseObj) {
				/* begin jump: */
				localIP = localIP + t1;
			} else {
				if (!(t2 == trueObj)) {
					/* begin externalizeIPandSP */
					instructionPointer = localIP;
					stackPointer = localSP;
					/* begin unPop: */
					stackPointer = stackPointer + (1 * 4);
					externalSendSelectorargumentCount(longAt((specialObjectsOop + 4) + (25 * 4)), 0);
					/* begin internalizeIPandSP */
					localIP = instructionPointer;
					localSP = stackPointer;
				}
			}
			break;
		case 160:
			/* longUnconditionalJump */
			t1 = (((160 & 7) - 4) * 256) + (byteAt(++localIP));
			localIP = localIP + t1;
			if (t1 < 0) {
				/* begin internalQuickCheckForInterrupts */
				if ((interruptCheckCounter = interruptCheckCounter - 1) <= 0) {
					interruptCheckCounter = 1000;
					/* begin externalizeIPandSP */
					instructionPointer = localIP;
					stackPointer = localSP;
					checkForInterrupts();
					/* begin internalizeIPandSP */
					localIP = instructionPointer;
					localSP = stackPointer;
				}
			}
			break;
		case 161:
			/* longUnconditionalJump */
			t1 = (((161 & 7) - 4) * 256) + (byteAt(++localIP));
			localIP = localIP + t1;
			if (t1 < 0) {
				/* begin internalQuickCheckForInterrupts */
				if ((interruptCheckCounter = interruptCheckCounter - 1) <= 0) {
					interruptCheckCounter = 1000;
					/* begin externalizeIPandSP */
					instructionPointer = localIP;
					stackPointer = localSP;
					checkForInterrupts();
					/* begin internalizeIPandSP */
					localIP = instructionPointer;
					localSP = stackPointer;
				}
			}
			break;
		case 162:
			/* longUnconditionalJump */
			t1 = (((162 & 7) - 4) * 256) + (byteAt(++localIP));
			localIP = localIP + t1;
			if (t1 < 0) {
				/* begin internalQuickCheckForInterrupts */
				if ((interruptCheckCounter = interruptCheckCounter - 1) <= 0) {
					interruptCheckCounter = 1000;
					/* begin externalizeIPandSP */
					instructionPointer = localIP;
					stackPointer = localSP;
					checkForInterrupts();
					/* begin internalizeIPandSP */
					localIP = instructionPointer;
					localSP = stackPointer;
				}
			}
			break;
		case 163:
			/* longUnconditionalJump */
			t1 = (((163 & 7) - 4) * 256) + (byteAt(++localIP));
			localIP = localIP + t1;
			if (t1 < 0) {
				/* begin internalQuickCheckForInterrupts */
				if ((interruptCheckCounter = interruptCheckCounter - 1) <= 0) {
					interruptCheckCounter = 1000;
					/* begin externalizeIPandSP */
					instructionPointer = localIP;
					stackPointer = localSP;
					checkForInterrupts();
					/* begin internalizeIPandSP */
					localIP = instructionPointer;
					localSP = stackPointer;
				}
			}
			break;
		case 164:
			/* longUnconditionalJump */
			t1 = (((164 & 7) - 4) * 256) + (byteAt(++localIP));
			localIP = localIP + t1;
			if (t1 < 0) {
				/* begin internalQuickCheckForInterrupts */
				if ((interruptCheckCounter = interruptCheckCounter - 1) <= 0) {
					interruptCheckCounter = 1000;
					/* begin externalizeIPandSP */
					instructionPointer = localIP;
					stackPointer = localSP;
					checkForInterrupts();
					/* begin internalizeIPandSP */
					localIP = instructionPointer;
					localSP = stackPointer;
				}
			}
			break;
		case 165:
			/* longUnconditionalJump */
			t1 = (((165 & 7) - 4) * 256) + (byteAt(++localIP));
			localIP = localIP + t1;
			if (t1 < 0) {
				/* begin internalQuickCheckForInterrupts */
				if ((interruptCheckCounter = interruptCheckCounter - 1) <= 0) {
					interruptCheckCounter = 1000;
					/* begin externalizeIPandSP */
					instructionPointer = localIP;
					stackPointer = localSP;
					checkForInterrupts();
					/* begin internalizeIPandSP */
					localIP = instructionPointer;
					localSP = stackPointer;
				}
			}
			break;
		case 166:
			/* longUnconditionalJump */
			t1 = (((166 & 7) - 4) * 256) + (byteAt(++localIP));
			localIP = localIP + t1;
			if (t1 < 0) {
				/* begin internalQuickCheckForInterrupts */
				if ((interruptCheckCounter = interruptCheckCounter - 1) <= 0) {
					interruptCheckCounter = 1000;
					/* begin externalizeIPandSP */
					instructionPointer = localIP;
					stackPointer = localSP;
					checkForInterrupts();
					/* begin internalizeIPandSP */
					localIP = instructionPointer;
					localSP = stackPointer;
				}
			}
			break;
		case 167:
			/* longUnconditionalJump */
			t1 = (((167 & 7) - 4) * 256) + (byteAt(++localIP));
			localIP = localIP + t1;
			if (t1 < 0) {
				/* begin internalQuickCheckForInterrupts */
				if ((interruptCheckCounter = interruptCheckCounter - 1) <= 0) {
					interruptCheckCounter = 1000;
					/* begin externalizeIPandSP */
					instructionPointer = localIP;
					stackPointer = localSP;
					checkForInterrupts();
					/* begin internalizeIPandSP */
					localIP = instructionPointer;
					localSP = stackPointer;
				}
			}
			break;
		case 168:
			/* longJumpIfTrue */
			/* begin jumplfTrueBy: */
			t1 = ((168 & 3) * 256) + (byteAt(++localIP));
			t2 = longAt(localSP);
			/* begin internalPop: */
			localSP = localSP - (1 * 4);
			if (t2 == trueObj) {
				/* begin jump: */
				localIP = localIP + t1;
			} else {
				if (!(t2 == falseObj)) {
					/* begin externalizeIPandSP */
					instructionPointer = localIP;
					stackPointer = localSP;
					/* begin unPop: */
					stackPointer = stackPointer + (1 * 4);
					externalSendSelectorargumentCount(longAt((specialObjectsOop + 4) + (25 * 4)), 0);
					/* begin internalizeIPandSP */
					localIP = instructionPointer;
					localSP = stackPointer;
				}
			}
			break;
		case 169:
			/* longJumpIfTrue */
			/* begin jumplfTrueBy: */
			t1 = ((169 & 3) * 256) + (byteAt(++localIP));
			t2 = longAt(localSP);
			/* begin internalPop: */
			localSP = localSP - (1 * 4);
			if (t2 == trueObj) {
				/* begin jump: */
				localIP = localIP + t1;
			} else {
				if (!(t2 == falseObj)) {
					/* begin externalizeIPandSP */
					instructionPointer = localIP;
					stackPointer = localSP;
					/* begin unPop: */
					stackPointer = stackPointer + (1 * 4);
					externalSendSelectorargumentCount(longAt((specialObjectsOop + 4) + (25 * 4)), 0);
					/* begin internalizeIPandSP */
					localIP = instructionPointer;
					localSP = stackPointer;
				}
			}
			break;
		case 170:
			/* longJumpIfTrue */
			/* begin jumplfTrueBy: */
			t1 = ((170 & 3) * 256) + (byteAt(++localIP));
			t2 = longAt(localSP);
			/* begin internalPop: */
			localSP = localSP - (1 * 4);
			if (t2 == trueObj) {
				/* begin jump: */
				localIP = localIP + t1;
			} else {
				if (!(t2 == falseObj)) {
					/* begin externalizeIPandSP */
					instructionPointer = localIP;
					stackPointer = localSP;
					/* begin unPop: */
					stackPointer = stackPointer + (1 * 4);
					externalSendSelectorargumentCount(longAt((specialObjectsOop + 4) + (25 * 4)), 0);
					/* begin internalizeIPandSP */
					localIP = instructionPointer;
					localSP = stackPointer;
				}
			}
			break;
		case 171:
			/* longJumpIfTrue */
			/* begin jumplfTrueBy: */
			t1 = ((171 & 3) * 256) + (byteAt(++localIP));
			t2 = longAt(localSP);
			/* begin internalPop: */
			localSP = localSP - (1 * 4);
			if (t2 == trueObj) {
				/* begin jump: */
				localIP = localIP + t1;
			} else {
				if (!(t2 == falseObj)) {
					/* begin externalizeIPandSP */
					instructionPointer = localIP;
					stackPointer = localSP;
					/* begin unPop: */
					stackPointer = stackPointer + (1 * 4);
					externalSendSelectorargumentCount(longAt((specialObjectsOop + 4) + (25 * 4)), 0);
					/* begin internalizeIPandSP */
					localIP = instructionPointer;
					localSP = stackPointer;
				}
			}
			break;
		case 172:
			/* longJumpIfFalse */
			/* begin jumplfFalseBy: */
			t1 = ((172 & 3) * 256) + (byteAt(++localIP));
			t2 = longAt(localSP);
			/* begin internalPop: */
			localSP = localSP - (1 * 4);
			if (t2 == falseObj) {
				/* begin jump: */
				localIP = localIP + t1;
			} else {
				if (!(t2 == trueObj)) {
					/* begin externalizeIPandSP */
					instructionPointer = localIP;
					stackPointer = localSP;
					/* begin unPop: */
					stackPointer = stackPointer + (1 * 4);
					externalSendSelectorargumentCount(longAt((specialObjectsOop + 4) + (25 * 4)), 0);
					/* begin internalizeIPandSP */
					localIP = instructionPointer;
					localSP = stackPointer;
				}
			}
			break;
		case 173:
			/* longJumpIfFalse */
			/* begin jumplfFalseBy: */
			t1 = ((173 & 3) * 256) + (byteAt(++localIP));
			t2 = longAt(localSP);
			/* begin internalPop: */
			localSP = localSP - (1 * 4);
			if (t2 == falseObj) {
				/* begin jump: */
				localIP = localIP + t1;
			} else {
				if (!(t2 == trueObj)) {
					/* begin externalizeIPandSP */
					instructionPointer = localIP;
					stackPointer = localSP;
					/* begin unPop: */
					stackPointer = stackPointer + (1 * 4);
					externalSendSelectorargumentCount(longAt((specialObjectsOop + 4) + (25 * 4)), 0);
					/* begin internalizeIPandSP */
					localIP = instructionPointer;
					localSP = stackPointer;
				}
			}
			break;
		case 174:
			/* longJumpIfFalse */
			/* begin jumplfFalseBy: */
			t1 = ((174 & 3) * 256) + (byteAt(++localIP));
			t2 = longAt(localSP);
			/* begin internalPop: */
			localSP = localSP - (1 * 4);
			if (t2 == falseObj) {
				/* begin jump: */
				localIP = localIP + t1;
			} else {
				if (!(t2 == trueObj)) {
					/* begin externalizeIPandSP */
					instructionPointer = localIP;
					stackPointer = localSP;
					/* begin unPop: */
					stackPointer = stackPointer + (1 * 4);
					externalSendSelectorargumentCount(longAt((specialObjectsOop + 4) + (25 * 4)), 0);
					/* begin internalizeIPandSP */
					localIP = instructionPointer;
					localSP = stackPointer;
				}
			}
			break;
		case 175:
			/* longJumpIfFalse */
			/* begin jumplfFalseBy: */
			t1 = ((175 & 3) * 256) + (byteAt(++localIP));
			t2 = longAt(localSP);
			/* begin internalPop: */
			localSP = localSP - (1 * 4);
			if (t2 == falseObj) {
				/* begin jump: */
				localIP = localIP + t1;
			} else {
				if (!(t2 == trueObj)) {
					/* begin externalizeIPandSP */
					instructionPointer = localIP;
					stackPointer = localSP;
					/* begin unPop: */
					stackPointer = stackPointer + (1 * 4);
					externalSendSelectorargumentCount(longAt((specialObjectsOop + 4) + (25 * 4)), 0);
					/* begin internalizeIPandSP */
					localIP = instructionPointer;
					localSP = stackPointer;
				}
			}
			break;
		case 176:
			/* bytecodePrimAdd */
			t1 = longAt(localSP - (1 * 4));
			t2 = longAt(localSP - (0 * 4));
			if (((t1 & t2) & 1) != 0) {
				t3 = ((t1 >> 1)) + ((t2 >> 1));
				if ((t3 >= -1073741824) && (t3 < 1073741824)) {
					longAtput(localSP = localSP - 4, ((t3 << 1) | 1));
					goto l11;
				}
			}
			/* begin externalizeIPandSP */
			instructionPointer = localIP;
			stackPointer = localSP;
			primitiveAdd();
			/* begin internalizeIPandSP */
			localIP = instructionPointer;
			localSP = stackPointer;
		l11:	/* end case */;
			break;
		case 177:
			/* bytecodePrimSubtract */
			t1 = longAt(localSP - (1 * 4));
			t2 = longAt(localSP - (0 * 4));
			if (((t1 & t2) & 1) != 0) {
				t3 = ((t1 >> 1)) - ((t2 >> 1));
				if ((t3 >= -1073741824) && (t3 < 1073741824)) {
					longAtput(localSP = localSP - 4, ((t3 << 1) | 1));
					goto l12;
				}
			}
			/* begin externalizeIPandSP */
			instructionPointer = localIP;
			stackPointer = localSP;
			primitiveSubtract();
			/* begin internalizeIPandSP */
			localIP = instructionPointer;
			localSP = stackPointer;
		l12:	/* end case */;
			break;
		case 178:
			/* bytecodePrimLessThan */
			t1 = longAt(localSP - (1 * 4));
			t2 = longAt(localSP - (0 * 4));
			if (((t1 & t2) & 1) != 0) {
				/* begin booleanCheat: */
				t3 = byteAt(++localIP);
				if ((t3 >= 152) && (t3 <= 159)) {
					/* begin internalPop: */
					localSP = localSP - (2 * 4);
					if (!(t1 < t2)) {
						/* begin jump: */
						localIP = localIP + (t3 - 151);
						goto l13;
					}
					goto l13;
				}
				if (t3 == 172) {
					/* begin internalPop: */
					localSP = localSP - (2 * 4);
					if (!(t1 < t2)) {
						/* begin jump: */
						t4 = byteAt(++localIP);
						localIP = localIP + t4;
						goto l13;
					}
					/* begin jump: */
					localIP = localIP + 1;
					goto l13;
				}
				localIP = localIP - 1;
				if (t1 < t2) {
					longAtput(localSP = localSP - 4, trueObj);
				} else {
					longAtput(localSP = localSP - 4, falseObj);
				}
				goto l13;
			}
			/* begin externalizeIPandSP */
			instructionPointer = localIP;
			stackPointer = localSP;
			primitiveLessThan();
			/* begin internalizeIPandSP */
			localIP = instructionPointer;
			localSP = stackPointer;
		l13:	/* end case */;
			break;
		case 179:
			/* bytecodePrimGreaterThan */
			t1 = longAt(localSP - (1 * 4));
			t2 = longAt(localSP - (0 * 4));
			if (((t1 & t2) & 1) != 0) {
				/* begin booleanCheat: */
				t3 = byteAt(++localIP);
				if ((t3 >= 152) && (t3 <= 159)) {
					/* begin internalPop: */
					localSP = localSP - (2 * 4);
					if (!(t1 > t2)) {
						/* begin jump: */
						localIP = localIP + (t3 - 151);
						goto l14;
					}
					goto l14;
				}
				if (t3 == 172) {
					/* begin internalPop: */
					localSP = localSP - (2 * 4);
					if (!(t1 > t2)) {
						/* begin jump: */
						t4 = byteAt(++localIP);
						localIP = localIP + t4;
						goto l14;
					}
					/* begin jump: */
					localIP = localIP + 1;
					goto l14;
				}
				localIP = localIP - 1;
				if (t1 > t2) {
					longAtput(localSP = localSP - 4, trueObj);
				} else {
					longAtput(localSP = localSP - 4, falseObj);
				}
				goto l14;
			}
			/* begin externalizeIPandSP */
			instructionPointer = localIP;
			stackPointer = localSP;
			primitiveGreaterThan();
			/* begin internalizeIPandSP */
			localIP = instructionPointer;
			localSP = stackPointer;
		l14:	/* end case */;
			break;
		case 180:
			/* bytecodePrimLessOrEqual */
			t1 = longAt(localSP - (1 * 4));
			t2 = longAt(localSP - (0 * 4));
			if (((t1 & t2) & 1) != 0) {
				/* begin booleanCheat: */
				t3 = byteAt(++localIP);
				if ((t3 >= 152) && (t3 <= 159)) {
					/* begin internalPop: */
					localSP = localSP - (2 * 4);
					if (!(t1 <= t2)) {
						/* begin jump: */
						localIP = localIP + (t3 - 151);
						goto l15;
					}
					goto l15;
				}
				if (t3 == 172) {
					/* begin internalPop: */
					localSP = localSP - (2 * 4);
					if (!(t1 <= t2)) {
						/* begin jump: */
						t4 = byteAt(++localIP);
						localIP = localIP + t4;
						goto l15;
					}
					/* begin jump: */
					localIP = localIP + 1;
					goto l15;
				}
				localIP = localIP - 1;
				if (t1 <= t2) {
					longAtput(localSP = localSP - 4, trueObj);
				} else {
					longAtput(localSP = localSP - 4, falseObj);
				}
				goto l15;
			}
			/* begin externalizeIPandSP */
			instructionPointer = localIP;
			stackPointer = localSP;
			primitiveLessOrEqual();
			/* begin internalizeIPandSP */
			localIP = instructionPointer;
			localSP = stackPointer;
		l15:	/* end case */;
			break;
		case 181:
			/* bytecodePrimGreaterOrEqual */
			t1 = longAt(localSP - (1 * 4));
			t2 = longAt(localSP - (0 * 4));
			if (((t1 & t2) & 1) != 0) {
				/* begin booleanCheat: */
				t3 = byteAt(++localIP);
				if ((t3 >= 152) && (t3 <= 159)) {
					/* begin internalPop: */
					localSP = localSP - (2 * 4);
					if (!(t1 >= t2)) {
						/* begin jump: */
						localIP = localIP + (t3 - 151);
						goto l16;
					}
					goto l16;
				}
				if (t3 == 172) {
					/* begin internalPop: */
					localSP = localSP - (2 * 4);
					if (!(t1 >= t2)) {
						/* begin jump: */
						t4 = byteAt(++localIP);
						localIP = localIP + t4;
						goto l16;
					}
					/* begin jump: */
					localIP = localIP + 1;
					goto l16;
				}
				localIP = localIP - 1;
				if (t1 >= t2) {
					longAtput(localSP = localSP - 4, trueObj);
				} else {
					longAtput(localSP = localSP - 4, falseObj);
				}
				goto l16;
			}
			/* begin externalizeIPandSP */
			instructionPointer = localIP;
			stackPointer = localSP;
			primitiveGreaterOrEqual();
			/* begin internalizeIPandSP */
			localIP = instructionPointer;
			localSP = stackPointer;
		l16:	/* end case */;
			break;
		case 182:
			/* bytecodePrimEqual */
			t1 = longAt(localSP - (1 * 4));
			t2 = longAt(localSP - (0 * 4));
			if (((t1 & t2) & 1) != 0) {
				/* begin booleanCheat: */
				t3 = byteAt(++localIP);
				if ((t3 >= 152) && (t3 <= 159)) {
					/* begin internalPop: */
					localSP = localSP - (2 * 4);
					if (!(t1 == t2)) {
						/* begin jump: */
						localIP = localIP + (t3 - 151);
						goto l17;
					}
					goto l17;
				}
				if (t3 == 172) {
					/* begin internalPop: */
					localSP = localSP - (2 * 4);
					if (!(t1 == t2)) {
						/* begin jump: */
						t4 = byteAt(++localIP);
						localIP = localIP + t4;
						goto l17;
					}
					/* begin jump: */
					localIP = localIP + 1;
					goto l17;
				}
				localIP = localIP - 1;
				if (t1 == t2) {
					longAtput(localSP = localSP - 4, trueObj);
				} else {
					longAtput(localSP = localSP - 4, falseObj);
				}
				goto l17;
			}
			/* begin externalizeIPandSP */
			instructionPointer = localIP;
			stackPointer = localSP;
			primitiveEqual();
			/* begin internalizeIPandSP */
			localIP = instructionPointer;
			localSP = stackPointer;
		l17:	/* end case */;
			break;
		case 183:
			/* bytecodePrimNotEqual */
			t1 = longAt(localSP - (1 * 4));
			t2 = longAt(localSP - (0 * 4));
			if (((t1 & t2) & 1) != 0) {
				/* begin booleanCheat: */
				t3 = byteAt(++localIP);
				if ((t3 >= 152) && (t3 <= 159)) {
					/* begin internalPop: */
					localSP = localSP - (2 * 4);
					if (!(t1 != t2)) {
						/* begin jump: */
						localIP = localIP + (t3 - 151);
						goto l18;
					}
					goto l18;
				}
				if (t3 == 172) {
					/* begin internalPop: */
					localSP = localSP - (2 * 4);
					if (!(t1 != t2)) {
						/* begin jump: */
						t4 = byteAt(++localIP);
						localIP = localIP + t4;
						goto l18;
					}
					/* begin jump: */
					localIP = localIP + 1;
					goto l18;
				}
				localIP = localIP - 1;
				if (t1 != t2) {
					longAtput(localSP = localSP - 4, trueObj);
				} else {
					longAtput(localSP = localSP - 4, falseObj);
				}
				goto l18;
			}
			/* begin externalizeIPandSP */
			instructionPointer = localIP;
			stackPointer = localSP;
			primitiveNotEqual();
			/* begin internalizeIPandSP */
			localIP = instructionPointer;
			localSP = stackPointer;
		l18:	/* end case */;
			break;
		case 184:
			/* bytecodePrimMultiply */
			t1 = longAt(localSP - (1 * 4));
			t2 = longAt(localSP - (0 * 4));
			if (((t1 & t2) & 1) != 0) {
				t1 = (t1 >> 1);
				t2 = (t2 >> 1);
				t3 = t1 * t2;
				if (((t2 == 0) || ((t3 / t2) == t1)) && ((t3 >= -1073741824) && (t3 < 1073741824))) {
					longAtput(localSP = localSP - 4, ((t3 << 1) | 1));
					goto l19;
				}
			}
			/* begin externalizeIPandSP */
			instructionPointer = localIP;
			stackPointer = localSP;
			primitiveMultiply();
			/* begin internalizeIPandSP */
			localIP = instructionPointer;
			localSP = stackPointer;
		l19:	/* end case */;
			break;
		case 185:
			/* bytecodePrimDivide */
			/* begin externalizeIPandSP */
			instructionPointer = localIP;
			stackPointer = localSP;
			primitiveDivide();
			/* begin internalizeIPandSP */
			localIP = instructionPointer;
			localSP = stackPointer;
			break;
		case 186:
			/* bytecodePrimMod */
			/* begin externalizeIPandSP */
			instructionPointer = localIP;
			stackPointer = localSP;
			primitiveMod();
			/* begin internalizeIPandSP */
			localIP = instructionPointer;
			localSP = stackPointer;
			break;
		case 187:
			/* bytecodePrimMakePoint */
			/* begin externalizeIPandSP */
			instructionPointer = localIP;
			stackPointer = localSP;
			primitiveMakePoint();
			/* begin internalizeIPandSP */
			localIP = instructionPointer;
			localSP = stackPointer;
			break;
		case 188:
			/* bytecodePrimBitShift */
			/* begin externalizeIPandSP */
			instructionPointer = localIP;
			stackPointer = localSP;
			primitiveBitShift();
			/* begin internalizeIPandSP */
			localIP = instructionPointer;
			localSP = stackPointer;
			break;
		case 189:
			/* bytecodePrimDiv */
			/* begin externalizeIPandSP */
			instructionPointer = localIP;
			stackPointer = localSP;
			primitiveDiv();
			/* begin internalizeIPandSP */
			localIP = instructionPointer;
			localSP = stackPointer;
			break;
		case 190:
			/* bytecodePrimBitAnd */
			/* begin externalizeIPandSP */
			instructionPointer = localIP;
			stackPointer = localSP;
			primitiveBitAnd();
			/* begin internalizeIPandSP */
			localIP = instructionPointer;
			localSP = stackPointer;
			break;
		case 191:
			/* bytecodePrimBitOr */
			/* begin externalizeIPandSP */
			instructionPointer = localIP;
			stackPointer = localSP;
			primitiveBitOr();
			/* begin internalizeIPandSP */
			localIP = instructionPointer;
			localSP = stackPointer;
			break;
		case 192:
			/* bytecodePrimAt */
			/* begin externalizeIPandSP */
			instructionPointer = localIP;
			stackPointer = localSP;
			successFlag = true;
			/* begin fetchClassOf: */
			if ((((longAt(stackPointer - (1 * 4))) & 1) == 1)) {
				t1 = longAt((specialObjectsOop + 4) + (5 * 4));
				goto l20;
			}
			t3 = ((((unsigned) (longAt(longAt(stackPointer - (1 * 4))))) >> 12) & 31) - 1;
			if (t3 < 0) {
				t1 = (longAt((longAt(stackPointer - (1 * 4))) - 4)) & 4294967292;
				goto l20;
			} else {
				t1 = longAt(((longAt((specialObjectsOop + 4) + (28 * 4))) + 4) + (t3 * 4));
				goto l20;
			}
		l20:	/* end fetchClassOf: */;
			t2 = t1 == (longAt((specialObjectsOop + 4) + (6 * 4)));
			if (t2 || ((t1 == (longAt((specialObjectsOop + 4) + (6 * 4)))) || ((t1 == (longAt((specialObjectsOop + 4) + (7 * 4)))) || ((t1 == (longAt((specialObjectsOop + 4) + (26 * 4)))) || (t1 == (longAt((specialObjectsOop + 4) + (4 * 4)))))))) {
				commonAt(t2);
			} else {
				failSpecialPrim(0);
			}
			/* begin internalizeIPandSP */
			localIP = instructionPointer;
			localSP = stackPointer;
			break;
		case 193:
			/* bytecodePrimAtPut */
			/* begin externalizeIPandSP */
			instructionPointer = localIP;
			stackPointer = localSP;
			successFlag = true;
			/* begin fetchClassOf: */
			if ((((longAt(stackPointer - (2 * 4))) & 1) == 1)) {
				t1 = longAt((specialObjectsOop + 4) + (5 * 4));
				goto l21;
			}
			t3 = ((((unsigned) (longAt(longAt(stackPointer - (2 * 4))))) >> 12) & 31) - 1;
			if (t3 < 0) {
				t1 = (longAt((longAt(stackPointer - (2 * 4))) - 4)) & 4294967292;
				goto l21;
			} else {
				t1 = longAt(((longAt((specialObjectsOop + 4) + (28 * 4))) + 4) + (t3 * 4));
				goto l21;
			}
		l21:	/* end fetchClassOf: */;
			t2 = t1 == (longAt((specialObjectsOop + 4) + (6 * 4)));
			if (t2 || ((t1 == (longAt((specialObjectsOop + 4) + (6 * 4)))) || ((t1 == (longAt((specialObjectsOop + 4) + (7 * 4)))) || ((t1 == (longAt((specialObjectsOop + 4) + (26 * 4)))) || (t1 == (longAt((specialObjectsOop + 4) + (4 * 4)))))))) {
				commonAtPut(t2);
			} else {
				failSpecialPrim(0);
			}
			/* begin internalizeIPandSP */
			localIP = instructionPointer;
			localSP = stackPointer;
			break;
		case 194:
			/* bytecodePrimSize */
			/* begin externalizeIPandSP */
			instructionPointer = localIP;
			stackPointer = localSP;
			successFlag = true;
			/* begin fetchClassOf: */
			if ((((longAt(stackPointer - (0 * 4))) & 1) == 1)) {
				t1 = longAt((specialObjectsOop + 4) + (5 * 4));
				goto l22;
			}
			t2 = ((((unsigned) (longAt(longAt(stackPointer - (0 * 4))))) >> 12) & 31) - 1;
			if (t2 < 0) {
				t1 = (longAt((longAt(stackPointer - (0 * 4))) - 4)) & 4294967292;
				goto l22;
			} else {
				t1 = longAt(((longAt((specialObjectsOop + 4) + (28 * 4))) + 4) + (t2 * 4));
				goto l22;
			}
		l22:	/* end fetchClassOf: */;
			if ((t1 == (longAt((specialObjectsOop + 4) + (6 * 4)))) || ((t1 == (longAt((specialObjectsOop + 4) + (7 * 4)))) || ((t1 == (longAt((specialObjectsOop + 4) + (26 * 4)))) || (t1 == (longAt((specialObjectsOop + 4) + (4 * 4))))))) {
				primitiveSize();
			} else {
				failSpecialPrim(0);
			}
			/* begin internalizeIPandSP */
			localIP = instructionPointer;
			localSP = stackPointer;
			break;
		case 195:
			/* bytecodePrimNext */
			/* begin externalizeIPandSP */
			instructionPointer = localIP;
			stackPointer = localSP;
			successFlag = true;
			/* begin fetchClassOf: */
			if ((((longAt(stackPointer - (0 * 4))) & 1) == 1)) {
				t1 = longAt((specialObjectsOop + 4) + (5 * 4));
				goto l23;
			}
			t3 = ((((unsigned) (longAt(longAt(stackPointer - (0 * 4))))) >> 12) & 31) - 1;
			if (t3 < 0) {
				t1 = (longAt((longAt(stackPointer - (0 * 4))) - 4)) & 4294967292;
				goto l23;
			} else {
				t1 = longAt(((longAt((specialObjectsOop + 4) + (28 * 4))) + 4) + (t3 * 4));
				goto l23;
			}
		l23:	/* end fetchClassOf: */;
			/* begin success: */
			t4 = (t1 == (longAt((specialObjectsOop + 4) + (6 * 4)))) || ((t1 == (longAt((specialObjectsOop + 4) + (7 * 4)))) || ((t1 == (longAt((specialObjectsOop + 4) + (26 * 4)))) || (t1 == (longAt((specialObjectsOop + 4) + (4 * 4))))));
			successFlag = t4 && successFlag;
			if (successFlag) {
				primitiveNext();
			}
			if (!(successFlag)) {
				t2 = longAt(((longAt((specialObjectsOop + 4) + (23 * 4))) + 4) + ((19 * 2) * 4));
				externalSendSelectorargumentCount(t2, 0);
			}
			/* begin internalizeIPandSP */
			localIP = instructionPointer;
			localSP = stackPointer;
			break;
		case 196:
			/* bytecodePrimNextPut */
			/* begin externalizeIPandSP */
			instructionPointer = localIP;
			stackPointer = localSP;
			primitiveNextPut();
			/* begin internalizeIPandSP */
			localIP = instructionPointer;
			localSP = stackPointer;
			break;
		case 197:
			/* bytecodePrimAtEnd */
			/* begin externalizeIPandSP */
			instructionPointer = localIP;
			stackPointer = localSP;
			primitiveAtEnd();
			/* begin internalizeIPandSP */
			localIP = instructionPointer;
			localSP = stackPointer;
			break;
		case 198:
			/* bytecodePrimEquivalent */
			/* begin booleanCheat: */
			t1 = (longAt(localSP - (1 * 4))) == (longAt(localSP - (0 * 4)));
			t2 = byteAt(++localIP);
			if ((t2 >= 152) && (t2 <= 159)) {
				/* begin internalPop: */
				localSP = localSP - (2 * 4);
				if (!(t1)) {
					/* begin jump: */
					localIP = localIP + (t2 - 151);
					goto l24;
				}
				goto l24;
			}
			if (t2 == 172) {
				/* begin internalPop: */
				localSP = localSP - (2 * 4);
				if (!(t1)) {
					/* begin jump: */
					t3 = byteAt(++localIP);
					localIP = localIP + t3;
					goto l24;
				}
				/* begin jump: */
				localIP = localIP + 1;
				goto l24;
			}
			localIP = localIP - 1;
			if (t1) {
				longAtput(localSP = localSP - 4, trueObj);
			} else {
				longAtput(localSP = localSP - 4, falseObj);
			}
		l24:	/* end booleanCheat: */;
			break;
		case 199:
			/* bytecodePrimClass */
			/* begin externalizeIPandSP */
			instructionPointer = localIP;
			stackPointer = localSP;
			primitiveClass();
			/* begin internalizeIPandSP */
			localIP = instructionPointer;
			localSP = stackPointer;
			break;
		case 200:
			/* bytecodePrimBlockCopy */
			/* begin externalizeIPandSP */
			instructionPointer = localIP;
			stackPointer = localSP;
			successFlag = true;
			argumentCount = 1;
			/* begin fetchClassOf: */
			if ((((longAt(stackPointer - (argumentCount * 4))) & 1) == 1)) {
				t2 = longAt((specialObjectsOop + 4) + (5 * 4));
				goto l25;
			}
			t3 = ((((unsigned) (longAt(longAt(stackPointer - (argumentCount * 4))))) >> 12) & 31) - 1;
			if (t3 < 0) {
				t2 = (longAt((longAt(stackPointer - (argumentCount * 4))) - 4)) & 4294967292;
				goto l25;
			} else {
				t2 = longAt(((longAt((specialObjectsOop + 4) + (28 * 4))) + 4) + (t3 * 4));
				goto l25;
			}
		l25:	/* end fetchClassOf: */;
			/* begin success: */
			t4 = (t2 == (longAt((specialObjectsOop + 4) + (11 * 4)))) || (t2 == (longAt((specialObjectsOop + 4) + (10 * 4))));
			successFlag = t4 && successFlag;
			if (successFlag) {
				/* begin primitiveBlockCopy */
				t5 = longAt(stackPointer - (1 * 4));
				if ((((longAt((t5 + 4) + (3 * 4))) & 1) == 1)) {
					t6 = longAt((t5 + 4) + (5 * 4));
				} else {
					t6 = t5;
				}
				/* begin sizeBitsOf: */
				t10 = longAt(t6);
				if ((t10 & 3) == 0) {
					t7 = (longAt(t6 - 8)) & 4294967292;
					goto l26;
				} else {
					t7 = t10 & 252;
					goto l26;
				}
			l26:	/* end sizeBitsOf: */;
				t5 = null;
				/* begin pushRemappableOop: */
				remapBuffer[remapBufferCount = remapBufferCount + 1] = t6;
				t8 = instantiateSmallClasssizeInBytesfill(longAt((specialObjectsOop + 4) + (11 * 4)), t7, nilObj);
				/* begin popRemappableOop */
				t11 = remapBuffer[remapBufferCount];
				remapBufferCount = remapBufferCount - 1;
				t6 = t11;
				t9 = (((instructionPointer - method) << 1) | 1);
				longAtput((t8 + 4) + (4 * 4), t9);
				longAtput((t8 + 4) + (1 * 4), t9);
				/* begin storeStackPointerValue:inContext: */
				longAtput((t8 + 4) + (2 * 4), ((0 << 1) | 1));
				longAtput((t8 + 4) + (3 * 4), longAt(stackPointer - (0 * 4)));
				longAtput((t8 + 4) + (5 * 4), t6);
				/* begin pop: */
				stackPointer = stackPointer - (2 * 4);
				/* begin push: */
				longAtput(stackPointer = stackPointer + 4, t8);
			}
			if (!(successFlag)) {
				t1 = longAt(((longAt((specialObjectsOop + 4) + (23 * 4))) + 4) + ((24 * 2) * 4));
				externalSendSelectorargumentCount(t1, argumentCount);
			}
			/* begin internalizeIPandSP */
			localIP = instructionPointer;
			localSP = stackPointer;
			break;
		case 201:
			/* bytecodePrimValue */
			/* begin externalizeIPandSP */
			instructionPointer = localIP;
			stackPointer = localSP;
			successFlag = true;
			argumentCount = 0;
			/* begin fetchClassOf: */
			if ((((longAt(stackPointer - (argumentCount * 4))) & 1) == 1)) {
				t2 = longAt((specialObjectsOop + 4) + (5 * 4));
				goto l27;
			}
			t3 = ((((unsigned) (longAt(longAt(stackPointer - (argumentCount * 4))))) >> 12) & 31) - 1;
			if (t3 < 0) {
				t2 = (longAt((longAt(stackPointer - (argumentCount * 4))) - 4)) & 4294967292;
				goto l27;
			} else {
				t2 = longAt(((longAt((specialObjectsOop + 4) + (28 * 4))) + 4) + (t3 * 4));
				goto l27;
			}
		l27:	/* end fetchClassOf: */;
			/* begin success: */
			successFlag = (t2 == (longAt((specialObjectsOop + 4) + (11 * 4)))) && successFlag;
			if (successFlag) {
				primitiveValue();
			}
			if (!(successFlag)) {
				t1 = longAt(((longAt((specialObjectsOop + 4) + (23 * 4))) + 4) + ((25 * 2) * 4));
				externalSendSelectorargumentCount(t1, argumentCount);
			}
			/* begin internalizeIPandSP */
			localIP = instructionPointer;
			localSP = stackPointer;
			break;
		case 202:
			/* bytecodePrimValueWithArg */
			/* begin externalizeIPandSP */
			instructionPointer = localIP;
			stackPointer = localSP;
			successFlag = true;
			argumentCount = 1;
			/* begin fetchClassOf: */
			if ((((longAt(stackPointer - (argumentCount * 4))) & 1) == 1)) {
				t2 = longAt((specialObjectsOop + 4) + (5 * 4));
				goto l28;
			}
			t3 = ((((unsigned) (longAt(longAt(stackPointer - (argumentCount * 4))))) >> 12) & 31) - 1;
			if (t3 < 0) {
				t2 = (longAt((longAt(stackPointer - (argumentCount * 4))) - 4)) & 4294967292;
				goto l28;
			} else {
				t2 = longAt(((longAt((specialObjectsOop + 4) + (28 * 4))) + 4) + (t3 * 4));
				goto l28;
			}
		l28:	/* end fetchClassOf: */;
			/* begin success: */
			successFlag = (t2 == (longAt((specialObjectsOop + 4) + (11 * 4)))) && successFlag;
			if (successFlag) {
				primitiveValue();
			}
			if (!(successFlag)) {
				t1 = longAt(((longAt((specialObjectsOop + 4) + (23 * 4))) + 4) + ((26 * 2) * 4));
				externalSendSelectorargumentCount(t1, argumentCount);
			}
			/* begin internalizeIPandSP */
			localIP = instructionPointer;
			localSP = stackPointer;
			break;
		case 203:
			/* bytecodePrimDo */
			t1 = longAt(((longAt((specialObjectsOop + 4) + (23 * 4))) + 4) + ((27 * 2) * 4));
			/* begin externalizeIPandSP */
			instructionPointer = localIP;
			stackPointer = localSP;
			externalSendSelectorargumentCount(t1, 1);
			/* begin internalizeIPandSP */
			localIP = instructionPointer;
			localSP = stackPointer;
			break;
		case 204:
			/* bytecodePrimNew */
			t1 = longAt(((longAt((specialObjectsOop + 4) + (23 * 4))) + 4) + ((28 * 2) * 4));
			/* begin externalizeIPandSP */
			instructionPointer = localIP;
			stackPointer = localSP;
			externalSendSelectorargumentCount(t1, 0);
			/* begin internalizeIPandSP */
			localIP = instructionPointer;
			localSP = stackPointer;
			break;
		case 205:
			/* bytecodePrimNewWithArg */
			t1 = longAt(((longAt((specialObjectsOop + 4) + (23 * 4))) + 4) + ((29 * 2) * 4));
			/* begin externalizeIPandSP */
			instructionPointer = localIP;
			stackPointer = localSP;
			externalSendSelectorargumentCount(t1, 1);
			/* begin internalizeIPandSP */
			localIP = instructionPointer;
			localSP = stackPointer;
			break;
		case 206:
			/* bytecodePrimPointX */
			/* begin externalizeIPandSP */
			instructionPointer = localIP;
			stackPointer = localSP;
			/* begin primitivePointX */
			successFlag = true;
			/* begin popStack */
			t2 = longAt(stackPointer);
			stackPointer = stackPointer - 4;
			t1 = t2;
			/* begin success: */
			t3 = (fetchClassOf(t1)) == (longAt((specialObjectsOop + 4) + (12 * 4)));
			successFlag = t3 && successFlag;
			if (successFlag) {
				/* begin push: */
				longAtput(stackPointer = stackPointer + 4, longAt((t1 + 4) + (0 * 4)));
			} else {
				/* begin unPop: */
				stackPointer = stackPointer + (1 * 4);
				failSpecialPrim(0);
			}
			/* begin internalizeIPandSP */
			localIP = instructionPointer;
			localSP = stackPointer;
			break;
		case 207:
			/* bytecodePrimPointY */
			/* begin externalizeIPandSP */
			instructionPointer = localIP;
			stackPointer = localSP;
			/* begin primitivePointY */
			successFlag = true;
			/* begin popStack */
			t2 = longAt(stackPointer);
			stackPointer = stackPointer - 4;
			t1 = t2;
			/* begin success: */
			t3 = (fetchClassOf(t1)) == (longAt((specialObjectsOop + 4) + (12 * 4)));
			successFlag = t3 && successFlag;
			if (successFlag) {
				/* begin push: */
				longAtput(stackPointer = stackPointer + 4, longAt((t1 + 4) + (1 * 4)));
			} else {
				/* begin unPop: */
				stackPointer = stackPointer + (1 * 4);
				failSpecialPrim(0);
			}
			/* begin internalizeIPandSP */
			localIP = instructionPointer;
			localSP = stackPointer;
			break;
		case 208:
		case 209:
		case 210:
		case 211:
		case 212:
		case 213:
		case 214:
		case 215:
		case 216:
		case 217:
		case 218:
		case 219:
		case 220:
		case 221:
		case 222:
		case 223:
		case 224:
		case 225:
		case 226:
		case 227:
		case 228:
		case 229:
		case 230:
		case 231:
		case 232:
		case 233:
		case 234:
		case 235:
		case 236:
		case 237:
		case 238:
		case 239:
		case 240:
		case 241:
		case 242:
		case 243:
		case 244:
		case 245:
		case 246:
		case 247:
		case 248:
		case 249:
		case 250:
		case 251:
		case 252:
		case 253:
		case 254:
		case 255:
			/* sendLiteralSelectorBytecode */
			/* begin literal: */
			t2 = currentBytecode & 15;
			t1 = longAt((method + 4) + ((t2 + 1) * 4));
			/* begin internalSendSelector:argumentCount: */
			t3 = ((((unsigned) currentBytecode) >> 4) & 3) - 1;
			messageSelector = t1;
			argumentCount = t3;
			/* begin fetchClassOf: */
			if ((((longAt(localSP - (argumentCount * 4))) & 1) == 1)) {
				t4 = longAt((specialObjectsOop + 4) + (5 * 4));
				goto l29;
			}
			t5 = ((((unsigned) (longAt(longAt(localSP - (argumentCount * 4))))) >> 12) & 31) - 1;
			if (t5 < 0) {
				t4 = (longAt((longAt(localSP - (argumentCount * 4))) - 4)) & 4294967292;
				goto l29;
			} else {
				t4 = longAt(((longAt((specialObjectsOop + 4) + (28 * 4))) + 4) + (t5 * 4));
				goto l29;
			}
		l29:	/* end fetchClassOf: */;
			/* begin externalizeIPandSP */
			instructionPointer = localIP;
			stackPointer = localSP;
			/* begin sendSelectorToClass: */
			/* begin findNewMethodInClass: */
			t6 = ((unsigned) (messageSelector ^ t4)) >> 2;
			for (t8 = 0; t8 <= (3 - 1); t8 += 1) {
				t7 = ((((unsigned) t6) >> t8) & 511) + 1;
				if (((methodCache[t7]) == messageSelector) && ((methodCache[t7 + 512]) == t4)) {
					newMethod = methodCache[(t7 + 512) + 512];
					primitiveIndex = (((unsigned) (longAt((newMethod + 4) + (0 * 4)))) >> 1) & 511;
					goto l30;
				}
			}
			lookupMethodInClass(t4);
			mcProbe = (mcProbe + 1) % 3;
			t7 = ((((unsigned) t6) >> (mcProbe * 3)) & 511) + 1;
			methodCache[t7] = messageSelector;
			methodCache[t7 + 512] = t4;
			methodCache[(t7 + 512) + 512] = newMethod;
		l30:	/* end findNewMethodInClass: */;
			/* begin executeNewMethod */
			if ((primitiveIndex == 0) || (!(primitiveResponse()))) {
				activateNewMethod();
				/* begin quickCheckForInterrupts */
				if ((interruptCheckCounter = interruptCheckCounter - 1) <= 0) {
					interruptCheckCounter = 1000;
					checkForInterrupts();
				}
			}
			/* begin internalizeIPandSP */
			localIP = instructionPointer;
			localSP = stackPointer;
			break;
		}
	}
	/* begin externalizeIPandSP */
	instructionPointer = localIP;
	stackPointer = localSP;
}

int isBytes(int oop) {
	return ((((unsigned) (longAt(oop))) >> 8) & 15) >= 8;
}

int isEmptyList(int aLinkedList) {
	return (longAt((aLinkedList + 4) + (0 * 4))) == nilObj;
}

int isFreeObject(int oop) {
	return ((longAt(oop)) & 3) == 2;
}

int isIntegerObject(int objectPointer) {
	return (objectPointer & 1) == 1;
}

int isIntegerValue(int valueWord) {
	return (valueWord >= -1073741824) && (valueWord < 1073741824);
}

int isObjectForwarded(int oop) {
	return ((oop & 1) == 0) && (((longAt(oop)) & 2147483648) != 0);
}

int isPointers(int oop) {
	return ((((unsigned) (longAt(oop))) >> 8) & 15) <= 4;
}

int isWords(int oop) {
	return ((((unsigned) (longAt(oop))) >> 8) & 15) == 6;
}

int isWordsOrBytes(int oop) {
    int fmt;

	fmt = (((unsigned) (longAt(oop))) >> 8) & 15;
	return (fmt == 6) || ((fmt >= 8) && (fmt <= 11));
}

int lastPointerOf(int objectPointer) {
    int fmt;
    int sz;
    int methodHeader;
    int header;
    int type;

	fmt = (((unsigned) (longAt(objectPointer))) >> 8) & 15;
	if (fmt < 4) {
		/* begin sizeBitsOfSafe: */
		header = longAt(objectPointer);
		/* begin rightType: */
		if ((header & 252) == 0) {
			type = 0;
			goto l1;
		} else {
			if ((header & 126976) == 0) {
				type = 1;
				goto l1;
			} else {
				type = 3;
				goto l1;
			}
		}
	l1:	/* end rightType: */;
		if (type == 0) {
			sz = (longAt(objectPointer - 8)) & 4294967292;
			goto l2;
		} else {
			sz = header & 252;
			goto l2;
		}
	l2:	/* end sizeBitsOfSafe: */;
		return sz - 4;
	}
	if (fmt < 12) {
		return 0;
	}
	methodHeader = longAt(objectPointer + 4);
	return (((((unsigned) methodHeader) >> 10) & 255) * 4) + 4;
}

int lastPointerWhileForwarding(int oop) {
    int header;
    int fwdBlock;
    int fmt;
    int size;
    int methodHeader;

	header = longAt(oop);
	if ((header & 2147483648) != 0) {
		fwdBlock = header & 2147483644;
		if (checkAssertions) {
			/* begin fwdBlockValidate: */
			if (!((fwdBlock > endOfMemory) && ((fwdBlock <= fwdTableNext) && ((fwdBlock & 3) == 0)))) {
				error("invalid fwd table entry");
			}
		}
		header = longAt(fwdBlock + 4);
	}
	fmt = (((unsigned) header) >> 8) & 15;
	if (fmt < 4) {
		if ((header & 3) == 0) {
			size = (longAt(oop - 8)) & 268435452;
		} else {
			size = header & 252;
		}
		return size - 4;
	}
	if (fmt < 12) {
		return 0;
	}
	methodHeader = longAt(oop + 4);
	return (((((unsigned) methodHeader) >> 10) & 255) * 4) + 4;
}

int lengthOf(int oop) {
    int header;
    int sz;
    int fmt;

	header = longAt(oop);
	if ((header & 3) == 0) {
		sz = (longAt(oop - 8)) & 4294967292;
	} else {
		sz = header & 252;
	}
	fmt = (((unsigned) header) >> 8) & 15;
	if (fmt < 8) {
		return (sz - 4) / 4;
	} else {
		return (sz - 4) - (fmt & 3);
	}
}

int literal(int offset) {
	return longAt((method + 4) + ((offset + 1) * 4));
}

int literalofMethod(int offset, int methodPointer) {
	return longAt((methodPointer + 4) + ((offset + 1) * 4));
}

int literalCountOf(int methodPointer) {
	return (((unsigned) (longAt((methodPointer + 4) + (0 * 4)))) >> 10) & 255;
}

int literalCountOfHeader(int headerPointer) {
	return (((unsigned) headerPointer) >> 10) & 255;
}

int loadBitBltFrom(int bbObj) {
    int destBitsSize;
    int destWidth;
    int destHeight;
    int sourceBitsSize;
    int sourcePixPerWord;
    int cmSize;
    int halftoneBits;
    int header;
    int sz;
    int fmt;
    int header1;
    int sz1;
    int fmt1;

	bitBltOop = bbObj;
	combinationRule = fetchIntegerofObject(3, bitBltOop);
	if ((!successFlag) || ((combinationRule < 0) || (combinationRule > 26))) {
		return false;
	}
	if ((combinationRule >= 16) && (combinationRule <= 17)) {
		return false;
	}
	sourceForm = longAt((bitBltOop + 4) + (1 * 4));
	/* begin ignoreSourceOrHalftone: */
	if (sourceForm == nilObj) {
		noSource = true;
		goto l3;
	}
	if (combinationRule == 0) {
		noSource = true;
		goto l3;
	}
	if (combinationRule == 5) {
		noSource = true;
		goto l3;
	}
	if (combinationRule == 10) {
		noSource = true;
		goto l3;
	}
	if (combinationRule == 15) {
		noSource = true;
		goto l3;
	}
	noSource = false;
l3:	/* end ignoreSourceOrHalftone: */;
	halftoneForm = longAt((bitBltOop + 4) + (2 * 4));
	/* begin ignoreSourceOrHalftone: */
	if (halftoneForm == nilObj) {
		noHalftone = true;
		goto l4;
	}
	if (combinationRule == 0) {
		noHalftone = true;
		goto l4;
	}
	if (combinationRule == 5) {
		noHalftone = true;
		goto l4;
	}
	if (combinationRule == 10) {
		noHalftone = true;
		goto l4;
	}
	if (combinationRule == 15) {
		noHalftone = true;
		goto l4;
	}
	noHalftone = false;
l4:	/* end ignoreSourceOrHalftone: */;
	destForm = longAt((bitBltOop + 4) + (0 * 4));
	if (!((((((unsigned) (longAt(destForm))) >> 8) & 15) <= 4) && ((lengthOf(destForm)) >= 4))) {
		return false;
	}
	destBits = longAt((destForm + 4) + (0 * 4));
	destBitsSize = byteLengthOf(destBits);
	destWidth = fetchIntegerofObject(1, destForm);
	destHeight = fetchIntegerofObject(2, destForm);
	if (!((destWidth >= 0) && (destHeight >= 0))) {
		return false;
	}
	destPixSize = fetchIntegerofObject(3, destForm);
	pixPerWord = 32 / destPixSize;
	destRaster = (destWidth + (pixPerWord - 1)) / pixPerWord;
	if (!((isWordsOrBytes(destBits)) && (destBitsSize == ((destRaster * destHeight) * 4)))) {
		return false;
	}
	destX = fetchIntegerofObject(4, bitBltOop);
	destY = fetchIntegerofObject(5, bitBltOop);
	width = fetchIntegerofObject(6, bitBltOop);
	height = fetchIntegerofObject(7, bitBltOop);
	if (!successFlag) {
		return false;
	}
	if (noSource) {
		sourceX = sourceY = 0;
	} else {
		if (!((((((unsigned) (longAt(sourceForm))) >> 8) & 15) <= 4) && ((lengthOf(sourceForm)) >= 4))) {
			return false;
		}
		sourceBits = longAt((sourceForm + 4) + (0 * 4));
		sourceBitsSize = byteLengthOf(sourceBits);
		srcWidth = fetchIntegerofObject(1, sourceForm);
		srcHeight = fetchIntegerofObject(2, sourceForm);
		if (!((srcWidth >= 0) && (srcHeight >= 0))) {
			return false;
		}
		sourcePixSize = fetchIntegerofObject(3, sourceForm);
		sourcePixPerWord = 32 / sourcePixSize;
		sourceRaster = (srcWidth + (sourcePixPerWord - 1)) / sourcePixPerWord;
		if (!((isWordsOrBytes(sourceBits)) && (sourceBitsSize == ((sourceRaster * srcHeight) * 4)))) {
			return false;
		}
		colorMap = longAt((bitBltOop + 4) + (14 * 4));
		if (!(colorMap == nilObj)) {
			if (((((unsigned) (longAt(colorMap))) >> 8) & 15) == 6) {
				/* begin lengthOf: */
				header = longAt(colorMap);
				if ((header & 3) == 0) {
					sz = (longAt(colorMap - 8)) & 4294967292;
				} else {
					sz = header & 252;
				}
				fmt = (((unsigned) header) >> 8) & 15;
				if (fmt < 8) {
					cmSize = (sz - 4) / 4;
					goto l1;
				} else {
					cmSize = (sz - 4) - (fmt & 3);
					goto l1;
				}
			l1:	/* end lengthOf: */;
				cmBitsPerColor = 0;
				if (cmSize == 512) {
					cmBitsPerColor = 3;
				}
				if (cmSize == 4096) {
					cmBitsPerColor = 4;
				}
				if (cmSize == 32768) {
					cmBitsPerColor = 5;
				}
				if (primitiveIndex != 147) {
					if (sourcePixSize <= 8) {
						if (!(cmSize == (1 << sourcePixSize))) {
							return false;
						}
					} else {
						if (cmBitsPerColor == 0) {
							return false;
						}
					}
				}
			} else {
				return false;
			}
		}
		sourceX = fetchIntegerofObject(8, bitBltOop);
		sourceY = fetchIntegerofObject(9, bitBltOop);
	}
	if (!(noHalftone)) {
		if ((((((unsigned) (longAt(halftoneForm))) >> 8) & 15) <= 4) && ((lengthOf(halftoneForm)) >= 4)) {
			halftoneBits = longAt((halftoneForm + 4) + (0 * 4));
			halftoneHeight = fetchIntegerofObject(2, halftoneForm);
			if (!(((((unsigned) (longAt(halftoneBits))) >> 8) & 15) == 6)) {
				noHalftone = true;
			}
		} else {
			if (!((!(((((unsigned) (longAt(halftoneForm))) >> 8) & 15) <= 4)) && (((((unsigned) (longAt(halftoneForm))) >> 8) & 15) == 6))) {
				return false;
			}
			halftoneBits = halftoneForm;
			/* begin lengthOf: */
			header1 = longAt(halftoneBits);
			if ((header1 & 3) == 0) {
				sz1 = (longAt(halftoneBits - 8)) & 4294967292;
			} else {
				sz1 = header1 & 252;
			}
			fmt1 = (((unsigned) header1) >> 8) & 15;
			if (fmt1 < 8) {
				halftoneHeight = (sz1 - 4) / 4;
				goto l2;
			} else {
				halftoneHeight = (sz1 - 4) - (fmt1 & 3);
				goto l2;
			}
		l2:	/* end lengthOf: */;
		}
		halftoneBase = halftoneBits + 4;
	}
	clipX = fetchIntegerofObject(10, bitBltOop);
	clipY = fetchIntegerofObject(11, bitBltOop);
	clipWidth = fetchIntegerofObject(12, bitBltOop);
	clipHeight = fetchIntegerofObject(13, bitBltOop);
	if (!successFlag) {
		return false;
	}
	if (clipX < 0) {
		clipWidth = clipWidth + clipX;
		clipX = 0;
	}
	if (clipY < 0) {
		clipHeight = clipHeight + clipY;
		clipY = 0;
	}
	if ((clipX + clipWidth) > destWidth) {
		clipWidth = destWidth - clipX;
	}
	if ((clipY + clipHeight) > destHeight) {
		clipHeight = destHeight - clipY;
	}
	return true;
}

int loadInitialContext(void) {
    int sched;
    int proc;
    int m;

	sched = longAt(((longAt((specialObjectsOop + 4) + (3 * 4))) + 4) + (1 * 4));
	proc = longAt((sched + 4) + (1 * 4));
	activeContext = longAt((proc + 4) + (1 * 4));
	if (activeContext < youngStart) {
		beRootIfOld(activeContext);
	}
	/* begin fetchContextRegisters */
	m = longAt((activeContext + 4) + (3 * 4));
	if (((m & 1) == 1)) {
		theHomeContext = longAt((activeContext + 4) + (5 * 4));
		if (theHomeContext < youngStart) {
			beRootIfOld(theHomeContext);
		}
	} else {
		theHomeContext = activeContext;
	}
	receiver = longAt((theHomeContext + 4) + (5 * 4));
	method = longAt((theHomeContext + 4) + (3 * 4));
	instructionPointer = ((longAt((activeContext + 4) + (1 * 4))) >> 1);
	instructionPointer = ((method + instructionPointer) + 4) - 2;
	stackPointer = ((longAt((activeContext + 4) + (2 * 4))) >> 1);
	stackPointer = (activeContext + 4) + (((6 + stackPointer) - 1) * 4);
	reclaimableContextCount = 0;
}

int loadScannerFromstartstopstringrightXstopArraydisplayFlag(int bbObj, int start, int stop, int string, int rightX, int stopArray, int displayFlag) {
    int successValue;
    int successValue1;
    int successValue2;

	scanStart = start;
	scanStop = stop;
	scanString = string;
	scanRightX = rightX;
	scanStopArray = stopArray;
	scanDisplayFlag = displayFlag;
	/* begin success: */
	successValue1 = (((((unsigned) (longAt(scanStopArray))) >> 8) & 15) <= 4) && ((lengthOf(scanStopArray)) >= 1);
	successFlag = successValue1 && successFlag;
	scanXTable = longAt((bbObj + 4) + (16 * 4));
	/* begin success: */
	successValue2 = (((((unsigned) (longAt(scanXTable))) >> 8) & 15) <= 4) && ((lengthOf(scanXTable)) >= 1);
	successFlag = successValue2 && successFlag;
	/* begin storeInteger:ofObject:withValue: */
	if ((0 >= -1073741824) && (0 < 1073741824)) {
		longAtput((bbObj + 4) + (6 * 4), ((0 << 1) | 1));
	} else {
		primitiveFail();
	}
	/* begin storeInteger:ofObject:withValue: */
	if ((0 >= -1073741824) && (0 < 1073741824)) {
		longAtput((bbObj + 4) + (8 * 4), ((0 << 1) | 1));
	} else {
		primitiveFail();
	}
	if (scanDisplayFlag) {
		/* begin success: */
		successValue = loadBitBltFrom(bbObj);
		successFlag = successValue && successFlag;
	} else {
		bitBltOop = bbObj;
		destX = fetchIntegerofObject(4, bbObj);
	}
	return !(!successFlag);
}

int lookupMethodInClass(int class) {
    int currentClass;
    int dictionary;
    int argumentArray;
    int message;
    int oop;
    int valuePointer;
    int fromIndex;
    int toIndex;
    int lastFrom;

	currentClass = class;
	while (currentClass != nilObj) {
		dictionary = longAt((currentClass + 4) + (1 * 4));
		if (lookupMethodInDictionary(dictionary)) {
			return currentClass;
		}
		currentClass = longAt((currentClass + 4) + (0 * 4));
	}
	if (messageSelector == (longAt((specialObjectsOop + 4) + (20 * 4)))) {
		error("Recursive not understood error encountered");
	}
	/* begin createActualMessage */
	argumentArray = instantiateClassindexableSize(longAt((specialObjectsOop + 4) + (7 * 4)), argumentCount);
	/* begin pushRemappableOop: */
	remapBuffer[remapBufferCount = remapBufferCount + 1] = argumentArray;
	message = instantiateClassindexableSize(longAt((specialObjectsOop + 4) + (15 * 4)), 0);
	/* begin popRemappableOop */
	oop = remapBuffer[remapBufferCount];
	remapBufferCount = remapBufferCount - 1;
	argumentArray = oop;
	if (argumentArray < youngStart) {
		beRootIfOld(argumentArray);
	}
	/* begin storePointer:ofObject:withValue: */
	valuePointer = messageSelector;
	if (message < youngStart) {
		possibleRootStoreIntovalue(message, valuePointer);
	}
	longAtput((message + 4) + (0 * 4), valuePointer);
	/* begin storePointer:ofObject:withValue: */
	if (message < youngStart) {
		possibleRootStoreIntovalue(message, argumentArray);
	}
	longAtput((message + 4) + (1 * 4), argumentArray);
	/* begin transfer:fromIndex:ofObject:toIndex:ofObject: */
	fromIndex = (activeContext + 4) + (((((stackPointer - activeContext) - 4) / 4) - (argumentCount - 1)) * 4);
	toIndex = (argumentArray + 4) + (0 * 4);
	lastFrom = fromIndex + (argumentCount * 4);
	while (fromIndex < lastFrom) {
		longAtput(toIndex, longAt(fromIndex));
		fromIndex = fromIndex + 4;
		toIndex = toIndex + 4;
	}
	/* begin pop: */
	stackPointer = stackPointer - (argumentCount * 4);
	/* begin push: */
	longAtput(stackPointer = stackPointer + 4, message);
	argumentCount = 1;
	messageSelector = longAt((specialObjectsOop + 4) + (20 * 4));
	return lookupMethodInClass(class);
}

int lookupMethodInDictionary(int dictionary) {
    int length;
    int index;
    int mask;
    int wrapAround;
    int nextSelector;
    int methodArray;

	length = fetchWordLengthOf(dictionary);
	mask = (length - 2) - 1;
	index = (mask & ((((unsigned) (longAt(messageSelector))) >> 17) & 4095)) + 2;
	wrapAround = false;
	while (true) {
		nextSelector = longAt((dictionary + 4) + (index * 4));
		if (nextSelector == nilObj) {
			return false;
		}
		if (nextSelector == messageSelector) {
			methodArray = longAt((dictionary + 4) + (1 * 4));
			newMethod = longAt((methodArray + 4) + ((index - 2) * 4));
			primitiveIndex = (((unsigned) (longAt((newMethod + 4) + (0 * 4)))) >> 1) & 511;
			return true;
		}
		index = index + 1;
		if (index == length) {
			if (wrapAround) {
				return false;
			}
			wrapAround = true;
			index = 2;
		}
	}
}

int lowestFreeAfter(int chunk) {
    int oop;
    int oopHeader;
    int oopHeaderType;
    int oopSize;

	oop = chunk + (extraHeaderBytes(chunk));
	while (oop < endOfMemory) {
		oopHeader = longAt(oop);
		oopHeaderType = oopHeader & 3;
		if (oopHeaderType == 2) {
			return oop;
		} else {
			if (oopHeaderType == 0) {
				oopSize = (longAt(oop - 8)) & 4294967292;
			} else {
				oopSize = oopHeader & 252;
			}
		}
		oop = (oop + oopSize) + (extraHeaderBytes(oop + oopSize));
	}
	error("expected to find at least one free object");
}

int makeDirEntryNamesizecreateDatemodDateisDirfileSize(char *entryName, int entryNameSize, int createDate, int modifiedDate, int dirFlag, int fileSize) {
    int modDateOop;
    int createDateOop;
    int nameString;
    int results;
    int i;
    int valuePointer;
    int valuePointer1;
    int oop;
    int oop1;
    int oop2;
    int oop3;
    int oop4;
    int oop5;
    int oop6;
    int oop7;

	/* begin pushRemappableOop: */
	oop = instantiateClassindexableSize(longAt((specialObjectsOop + 4) + (7 * 4)), 5);
	remapBuffer[remapBufferCount = remapBufferCount + 1] = oop;
	/* begin pushRemappableOop: */
	oop1 = instantiateClassindexableSize(longAt((specialObjectsOop + 4) + (6 * 4)), entryNameSize);
	remapBuffer[remapBufferCount = remapBufferCount + 1] = oop1;
	/* begin pushRemappableOop: */
	oop2 = positive32BitIntegerFor(createDate);
	remapBuffer[remapBufferCount = remapBufferCount + 1] = oop2;
	/* begin pushRemappableOop: */
	oop3 = positive32BitIntegerFor(modifiedDate);
	remapBuffer[remapBufferCount = remapBufferCount + 1] = oop3;
	/* begin popRemappableOop */
	oop4 = remapBuffer[remapBufferCount];
	remapBufferCount = remapBufferCount - 1;
	modDateOop = oop4;
	/* begin popRemappableOop */
	oop5 = remapBuffer[remapBufferCount];
	remapBufferCount = remapBufferCount - 1;
	createDateOop = oop5;
	/* begin popRemappableOop */
	oop6 = remapBuffer[remapBufferCount];
	remapBufferCount = remapBufferCount - 1;
	nameString = oop6;
	/* begin popRemappableOop */
	oop7 = remapBuffer[remapBufferCount];
	remapBufferCount = remapBufferCount - 1;
	results = oop7;
	for (i = 0; i <= (entryNameSize - 1); i += 1) {
		byteAtput((nameString + 4) + i, entryName[i]);
	}
	/* begin storePointer:ofObject:withValue: */
	if (results < youngStart) {
		possibleRootStoreIntovalue(results, nameString);
	}
	longAtput((results + 4) + (0 * 4), nameString);
	/* begin storePointer:ofObject:withValue: */
	if (results < youngStart) {
		possibleRootStoreIntovalue(results, createDateOop);
	}
	longAtput((results + 4) + (1 * 4), createDateOop);
	/* begin storePointer:ofObject:withValue: */
	if (results < youngStart) {
		possibleRootStoreIntovalue(results, modDateOop);
	}
	longAtput((results + 4) + (2 * 4), modDateOop);
	if (dirFlag) {
		/* begin storePointer:ofObject:withValue: */
		valuePointer = trueObj;
		if (results < youngStart) {
			possibleRootStoreIntovalue(results, valuePointer);
		}
		longAtput((results + 4) + (3 * 4), valuePointer);
	} else {
		/* begin storePointer:ofObject:withValue: */
		valuePointer1 = falseObj;
		if (results < youngStart) {
			possibleRootStoreIntovalue(results, valuePointer1);
		}
		longAtput((results + 4) + (3 * 4), valuePointer1);
	}
	/* begin storePointer:ofObject:withValue: */
	if (results < youngStart) {
		possibleRootStoreIntovalue(results, ((fileSize << 1) | 1));
	}
	longAtput((results + 4) + (4 * 4), ((fileSize << 1) | 1));
	return results;
}

int makePointwithxValueyValue(int xValue, int yValue) {
    int pointResult;

	pointResult = instantiateSmallClasssizeInBytesfill(longAt((specialObjectsOop + 4) + (12 * 4)), 12, nilObj);
	/* begin storePointer:ofObject:withValue: */
	if (pointResult < youngStart) {
		possibleRootStoreIntovalue(pointResult, ((xValue << 1) | 1));
	}
	longAtput((pointResult + 4) + (0 * 4), ((xValue << 1) | 1));
	/* begin storePointer:ofObject:withValue: */
	if (pointResult < youngStart) {
		possibleRootStoreIntovalue(pointResult, ((yValue << 1) | 1));
	}
	longAtput((pointResult + 4) + (1 * 4), ((yValue << 1) | 1));
	return pointResult;
}

int mapInterpreterOops(void) {
    int i;
    int oop;

	nilObj = remap(nilObj);
	falseObj = remap(falseObj);
	trueObj = remap(trueObj);
	specialObjectsOop = remap(specialObjectsOop);
	stackPointer = stackPointer - activeContext;
	activeContext = remap(activeContext);
	stackPointer = stackPointer + activeContext;
	theHomeContext = remap(theHomeContext);
	instructionPointer = instructionPointer - method;
	method = remap(method);
	instructionPointer = instructionPointer + method;
	receiver = remap(receiver);
	messageSelector = remap(messageSelector);
	newMethod = remap(newMethod);
	for (i = 1; i <= remapBufferCount; i += 1) {
		oop = remapBuffer[i];
		if (!(((oop & 1) == 1))) {
			remapBuffer[i] = (remap(oop));
		}
	}
	primitiveFlushCache();
}

int mapPointersInObjectsFromto(int memStart, int memEnd) {
    int i;
    int oop;
    int i1;
    int oop1;
    int header;
    int fwdBlock;
    int realHeader;
    int sz;
    int sz1;
    int header1;
    int fieldOffset;
    int fieldOop;
    int fwdBlock3;
    int newOop;
    int header2;
    int fwdBlock1;
    int fmt;
    int size;
    int methodHeader;
    int classHeader;
    int classOop;
    int fwdBlock2;
    int newClassOop;
    int newClassHeader;
    int fieldOffset1;
    int fieldOop1;
    int fwdBlock4;
    int newOop1;
    int header3;
    int fwdBlock11;
    int fmt1;
    int size1;
    int methodHeader1;
    int classHeader1;
    int classOop1;
    int fwdBlock21;
    int newClassOop1;
    int newClassHeader1;

	/* begin mapInterpreterOops */
	nilObj = remap(nilObj);
	falseObj = remap(falseObj);
	trueObj = remap(trueObj);
	specialObjectsOop = remap(specialObjectsOop);
	stackPointer = stackPointer - activeContext;
	activeContext = remap(activeContext);
	stackPointer = stackPointer + activeContext;
	theHomeContext = remap(theHomeContext);
	instructionPointer = instructionPointer - method;
	method = remap(method);
	instructionPointer = instructionPointer + method;
	receiver = remap(receiver);
	messageSelector = remap(messageSelector);
	newMethod = remap(newMethod);
	for (i1 = 1; i1 <= remapBufferCount; i1 += 1) {
		oop1 = remapBuffer[i1];
		if (!(((oop1 & 1) == 1))) {
			remapBuffer[i1] = (remap(oop1));
		}
	}
	primitiveFlushCache();
	for (i = 1; i <= rootTableCount; i += 1) {
		oop = rootTable[i];
		if ((oop < memStart) || (oop >= memEnd)) {
			/* begin remapFieldsAndClassOf: */
			/* begin lastPointerWhileForwarding: */
			header2 = longAt(oop);
			if ((header2 & 2147483648) != 0) {
				fwdBlock1 = header2 & 2147483644;
				if (checkAssertions) {
					/* begin fwdBlockValidate: */
					if (!((fwdBlock1 > endOfMemory) && ((fwdBlock1 <= fwdTableNext) && ((fwdBlock1 & 3) == 0)))) {
						error("invalid fwd table entry");
					}
				}
				header2 = longAt(fwdBlock1 + 4);
			}
			fmt = (((unsigned) header2) >> 8) & 15;
			if (fmt < 4) {
				if ((header2 & 3) == 0) {
					size = (longAt(oop - 8)) & 268435452;
				} else {
					size = header2 & 252;
				}
				fieldOffset = size - 4;
				goto l3;
			}
			if (fmt < 12) {
				fieldOffset = 0;
				goto l3;
			}
			methodHeader = longAt(oop + 4);
			fieldOffset = (((((unsigned) methodHeader) >> 10) & 255) * 4) + 4;
		l3:	/* end lastPointerWhileForwarding: */;
			while (fieldOffset >= 4) {
				fieldOop = longAt(oop + fieldOffset);
				if (((fieldOop & 1) == 0) && (((longAt(fieldOop)) & 2147483648) != 0)) {
					fwdBlock3 = (longAt(fieldOop)) & 2147483644;
					if (checkAssertions) {
						/* begin fwdBlockValidate: */
						if (!((fwdBlock3 > endOfMemory) && ((fwdBlock3 <= fwdTableNext) && ((fwdBlock3 & 3) == 0)))) {
							error("invalid fwd table entry");
						}
					}
					newOop = longAt(fwdBlock3);
					longAtput(oop + fieldOffset, newOop);
					if ((oop < youngStart) && (newOop >= youngStart)) {
						beRootWhileForwarding(oop);
					}
				}
				fieldOffset = fieldOffset - 4;
			}
			/* begin remapClassOf: */
			if (((longAt(oop)) & 3) == 3) {
				goto l4;
			}
			classHeader = longAt(oop - 4);
			classOop = classHeader & 4294967292;
			if (((classOop & 1) == 0) && (((longAt(classOop)) & 2147483648) != 0)) {
				fwdBlock2 = (longAt(classOop)) & 2147483644;
				if (checkAssertions) {
					/* begin fwdBlockValidate: */
					if (!((fwdBlock2 > endOfMemory) && ((fwdBlock2 <= fwdTableNext) && ((fwdBlock2 & 3) == 0)))) {
						error("invalid fwd table entry");
					}
				}
				newClassOop = longAt(fwdBlock2);
				newClassHeader = newClassOop | (classHeader & 3);
				longAtput(oop - 4, newClassHeader);
				if ((oop < youngStart) && (newClassOop >= youngStart)) {
					beRootWhileForwarding(oop);
				}
			}
		l4:	/* end remapClassOf: */;
		}
	}
	oop = memStart + (extraHeaderBytes(memStart));
	while (oop < memEnd) {
		if (!(((longAt(oop)) & 3) == 2)) {
			/* begin remapFieldsAndClassOf: */
			/* begin lastPointerWhileForwarding: */
			header3 = longAt(oop);
			if ((header3 & 2147483648) != 0) {
				fwdBlock11 = header3 & 2147483644;
				if (checkAssertions) {
					/* begin fwdBlockValidate: */
					if (!((fwdBlock11 > endOfMemory) && ((fwdBlock11 <= fwdTableNext) && ((fwdBlock11 & 3) == 0)))) {
						error("invalid fwd table entry");
					}
				}
				header3 = longAt(fwdBlock11 + 4);
			}
			fmt1 = (((unsigned) header3) >> 8) & 15;
			if (fmt1 < 4) {
				if ((header3 & 3) == 0) {
					size1 = (longAt(oop - 8)) & 268435452;
				} else {
					size1 = header3 & 252;
				}
				fieldOffset1 = size1 - 4;
				goto l5;
			}
			if (fmt1 < 12) {
				fieldOffset1 = 0;
				goto l5;
			}
			methodHeader1 = longAt(oop + 4);
			fieldOffset1 = (((((unsigned) methodHeader1) >> 10) & 255) * 4) + 4;
		l5:	/* end lastPointerWhileForwarding: */;
			while (fieldOffset1 >= 4) {
				fieldOop1 = longAt(oop + fieldOffset1);
				if (((fieldOop1 & 1) == 0) && (((longAt(fieldOop1)) & 2147483648) != 0)) {
					fwdBlock4 = (longAt(fieldOop1)) & 2147483644;
					if (checkAssertions) {
						/* begin fwdBlockValidate: */
						if (!((fwdBlock4 > endOfMemory) && ((fwdBlock4 <= fwdTableNext) && ((fwdBlock4 & 3) == 0)))) {
							error("invalid fwd table entry");
						}
					}
					newOop1 = longAt(fwdBlock4);
					longAtput(oop + fieldOffset1, newOop1);
					if ((oop < youngStart) && (newOop1 >= youngStart)) {
						beRootWhileForwarding(oop);
					}
				}
				fieldOffset1 = fieldOffset1 - 4;
			}
			/* begin remapClassOf: */
			if (((longAt(oop)) & 3) == 3) {
				goto l6;
			}
			classHeader1 = longAt(oop - 4);
			classOop1 = classHeader1 & 4294967292;
			if (((classOop1 & 1) == 0) && (((longAt(classOop1)) & 2147483648) != 0)) {
				fwdBlock21 = (longAt(classOop1)) & 2147483644;
				if (checkAssertions) {
					/* begin fwdBlockValidate: */
					if (!((fwdBlock21 > endOfMemory) && ((fwdBlock21 <= fwdTableNext) && ((fwdBlock21 & 3) == 0)))) {
						error("invalid fwd table entry");
					}
				}
				newClassOop1 = longAt(fwdBlock21);
				newClassHeader1 = newClassOop1 | (classHeader1 & 3);
				longAtput(oop - 4, newClassHeader1);
				if ((oop < youngStart) && (newClassOop1 >= youngStart)) {
					beRootWhileForwarding(oop);
				}
			}
		l6:	/* end remapClassOf: */;
		}
		/* begin objectAfterWhileForwarding: */
		header = longAt(oop);
		if ((header & 2147483648) == 0) {
			/* begin objectAfter: */
			if (checkAssertions) {
				if (oop >= endOfMemory) {
					error("no objects after the end of memory");
				}
			}
			if (((longAt(oop)) & 3) == 2) {
				sz1 = (longAt(oop)) & 536870908;
			} else {
				/* begin sizeBitsOf: */
				header1 = longAt(oop);
				if ((header1 & 3) == 0) {
					sz1 = (longAt(oop - 8)) & 4294967292;
					goto l1;
				} else {
					sz1 = header1 & 252;
					goto l1;
				}
			l1:	/* end sizeBitsOf: */;
			}
			oop = (oop + sz1) + (extraHeaderBytes(oop + sz1));
			goto l2;
		}
		fwdBlock = header & 2147483644;
		if (checkAssertions) {
			/* begin fwdBlockValidate: */
			if (!((fwdBlock > endOfMemory) && ((fwdBlock <= fwdTableNext) && ((fwdBlock & 3) == 0)))) {
				error("invalid fwd table entry");
			}
		}
		realHeader = longAt(fwdBlock + 4);
		if ((realHeader & 3) == 0) {
			sz = (longAt(oop - 8)) & 268435452;
		} else {
			sz = realHeader & 252;
		}
		oop = (oop + sz) + (extraHeaderBytes(oop + sz));
	l2:	/* end objectAfterWhileForwarding: */;
	}
}

int markAndTrace(int oop) {
    int header;
    int lastFieldOffset;
    int action;
    int type;
    int header1;
    int oop1;
    int header2;
    int lastFieldOffset1;
    int typeBits;
    int childType;
    int fmt;
    int sz;
    int methodHeader;
    int fmt1;
    int sz1;
    int methodHeader1;
    int header3;
    int type1;
    int header4;
    int type2;

	header = longAt(oop);
	header = (header & 4294967292) | 2;
	if (oop >= youngStart) {
		header = header | 2147483648;
	}
	longAtput(oop, header);
	parentField = 3;
	child = oop;
	/* begin lastPointerOf: */
	fmt1 = (((unsigned) (longAt(oop))) >> 8) & 15;
	if (fmt1 < 4) {
		/* begin sizeBitsOfSafe: */
		header3 = longAt(oop);
		/* begin rightType: */
		if ((header3 & 252) == 0) {
			type1 = 0;
			goto l9;
		} else {
			if ((header3 & 126976) == 0) {
				type1 = 1;
				goto l9;
			} else {
				type1 = 3;
				goto l9;
			}
		}
	l9:	/* end rightType: */;
		if (type1 == 0) {
			sz1 = (longAt(oop - 8)) & 4294967292;
			goto l10;
		} else {
			sz1 = header3 & 252;
			goto l10;
		}
	l10:	/* end sizeBitsOfSafe: */;
		lastFieldOffset = sz1 - 4;
		goto l8;
	}
	if (fmt1 < 12) {
		lastFieldOffset = 0;
		goto l8;
	}
	methodHeader1 = longAt(oop + 4);
	lastFieldOffset = (((((unsigned) methodHeader1) >> 10) & 255) * 4) + 4;
l8:	/* end lastPointerOf: */;
	field = oop + lastFieldOffset;
	action = 1;
	while (!(action == 4)) {
		if (action == 1) {
			/* begin startField */
			child = longAt(field);
			typeBits = child & 3;
			if ((typeBits & 1) == 1) {
				field = field - 4;
				action = 1;
				goto l6;
			}
			if (typeBits == 0) {
				longAtput(field, parentField);
				parentField = field;
				action = 2;
				goto l6;
			}
			if (typeBits == 2) {
				if ((child & 126976) != 0) {
					child = child & 4294967292;
					/* begin rightType: */
					if ((child & 252) == 0) {
						childType = 0;
						goto l5;
					} else {
						if ((child & 126976) == 0) {
							childType = 1;
							goto l5;
						} else {
							childType = 3;
							goto l5;
						}
					}
				l5:	/* end rightType: */;
					longAtput(field, child | childType);
					action = 3;
					goto l6;
				} else {
					child = longAt(field - 4);
					child = child & 4294967292;
					longAtput(field - 4, parentField);
					parentField = (field - 4) | 1;
					action = 2;
					goto l6;
				}
			}
		l6:	/* end startField */;
		}
		if (action == 2) {
			/* begin startObj */
			oop1 = child;
			if (oop1 < youngStart) {
				field = oop1;
				action = 3;
				goto l2;
			}
			header2 = longAt(oop1);
			if ((header2 & 2147483648) == 0) {
				header2 = header2 & 4294967292;
				header2 = (header2 | 2147483648) | 2;
				longAtput(oop1, header2);
				/* begin lastPointerOf: */
				fmt = (((unsigned) (longAt(oop1))) >> 8) & 15;
				if (fmt < 4) {
					/* begin sizeBitsOfSafe: */
					header4 = longAt(oop1);
					/* begin rightType: */
					if ((header4 & 252) == 0) {
						type2 = 0;
						goto l11;
					} else {
						if ((header4 & 126976) == 0) {
							type2 = 1;
							goto l11;
						} else {
							type2 = 3;
							goto l11;
						}
					}
				l11:	/* end rightType: */;
					if (type2 == 0) {
						sz = (longAt(oop1 - 8)) & 4294967292;
						goto l12;
					} else {
						sz = header4 & 252;
						goto l12;
					}
				l12:	/* end sizeBitsOfSafe: */;
					lastFieldOffset1 = sz - 4;
					goto l7;
				}
				if (fmt < 12) {
					lastFieldOffset1 = 0;
					goto l7;
				}
				methodHeader = longAt(oop1 + 4);
				lastFieldOffset1 = (((((unsigned) methodHeader) >> 10) & 255) * 4) + 4;
			l7:	/* end lastPointerOf: */;
				field = oop1 + lastFieldOffset1;
				action = 1;
				goto l2;
			} else {
				field = oop1;
				action = 3;
				goto l2;
			}
		l2:	/* end startObj */;
		}
		if (action == 3) {
			/* begin upward */
			if ((parentField & 1) == 1) {
				if (parentField == 3) {
					header1 = (longAt(field)) & 4294967292;
					/* begin rightType: */
					if ((header1 & 252) == 0) {
						type = 0;
						goto l3;
					} else {
						if ((header1 & 126976) == 0) {
							type = 1;
							goto l3;
						} else {
							type = 3;
							goto l3;
						}
					}
				l3:	/* end rightType: */;
					longAtput(field, header1 + type);
					action = 4;
					goto l1;
				} else {
					child = field;
					field = parentField - 1;
					parentField = longAt(field);
					header1 = longAt(field + 4);
					/* begin rightType: */
					if ((header1 & 252) == 0) {
						type = 0;
						goto l4;
					} else {
						if ((header1 & 126976) == 0) {
							type = 1;
							goto l4;
						} else {
							type = 3;
							goto l4;
						}
					}
				l4:	/* end rightType: */;
					longAtput(field, child + type);
					field = field + 4;
					header1 = header1 & 4294967292;
					longAtput(field, header1 + type);
					action = 3;
					goto l1;
				}
			} else {
				child = field;
				field = parentField;
				parentField = longAt(field);
				longAtput(field, child);
				field = field - 4;
				action = 1;
				goto l1;
			}
		l1:	/* end upward */;
		}
	}
}

int markAndTraceInterpreterOops(void) {
    int i;
    int oop;

	markAndTrace(specialObjectsOop);
	markAndTrace(activeContext);
	markAndTrace(messageSelector);
	markAndTrace(newMethod);
	for (i = 1; i <= remapBufferCount; i += 1) {
		oop = remapBuffer[i];
		if (!(((oop & 1) == 1))) {
			markAndTrace(oop);
		}
	}
}

int markPhase(void) {
    int i;
    int oop;
    int i1;
    int oop1;

	freeSmallContexts = 1;
	freeLargeContexts = 1;
	/* begin markAndTraceInterpreterOops */
	markAndTrace(specialObjectsOop);
	markAndTrace(activeContext);
	markAndTrace(messageSelector);
	markAndTrace(newMethod);
	for (i1 = 1; i1 <= remapBufferCount; i1 += 1) {
		oop1 = remapBuffer[i1];
		if (!(((oop1 & 1) == 1))) {
			markAndTrace(oop1);
		}
	}
	for (i = 1; i <= rootTableCount; i += 1) {
		oop = rootTable[i];
		if (!(((oop & 1) == 1))) {
			markAndTrace(oop);
		}
	}
}

int mergewith(int sourceWord, int destinationWord) {
	if (combinationRule < 16) {
		if (combinationRule < 8) {
			if (combinationRule < 4) {
				if (combinationRule < 2) {
					if (combinationRule < 1) {
						return 0;
					} else {
						return sourceWord & destinationWord;
					}
				} else {
					if (combinationRule < 3) {
						return sourceWord & (~destinationWord);
					} else {
						return sourceWord;
					}
				}
			} else {
				if (combinationRule < 6) {
					if (combinationRule < 5) {
						return (~sourceWord) & destinationWord;
					} else {
						return destinationWord;
					}
				} else {
					if (combinationRule < 7) {
						return sourceWord ^ destinationWord;
					} else {
						return sourceWord | destinationWord;
					}
				}
			}
		} else {
			if (combinationRule < 12) {
				if (combinationRule < 10) {
					if (combinationRule < 9) {
						return (~sourceWord) & (~destinationWord);
					} else {
						return (~sourceWord) ^ destinationWord;
					}
				} else {
					if (combinationRule < 11) {
						return ~destinationWord;
					} else {
						return sourceWord | (~destinationWord);
					}
				}
			} else {
				if (combinationRule < 14) {
					if (combinationRule < 13) {
						return ~sourceWord;
					} else {
						return (~sourceWord) | destinationWord;
					}
				} else {
					if (combinationRule < 15) {
						return (~sourceWord) | (~destinationWord);
					} else {
						return destinationWord;
					}
				}
			}
		}
	} else {
		if (combinationRule < 24) {
			if (combinationRule < 20) {
				if (combinationRule < 18) {
					if (combinationRule < 17) {
						return destinationWord;
					} else {
						return destinationWord;
					}
				} else {
					if (combinationRule < 19) {
						return sourceWord + destinationWord;
					} else {
						return sourceWord - destinationWord;
					}
				}
			} else {
				if (combinationRule < 22) {
					if (combinationRule < 21) {
						return rgbAddwith(sourceWord, destinationWord);
					} else {
						return rgbSubwith(sourceWord, destinationWord);
					}
				} else {
					if (combinationRule < 23) {
						return rgbDiffwith(sourceWord, destinationWord);
					} else {
						return tallyIntoMap(destinationWord);
					}
				}
			}
		} else {
			if (combinationRule < 28) {
				if (combinationRule < 26) {
					if (combinationRule < 25) {
						return alphaBlendwith(sourceWord, destinationWord);
					} else {
						return pixPaintwith(sourceWord, destinationWord);
					}
				} else {
					if (combinationRule < 27) {
						return pixMaskwith(sourceWord, destinationWord);
					} else {
						return destinationWord;
					}
				}
			} else {
				if (combinationRule < 30) {
					if (combinationRule < 29) {
						return destinationWord;
					} else {
						return destinationWord;
					}
				} else {
					if (combinationRule < 31) {
						return destinationWord;
					} else {
						return destinationWord;
					}
				}
			}
		}
	}
}

int methodClassOf(int methodPointer) {
    int literalCount;
    int association;

	literalCount = (((unsigned) (longAt((methodPointer + 4) + (0 * 4)))) >> 10) & 255;
	association = longAt((methodPointer + 4) + (((literalCount - 1) + 1) * 4));
	return longAt((association + 4) + (1 * 4));
}

int newActiveContext(int aContext) {
    int m;

	/* begin storeContextRegisters */
	longAtput((activeContext + 4) + (1 * 4), ((((instructionPointer - method) - (4 - 2)) << 1) | 1));
	longAtput((activeContext + 4) + (2 * 4), (((((((stackPointer - activeContext) - 4) / 4) - 6) + 1) << 1) | 1));
	activeContext = aContext;
	if (activeContext < youngStart) {
		beRootIfOld(activeContext);
	}
	/* begin fetchContextRegisters */
	m = longAt((activeContext + 4) + (3 * 4));
	if (((m & 1) == 1)) {
		theHomeContext = longAt((activeContext + 4) + (5 * 4));
		if (theHomeContext < youngStart) {
			beRootIfOld(theHomeContext);
		}
	} else {
		theHomeContext = activeContext;
	}
	receiver = longAt((theHomeContext + 4) + (5 * 4));
	method = longAt((theHomeContext + 4) + (3 * 4));
	instructionPointer = ((longAt((activeContext + 4) + (1 * 4))) >> 1);
	instructionPointer = ((method + instructionPointer) + 4) - 2;
	stackPointer = ((longAt((activeContext + 4) + (2 * 4))) >> 1);
	stackPointer = (activeContext + 4) + (((6 + stackPointer) - 1) * 4);
}

int newObjectHash(void) {
	lastHash = (13849 + (27181 * lastHash)) & 65535;
	return lastHash & 4095;
}

int nilContextFields(void) {
	longAtput((activeContext + 4) + (0 * 4), nilObj);
	longAtput((activeContext + 4) + (1 * 4), nilObj);
}

int nilObject(void) {
	return nilObj;
}

int objectAfter(int oop) {
    int sz;
    int header;

	if (checkAssertions) {
		if (oop >= endOfMemory) {
			error("no objects after the end of memory");
		}
	}
	if (((longAt(oop)) & 3) == 2) {
		sz = (longAt(oop)) & 536870908;
	} else {
		/* begin sizeBitsOf: */
		header = longAt(oop);
		if ((header & 3) == 0) {
			sz = (longAt(oop - 8)) & 4294967292;
			goto l1;
		} else {
			sz = header & 252;
			goto l1;
		}
	l1:	/* end sizeBitsOf: */;
	}
	return (oop + sz) + (extraHeaderBytes(oop + sz));
}

int objectAfterWhileForwarding(int oop) {
    int header;
    int fwdBlock;
    int realHeader;
    int sz;
    int sz1;
    int header1;

	header = longAt(oop);
	if ((header & 2147483648) == 0) {
		/* begin objectAfter: */
		if (checkAssertions) {
			if (oop >= endOfMemory) {
				error("no objects after the end of memory");
			}
		}
		if (((longAt(oop)) & 3) == 2) {
			sz1 = (longAt(oop)) & 536870908;
		} else {
			/* begin sizeBitsOf: */
			header1 = longAt(oop);
			if ((header1 & 3) == 0) {
				sz1 = (longAt(oop - 8)) & 4294967292;
				goto l1;
			} else {
				sz1 = header1 & 252;
				goto l1;
			}
		l1:	/* end sizeBitsOf: */;
		}
		return (oop + sz1) + (extraHeaderBytes(oop + sz1));
	}
	fwdBlock = header & 2147483644;
	if (checkAssertions) {
		/* begin fwdBlockValidate: */
		if (!((fwdBlock > endOfMemory) && ((fwdBlock <= fwdTableNext) && ((fwdBlock & 3) == 0)))) {
			error("invalid fwd table entry");
		}
	}
	realHeader = longAt(fwdBlock + 4);
	if ((realHeader & 3) == 0) {
		sz = (longAt(oop - 8)) & 268435452;
	} else {
		sz = realHeader & 252;
	}
	return (oop + sz) + (extraHeaderBytes(oop + sz));
}

int okayActiveProcessStack(void) {
    int cntxt;

	cntxt = activeContext;
	while (!(cntxt == nilObj)) {
		okayFields(cntxt);
		cntxt = longAt((cntxt + 4) + (0 * 4));
	}
}

int okayFields(int oop) {
    int i;
    int fieldOop;

	if ((oop == null) || (oop == 0)) {
		return true;
	}
	if (((oop & 1) == 1)) {
		return true;
	}
	okayOop(oop);
	oopHasOkayClass(oop);
	if (!(((((unsigned) (longAt(oop))) >> 8) & 15) <= 4)) {
		return true;
	}
	i = (lengthOf(oop)) - 1;
	while (i >= 0) {
		fieldOop = longAt((oop + 4) + (i * 4));
		if (!(((fieldOop & 1) == 1))) {
			okayOop(fieldOop);
			oopHasOkayClass(fieldOop);
		}
		i = i - 1;
	}
}

int okayInterpreterObjects(void) {
    int i;
    int oopOrZero;
    int oop;
    int cntxt;

	okayFields(nilObj);
	okayFields(falseObj);
	okayFields(trueObj);
	okayFields(specialObjectsOop);
	okayFields(activeContext);
	okayFields(method);
	okayFields(receiver);
	okayFields(theHomeContext);
	okayFields(messageSelector);
	okayFields(newMethod);
	for (i = 1; i <= 512; i += 1) {
		oopOrZero = methodCache[i];
		if (!(oopOrZero == 0)) {
			okayFields(methodCache[i]);
			okayFields(methodCache[i + 512]);
			okayFields(methodCache[i + (2 * 512)]);
		}
	}
	for (i = 1; i <= remapBufferCount; i += 1) {
		oop = remapBuffer[i];
		if (!(((oop & 1) == 1))) {
			okayFields(oop);
		}
	}
	/* begin okayActiveProcessStack */
	cntxt = activeContext;
	while (!(cntxt == nilObj)) {
		okayFields(cntxt);
		cntxt = longAt((cntxt + 4) + (0 * 4));
	}
}

int okayOop(int oop) {
    int sz;
    int type;
    int fmt;
    int header;

	if (((oop & 1) == 1)) {
		return true;
	}
	if (!((0 < oop) && (oop < endOfMemory))) {
		error("oop is not a valid address");
	}
	if (!((oop % 4) == 0)) {
		error("oop is not a word-aligned address");
	}
	/* begin sizeBitsOf: */
	header = longAt(oop);
	if ((header & 3) == 0) {
		sz = (longAt(oop - 8)) & 4294967292;
		goto l1;
	} else {
		sz = header & 252;
		goto l1;
	}
l1:	/* end sizeBitsOf: */;
	if (!((oop + sz) < endOfMemory)) {
		error("oop size would make it extend beyond the end of memory");
	}
	type = (longAt(oop)) & 3;
	if (type == 2) {
		error("oop is a free chunk, not an object");
	}
	if (type == 3) {
		if (((((unsigned) (longAt(oop))) >> 12) & 31) == 0) {
			error("cannot have zero compact class field in a short header");
		}
	}
	if (type == 1) {
		if (!((oop >= 4) && (((longAt(oop - 4)) & 3) == type))) {
			error("class header word has wrong type");
		}
	}
	if (type == 0) {
		if (!((oop >= 8) && ((((longAt(oop - 8)) & 3) == type) && (((longAt(oop - 4)) & 3) == type)))) {
			error("class header word has wrong type");
		}
	}
	fmt = (((unsigned) (longAt(oop))) >> 8) & 15;
	if (((fmt == 4) || (fmt == 5)) || (fmt == 7)) {
		error("oop has an unknown format type");
	}
	if (!(((longAt(oop)) & 536870912) == 0)) {
		error("unused header bit 30 is set; should be zero");
	}
	if ((((longAt(oop)) & 1073741824) == 1) && (oop >= youngStart)) {
		error("root bit is set in a young object");
	}
	return true;
}

int okStreamArrayClass(int cl) {
	return (cl == (longAt((specialObjectsOop + 4) + (6 * 4)))) || ((cl == (longAt((specialObjectsOop + 4) + (7 * 4)))) || ((cl == (longAt((specialObjectsOop + 4) + (26 * 4)))) || (cl == (longAt((specialObjectsOop + 4) + (4 * 4))))));
}

int oopFromChunk(int chunk) {
	return chunk + (extraHeaderBytes(chunk));
}

int oopHasOkayClass(int oop) {
    int oopClass;
    int formatMask;
    int behaviorFormatBits;
    int oopFormatBits;
    int ccIndex;

	okayOop(oop);
	/* begin fetchClassOf: */
	if (((oop & 1) == 1)) {
		oopClass = longAt((specialObjectsOop + 4) + (5 * 4));
		goto l1;
	}
	ccIndex = ((((unsigned) (longAt(oop))) >> 12) & 31) - 1;
	if (ccIndex < 0) {
		oopClass = (longAt(oop - 4)) & 4294967292;
		goto l1;
	} else {
		oopClass = longAt(((longAt((specialObjectsOop + 4) + (28 * 4))) + 4) + (ccIndex * 4));
		goto l1;
	}
l1:	/* end fetchClassOf: */;
	if (((oopClass & 1) == 1)) {
		error("a SmallInteger is not a valid class or behavior");
	}
	okayOop(oopClass);
	if (!((((((unsigned) (longAt(oopClass))) >> 8) & 15) <= 4) && ((lengthOf(oopClass)) >= 3))) {
		error("a class (behavior) must be a pointers object of size >= 3");
	}
	if (((((unsigned) (longAt(oop))) >> 8) & 15) >= 8) {
		formatMask = 3072;
	} else {
		formatMask = 3840;
	}
	behaviorFormatBits = ((longAt((oopClass + 4) + (2 * 4))) - 1) & formatMask;
	oopFormatBits = (longAt(oop)) & formatMask;
	if (!(behaviorFormatBits == oopFormatBits)) {
		error("object and its class (behavior) formats differ");
	}
	return true;
}

int partitionedAddtonBitsnPartitions(int word1, int word2, int nBits, int nParts) {
    int mask;
    int sum;
    int result;
    int i;

	mask = (1 << nBits) - 1;
	result = 0;
	for (i = 1; i <= nParts; i += 1) {
		sum = (word1 & mask) + (word2 & mask);
		if (sum <= mask) {
			result = result | sum;
		} else {
			result = result | mask;
		}
		mask = mask << nBits;
	}
	return result;
}

int partitionedANDtonBitsnPartitions(int word1, int word2, int nBits, int nParts) {
    int mask;
    int result;
    int i;

	mask = (1 << nBits) - 1;
	result = 0;
	for (i = 1; i <= nParts; i += 1) {
		if ((word1 & mask) == mask) {
			result = result | (word2 & mask);
		}
		mask = mask << nBits;
	}
	return result;
}

int partitionedSubfromnBitsnPartitions(int word1, int word2, int nBits, int nParts) {
    int mask;
    int result;
    int i;
    int p1;
    int p2;

	mask = (1 << nBits) - 1;
	result = 0;
	for (i = 1; i <= nParts; i += 1) {
		p1 = word1 & mask;
		p2 = word2 & mask;
		if (p1 < p2) {
			result = result | (p2 - p1);
		} else {
			result = result | (p1 - p2);
		}
		mask = mask << nBits;
	}
	return result;
}

int pickSourcePixelsnullMapsrcMaskdestMask(int nPix, int nullMap, int sourcePixMask, int destPixMask) {
    int sourceWord;
    int destWord;
    int sourcePix;
    int i;
    int sourceWord1;
    int destWord1;
    int sourcePix1;
    int destPix;
    int i1;
    int mask;
    int d;
    int srcPix;
    int destPix1;
    int mask3;
    int d1;
    int srcPix1;
    int destPix2;
    int mask4;
    int d2;
    int srcPix2;
    int destPix3;
    int mask5;
    int d3;
    int srcPix3;
    int destPix4;
    int sourceWord2;
    int destWord2;
    int sourcePix2;
    int destPix5;
    int i2;

	if (sourcePixSize >= 16) {
		/* begin pickSourcePixelsRGB:nullMap:srcMask:destMask: */
		sourceWord1 = longAt(sourceIndex);
		destWord1 = 0;
		for (i1 = 1; i1 <= nPix; i1 += 1) {
			sourcePix1 = (((unsigned) sourceWord1) >> ((32 - sourcePixSize) - srcBitIndex)) & sourcePixMask;
			if (nullMap) {
				if (sourcePixSize == 16) {
					/* begin rgbMap:from:to: */
					if ((d = 8 - 5) > 0) {
						mask = (1 << 5) - 1;
						srcPix = sourcePix1 << d;
						mask = mask << d;
						destPix1 = srcPix & mask;
						mask = mask << 8;
						srcPix = srcPix << d;
						destPix = (destPix1 + (srcPix & mask)) + ((srcPix << d) & (mask << 8));
						goto l1;
					} else {
						if (d == 0) {
							destPix = sourcePix1;
							goto l1;
						}
						d = 5 - 8;
						mask = (1 << 8) - 1;
						srcPix = ((unsigned) sourcePix1) >> d;
						destPix1 = srcPix & mask;
						mask = mask << 8;
						srcPix = ((unsigned) srcPix) >> d;
						destPix = (destPix1 + (srcPix & mask)) + ((((unsigned) srcPix) >> d) & (mask << 8));
						goto l1;
					}
				l1:	/* end rgbMap:from:to: */;
				} else {
					/* begin rgbMap:from:to: */
					if ((d1 = 5 - 8) > 0) {
						mask3 = (1 << 8) - 1;
						srcPix1 = sourcePix1 << d1;
						mask3 = mask3 << d1;
						destPix2 = srcPix1 & mask3;
						mask3 = mask3 << 5;
						srcPix1 = srcPix1 << d1;
						destPix = (destPix2 + (srcPix1 & mask3)) + ((srcPix1 << d1) & (mask3 << 5));
						goto l2;
					} else {
						if (d1 == 0) {
							destPix = sourcePix1;
							goto l2;
						}
						d1 = 8 - 5;
						mask3 = (1 << 5) - 1;
						srcPix1 = ((unsigned) sourcePix1) >> d1;
						destPix2 = srcPix1 & mask3;
						mask3 = mask3 << 5;
						srcPix1 = ((unsigned) srcPix1) >> d1;
						destPix = (destPix2 + (srcPix1 & mask3)) + ((((unsigned) srcPix1) >> d1) & (mask3 << 5));
						goto l2;
					}
				l2:	/* end rgbMap:from:to: */;
				}
			} else {
				if (sourcePixSize == 16) {
					/* begin rgbMap:from:to: */
					if ((d2 = cmBitsPerColor - 5) > 0) {
						mask4 = (1 << 5) - 1;
						srcPix2 = sourcePix1 << d2;
						mask4 = mask4 << d2;
						destPix3 = srcPix2 & mask4;
						mask4 = mask4 << cmBitsPerColor;
						srcPix2 = srcPix2 << d2;
						sourcePix1 = (destPix3 + (srcPix2 & mask4)) + ((srcPix2 << d2) & (mask4 << cmBitsPerColor));
						goto l3;
					} else {
						if (d2 == 0) {
							sourcePix1 = sourcePix1;
							goto l3;
						}
						d2 = 5 - cmBitsPerColor;
						mask4 = (1 << cmBitsPerColor) - 1;
						srcPix2 = ((unsigned) sourcePix1) >> d2;
						destPix3 = srcPix2 & mask4;
						mask4 = mask4 << cmBitsPerColor;
						srcPix2 = ((unsigned) srcPix2) >> d2;
						sourcePix1 = (destPix3 + (srcPix2 & mask4)) + ((((unsigned) srcPix2) >> d2) & (mask4 << cmBitsPerColor));
						goto l3;
					}
				l3:	/* end rgbMap:from:to: */;
				} else {
					/* begin rgbMap:from:to: */
					if ((d3 = cmBitsPerColor - 8) > 0) {
						mask5 = (1 << 8) - 1;
						srcPix3 = sourcePix1 << d3;
						mask5 = mask5 << d3;
						destPix4 = srcPix3 & mask5;
						mask5 = mask5 << cmBitsPerColor;
						srcPix3 = srcPix3 << d3;
						sourcePix1 = (destPix4 + (srcPix3 & mask5)) + ((srcPix3 << d3) & (mask5 << cmBitsPerColor));
						goto l4;
					} else {
						if (d3 == 0) {
							sourcePix1 = sourcePix1;
							goto l4;
						}
						d3 = 8 - cmBitsPerColor;
						mask5 = (1 << cmBitsPerColor) - 1;
						srcPix3 = ((unsigned) sourcePix1) >> d3;
						destPix4 = srcPix3 & mask5;
						mask5 = mask5 << cmBitsPerColor;
						srcPix3 = ((unsigned) srcPix3) >> d3;
						sourcePix1 = (destPix4 + (srcPix3 & mask5)) + ((((unsigned) srcPix3) >> d3) & (mask5 << cmBitsPerColor));
						goto l4;
					}
				l4:	/* end rgbMap:from:to: */;
				}
				destPix = (longAt((colorMap + 4) + (sourcePix1 * 4))) & destPixMask;
			}
			destWord1 = (destWord1 << destPixSize) | destPix;
			if ((srcBitIndex = srcBitIndex + sourcePixSize) > 31) {
				srcBitIndex = srcBitIndex - 32;
				sourceIndex = sourceIndex + 4;
				sourceWord1 = longAt(sourceIndex);
			}
		}
		return destWord1;
	}
	if (nullMap) {
		/* begin pickSourcePixelsNullMap:srcMask:destMask: */
		sourceWord = longAt(sourceIndex);
		destWord = 0;
		for (i = 1; i <= nPix; i += 1) {
			sourcePix = (((unsigned) sourceWord) >> ((32 - sourcePixSize) - srcBitIndex)) & sourcePixMask;
			destWord = (destWord << destPixSize) | (sourcePix & destPixMask);
			if ((srcBitIndex = srcBitIndex + sourcePixSize) > 31) {
				srcBitIndex = srcBitIndex - 32;
				sourceIndex = sourceIndex + 4;
				sourceWord = longAt(sourceIndex);
			}
		}
		return destWord;
	}
	/* begin pickSourcePixels:srcMask:destMask: */
	sourceWord2 = longAt(sourceIndex);
	destWord2 = 0;
	for (i2 = 1; i2 <= nPix; i2 += 1) {
		sourcePix2 = (((unsigned) sourceWord2) >> ((32 - sourcePixSize) - srcBitIndex)) & sourcePixMask;
		destPix5 = (longAt((colorMap + 4) + (sourcePix2 * 4))) & destPixMask;
		destWord2 = (destWord2 << destPixSize) | destPix5;
		if ((srcBitIndex = srcBitIndex + sourcePixSize) > 31) {
			srcBitIndex = srcBitIndex - 32;
			sourceIndex = sourceIndex + 4;
			sourceWord2 = longAt(sourceIndex);
		}
	}
	return destWord2;
}

int pickSourcePixelssrcMaskdestMask(int nPix, int sourcePixMask, int destPixMask) {
    int sourceWord;
    int destWord;
    int sourcePix;
    int destPix;
    int i;

	sourceWord = longAt(sourceIndex);
	destWord = 0;
	for (i = 1; i <= nPix; i += 1) {
		sourcePix = (((unsigned) sourceWord) >> ((32 - sourcePixSize) - srcBitIndex)) & sourcePixMask;
		destPix = (longAt((colorMap + 4) + (sourcePix * 4))) & destPixMask;
		destWord = (destWord << destPixSize) | destPix;
		if ((srcBitIndex = srcBitIndex + sourcePixSize) > 31) {
			srcBitIndex = srcBitIndex - 32;
			sourceIndex = sourceIndex + 4;
			sourceWord = longAt(sourceIndex);
		}
	}
	return destWord;
}

int pickSourcePixelsNullMapsrcMaskdestMask(int nPix, int sourcePixMask, int destPixMask) {
    int sourceWord;
    int destWord;
    int sourcePix;
    int i;

	sourceWord = longAt(sourceIndex);
	destWord = 0;
	for (i = 1; i <= nPix; i += 1) {
		sourcePix = (((unsigned) sourceWord) >> ((32 - sourcePixSize) - srcBitIndex)) & sourcePixMask;
		destWord = (destWord << destPixSize) | (sourcePix & destPixMask);
		if ((srcBitIndex = srcBitIndex + sourcePixSize) > 31) {
			srcBitIndex = srcBitIndex - 32;
			sourceIndex = sourceIndex + 4;
			sourceWord = longAt(sourceIndex);
		}
	}
	return destWord;
}

int pickSourcePixelsRGBnullMapsrcMaskdestMask(int nPix, int nullMap, int sourcePixMask, int destPixMask) {
    int sourceWord;
    int destWord;
    int sourcePix;
    int destPix;
    int i;
    int mask;
    int d;
    int srcPix;
    int destPix1;
    int mask3;
    int d1;
    int srcPix1;
    int destPix2;
    int mask4;
    int d2;
    int srcPix2;
    int destPix3;
    int mask5;
    int d3;
    int srcPix3;
    int destPix4;

	sourceWord = longAt(sourceIndex);
	destWord = 0;
	for (i = 1; i <= nPix; i += 1) {
		sourcePix = (((unsigned) sourceWord) >> ((32 - sourcePixSize) - srcBitIndex)) & sourcePixMask;
		if (nullMap) {
			if (sourcePixSize == 16) {
				/* begin rgbMap:from:to: */
				if ((d = 8 - 5) > 0) {
					mask = (1 << 5) - 1;
					srcPix = sourcePix << d;
					mask = mask << d;
					destPix1 = srcPix & mask;
					mask = mask << 8;
					srcPix = srcPix << d;
					destPix = (destPix1 + (srcPix & mask)) + ((srcPix << d) & (mask << 8));
					goto l1;
				} else {
					if (d == 0) {
						destPix = sourcePix;
						goto l1;
					}
					d = 5 - 8;
					mask = (1 << 8) - 1;
					srcPix = ((unsigned) sourcePix) >> d;
					destPix1 = srcPix & mask;
					mask = mask << 8;
					srcPix = ((unsigned) srcPix) >> d;
					destPix = (destPix1 + (srcPix & mask)) + ((((unsigned) srcPix) >> d) & (mask << 8));
					goto l1;
				}
			l1:	/* end rgbMap:from:to: */;
			} else {
				/* begin rgbMap:from:to: */
				if ((d1 = 5 - 8) > 0) {
					mask3 = (1 << 8) - 1;
					srcPix1 = sourcePix << d1;
					mask3 = mask3 << d1;
					destPix2 = srcPix1 & mask3;
					mask3 = mask3 << 5;
					srcPix1 = srcPix1 << d1;
					destPix = (destPix2 + (srcPix1 & mask3)) + ((srcPix1 << d1) & (mask3 << 5));
					goto l2;
				} else {
					if (d1 == 0) {
						destPix = sourcePix;
						goto l2;
					}
					d1 = 8 - 5;
					mask3 = (1 << 5) - 1;
					srcPix1 = ((unsigned) sourcePix) >> d1;
					destPix2 = srcPix1 & mask3;
					mask3 = mask3 << 5;
					srcPix1 = ((unsigned) srcPix1) >> d1;
					destPix = (destPix2 + (srcPix1 & mask3)) + ((((unsigned) srcPix1) >> d1) & (mask3 << 5));
					goto l2;
				}
			l2:	/* end rgbMap:from:to: */;
			}
		} else {
			if (sourcePixSize == 16) {
				/* begin rgbMap:from:to: */
				if ((d2 = cmBitsPerColor - 5) > 0) {
					mask4 = (1 << 5) - 1;
					srcPix2 = sourcePix << d2;
					mask4 = mask4 << d2;
					destPix3 = srcPix2 & mask4;
					mask4 = mask4 << cmBitsPerColor;
					srcPix2 = srcPix2 << d2;
					sourcePix = (destPix3 + (srcPix2 & mask4)) + ((srcPix2 << d2) & (mask4 << cmBitsPerColor));
					goto l3;
				} else {
					if (d2 == 0) {
						sourcePix = sourcePix;
						goto l3;
					}
					d2 = 5 - cmBitsPerColor;
					mask4 = (1 << cmBitsPerColor) - 1;
					srcPix2 = ((unsigned) sourcePix) >> d2;
					destPix3 = srcPix2 & mask4;
					mask4 = mask4 << cmBitsPerColor;
					srcPix2 = ((unsigned) srcPix2) >> d2;
					sourcePix = (destPix3 + (srcPix2 & mask4)) + ((((unsigned) srcPix2) >> d2) & (mask4 << cmBitsPerColor));
					goto l3;
				}
			l3:	/* end rgbMap:from:to: */;
			} else {
				/* begin rgbMap:from:to: */
				if ((d3 = cmBitsPerColor - 8) > 0) {
					mask5 = (1 << 8) - 1;
					srcPix3 = sourcePix << d3;
					mask5 = mask5 << d3;
					destPix4 = srcPix3 & mask5;
					mask5 = mask5 << cmBitsPerColor;
					srcPix3 = srcPix3 << d3;
					sourcePix = (destPix4 + (srcPix3 & mask5)) + ((srcPix3 << d3) & (mask5 << cmBitsPerColor));
					goto l4;
				} else {
					if (d3 == 0) {
						sourcePix = sourcePix;
						goto l4;
					}
					d3 = 8 - cmBitsPerColor;
					mask5 = (1 << cmBitsPerColor) - 1;
					srcPix3 = ((unsigned) sourcePix) >> d3;
					destPix4 = srcPix3 & mask5;
					mask5 = mask5 << cmBitsPerColor;
					srcPix3 = ((unsigned) srcPix3) >> d3;
					sourcePix = (destPix4 + (srcPix3 & mask5)) + ((((unsigned) srcPix3) >> d3) & (mask5 << cmBitsPerColor));
					goto l4;
				}
			l4:	/* end rgbMap:from:to: */;
			}
			destPix = (longAt((colorMap + 4) + (sourcePix * 4))) & destPixMask;
		}
		destWord = (destWord << destPixSize) | destPix;
		if ((srcBitIndex = srcBitIndex + sourcePixSize) > 31) {
			srcBitIndex = srcBitIndex - 32;
			sourceIndex = sourceIndex + 4;
			sourceWord = longAt(sourceIndex);
		}
	}
	return destWord;
}

int pixMaskwith(int sourceWord, int destinationWord) {
    int mask;
    int result;
    int i;

	/* begin partitionedAND:to:nBits:nPartitions: */
	mask = (1 << destPixSize) - 1;
	result = 0;
	for (i = 1; i <= pixPerWord; i += 1) {
		if (((~sourceWord) & mask) == mask) {
			result = result | (destinationWord & mask);
		}
		mask = mask << destPixSize;
	}
	return result;
}

int pixPaintwith(int sourceWord, int destinationWord) {
	return sourceWord | (partitionedANDtonBitsnPartitions(~sourceWord, destinationWord, destPixSize, pixPerWord));
}

int pop(int nItems) {
	stackPointer = stackPointer - (nItems * 4);
}

double popFloat(void) {
    int top;
    int top1;
    int cl;
    int ccIndex;

	/* begin popStack */
	top1 = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	top = top1;
	/* begin floatValueOf: */
	/* begin fetchClassOf: */
	if (((top & 1) == 1)) {
		cl = longAt((specialObjectsOop + 4) + (5 * 4));
		goto l1;
	}
	ccIndex = ((((unsigned) (longAt(top))) >> 12) & 31) - 1;
	if (ccIndex < 0) {
		cl = (longAt(top - 4)) & 4294967292;
		goto l1;
	} else {
		cl = longAt(((longAt((specialObjectsOop + 4) + (28 * 4))) + 4) + (ccIndex * 4));
		goto l1;
	}
l1:	/* end fetchClassOf: */;
	/* begin success: */
	successFlag = (cl == (longAt((specialObjectsOop + 4) + (9 * 4)))) && successFlag;
	if (successFlag) {
		return floatAt(top + 4);
	}
	return 0.0;
}

int popInteger(void) {
    int integerPointer;
    int top;

	/* begin popStack */
	top = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	integerPointer = top;
	if (((integerPointer & 1) == 1)) {
		return (integerPointer >> 1);
	} else {
		successFlag = false;
		return 1;
	}
}

int popPos32BitInteger(void) {
    int top;
    int top1;

	/* begin popStack */
	top1 = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	top = top1;
	return positive32BitValueOf(top);
}

int popRemappableOop(void) {
    int oop;

	oop = remapBuffer[remapBufferCount];
	remapBufferCount = remapBufferCount - 1;
	return oop;
}

int popStack(void) {
    int top;

	top = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	return top;
}

int positive32BitIntegerFor(int integerValue) {
    int newLargeInteger;

	if ((integerValue >= 0) && ((integerValue >= -1073741824) && (integerValue < 1073741824))) {
		return ((integerValue << 1) | 1);
	}
	newLargeInteger = instantiateSmallClasssizeInBytesfill(longAt((specialObjectsOop + 4) + (13 * 4)), 8, 0);
	byteAtput((newLargeInteger + 4) + 3, (((unsigned) integerValue) >> 24) & 255);
	byteAtput((newLargeInteger + 4) + 2, (((unsigned) integerValue) >> 16) & 255);
	byteAtput((newLargeInteger + 4) + 1, (((unsigned) integerValue) >> 8) & 255);
	byteAtput((newLargeInteger + 4) + 0, integerValue & 255);
	return newLargeInteger;
}

int positive32BitValueOf(int integerPointer) {
    int sz;
    int value;
    int header;
    int sz1;
    int fmt;

	if (((integerPointer & 1) == 1)) {
		value = (integerPointer >> 1);
		if (value < 0) {
			return primitiveFail();
		}
		return value;
	}
	/* begin lengthOf: */
	header = longAt(integerPointer);
	if ((header & 3) == 0) {
		sz1 = (longAt(integerPointer - 8)) & 4294967292;
	} else {
		sz1 = header & 252;
	}
	fmt = (((unsigned) header) >> 8) & 15;
	if (fmt < 8) {
		sz = (sz1 - 4) / 4;
		goto l1;
	} else {
		sz = (sz1 - 4) - (fmt & 3);
		goto l1;
	}
l1:	/* end lengthOf: */;
	if (!(((fetchClassOf(integerPointer)) == (longAt((specialObjectsOop + 4) + (13 * 4)))) && (sz == 4))) {
		return primitiveFail();
	}
	value = (((byteAt((integerPointer + 4) + 0)) + ((byteAt((integerPointer + 4) + 1)) << 8)) + ((byteAt((integerPointer + 4) + 2)) << 16)) + ((byteAt((integerPointer + 4) + 3)) << 24);
	return value;
}

int possibleRootStoreIntovalue(int oop, int valueObj) {
    int header;

	if ((valueObj >= youngStart) && (!(((valueObj & 1) == 1)))) {
		header = longAt(oop);
		if ((header & 1073741824) == 0) {
			if (rootTableCount < 1000) {
				rootTableCount = rootTableCount + 1;
				rootTable[rootTableCount] = oop;
				longAtput(oop, header | 1073741824);
			}
		}
	}
}

int postGCAction(void) {
	if (activeContext < youngStart) {
		beRootIfOld(activeContext);
	}
	if (theHomeContext < youngStart) {
		beRootIfOld(theHomeContext);
	}
}

int prepareForwardingTableForBecomingwith(int array1, int array2) {
    int entriesNeeded;
    int entriesAvailable;
    int fieldOffset;
    int oop1;
    int oop2;
    int fwdBlock;
    int originalHeader;
    int originalHeaderType;
    int originalHeader1;
    int originalHeaderType1;
    int fmt;
    int sz;
    int methodHeader;
    int header;
    int type;

	entriesNeeded = 2 * ((lastPointerOf(array1)) / 4);
	entriesAvailable = fwdTableInit();
	if (entriesAvailable < entriesNeeded) {
		initializeMemoryFirstFree(freeBlock);
		return false;
	}
	/* begin lastPointerOf: */
	fmt = (((unsigned) (longAt(array1))) >> 8) & 15;
	if (fmt < 4) {
		/* begin sizeBitsOfSafe: */
		header = longAt(array1);
		/* begin rightType: */
		if ((header & 252) == 0) {
			type = 0;
			goto l4;
		} else {
			if ((header & 126976) == 0) {
				type = 1;
				goto l4;
			} else {
				type = 3;
				goto l4;
			}
		}
	l4:	/* end rightType: */;
		if (type == 0) {
			sz = (longAt(array1 - 8)) & 4294967292;
			goto l5;
		} else {
			sz = header & 252;
			goto l5;
		}
	l5:	/* end sizeBitsOfSafe: */;
		fieldOffset = sz - 4;
		goto l3;
	}
	if (fmt < 12) {
		fieldOffset = 0;
		goto l3;
	}
	methodHeader = longAt(array1 + 4);
	fieldOffset = (((((unsigned) methodHeader) >> 10) & 255) * 4) + 4;
l3:	/* end lastPointerOf: */;
	while (fieldOffset >= 4) {
		oop1 = longAt(array1 + fieldOffset);
		oop2 = longAt(array2 + fieldOffset);
		/* begin fwdBlockGet */
		fwdTableNext = fwdTableNext + 8;
		if (fwdTableNext <= fwdTableLast) {
			fwdBlock = fwdTableNext;
			goto l1;
		} else {
			fwdBlock = null;
			goto l1;
		}
	l1:	/* end fwdBlockGet */;
		/* begin initForwardBlock:mapping:to: */
		originalHeader = longAt(oop1);
		if (checkAssertions) {
			if (fwdBlock == null) {
				error("ran out of forwarding blocks in become");
			}
			if ((originalHeader & 2147483648) != 0) {
				error("object already has a forwarding table entry");
			}
		}
		originalHeaderType = originalHeader & 3;
		longAtput(fwdBlock, oop2);
		longAtput(fwdBlock + 4, originalHeader);
		longAtput(oop1, fwdBlock | (2147483648 | originalHeaderType));
		/* begin fwdBlockGet */
		fwdTableNext = fwdTableNext + 8;
		if (fwdTableNext <= fwdTableLast) {
			fwdBlock = fwdTableNext;
			goto l2;
		} else {
			fwdBlock = null;
			goto l2;
		}
	l2:	/* end fwdBlockGet */;
		/* begin initForwardBlock:mapping:to: */
		originalHeader1 = longAt(oop2);
		if (checkAssertions) {
			if (fwdBlock == null) {
				error("ran out of forwarding blocks in become");
			}
			if ((originalHeader1 & 2147483648) != 0) {
				error("object already has a forwarding table entry");
			}
		}
		originalHeaderType1 = originalHeader1 & 3;
		longAtput(fwdBlock, oop1);
		longAtput(fwdBlock + 4, originalHeader1);
		longAtput(oop2, fwdBlock | (2147483648 | originalHeaderType1));
		fieldOffset = fieldOffset - 4;
	}
	return true;
}

int primIndex(void) {
	return primitiveIndex;
}

int primitiveAdd(void) {
    int rcvr;
    int arg;
    int result;

	successFlag = true;
	rcvr = longAt(stackPointer - (1 * 4));
	arg = longAt(stackPointer - (0 * 4));
	if (areFloatsand(rcvr, arg)) {
		primitiveFloatAdd();
		if (successFlag) {
			return null;
		}
	}
	/* begin pop: */
	stackPointer = stackPointer - (2 * 4);
	/* begin success: */
	successFlag = (((rcvr & arg) & 1) != 0) && successFlag;
	if (successFlag) {
		result = ((rcvr >> 1)) + ((arg >> 1));
	}
	/* begin checkIntegerResult:from: */
	if (successFlag && ((result >= -1073741824) && (result < 1073741824))) {
		/* begin pushInteger: */
		/* begin push: */
		longAtput(stackPointer = stackPointer + 4, ((result << 1) | 1));
	} else {
		/* begin unPop: */
		stackPointer = stackPointer + (2 * 4);
		failSpecialPrim(1);
	}
}

int primitiveArrayBecome(void) {
    int arg;
    int rcvr;
    int top;
    int successValue;
    int fieldOffset;
    int oop1;
    int oop2;
    int fwdHeader;
    int fwdBlock;
    int fwdHeader1;
    int fwdBlock1;
    int hdr1;
    int hdr2;
    int fmt;
    int sz;
    int methodHeader;
    int header;
    int type;

	/* begin popStack */
	top = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	arg = top;
	rcvr = longAt(stackPointer);
	/* begin success: */
	/* begin become:with: */
	if (!((fetchClassOf(rcvr)) == (longAt((specialObjectsOop + 4) + (7 * 4))))) {
		successValue = false;
		goto l1;
	}
	if (!((fetchClassOf(arg)) == (longAt((specialObjectsOop + 4) + (7 * 4))))) {
		successValue = false;
		goto l1;
	}
	if (!((lastPointerOf(rcvr)) == (lastPointerOf(arg)))) {
		successValue = false;
		goto l1;
	}
	if (!(containOnlyOopsand(rcvr, arg))) {
		successValue = false;
		goto l1;
	}
	if (!(prepareForwardingTableForBecomingwith(rcvr, arg))) {
		successValue = false;
		goto l1;
	}
	if (allYoungand(rcvr, arg)) {
		mapPointersInObjectsFromto(youngStart, endOfMemory);
	} else {
		mapPointersInObjectsFromto(startOfMemory(), endOfMemory);
	}
	/* begin restoreHeadersAfterBecoming:with: */
	/* begin lastPointerOf: */
	fmt = (((unsigned) (longAt(rcvr))) >> 8) & 15;
	if (fmt < 4) {
		/* begin sizeBitsOfSafe: */
		header = longAt(rcvr);
		/* begin rightType: */
		if ((header & 252) == 0) {
			type = 0;
			goto l3;
		} else {
			if ((header & 126976) == 0) {
				type = 1;
				goto l3;
			} else {
				type = 3;
				goto l3;
			}
		}
	l3:	/* end rightType: */;
		if (type == 0) {
			sz = (longAt(rcvr - 8)) & 4294967292;
			goto l4;
		} else {
			sz = header & 252;
			goto l4;
		}
	l4:	/* end sizeBitsOfSafe: */;
		fieldOffset = sz - 4;
		goto l2;
	}
	if (fmt < 12) {
		fieldOffset = 0;
		goto l2;
	}
	methodHeader = longAt(rcvr + 4);
	fieldOffset = (((((unsigned) methodHeader) >> 10) & 255) * 4) + 4;
l2:	/* end lastPointerOf: */;
	while (fieldOffset >= 4) {
		oop1 = longAt(rcvr + fieldOffset);
		oop2 = longAt(arg + fieldOffset);
		/* begin restoreHeaderOf: */
		fwdHeader = longAt(oop1);
		fwdBlock = fwdHeader & 2147483644;
		if (checkAssertions) {
			if ((fwdHeader & 2147483648) == 0) {
				error("attempting to restore the header of an object that has no forwarding block");
			}
			/* begin fwdBlockValidate: */
			if (!((fwdBlock > endOfMemory) && ((fwdBlock <= fwdTableNext) && ((fwdBlock & 3) == 0)))) {
				error("invalid fwd table entry");
			}
		}
		longAtput(oop1, longAt(fwdBlock + 4));
		/* begin restoreHeaderOf: */
		fwdHeader1 = longAt(oop2);
		fwdBlock1 = fwdHeader1 & 2147483644;
		if (checkAssertions) {
			if ((fwdHeader1 & 2147483648) == 0) {
				error("attempting to restore the header of an object that has no forwarding block");
			}
			/* begin fwdBlockValidate: */
			if (!((fwdBlock1 > endOfMemory) && ((fwdBlock1 <= fwdTableNext) && ((fwdBlock1 & 3) == 0)))) {
				error("invalid fwd table entry");
			}
		}
		longAtput(oop2, longAt(fwdBlock1 + 4));
		/* begin exchangeHashBits:with: */
		hdr1 = longAt(oop1);
		hdr2 = longAt(oop2);
		longAtput(oop1, (hdr1 & 3758227455) | (hdr2 & 536739840));
		longAtput(oop2, (hdr2 & 3758227455) | (hdr1 & 536739840));
		fieldOffset = fieldOffset - 4;
	}
	initializeMemoryFirstFree(freeBlock);
	successValue = true;
l1:	/* end become:with: */;
	successFlag = successValue && successFlag;
	if (!(successFlag)) {
		/* begin unPop: */
		stackPointer = stackPointer + (1 * 4);
	}
}

int primitiveAsFloat(void) {
    int arg;
    int object;
    int integerPointer;
    int top;
    int newFloat;

	/* begin popInteger */
	/* begin popStack */
	top = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	integerPointer = top;
	if (((integerPointer & 1) == 1)) {
		arg = (integerPointer >> 1);
		goto l1;
	} else {
		successFlag = false;
		arg = 1;
		goto l1;
	}
l1:	/* end popInteger */;
	if (successFlag) {
		/* begin pushFloat: */
		/* begin push: */
		/* begin floatObjectOf: */
		newFloat = instantiateSmallClasssizeInBytesfill(longAt((specialObjectsOop + 4) + (9 * 4)), 12, 0);
		floatAtput(newFloat + 4, ((double) arg));
		object = newFloat;
		longAtput(stackPointer = stackPointer + 4, object);
	} else {
		/* begin unPop: */
		stackPointer = stackPointer + (1 * 4);
	}
}

int primitiveAsOop(void) {
    int thisReceiver;
    int top;

	/* begin popStack */
	top = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	thisReceiver = top;
	/* begin success: */
	successFlag = (!(((thisReceiver & 1) == 1))) && successFlag;
	if (successFlag) {
		/* begin pushInteger: */
		/* begin push: */
		longAtput(stackPointer = stackPointer + 4, ((((((unsigned) (longAt(thisReceiver))) >> 17) & 4095) << 1) | 1));
	} else {
		/* begin unPop: */
		stackPointer = stackPointer + (1 * 4);
	}
}

int primitiveAt(void) {
	return commonAt(false);
}

int primitiveAtEnd(void) {
    int stream;
    int array;
    int index;
    int limit;
    int arrayClass;
    int size;
    int successValue;
    int totalLength;
    int fixedFields;
    int header;
    int sz;
    int fmt;
    int top;
    int successValue1;
    int ccIndex;
    int classPointer;
    int fmt1;
    int ccIndex1;

	successFlag = true;
	/* begin popStack */
	top = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	stream = top;
	/* begin success: */
	successValue1 = (((((unsigned) (longAt(stream))) >> 8) & 15) <= 4) && ((lengthOf(stream)) >= 3);
	successFlag = successValue1 && successFlag;
	if (successFlag) {
		array = longAt((stream + 4) + (0 * 4));
		index = fetchIntegerofObject(1, stream);
		limit = fetchIntegerofObject(2, stream);
		/* begin fetchClassOf: */
		if (((array & 1) == 1)) {
			arrayClass = longAt((specialObjectsOop + 4) + (5 * 4));
			goto l3;
		}
		ccIndex = ((((unsigned) (longAt(array))) >> 12) & 31) - 1;
		if (ccIndex < 0) {
			arrayClass = (longAt(array - 4)) & 4294967292;
			goto l3;
		} else {
			arrayClass = longAt(((longAt((specialObjectsOop + 4) + (28 * 4))) + 4) + (ccIndex * 4));
			goto l3;
		}
	l3:	/* end fetchClassOf: */;
		/* begin success: */
		successValue = (arrayClass == (longAt((specialObjectsOop + 4) + (6 * 4)))) || ((arrayClass == (longAt((specialObjectsOop + 4) + (7 * 4)))) || ((arrayClass == (longAt((specialObjectsOop + 4) + (26 * 4)))) || (arrayClass == (longAt((specialObjectsOop + 4) + (4 * 4))))));
		successFlag = successValue && successFlag;
		/* begin stSizeOf: */
		if (((array & 1) == 1)) {
			size = 0;
			goto l2;
		}
		/* begin lengthOf: */
		header = longAt(array);
		if ((header & 3) == 0) {
			sz = (longAt(array - 8)) & 4294967292;
		} else {
			sz = header & 252;
		}
		fmt = (((unsigned) header) >> 8) & 15;
		if (fmt < 8) {
			totalLength = (sz - 4) / 4;
			goto l1;
		} else {
			totalLength = (sz - 4) - (fmt & 3);
			goto l1;
		}
	l1:	/* end lengthOf: */;
		/* begin fixedFieldsOf: */
		/* begin fetchClassOf: */
		if (((array & 1) == 1)) {
			classPointer = longAt((specialObjectsOop + 4) + (5 * 4));
			goto l4;
		}
		ccIndex1 = ((((unsigned) (longAt(array))) >> 12) & 31) - 1;
		if (ccIndex1 < 0) {
			classPointer = (longAt(array - 4)) & 4294967292;
			goto l4;
		} else {
			classPointer = longAt(((longAt((specialObjectsOop + 4) + (28 * 4))) + 4) + (ccIndex1 * 4));
			goto l4;
		}
	l4:	/* end fetchClassOf: */;
		fmt1 = (longAt((classPointer + 4) + (2 * 4))) - 1;
		fixedFields = ((((unsigned) fmt1) >> 2) & 63) - 1;
		size = totalLength - fixedFields;
	l2:	/* end stSizeOf: */;
	}
	if (successFlag) {
		/* begin pushBool: */
		if ((index >= limit) || (index >= size)) {
			/* begin push: */
			longAtput(stackPointer = stackPointer + 4, trueObj);
		} else {
			/* begin push: */
			longAtput(stackPointer = stackPointer + 4, falseObj);
		}
	} else {
		/* begin unPop: */
		stackPointer = stackPointer + (1 * 4);
		failSpecialPrim(67);
	}
}

int primitiveAtPut(void) {
	return commonAtPut(false);
}

int primitiveBeCursor(void) {
    int cursorObj;
    int bitsObj;
    int extentX;
    int extentY;
    int offsetObj;
    int offsetX;
    int offsetY;
    int cursorBitsIndex;
    int successValue;
    int successValue1;
    int successValue2;
    int successValue3;
    int successValue4;
    int successValue5;

	cursorObj = longAt(stackPointer);
	/* begin success: */
	successValue5 = (((((unsigned) (longAt(cursorObj))) >> 8) & 15) <= 4) && ((lengthOf(cursorObj)) >= 5);
	successFlag = successValue5 && successFlag;
	if (successFlag) {
		bitsObj = longAt((cursorObj + 4) + (0 * 4));
		extentX = fetchIntegerofObject(1, cursorObj);
		extentY = fetchIntegerofObject(2, cursorObj);
		offsetObj = longAt((cursorObj + 4) + (4 * 4));
		/* begin success: */
		successValue = (((((unsigned) (longAt(offsetObj))) >> 8) & 15) <= 4) && ((lengthOf(offsetObj)) >= 2);
		successFlag = successValue && successFlag;
	}
	if (successFlag) {
		offsetX = fetchIntegerofObject(0, offsetObj);
		offsetY = fetchIntegerofObject(1, offsetObj);
		/* begin success: */
		successValue1 = (extentX == 16) && (extentY == 16);
		successFlag = successValue1 && successFlag;
		/* begin success: */
		successValue2 = (offsetX >= -16) && (offsetX <= 0);
		successFlag = successValue2 && successFlag;
		/* begin success: */
		successValue3 = (offsetY >= -16) && (offsetY <= 0);
		successFlag = successValue3 && successFlag;
		/* begin success: */
		successValue4 = (((((unsigned) (longAt(bitsObj))) >> 8) & 15) == 6) && ((lengthOf(bitsObj)) == 16);
		successFlag = successValue4 && successFlag;
		cursorBitsIndex = bitsObj + 4;
	}
	if (successFlag) {
		ioSetCursor(cursorBitsIndex, offsetX, offsetY);
		/* begin pop: */
		stackPointer = stackPointer - (1 * 4);
	}
}

int primitiveBeDisplay(void) {
    int rcvr;
    int objectPointer;
    int successValue;

	rcvr = longAt(stackPointer);
	/* begin success: */
	successValue = (((((unsigned) (longAt(rcvr))) >> 8) & 15) <= 4) && ((lengthOf(rcvr)) >= 4);
	successFlag = successValue && successFlag;
	if (successFlag) {
		/* begin storePointer:ofObject:withValue: */
		objectPointer = specialObjectsOop;
		if (objectPointer < youngStart) {
			possibleRootStoreIntovalue(objectPointer, rcvr);
		}
		longAtput((objectPointer + 4) + (14 * 4), rcvr);
		/* begin pop: */
		stackPointer = stackPointer - (1 * 4);
	}
}

int primitiveBeep(void) {
	/* begin pop: */
	stackPointer = stackPointer - (1 * 4);
	ioBeep();
}

int primitiveBitAnd(void) {
    int integerReceiver;
    int integerArgument;
    int object;
    int top;
    int top1;
    int top2;
    int top11;

	successFlag = true;
	/* begin popPos32BitInteger */
	/* begin popStack */
	top1 = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	top = top1;
	integerArgument = positive32BitValueOf(top);
	/* begin popPos32BitInteger */
	/* begin popStack */
	top11 = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	top2 = top11;
	integerReceiver = positive32BitValueOf(top2);
	if (successFlag) {
		/* begin push: */
		object = positive32BitIntegerFor(integerReceiver & integerArgument);
		longAtput(stackPointer = stackPointer + 4, object);
	} else {
		/* begin unPop: */
		stackPointer = stackPointer + (2 * 4);
		failSpecialPrim(14);
	}
}

int primitiveBitOr(void) {
    int integerReceiver;
    int integerArgument;
    int object;
    int top;
    int top1;
    int top2;
    int top11;

	successFlag = true;
	/* begin popPos32BitInteger */
	/* begin popStack */
	top1 = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	top = top1;
	integerArgument = positive32BitValueOf(top);
	/* begin popPos32BitInteger */
	/* begin popStack */
	top11 = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	top2 = top11;
	integerReceiver = positive32BitValueOf(top2);
	if (successFlag) {
		/* begin push: */
		object = positive32BitIntegerFor(integerReceiver | integerArgument);
		longAtput(stackPointer = stackPointer + 4, object);
	} else {
		/* begin unPop: */
		stackPointer = stackPointer + (2 * 4);
		failSpecialPrim(15);
	}
}

int primitiveBitShift(void) {
    int integerReceiver;
    int integerArgument;
    int shifted;
    int object;
    int integerPointer;
    int top;
    int top2;
    int top1;

	successFlag = true;
	/* begin popInteger */
	/* begin popStack */
	top = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	integerPointer = top;
	if (((integerPointer & 1) == 1)) {
		integerArgument = (integerPointer >> 1);
		goto l1;
	} else {
		successFlag = false;
		integerArgument = 1;
		goto l1;
	}
l1:	/* end popInteger */;
	/* begin popPos32BitInteger */
	/* begin popStack */
	top1 = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	top2 = top1;
	integerReceiver = positive32BitValueOf(top2);
	if (integerArgument >= 0) {
		/* begin success: */
		successFlag = (integerArgument <= 31) && successFlag;
		shifted = integerReceiver << integerArgument;
		/* begin success: */
		successFlag = ((((unsigned) shifted) >> integerArgument) == integerReceiver) && successFlag;
	} else {
		/* begin success: */
		successFlag = (integerArgument >= -31) && successFlag;
		shifted = ((integerArgument < 0) ? ((unsigned) integerReceiver >> -integerArgument) : ((unsigned) integerReceiver << integerArgument));
	}
	if (successFlag) {
		/* begin push: */
		object = positive32BitIntegerFor(shifted);
		longAtput(stackPointer = stackPointer + 4, object);
	} else {
		/* begin unPop: */
		stackPointer = stackPointer + (2 * 4);
		failSpecialPrim(17);
	}
}

int primitiveBitXor(void) {
    int integerReceiver;
    int integerArgument;
    int object;
    int top;
    int top1;
    int top2;
    int top11;

	/* begin popPos32BitInteger */
	/* begin popStack */
	top1 = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	top = top1;
	integerArgument = positive32BitValueOf(top);
	/* begin popPos32BitInteger */
	/* begin popStack */
	top11 = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	top2 = top11;
	integerReceiver = positive32BitValueOf(top2);
	if (successFlag) {
		/* begin push: */
		object = positive32BitIntegerFor(integerReceiver ^ integerArgument);
		longAtput(stackPointer = stackPointer + 4, object);
	} else {
		/* begin unPop: */
		stackPointer = stackPointer + (2 * 4);
	}
}

int primitiveBlockCopy(void) {
    int context;
    int methodContext;
    int contextSize;
    int newContext;
    int initialIP;
    int header;
    int oop;

	context = longAt(stackPointer - (1 * 4));
	if ((((longAt((context + 4) + (3 * 4))) & 1) == 1)) {
		methodContext = longAt((context + 4) + (5 * 4));
	} else {
		methodContext = context;
	}
	/* begin sizeBitsOf: */
	header = longAt(methodContext);
	if ((header & 3) == 0) {
		contextSize = (longAt(methodContext - 8)) & 4294967292;
		goto l1;
	} else {
		contextSize = header & 252;
		goto l1;
	}
l1:	/* end sizeBitsOf: */;
	context = null;
	/* begin pushRemappableOop: */
	remapBuffer[remapBufferCount = remapBufferCount + 1] = methodContext;
	newContext = instantiateSmallClasssizeInBytesfill(longAt((specialObjectsOop + 4) + (11 * 4)), contextSize, nilObj);
	/* begin popRemappableOop */
	oop = remapBuffer[remapBufferCount];
	remapBufferCount = remapBufferCount - 1;
	methodContext = oop;
	initialIP = (((instructionPointer - method) << 1) | 1);
	longAtput((newContext + 4) + (4 * 4), initialIP);
	longAtput((newContext + 4) + (1 * 4), initialIP);
	/* begin storeStackPointerValue:inContext: */
	longAtput((newContext + 4) + (2 * 4), ((0 << 1) | 1));
	longAtput((newContext + 4) + (3 * 4), longAt(stackPointer - (0 * 4)));
	longAtput((newContext + 4) + (5 * 4), methodContext);
	/* begin pop: */
	stackPointer = stackPointer - (2 * 4);
	/* begin push: */
	longAtput(stackPointer = stackPointer + 4, newContext);
}

int primitiveBytesLeft(void) {
    int integerValue;

	/* begin pop: */
	stackPointer = stackPointer - (1 * 4);
	/* begin pushInteger: */
	integerValue = (longAt(freeBlock)) & 536870908;
	/* begin push: */
	longAtput(stackPointer = stackPointer + 4, ((integerValue << 1) | 1));
}

int primitiveClass(void) {
    int instance;
    int top;
    int object;
    int ccIndex;

	/* begin popStack */
	top = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	instance = top;
	/* begin push: */
	/* begin fetchClassOf: */
	if (((instance & 1) == 1)) {
		object = longAt((specialObjectsOop + 4) + (5 * 4));
		goto l1;
	}
	ccIndex = ((((unsigned) (longAt(instance))) >> 12) & 31) - 1;
	if (ccIndex < 0) {
		object = (longAt(instance - 4)) & 4294967292;
		goto l1;
	} else {
		object = longAt(((longAt((specialObjectsOop + 4) + (28 * 4))) + 4) + (ccIndex * 4));
		goto l1;
	}
l1:	/* end fetchClassOf: */;
	longAtput(stackPointer = stackPointer + 4, object);
}

int primitiveClipboardText(void) {
    int s;
    int sz;
    int totalLength;
    int fixedFields;
    int header;
    int sz1;
    int fmt;
    int successValue;
    int classPointer;
    int fmt1;
    int ccIndex;

	if (argumentCount == 1) {
		s = longAt(stackPointer);
		/* begin success: */
		successValue = (fetchClassOf(s)) == (longAt((specialObjectsOop + 4) + (6 * 4)));
		successFlag = successValue && successFlag;
		if (successFlag) {
			/* begin stSizeOf: */
			if (((s & 1) == 1)) {
				sz = 0;
				goto l2;
			}
			/* begin lengthOf: */
			header = longAt(s);
			if ((header & 3) == 0) {
				sz1 = (longAt(s - 8)) & 4294967292;
			} else {
				sz1 = header & 252;
			}
			fmt = (((unsigned) header) >> 8) & 15;
			if (fmt < 8) {
				totalLength = (sz1 - 4) / 4;
				goto l1;
			} else {
				totalLength = (sz1 - 4) - (fmt & 3);
				goto l1;
			}
		l1:	/* end lengthOf: */;
			/* begin fixedFieldsOf: */
			/* begin fetchClassOf: */
			if (((s & 1) == 1)) {
				classPointer = longAt((specialObjectsOop + 4) + (5 * 4));
				goto l3;
			}
			ccIndex = ((((unsigned) (longAt(s))) >> 12) & 31) - 1;
			if (ccIndex < 0) {
				classPointer = (longAt(s - 4)) & 4294967292;
				goto l3;
			} else {
				classPointer = longAt(((longAt((specialObjectsOop + 4) + (28 * 4))) + 4) + (ccIndex * 4));
				goto l3;
			}
		l3:	/* end fetchClassOf: */;
			fmt1 = (longAt((classPointer + 4) + (2 * 4))) - 1;
			fixedFields = ((((unsigned) fmt1) >> 2) & 63) - 1;
			sz = totalLength - fixedFields;
		l2:	/* end stSizeOf: */;
			clipboardWriteFromAt(sz, s + 4, 0);
			/* begin pop: */
			stackPointer = stackPointer - (1 * 4);
		}
	} else {
		sz = clipboardSize();
		s = instantiateClassindexableSize(longAt((specialObjectsOop + 4) + (6 * 4)), sz);
		clipboardReadIntoAt(sz, s + 4, 0);
		/* begin pop: */
		stackPointer = stackPointer - (1 * 4);
		/* begin push: */
		longAtput(stackPointer = stackPointer + 4, s);
	}
}

int primitiveConstantFill(void) {
    int fillValue;
    int rcvr;
    int rcvrIsBytes;
    int end;
    int i;
    int successValue;
    int integerPointer;
    int successValue1;
    int fmt;

	/* begin stackIntegerValue: */
	integerPointer = longAt(stackPointer - (0 * 4));
	if (((integerPointer & 1) == 1)) {
		fillValue = (integerPointer >> 1);
		goto l1;
	} else {
		primitiveFail();
		fillValue = 0;
		goto l1;
	}
l1:	/* end stackIntegerValue: */;
	rcvr = longAt(stackPointer - (1 * 4));
	/* begin success: */
	/* begin isWordsOrBytes: */
	fmt = (((unsigned) (longAt(rcvr))) >> 8) & 15;
	successValue1 = (fmt == 6) || ((fmt >= 8) && (fmt <= 11));
	successFlag = successValue1 && successFlag;
	rcvrIsBytes = ((((unsigned) (longAt(rcvr))) >> 8) & 15) >= 8;
	if (rcvrIsBytes) {
		/* begin success: */
		successValue = (fillValue >= 0) && (fillValue <= 255);
		successFlag = successValue && successFlag;
	}
	if (successFlag) {
		end = rcvr + (sizeBitsOf(rcvr));
		i = rcvr + 4;
		if (rcvrIsBytes) {
			while (i < end) {
				byteAtput(i, fillValue);
				i = i + 1;
			}
		} else {
			while (i < end) {
				longAtput(i, fillValue);
				i = i + 4;
			}
		}
		/* begin pop: */
		stackPointer = stackPointer - (1 * 4);
	}
}

int primitiveCopyBits(void) {
    int rcvr;
    int successValue;

	rcvr = longAt(stackPointer);
	/* begin success: */
	successValue = loadBitBltFrom(rcvr);
	successFlag = successValue && successFlag;
	if (successFlag) {
		copyBits();
		if (destForm == (longAt((specialObjectsOop + 4) + (14 * 4)))) {
			showDisplayBits();
		}
	}
}

int primitiveDirectoryCreate(void) {
    int dirName;
    int dirNameIndex;
    int dirNameSize;
    int header;
    int sz;
    int fmt;

	dirName = longAt(stackPointer);
	/* begin success: */
	successFlag = (((((unsigned) (longAt(dirName))) >> 8) & 15) >= 8) && successFlag;
	if (successFlag) {
		dirNameIndex = dirName + 4;
		/* begin lengthOf: */
		header = longAt(dirName);
		if ((header & 3) == 0) {
			sz = (longAt(dirName - 8)) & 4294967292;
		} else {
			sz = header & 252;
		}
		fmt = (((unsigned) header) >> 8) & 15;
		if (fmt < 8) {
			dirNameSize = (sz - 4) / 4;
			goto l1;
		} else {
			dirNameSize = (sz - 4) - (fmt & 3);
			goto l1;
		}
	l1:	/* end lengthOf: */;
	}
	if (successFlag) {
		/* begin success: */
		successFlag = (dir_Create((char *) dirNameIndex, dirNameSize)) && successFlag;
	}
	if (successFlag) {
		/* begin pop: */
		stackPointer = stackPointer - (1 * 4);
	}
}

int primitiveDirectoryDelimitor(void) {
    int ascii;
    int successValue;

	ascii = asciiDirectoryDelimiter();
	/* begin success: */
	successValue = (ascii >= 0) && (ascii <= 255);
	successFlag = successValue && successFlag;
	if (successFlag) {
		/* begin pop: */
		stackPointer = stackPointer - (1 * 4);
		/* begin push: */
		longAtput(stackPointer = stackPointer + 4, longAt(((longAt((specialObjectsOop + 4) + (24 * 4))) + 4) + (ascii * 4)));
	}
}

int primitiveDirectoryLookup(void) {
    int index;
    int pathName;
    int pathNameIndex;
    int pathNameSize;
    int status;
    char entryName[256];
    int entryNameSize;
    int createDate;
    int modifiedDate;
    int dirFlag;
    int fileSize;
    int header;
    int sz;
    int fmt;
    int object;
    int integerPointer;

	/* begin stackIntegerValue: */
	integerPointer = longAt(stackPointer - (0 * 4));
	if (((integerPointer & 1) == 1)) {
		index = (integerPointer >> 1);
		goto l2;
	} else {
		primitiveFail();
		index = 0;
		goto l2;
	}
l2:	/* end stackIntegerValue: */;
	pathName = longAt(stackPointer - (1 * 4));
	/* begin success: */
	successFlag = (((((unsigned) (longAt(pathName))) >> 8) & 15) >= 8) && successFlag;
	if (successFlag) {
		pathNameIndex = pathName + 4;
		/* begin lengthOf: */
		header = longAt(pathName);
		if ((header & 3) == 0) {
			sz = (longAt(pathName - 8)) & 4294967292;
		} else {
			sz = header & 252;
		}
		fmt = (((unsigned) header) >> 8) & 15;
		if (fmt < 8) {
			pathNameSize = (sz - 4) / 4;
			goto l1;
		} else {
			pathNameSize = (sz - 4) - (fmt & 3);
			goto l1;
		}
	l1:	/* end lengthOf: */;
	}
	if (successFlag) {
		status = dir_Lookup(
				(char *) pathNameIndex, pathNameSize, index,
				entryName, &entryNameSize, &createDate, &modifiedDate,
				&dirFlag, &fileSize);
		if (status == 1) {
			/* begin pop: */
			stackPointer = stackPointer - (3 * 4);
			/* begin push: */
			longAtput(stackPointer = stackPointer + 4, nilObj);
			return null;
		}
		if (status == 2) {
			return primitiveFail();
		}
	}
	if (successFlag) {
		/* begin pop: */
		stackPointer = stackPointer - (3 * 4);
		/* begin push: */
		object = makeDirEntryNamesizecreateDatemodDateisDirfileSize(entryName, entryNameSize, createDate, modifiedDate, dirFlag, fileSize);
		longAtput(stackPointer = stackPointer + 4, object);
	}
}

int primitiveDirectorySetMacTypeAndCreator(void) {
    int creatorString;
    int typeString;
    int fileName;
    int creatorStringIndex;
    int typeStringIndex;
    int fileNameIndex;
    int fileNameSize;
    int header;
    int sz;
    int fmt;
    int successValue;
    int successValue1;

	creatorString = longAt(stackPointer);
	typeString = longAt(stackPointer - (1 * 4));
	fileName = longAt(stackPointer - (2 * 4));
	/* begin success: */
	successValue = (((((unsigned) (longAt(creatorString))) >> 8) & 15) >= 8) && ((lengthOf(creatorString)) == 4);
	successFlag = successValue && successFlag;
	/* begin success: */
	successValue1 = (((((unsigned) (longAt(typeString))) >> 8) & 15) >= 8) && ((lengthOf(typeString)) == 4);
	successFlag = successValue1 && successFlag;
	/* begin success: */
	successFlag = (((((unsigned) (longAt(fileName))) >> 8) & 15) >= 8) && successFlag;
	if (successFlag) {
		creatorStringIndex = creatorString + 4;
		typeStringIndex = typeString + 4;
		fileNameIndex = fileName + 4;
		/* begin lengthOf: */
		header = longAt(fileName);
		if ((header & 3) == 0) {
			sz = (longAt(fileName - 8)) & 4294967292;
		} else {
			sz = header & 252;
		}
		fmt = (((unsigned) header) >> 8) & 15;
		if (fmt < 8) {
			fileNameSize = (sz - 4) / 4;
			goto l1;
		} else {
			fileNameSize = (sz - 4) - (fmt & 3);
			goto l1;
		}
	l1:	/* end lengthOf: */;
	}
	if (successFlag) {
		/* begin success: */
		successFlag = (dir_SetMacFileTypeAndCreator(
				(char *) fileNameIndex, fileNameSize,
				(char *) typeStringIndex, (char *) creatorStringIndex)) && successFlag;
	}
	if (successFlag) {
		/* begin pop: */
		stackPointer = stackPointer - (3 * 4);
	}
}

int primitiveDiv(void) {
    int rcvr;
    int arg;
    int result;
    int posArg;
    int posRcvr;
    int integerPointer;
    int top;
    int integerPointer1;
    int top1;

	successFlag = true;
	/* begin popInteger */
	/* begin popStack */
	top = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	integerPointer = top;
	if (((integerPointer & 1) == 1)) {
		arg = (integerPointer >> 1);
		goto l1;
	} else {
		successFlag = false;
		arg = 1;
		goto l1;
	}
l1:	/* end popInteger */;
	/* begin popInteger */
	/* begin popStack */
	top1 = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	integerPointer1 = top1;
	if (((integerPointer1 & 1) == 1)) {
		rcvr = (integerPointer1 >> 1);
		goto l2;
	} else {
		successFlag = false;
		rcvr = 1;
		goto l2;
	}
l2:	/* end popInteger */;
	/* begin success: */
	successFlag = (arg != 0) && successFlag;
	if (successFlag) {
		if (rcvr > 0) {
			if (arg > 0) {
				result = rcvr / arg;
			} else {
				posArg = 0 - arg;
				result = 0 - ((rcvr + (posArg - 1)) / posArg);
			}
		} else {
			posRcvr = 0 - rcvr;
			if (arg > 0) {
				result = 0 - ((posRcvr + (arg - 1)) / arg);
			} else {
				posArg = 0 - arg;
				result = posRcvr / posArg;
			}
		}
		/* begin checkIntegerResult:from: */
		if (successFlag && ((result >= -1073741824) && (result < 1073741824))) {
			/* begin pushInteger: */
			/* begin push: */
			longAtput(stackPointer = stackPointer + 4, ((result << 1) | 1));
		} else {
			/* begin unPop: */
			stackPointer = stackPointer + (2 * 4);
			failSpecialPrim(12);
		}
	} else {
		/* begin checkIntegerResult:from: */
		if (successFlag && ((0 >= -1073741824) && (0 < 1073741824))) {
			/* begin pushInteger: */
			/* begin push: */
			longAtput(stackPointer = stackPointer + 4, ((0 << 1) | 1));
		} else {
			/* begin unPop: */
			stackPointer = stackPointer + (2 * 4);
			failSpecialPrim(12);
		}
	}
}

int primitiveDivide(void) {
    int integerReceiver;
    int integerArgument;
    int integerPointer;
    int top;
    int integerPointer1;
    int top1;

	successFlag = true;
	/* begin popInteger */
	/* begin popStack */
	top = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	integerPointer = top;
	if (((integerPointer & 1) == 1)) {
		integerArgument = (integerPointer >> 1);
		goto l1;
	} else {
		successFlag = false;
		integerArgument = 1;
		goto l1;
	}
l1:	/* end popInteger */;
	/* begin popInteger */
	/* begin popStack */
	top1 = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	integerPointer1 = top1;
	if (((integerPointer1 & 1) == 1)) {
		integerReceiver = (integerPointer1 >> 1);
		goto l2;
	} else {
		successFlag = false;
		integerReceiver = 1;
		goto l2;
	}
l2:	/* end popInteger */;
	/* begin success: */
	successFlag = (integerArgument != 0) && successFlag;
	if (!(successFlag)) {
		integerArgument = 1;
	}
	/* begin success: */
	successFlag = ((integerReceiver % integerArgument) == 0) && successFlag;
	/* begin checkIntegerResult:from: */
	if (successFlag && (((integerReceiver / integerArgument) >= -1073741824) && ((integerReceiver / integerArgument) < 1073741824))) {
		/* begin pushInteger: */
		/* begin push: */
		longAtput(stackPointer = stackPointer + 4, (((integerReceiver / integerArgument) << 1) | 1));
	} else {
		/* begin unPop: */
		stackPointer = stackPointer + (2 * 4);
		failSpecialPrim(10);
	}
}

int primitiveDrawLoop(void) {
    int rcvr;
    int xDelta;
    int yDelta;
    int dx1;
    int dy1;
    int px;
    int py;
    int P;
    int affL;
    int affR;
    int affT;
    int affB;
    int i;
    int integerPointer;
    int integerPointer1;
    int successValue;
    int objectPointer;
    int integerValue;
    int objectPointer1;
    int integerValue1;

	rcvr = longAt(stackPointer - (2 * 4));
	/* begin stackIntegerValue: */
	integerPointer = longAt(stackPointer - (1 * 4));
	if (((integerPointer & 1) == 1)) {
		xDelta = (integerPointer >> 1);
		goto l1;
	} else {
		primitiveFail();
		xDelta = 0;
		goto l1;
	}
l1:	/* end stackIntegerValue: */;
	/* begin stackIntegerValue: */
	integerPointer1 = longAt(stackPointer - (0 * 4));
	if (((integerPointer1 & 1) == 1)) {
		yDelta = (integerPointer1 >> 1);
		goto l2;
	} else {
		primitiveFail();
		yDelta = 0;
		goto l2;
	}
l2:	/* end stackIntegerValue: */;
	/* begin success: */
	successValue = loadBitBltFrom(rcvr);
	successFlag = successValue && successFlag;
	if (successFlag) {
		/* begin drawLoopX:Y: */
		if (xDelta > 0) {
			dx1 = 1;
		} else {
			if (xDelta == 0) {
				dx1 = 0;
			} else {
				dx1 = -1;
			}
		}
		if (yDelta > 0) {
			dy1 = 1;
		} else {
			if (yDelta == 0) {
				dy1 = 0;
			} else {
				dy1 = -1;
			}
		}
		px = abs(yDelta);
		py = abs(xDelta);
		copyBits();
		affL = affectedL;
		affR = affectedR;
		affT = affectedT;
		affB = affectedB;
		if (py > px) {
			P = py / 2;
			for (i = 1; i <= py; i += 1) {
				destX = destX + dx1;
				if ((P = P - px) < 0) {
					destY = destY + dy1;
					P = P + py;
				}
				copyBits();
			}
		} else {
			P = px / 2;
			for (i = 1; i <= px; i += 1) {
				destY = destY + dy1;
				if ((P = P - py) < 0) {
					destX = destX + dx1;
					P = P + px;
				}
				copyBits();
			}
		}
		affectedL = ((affL < affectedL) ? affL : affectedL);
		affectedR = ((affR < affectedR) ? affectedR : affR);
		affectedT = ((affT < affectedT) ? affT : affectedT);
		affectedB = ((affB < affectedB) ? affectedB : affB);
		/* begin storeInteger:ofObject:withValue: */
		objectPointer = bitBltOop;
		integerValue = destX;
		if ((integerValue >= -1073741824) && (integerValue < 1073741824)) {
			longAtput((objectPointer + 4) + (4 * 4), ((integerValue << 1) | 1));
		} else {
			primitiveFail();
		}
		/* begin storeInteger:ofObject:withValue: */
		objectPointer1 = bitBltOop;
		integerValue1 = destY;
		if ((integerValue1 >= -1073741824) && (integerValue1 < 1073741824)) {
			longAtput((objectPointer1 + 4) + (5 * 4), ((integerValue1 << 1) | 1));
		} else {
			primitiveFail();
		}
		if (destForm == (longAt((specialObjectsOop + 4) + (14 * 4)))) {
			showDisplayBits();
		}
		/* begin pop: */
		stackPointer = stackPointer - (2 * 4);
	}
}

int primitiveEqual(void) {
    int integerReceiver;
    int integerArgument;
    int result;
    int top;
    int top1;

	successFlag = true;
	/* begin popStack */
	top = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	integerArgument = top;
	/* begin popStack */
	top1 = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	integerReceiver = top1;
	/* begin compare31or32Bits:equal: */
	if ((((integerReceiver & 1) == 1)) && (((integerArgument & 1) == 1))) {
		result = integerReceiver == integerArgument;
		goto l1;
	}
	result = (positive32BitValueOf(integerReceiver)) == (positive32BitValueOf(integerArgument));
l1:	/* end compare31or32Bits:equal: */;
	/* begin checkBooleanResult:from: */
	if (successFlag) {
		/* begin pushBool: */
		if (result) {
			/* begin push: */
			longAtput(stackPointer = stackPointer + 4, trueObj);
		} else {
			/* begin push: */
			longAtput(stackPointer = stackPointer + 4, falseObj);
		}
	} else {
		/* begin unPop: */
		stackPointer = stackPointer + (2 * 4);
		failSpecialPrim(7);
	}
}

int primitiveEquivalent(void) {
    int thisObject;
    int otherObject;
    int top;
    int top1;

	/* begin popStack */
	top = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	otherObject = top;
	/* begin popStack */
	top1 = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	thisObject = top1;
	/* begin pushBool: */
	if (thisObject == otherObject) {
		/* begin push: */
		longAtput(stackPointer = stackPointer + 4, trueObj);
	} else {
		/* begin push: */
		longAtput(stackPointer = stackPointer + 4, falseObj);
	}
}

int primitiveExitToDebugger(void) {
	error("Exit to debugger at user request");
}

int primitiveExponent(void) {
    double rcvr;
    double frac;
    int pwr;
    int top;
    int top1;
    int cl;
    int ccIndex;

	/* begin popFloat */
	/* begin popStack */
	top1 = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	top = top1;
	/* begin floatValueOf: */
	/* begin fetchClassOf: */
	if (((top & 1) == 1)) {
		cl = longAt((specialObjectsOop + 4) + (5 * 4));
		goto l1;
	}
	ccIndex = ((((unsigned) (longAt(top))) >> 12) & 31) - 1;
	if (ccIndex < 0) {
		cl = (longAt(top - 4)) & 4294967292;
		goto l1;
	} else {
		cl = longAt(((longAt((specialObjectsOop + 4) + (28 * 4))) + 4) + (ccIndex * 4));
		goto l1;
	}
l1:	/* end fetchClassOf: */;
	/* begin success: */
	successFlag = (cl == (longAt((specialObjectsOop + 4) + (9 * 4)))) && successFlag;
	if (successFlag) {
		rcvr = floatAt(top + 4);
		goto l2;
	}
	rcvr = 0.0;
l2:	/* end floatValueOf: */;
	if (successFlag) {
		frac = frexp(rcvr, &pwr);
		if (pwr == 0) {
			/* begin pushInteger: */
			/* begin push: */
			longAtput(stackPointer = stackPointer + 4, ((0 << 1) | 1));
		} else {
			/* begin pushInteger: */
			/* begin push: */
			longAtput(stackPointer = stackPointer + 4, (((pwr - 1) << 1) | 1));
		}
	} else {
		/* begin unPop: */
		stackPointer = stackPointer + (1 * 4);
	}
}

int primitiveFail(void) {
	successFlag = false;
}

int primitiveFileAtEnd(void) {
    SQFile *file;
    int atEnd;

	file = fileValueOf(longAt(stackPointer));
	if (successFlag) {
		atEnd = sqFileAtEnd(file);
	}
	if (successFlag) {
		/* begin pop: */
		stackPointer = stackPointer - (2 * 4);
		/* begin pushBool: */
		if (atEnd) {
			/* begin push: */
			longAtput(stackPointer = stackPointer + 4, trueObj);
		} else {
			/* begin push: */
			longAtput(stackPointer = stackPointer + 4, falseObj);
		}
	}
}

int primitiveFileClose(void) {
    SQFile *file;

	file = fileValueOf(longAt(stackPointer));
	if (successFlag) {
		sqFileClose(file);
	}
	if (successFlag) {
		/* begin pop: */
		stackPointer = stackPointer - (1 * 4);
	}
}

int primitiveFileDelete(void) {
    int namePointer;
    int nameIndex;
    int nameSize;
    int header;
    int sz;
    int fmt;

	namePointer = longAt(stackPointer);
	/* begin success: */
	successFlag = (((((unsigned) (longAt(namePointer))) >> 8) & 15) >= 8) && successFlag;
	if (successFlag) {
		nameIndex = namePointer + 4;
		/* begin lengthOf: */
		header = longAt(namePointer);
		if ((header & 3) == 0) {
			sz = (longAt(namePointer - 8)) & 4294967292;
		} else {
			sz = header & 252;
		}
		fmt = (((unsigned) header) >> 8) & 15;
		if (fmt < 8) {
			nameSize = (sz - 4) / 4;
			goto l1;
		} else {
			nameSize = (sz - 4) - (fmt & 3);
			goto l1;
		}
	l1:	/* end lengthOf: */;
	}
	if (successFlag) {
		sqFileDeleteNameSize(nameIndex, nameSize);
	}
	if (successFlag) {
		/* begin pop: */
		stackPointer = stackPointer - (1 * 4);
	}
}

int primitiveFileGetPosition(void) {
    SQFile *file;
    int position;

	file = fileValueOf(longAt(stackPointer));
	if (successFlag) {
		position = sqFileGetPosition(file);
	}
	if (successFlag) {
		/* begin pop: */
		stackPointer = stackPointer - (2 * 4);
		/* begin pushInteger: */
		/* begin push: */
		longAtput(stackPointer = stackPointer + 4, ((position << 1) | 1));
	}
}

int primitiveFileOpen(void) {
    int writeFlag;
    int namePointer;
    int filePointer;
    SQFile *file;
    int nameIndex;
    int nameSize;
    int header;
    int sz;
    int fmt;

	/* begin booleanValueOf: */
	if ((longAt(stackPointer)) == trueObj) {
		writeFlag = true;
		goto l2;
	}
	if ((longAt(stackPointer)) == falseObj) {
		writeFlag = false;
		goto l2;
	}
	successFlag = false;
	writeFlag = null;
l2:	/* end booleanValueOf: */;
	namePointer = longAt(stackPointer - (1 * 4));
	/* begin success: */
	successFlag = (((((unsigned) (longAt(namePointer))) >> 8) & 15) >= 8) && successFlag;
	if (successFlag) {
		filePointer = instantiateClassindexableSize(longAt((specialObjectsOop + 4) + (26 * 4)), fileRecordSize());
		file = fileValueOf(filePointer);
		nameIndex = namePointer + 4;
		/* begin lengthOf: */
		header = longAt(namePointer);
		if ((header & 3) == 0) {
			sz = (longAt(namePointer - 8)) & 4294967292;
		} else {
			sz = header & 252;
		}
		fmt = (((unsigned) header) >> 8) & 15;
		if (fmt < 8) {
			nameSize = (sz - 4) / 4;
			goto l1;
		} else {
			nameSize = (sz - 4) - (fmt & 3);
			goto l1;
		}
	l1:	/* end lengthOf: */;
	}
	if (successFlag) {
		sqFileOpen(file, nameIndex, nameSize, writeFlag);
	}
	if (successFlag) {
		/* begin pop: */
		stackPointer = stackPointer - (3 * 4);
		/* begin push: */
		longAtput(stackPointer = stackPointer + 4, filePointer);
	}
}

int primitiveFileRead(void) {
    int count;
    int startIndex;
    int array;
    SQFile *file;
    int byteSize;
    int arrayIndex;
    int bytesRead;
    int integerPointer;
    int integerPointer1;
    int successValue;
    int successValue1;
    int fmt;

	/* begin stackIntegerValue: */
	integerPointer = longAt(stackPointer - (0 * 4));
	if (((integerPointer & 1) == 1)) {
		count = (integerPointer >> 1);
		goto l1;
	} else {
		primitiveFail();
		count = 0;
		goto l1;
	}
l1:	/* end stackIntegerValue: */;
	/* begin stackIntegerValue: */
	integerPointer1 = longAt(stackPointer - (1 * 4));
	if (((integerPointer1 & 1) == 1)) {
		startIndex = (integerPointer1 >> 1);
		goto l2;
	} else {
		primitiveFail();
		startIndex = 0;
		goto l2;
	}
l2:	/* end stackIntegerValue: */;
	array = longAt(stackPointer - (2 * 4));
	file = fileValueOf(longAt(stackPointer - (3 * 4)));
	/* begin success: */
	/* begin isWordsOrBytes: */
	fmt = (((unsigned) (longAt(array))) >> 8) & 15;
	successValue = (fmt == 6) || ((fmt >= 8) && (fmt <= 11));
	successFlag = successValue && successFlag;
	if (((((unsigned) (longAt(array))) >> 8) & 15) == 6) {
		byteSize = 4;
	} else {
		byteSize = 1;
	}
	/* begin success: */
	successValue1 = (startIndex >= 1) && (((startIndex + count) - 1) <= (lengthOf(array)));
	successFlag = successValue1 && successFlag;
	if (successFlag) {
		arrayIndex = array + 4;
		bytesRead = sqFileReadIntoAt(file, count * byteSize, arrayIndex, (startIndex - 1) * byteSize);
	}
	if (successFlag) {
		/* begin pop: */
		stackPointer = stackPointer - (5 * 4);
		/* begin pushInteger: */
		/* begin push: */
		longAtput(stackPointer = stackPointer + 4, (((bytesRead / byteSize) << 1) | 1));
	}
}

int primitiveFileRename(void) {
    int oldNamePointer;
    int newNamePointer;
    int oldNameIndex;
    int oldNameSize;
    int newNameIndex;
    int newNameSize;
    int header;
    int sz;
    int fmt;
    int header1;
    int sz1;
    int fmt1;

	newNamePointer = longAt(stackPointer);
	oldNamePointer = longAt(stackPointer - (1 * 4));
	/* begin success: */
	successFlag = (((((unsigned) (longAt(newNamePointer))) >> 8) & 15) >= 8) && successFlag;
	/* begin success: */
	successFlag = (((((unsigned) (longAt(oldNamePointer))) >> 8) & 15) >= 8) && successFlag;
	if (successFlag) {
		newNameIndex = newNamePointer + 4;
		/* begin lengthOf: */
		header = longAt(newNamePointer);
		if ((header & 3) == 0) {
			sz = (longAt(newNamePointer - 8)) & 4294967292;
		} else {
			sz = header & 252;
		}
		fmt = (((unsigned) header) >> 8) & 15;
		if (fmt < 8) {
			newNameSize = (sz - 4) / 4;
			goto l1;
		} else {
			newNameSize = (sz - 4) - (fmt & 3);
			goto l1;
		}
	l1:	/* end lengthOf: */;
		oldNameIndex = oldNamePointer + 4;
		/* begin lengthOf: */
		header1 = longAt(oldNamePointer);
		if ((header1 & 3) == 0) {
			sz1 = (longAt(oldNamePointer - 8)) & 4294967292;
		} else {
			sz1 = header1 & 252;
		}
		fmt1 = (((unsigned) header1) >> 8) & 15;
		if (fmt1 < 8) {
			oldNameSize = (sz1 - 4) / 4;
			goto l2;
		} else {
			oldNameSize = (sz1 - 4) - (fmt1 & 3);
			goto l2;
		}
	l2:	/* end lengthOf: */;
	}
	if (successFlag) {
		sqFileRenameOldSizeNewSize(oldNameIndex, oldNameSize, newNameIndex, newNameSize);
	}
	if (successFlag) {
		/* begin pop: */
		stackPointer = stackPointer - (2 * 4);
	}
}

int primitiveFileSetPosition(void) {
    int newPosition;
    SQFile *file;
    int integerPointer;

	/* begin stackIntegerValue: */
	integerPointer = longAt(stackPointer - (0 * 4));
	if (((integerPointer & 1) == 1)) {
		newPosition = (integerPointer >> 1);
		goto l1;
	} else {
		primitiveFail();
		newPosition = 0;
		goto l1;
	}
l1:	/* end stackIntegerValue: */;
	file = fileValueOf(longAt(stackPointer - (1 * 4)));
	if (successFlag) {
		sqFileSetPosition(file, newPosition);
	}
	if (successFlag) {
		/* begin pop: */
		stackPointer = stackPointer - (2 * 4);
	}
}

int primitiveFileSize(void) {
    SQFile *file;
    int size;

	file = fileValueOf(longAt(stackPointer));
	if (successFlag) {
		size = sqFileSize(file);
	}
	if (successFlag) {
		/* begin pop: */
		stackPointer = stackPointer - (2 * 4);
		/* begin pushInteger: */
		/* begin push: */
		longAtput(stackPointer = stackPointer + 4, ((size << 1) | 1));
	}
}

int primitiveFileWrite(void) {
    int count;
    int startIndex;
    int array;
    SQFile *file;
    int byteSize;
    int arrayIndex;
    int bytesWritten;
    int integerPointer;
    int integerPointer1;
    int successValue;
    int successValue1;
    int fmt;

	/* begin stackIntegerValue: */
	integerPointer = longAt(stackPointer - (0 * 4));
	if (((integerPointer & 1) == 1)) {
		count = (integerPointer >> 1);
		goto l1;
	} else {
		primitiveFail();
		count = 0;
		goto l1;
	}
l1:	/* end stackIntegerValue: */;
	/* begin stackIntegerValue: */
	integerPointer1 = longAt(stackPointer - (1 * 4));
	if (((integerPointer1 & 1) == 1)) {
		startIndex = (integerPointer1 >> 1);
		goto l2;
	} else {
		primitiveFail();
		startIndex = 0;
		goto l2;
	}
l2:	/* end stackIntegerValue: */;
	array = longAt(stackPointer - (2 * 4));
	file = fileValueOf(longAt(stackPointer - (3 * 4)));
	/* begin success: */
	/* begin isWordsOrBytes: */
	fmt = (((unsigned) (longAt(array))) >> 8) & 15;
	successValue = (fmt == 6) || ((fmt >= 8) && (fmt <= 11));
	successFlag = successValue && successFlag;
	if (((((unsigned) (longAt(array))) >> 8) & 15) == 6) {
		byteSize = 4;
	} else {
		byteSize = 1;
	}
	/* begin success: */
	successValue1 = (startIndex >= 1) && (((startIndex + count) - 1) <= (lengthOf(array)));
	successFlag = successValue1 && successFlag;
	if (successFlag) {
		arrayIndex = array + 4;
		bytesWritten = sqFileWriteFromAt(file, count * byteSize, arrayIndex, (startIndex - 1) * byteSize);
	}
	if (successFlag) {
		/* begin pop: */
		stackPointer = stackPointer - (5 * 4);
		/* begin pushInteger: */
		/* begin push: */
		longAtput(stackPointer = stackPointer + 4, (((bytesWritten / byteSize) << 1) | 1));
	}
}

int primitiveFloatAdd(void) {
    double rcvr;
    double arg;
    int object;
    int top;
    int top1;
    int top2;
    int top11;
    int newFloat;
    int cl;
    int ccIndex;
    int cl1;
    int ccIndex1;

	/* begin popFloat */
	/* begin popStack */
	top1 = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	top = top1;
	/* begin floatValueOf: */
	/* begin fetchClassOf: */
	if (((top & 1) == 1)) {
		cl = longAt((specialObjectsOop + 4) + (5 * 4));
		goto l1;
	}
	ccIndex = ((((unsigned) (longAt(top))) >> 12) & 31) - 1;
	if (ccIndex < 0) {
		cl = (longAt(top - 4)) & 4294967292;
		goto l1;
	} else {
		cl = longAt(((longAt((specialObjectsOop + 4) + (28 * 4))) + 4) + (ccIndex * 4));
		goto l1;
	}
l1:	/* end fetchClassOf: */;
	/* begin success: */
	successFlag = (cl == (longAt((specialObjectsOop + 4) + (9 * 4)))) && successFlag;
	if (successFlag) {
		arg = floatAt(top + 4);
		goto l2;
	}
	arg = 0.0;
l2:	/* end floatValueOf: */;
	/* begin popFloat */
	/* begin popStack */
	top11 = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	top2 = top11;
	/* begin floatValueOf: */
	/* begin fetchClassOf: */
	if (((top2 & 1) == 1)) {
		cl1 = longAt((specialObjectsOop + 4) + (5 * 4));
		goto l3;
	}
	ccIndex1 = ((((unsigned) (longAt(top2))) >> 12) & 31) - 1;
	if (ccIndex1 < 0) {
		cl1 = (longAt(top2 - 4)) & 4294967292;
		goto l3;
	} else {
		cl1 = longAt(((longAt((specialObjectsOop + 4) + (28 * 4))) + 4) + (ccIndex1 * 4));
		goto l3;
	}
l3:	/* end fetchClassOf: */;
	/* begin success: */
	successFlag = (cl1 == (longAt((specialObjectsOop + 4) + (9 * 4)))) && successFlag;
	if (successFlag) {
		rcvr = floatAt(top2 + 4);
		goto l4;
	}
	rcvr = 0.0;
l4:	/* end floatValueOf: */;
	if (successFlag) {
		/* begin pushFloat: */
		/* begin push: */
		/* begin floatObjectOf: */
		newFloat = instantiateSmallClasssizeInBytesfill(longAt((specialObjectsOop + 4) + (9 * 4)), 12, 0);
		floatAtput(newFloat + 4, rcvr + arg);
		object = newFloat;
		longAtput(stackPointer = stackPointer + 4, object);
	} else {
		/* begin unPop: */
		stackPointer = stackPointer + (2 * 4);
	}
}

int primitiveFloatDivide(void) {
    double rcvr;
    double arg;
    int object;
    int top;
    int top1;
    int top2;
    int top11;
    int newFloat;
    int cl;
    int ccIndex;
    int cl1;
    int ccIndex1;

	/* begin popFloat */
	/* begin popStack */
	top1 = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	top = top1;
	/* begin floatValueOf: */
	/* begin fetchClassOf: */
	if (((top & 1) == 1)) {
		cl = longAt((specialObjectsOop + 4) + (5 * 4));
		goto l1;
	}
	ccIndex = ((((unsigned) (longAt(top))) >> 12) & 31) - 1;
	if (ccIndex < 0) {
		cl = (longAt(top - 4)) & 4294967292;
		goto l1;
	} else {
		cl = longAt(((longAt((specialObjectsOop + 4) + (28 * 4))) + 4) + (ccIndex * 4));
		goto l1;
	}
l1:	/* end fetchClassOf: */;
	/* begin success: */
	successFlag = (cl == (longAt((specialObjectsOop + 4) + (9 * 4)))) && successFlag;
	if (successFlag) {
		arg = floatAt(top + 4);
		goto l2;
	}
	arg = 0.0;
l2:	/* end floatValueOf: */;
	/* begin popFloat */
	/* begin popStack */
	top11 = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	top2 = top11;
	/* begin floatValueOf: */
	/* begin fetchClassOf: */
	if (((top2 & 1) == 1)) {
		cl1 = longAt((specialObjectsOop + 4) + (5 * 4));
		goto l3;
	}
	ccIndex1 = ((((unsigned) (longAt(top2))) >> 12) & 31) - 1;
	if (ccIndex1 < 0) {
		cl1 = (longAt(top2 - 4)) & 4294967292;
		goto l3;
	} else {
		cl1 = longAt(((longAt((specialObjectsOop + 4) + (28 * 4))) + 4) + (ccIndex1 * 4));
		goto l3;
	}
l3:	/* end fetchClassOf: */;
	/* begin success: */
	successFlag = (cl1 == (longAt((specialObjectsOop + 4) + (9 * 4)))) && successFlag;
	if (successFlag) {
		rcvr = floatAt(top2 + 4);
		goto l4;
	}
	rcvr = 0.0;
l4:	/* end floatValueOf: */;
	/* begin success: */
	successFlag = (arg != 0.0) && successFlag;
	if (successFlag) {
		/* begin pushFloat: */
		/* begin push: */
		/* begin floatObjectOf: */
		newFloat = instantiateSmallClasssizeInBytesfill(longAt((specialObjectsOop + 4) + (9 * 4)), 12, 0);
		floatAtput(newFloat + 4, rcvr / arg);
		object = newFloat;
		longAtput(stackPointer = stackPointer + 4, object);
	} else {
		/* begin unPop: */
		stackPointer = stackPointer + (2 * 4);
	}
}

int primitiveFloatEqual(void) {
    double rcvr;
    double arg;
    int top;
    int top1;
    int top2;
    int top11;
    int cl;
    int ccIndex;
    int cl1;
    int ccIndex1;

	/* begin popFloat */
	/* begin popStack */
	top1 = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	top = top1;
	/* begin floatValueOf: */
	/* begin fetchClassOf: */
	if (((top & 1) == 1)) {
		cl = longAt((specialObjectsOop + 4) + (5 * 4));
		goto l1;
	}
	ccIndex = ((((unsigned) (longAt(top))) >> 12) & 31) - 1;
	if (ccIndex < 0) {
		cl = (longAt(top - 4)) & 4294967292;
		goto l1;
	} else {
		cl = longAt(((longAt((specialObjectsOop + 4) + (28 * 4))) + 4) + (ccIndex * 4));
		goto l1;
	}
l1:	/* end fetchClassOf: */;
	/* begin success: */
	successFlag = (cl == (longAt((specialObjectsOop + 4) + (9 * 4)))) && successFlag;
	if (successFlag) {
		arg = floatAt(top + 4);
		goto l2;
	}
	arg = 0.0;
l2:	/* end floatValueOf: */;
	/* begin popFloat */
	/* begin popStack */
	top11 = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	top2 = top11;
	/* begin floatValueOf: */
	/* begin fetchClassOf: */
	if (((top2 & 1) == 1)) {
		cl1 = longAt((specialObjectsOop + 4) + (5 * 4));
		goto l3;
	}
	ccIndex1 = ((((unsigned) (longAt(top2))) >> 12) & 31) - 1;
	if (ccIndex1 < 0) {
		cl1 = (longAt(top2 - 4)) & 4294967292;
		goto l3;
	} else {
		cl1 = longAt(((longAt((specialObjectsOop + 4) + (28 * 4))) + 4) + (ccIndex1 * 4));
		goto l3;
	}
l3:	/* end fetchClassOf: */;
	/* begin success: */
	successFlag = (cl1 == (longAt((specialObjectsOop + 4) + (9 * 4)))) && successFlag;
	if (successFlag) {
		rcvr = floatAt(top2 + 4);
		goto l4;
	}
	rcvr = 0.0;
l4:	/* end floatValueOf: */;
	if (successFlag) {
		/* begin pushBool: */
		if (rcvr == arg) {
			/* begin push: */
			longAtput(stackPointer = stackPointer + 4, trueObj);
		} else {
			/* begin push: */
			longAtput(stackPointer = stackPointer + 4, falseObj);
		}
	} else {
		/* begin unPop: */
		stackPointer = stackPointer + (2 * 4);
	}
}

int primitiveFloatGreaterOrEqual(void) {
    double rcvr;
    double arg;
    int top;
    int top1;
    int top2;
    int top11;
    int cl;
    int ccIndex;
    int cl1;
    int ccIndex1;

	/* begin popFloat */
	/* begin popStack */
	top1 = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	top = top1;
	/* begin floatValueOf: */
	/* begin fetchClassOf: */
	if (((top & 1) == 1)) {
		cl = longAt((specialObjectsOop + 4) + (5 * 4));
		goto l1;
	}
	ccIndex = ((((unsigned) (longAt(top))) >> 12) & 31) - 1;
	if (ccIndex < 0) {
		cl = (longAt(top - 4)) & 4294967292;
		goto l1;
	} else {
		cl = longAt(((longAt((specialObjectsOop + 4) + (28 * 4))) + 4) + (ccIndex * 4));
		goto l1;
	}
l1:	/* end fetchClassOf: */;
	/* begin success: */
	successFlag = (cl == (longAt((specialObjectsOop + 4) + (9 * 4)))) && successFlag;
	if (successFlag) {
		arg = floatAt(top + 4);
		goto l2;
	}
	arg = 0.0;
l2:	/* end floatValueOf: */;
	/* begin popFloat */
	/* begin popStack */
	top11 = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	top2 = top11;
	/* begin floatValueOf: */
	/* begin fetchClassOf: */
	if (((top2 & 1) == 1)) {
		cl1 = longAt((specialObjectsOop + 4) + (5 * 4));
		goto l3;
	}
	ccIndex1 = ((((unsigned) (longAt(top2))) >> 12) & 31) - 1;
	if (ccIndex1 < 0) {
		cl1 = (longAt(top2 - 4)) & 4294967292;
		goto l3;
	} else {
		cl1 = longAt(((longAt((specialObjectsOop + 4) + (28 * 4))) + 4) + (ccIndex1 * 4));
		goto l3;
	}
l3:	/* end fetchClassOf: */;
	/* begin success: */
	successFlag = (cl1 == (longAt((specialObjectsOop + 4) + (9 * 4)))) && successFlag;
	if (successFlag) {
		rcvr = floatAt(top2 + 4);
		goto l4;
	}
	rcvr = 0.0;
l4:	/* end floatValueOf: */;
	if (successFlag) {
		/* begin pushBool: */
		if (rcvr >= arg) {
			/* begin push: */
			longAtput(stackPointer = stackPointer + 4, trueObj);
		} else {
			/* begin push: */
			longAtput(stackPointer = stackPointer + 4, falseObj);
		}
	} else {
		/* begin unPop: */
		stackPointer = stackPointer + (2 * 4);
	}
}

int primitiveFloatGreaterThan(void) {
    double rcvr;
    double arg;
    int top;
    int top1;
    int top2;
    int top11;
    int cl;
    int ccIndex;
    int cl1;
    int ccIndex1;

	/* begin popFloat */
	/* begin popStack */
	top1 = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	top = top1;
	/* begin floatValueOf: */
	/* begin fetchClassOf: */
	if (((top & 1) == 1)) {
		cl = longAt((specialObjectsOop + 4) + (5 * 4));
		goto l1;
	}
	ccIndex = ((((unsigned) (longAt(top))) >> 12) & 31) - 1;
	if (ccIndex < 0) {
		cl = (longAt(top - 4)) & 4294967292;
		goto l1;
	} else {
		cl = longAt(((longAt((specialObjectsOop + 4) + (28 * 4))) + 4) + (ccIndex * 4));
		goto l1;
	}
l1:	/* end fetchClassOf: */;
	/* begin success: */
	successFlag = (cl == (longAt((specialObjectsOop + 4) + (9 * 4)))) && successFlag;
	if (successFlag) {
		arg = floatAt(top + 4);
		goto l2;
	}
	arg = 0.0;
l2:	/* end floatValueOf: */;
	/* begin popFloat */
	/* begin popStack */
	top11 = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	top2 = top11;
	/* begin floatValueOf: */
	/* begin fetchClassOf: */
	if (((top2 & 1) == 1)) {
		cl1 = longAt((specialObjectsOop + 4) + (5 * 4));
		goto l3;
	}
	ccIndex1 = ((((unsigned) (longAt(top2))) >> 12) & 31) - 1;
	if (ccIndex1 < 0) {
		cl1 = (longAt(top2 - 4)) & 4294967292;
		goto l3;
	} else {
		cl1 = longAt(((longAt((specialObjectsOop + 4) + (28 * 4))) + 4) + (ccIndex1 * 4));
		goto l3;
	}
l3:	/* end fetchClassOf: */;
	/* begin success: */
	successFlag = (cl1 == (longAt((specialObjectsOop + 4) + (9 * 4)))) && successFlag;
	if (successFlag) {
		rcvr = floatAt(top2 + 4);
		goto l4;
	}
	rcvr = 0.0;
l4:	/* end floatValueOf: */;
	if (successFlag) {
		/* begin pushBool: */
		if (rcvr > arg) {
			/* begin push: */
			longAtput(stackPointer = stackPointer + 4, trueObj);
		} else {
			/* begin push: */
			longAtput(stackPointer = stackPointer + 4, falseObj);
		}
	} else {
		/* begin unPop: */
		stackPointer = stackPointer + (2 * 4);
	}
}

int primitiveFloatLessOrEqual(void) {
    double rcvr;
    double arg;
    int top;
    int top1;
    int top2;
    int top11;
    int cl;
    int ccIndex;
    int cl1;
    int ccIndex1;

	/* begin popFloat */
	/* begin popStack */
	top1 = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	top = top1;
	/* begin floatValueOf: */
	/* begin fetchClassOf: */
	if (((top & 1) == 1)) {
		cl = longAt((specialObjectsOop + 4) + (5 * 4));
		goto l1;
	}
	ccIndex = ((((unsigned) (longAt(top))) >> 12) & 31) - 1;
	if (ccIndex < 0) {
		cl = (longAt(top - 4)) & 4294967292;
		goto l1;
	} else {
		cl = longAt(((longAt((specialObjectsOop + 4) + (28 * 4))) + 4) + (ccIndex * 4));
		goto l1;
	}
l1:	/* end fetchClassOf: */;
	/* begin success: */
	successFlag = (cl == (longAt((specialObjectsOop + 4) + (9 * 4)))) && successFlag;
	if (successFlag) {
		arg = floatAt(top + 4);
		goto l2;
	}
	arg = 0.0;
l2:	/* end floatValueOf: */;
	/* begin popFloat */
	/* begin popStack */
	top11 = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	top2 = top11;
	/* begin floatValueOf: */
	/* begin fetchClassOf: */
	if (((top2 & 1) == 1)) {
		cl1 = longAt((specialObjectsOop + 4) + (5 * 4));
		goto l3;
	}
	ccIndex1 = ((((unsigned) (longAt(top2))) >> 12) & 31) - 1;
	if (ccIndex1 < 0) {
		cl1 = (longAt(top2 - 4)) & 4294967292;
		goto l3;
	} else {
		cl1 = longAt(((longAt((specialObjectsOop + 4) + (28 * 4))) + 4) + (ccIndex1 * 4));
		goto l3;
	}
l3:	/* end fetchClassOf: */;
	/* begin success: */
	successFlag = (cl1 == (longAt((specialObjectsOop + 4) + (9 * 4)))) && successFlag;
	if (successFlag) {
		rcvr = floatAt(top2 + 4);
		goto l4;
	}
	rcvr = 0.0;
l4:	/* end floatValueOf: */;
	if (successFlag) {
		/* begin pushBool: */
		if (rcvr <= arg) {
			/* begin push: */
			longAtput(stackPointer = stackPointer + 4, trueObj);
		} else {
			/* begin push: */
			longAtput(stackPointer = stackPointer + 4, falseObj);
		}
	} else {
		/* begin unPop: */
		stackPointer = stackPointer + (2 * 4);
	}
}

int primitiveFloatLessThan(void) {
    double rcvr;
    double arg;
    int top;
    int top1;
    int top2;
    int top11;
    int cl;
    int ccIndex;
    int cl1;
    int ccIndex1;

	/* begin popFloat */
	/* begin popStack */
	top1 = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	top = top1;
	/* begin floatValueOf: */
	/* begin fetchClassOf: */
	if (((top & 1) == 1)) {
		cl = longAt((specialObjectsOop + 4) + (5 * 4));
		goto l1;
	}
	ccIndex = ((((unsigned) (longAt(top))) >> 12) & 31) - 1;
	if (ccIndex < 0) {
		cl = (longAt(top - 4)) & 4294967292;
		goto l1;
	} else {
		cl = longAt(((longAt((specialObjectsOop + 4) + (28 * 4))) + 4) + (ccIndex * 4));
		goto l1;
	}
l1:	/* end fetchClassOf: */;
	/* begin success: */
	successFlag = (cl == (longAt((specialObjectsOop + 4) + (9 * 4)))) && successFlag;
	if (successFlag) {
		arg = floatAt(top + 4);
		goto l2;
	}
	arg = 0.0;
l2:	/* end floatValueOf: */;
	/* begin popFloat */
	/* begin popStack */
	top11 = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	top2 = top11;
	/* begin floatValueOf: */
	/* begin fetchClassOf: */
	if (((top2 & 1) == 1)) {
		cl1 = longAt((specialObjectsOop + 4) + (5 * 4));
		goto l3;
	}
	ccIndex1 = ((((unsigned) (longAt(top2))) >> 12) & 31) - 1;
	if (ccIndex1 < 0) {
		cl1 = (longAt(top2 - 4)) & 4294967292;
		goto l3;
	} else {
		cl1 = longAt(((longAt((specialObjectsOop + 4) + (28 * 4))) + 4) + (ccIndex1 * 4));
		goto l3;
	}
l3:	/* end fetchClassOf: */;
	/* begin success: */
	successFlag = (cl1 == (longAt((specialObjectsOop + 4) + (9 * 4)))) && successFlag;
	if (successFlag) {
		rcvr = floatAt(top2 + 4);
		goto l4;
	}
	rcvr = 0.0;
l4:	/* end floatValueOf: */;
	if (successFlag) {
		/* begin pushBool: */
		if (rcvr < arg) {
			/* begin push: */
			longAtput(stackPointer = stackPointer + 4, trueObj);
		} else {
			/* begin push: */
			longAtput(stackPointer = stackPointer + 4, falseObj);
		}
	} else {
		/* begin unPop: */
		stackPointer = stackPointer + (2 * 4);
	}
}

int primitiveFloatMultiply(void) {
    double rcvr;
    double arg;
    int object;
    int top;
    int top1;
    int top2;
    int top11;
    int newFloat;
    int cl;
    int ccIndex;
    int cl1;
    int ccIndex1;

	/* begin popFloat */
	/* begin popStack */
	top1 = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	top = top1;
	/* begin floatValueOf: */
	/* begin fetchClassOf: */
	if (((top & 1) == 1)) {
		cl = longAt((specialObjectsOop + 4) + (5 * 4));
		goto l1;
	}
	ccIndex = ((((unsigned) (longAt(top))) >> 12) & 31) - 1;
	if (ccIndex < 0) {
		cl = (longAt(top - 4)) & 4294967292;
		goto l1;
	} else {
		cl = longAt(((longAt((specialObjectsOop + 4) + (28 * 4))) + 4) + (ccIndex * 4));
		goto l1;
	}
l1:	/* end fetchClassOf: */;
	/* begin success: */
	successFlag = (cl == (longAt((specialObjectsOop + 4) + (9 * 4)))) && successFlag;
	if (successFlag) {
		arg = floatAt(top + 4);
		goto l2;
	}
	arg = 0.0;
l2:	/* end floatValueOf: */;
	/* begin popFloat */
	/* begin popStack */
	top11 = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	top2 = top11;
	/* begin floatValueOf: */
	/* begin fetchClassOf: */
	if (((top2 & 1) == 1)) {
		cl1 = longAt((specialObjectsOop + 4) + (5 * 4));
		goto l3;
	}
	ccIndex1 = ((((unsigned) (longAt(top2))) >> 12) & 31) - 1;
	if (ccIndex1 < 0) {
		cl1 = (longAt(top2 - 4)) & 4294967292;
		goto l3;
	} else {
		cl1 = longAt(((longAt((specialObjectsOop + 4) + (28 * 4))) + 4) + (ccIndex1 * 4));
		goto l3;
	}
l3:	/* end fetchClassOf: */;
	/* begin success: */
	successFlag = (cl1 == (longAt((specialObjectsOop + 4) + (9 * 4)))) && successFlag;
	if (successFlag) {
		rcvr = floatAt(top2 + 4);
		goto l4;
	}
	rcvr = 0.0;
l4:	/* end floatValueOf: */;
	if (successFlag) {
		/* begin pushFloat: */
		/* begin push: */
		/* begin floatObjectOf: */
		newFloat = instantiateSmallClasssizeInBytesfill(longAt((specialObjectsOop + 4) + (9 * 4)), 12, 0);
		floatAtput(newFloat + 4, rcvr * arg);
		object = newFloat;
		longAtput(stackPointer = stackPointer + 4, object);
	} else {
		/* begin unPop: */
		stackPointer = stackPointer + (2 * 4);
	}
}

int primitiveFloatNotEqual(void) {
    double rcvr;
    double arg;
    int top;
    int top1;
    int top2;
    int top11;
    int cl;
    int ccIndex;
    int cl1;
    int ccIndex1;

	/* begin popFloat */
	/* begin popStack */
	top1 = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	top = top1;
	/* begin floatValueOf: */
	/* begin fetchClassOf: */
	if (((top & 1) == 1)) {
		cl = longAt((specialObjectsOop + 4) + (5 * 4));
		goto l1;
	}
	ccIndex = ((((unsigned) (longAt(top))) >> 12) & 31) - 1;
	if (ccIndex < 0) {
		cl = (longAt(top - 4)) & 4294967292;
		goto l1;
	} else {
		cl = longAt(((longAt((specialObjectsOop + 4) + (28 * 4))) + 4) + (ccIndex * 4));
		goto l1;
	}
l1:	/* end fetchClassOf: */;
	/* begin success: */
	successFlag = (cl == (longAt((specialObjectsOop + 4) + (9 * 4)))) && successFlag;
	if (successFlag) {
		arg = floatAt(top + 4);
		goto l2;
	}
	arg = 0.0;
l2:	/* end floatValueOf: */;
	/* begin popFloat */
	/* begin popStack */
	top11 = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	top2 = top11;
	/* begin floatValueOf: */
	/* begin fetchClassOf: */
	if (((top2 & 1) == 1)) {
		cl1 = longAt((specialObjectsOop + 4) + (5 * 4));
		goto l3;
	}
	ccIndex1 = ((((unsigned) (longAt(top2))) >> 12) & 31) - 1;
	if (ccIndex1 < 0) {
		cl1 = (longAt(top2 - 4)) & 4294967292;
		goto l3;
	} else {
		cl1 = longAt(((longAt((specialObjectsOop + 4) + (28 * 4))) + 4) + (ccIndex1 * 4));
		goto l3;
	}
l3:	/* end fetchClassOf: */;
	/* begin success: */
	successFlag = (cl1 == (longAt((specialObjectsOop + 4) + (9 * 4)))) && successFlag;
	if (successFlag) {
		rcvr = floatAt(top2 + 4);
		goto l4;
	}
	rcvr = 0.0;
l4:	/* end floatValueOf: */;
	if (successFlag) {
		/* begin pushBool: */
		if (rcvr != arg) {
			/* begin push: */
			longAtput(stackPointer = stackPointer + 4, trueObj);
		} else {
			/* begin push: */
			longAtput(stackPointer = stackPointer + 4, falseObj);
		}
	} else {
		/* begin unPop: */
		stackPointer = stackPointer + (2 * 4);
	}
}

int primitiveFloatSubtract(void) {
    double rcvr;
    double arg;
    int object;
    int top;
    int top1;
    int top2;
    int top11;
    int newFloat;
    int cl;
    int ccIndex;
    int cl1;
    int ccIndex1;

	/* begin popFloat */
	/* begin popStack */
	top1 = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	top = top1;
	/* begin floatValueOf: */
	/* begin fetchClassOf: */
	if (((top & 1) == 1)) {
		cl = longAt((specialObjectsOop + 4) + (5 * 4));
		goto l1;
	}
	ccIndex = ((((unsigned) (longAt(top))) >> 12) & 31) - 1;
	if (ccIndex < 0) {
		cl = (longAt(top - 4)) & 4294967292;
		goto l1;
	} else {
		cl = longAt(((longAt((specialObjectsOop + 4) + (28 * 4))) + 4) + (ccIndex * 4));
		goto l1;
	}
l1:	/* end fetchClassOf: */;
	/* begin success: */
	successFlag = (cl == (longAt((specialObjectsOop + 4) + (9 * 4)))) && successFlag;
	if (successFlag) {
		arg = floatAt(top + 4);
		goto l2;
	}
	arg = 0.0;
l2:	/* end floatValueOf: */;
	/* begin popFloat */
	/* begin popStack */
	top11 = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	top2 = top11;
	/* begin floatValueOf: */
	/* begin fetchClassOf: */
	if (((top2 & 1) == 1)) {
		cl1 = longAt((specialObjectsOop + 4) + (5 * 4));
		goto l3;
	}
	ccIndex1 = ((((unsigned) (longAt(top2))) >> 12) & 31) - 1;
	if (ccIndex1 < 0) {
		cl1 = (longAt(top2 - 4)) & 4294967292;
		goto l3;
	} else {
		cl1 = longAt(((longAt((specialObjectsOop + 4) + (28 * 4))) + 4) + (ccIndex1 * 4));
		goto l3;
	}
l3:	/* end fetchClassOf: */;
	/* begin success: */
	successFlag = (cl1 == (longAt((specialObjectsOop + 4) + (9 * 4)))) && successFlag;
	if (successFlag) {
		rcvr = floatAt(top2 + 4);
		goto l4;
	}
	rcvr = 0.0;
l4:	/* end floatValueOf: */;
	if (successFlag) {
		/* begin pushFloat: */
		/* begin push: */
		/* begin floatObjectOf: */
		newFloat = instantiateSmallClasssizeInBytesfill(longAt((specialObjectsOop + 4) + (9 * 4)), 12, 0);
		floatAtput(newFloat + 4, rcvr - arg);
		object = newFloat;
		longAtput(stackPointer = stackPointer + 4, object);
	} else {
		/* begin unPop: */
		stackPointer = stackPointer + (2 * 4);
	}
}

int primitiveFlushCache(void) {
    int i;

	for (i = 1; i <= 1536; i += 1) {
		methodCache[i] = 0;
	}
	mcProbe = 0;
}

int primitiveFractionalPart(void) {
    double rcvr;
    double frac;
    double trunc;
    int object;
    int top;
    int top1;
    int newFloat;
    int cl;
    int ccIndex;

	/* begin popFloat */
	/* begin popStack */
	top1 = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	top = top1;
	/* begin floatValueOf: */
	/* begin fetchClassOf: */
	if (((top & 1) == 1)) {
		cl = longAt((specialObjectsOop + 4) + (5 * 4));
		goto l1;
	}
	ccIndex = ((((unsigned) (longAt(top))) >> 12) & 31) - 1;
	if (ccIndex < 0) {
		cl = (longAt(top - 4)) & 4294967292;
		goto l1;
	} else {
		cl = longAt(((longAt((specialObjectsOop + 4) + (28 * 4))) + 4) + (ccIndex * 4));
		goto l1;
	}
l1:	/* end fetchClassOf: */;
	/* begin success: */
	successFlag = (cl == (longAt((specialObjectsOop + 4) + (9 * 4)))) && successFlag;
	if (successFlag) {
		rcvr = floatAt(top + 4);
		goto l2;
	}
	rcvr = 0.0;
l2:	/* end floatValueOf: */;
	if (successFlag) {
		frac = modf(rcvr, &trunc);
		/* begin pushFloat: */
		/* begin push: */
		/* begin floatObjectOf: */
		newFloat = instantiateSmallClasssizeInBytesfill(longAt((specialObjectsOop + 4) + (9 * 4)), 12, 0);
		floatAtput(newFloat + 4, frac);
		object = newFloat;
		longAtput(stackPointer = stackPointer + 4, object);
	} else {
		/* begin unPop: */
		stackPointer = stackPointer + (1 * 4);
	}
}

int primitiveFullGC(void) {
	/* begin pop: */
	stackPointer = stackPointer - (1 * 4);
	incrementalGC();
	fullGC();
	/* begin pushInteger: */
	/* begin push: */
	longAtput(stackPointer = stackPointer + 4, ((((longAt(freeBlock)) & 536870908) << 1) | 1));
}

int primitiveGreaterOrEqual(void) {
    int integerReceiver;
    int integerArgument;
    int integerPointer;
    int top;
    int integerPointer1;
    int top1;

	successFlag = true;
	/* begin popInteger */
	/* begin popStack */
	top = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	integerPointer = top;
	if (((integerPointer & 1) == 1)) {
		integerArgument = (integerPointer >> 1);
		goto l1;
	} else {
		successFlag = false;
		integerArgument = 1;
		goto l1;
	}
l1:	/* end popInteger */;
	/* begin popInteger */
	/* begin popStack */
	top1 = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	integerPointer1 = top1;
	if (((integerPointer1 & 1) == 1)) {
		integerReceiver = (integerPointer1 >> 1);
		goto l2;
	} else {
		successFlag = false;
		integerReceiver = 1;
		goto l2;
	}
l2:	/* end popInteger */;
	/* begin checkBooleanResult:from: */
	if (successFlag) {
		/* begin pushBool: */
		if (integerReceiver >= integerArgument) {
			/* begin push: */
			longAtput(stackPointer = stackPointer + 4, trueObj);
		} else {
			/* begin push: */
			longAtput(stackPointer = stackPointer + 4, falseObj);
		}
	} else {
		/* begin unPop: */
		stackPointer = stackPointer + (2 * 4);
		failSpecialPrim(6);
	}
}

int primitiveGreaterThan(void) {
    int integerReceiver;
    int integerArgument;
    int integerPointer;
    int top;
    int integerPointer1;
    int top1;

	successFlag = true;
	/* begin popInteger */
	/* begin popStack */
	top = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	integerPointer = top;
	if (((integerPointer & 1) == 1)) {
		integerArgument = (integerPointer >> 1);
		goto l1;
	} else {
		successFlag = false;
		integerArgument = 1;
		goto l1;
	}
l1:	/* end popInteger */;
	/* begin popInteger */
	/* begin popStack */
	top1 = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	integerPointer1 = top1;
	if (((integerPointer1 & 1) == 1)) {
		integerReceiver = (integerPointer1 >> 1);
		goto l2;
	} else {
		successFlag = false;
		integerReceiver = 1;
		goto l2;
	}
l2:	/* end popInteger */;
	/* begin checkBooleanResult:from: */
	if (successFlag) {
		/* begin pushBool: */
		if (integerReceiver > integerArgument) {
			/* begin push: */
			longAtput(stackPointer = stackPointer + 4, trueObj);
		} else {
			/* begin push: */
			longAtput(stackPointer = stackPointer + 4, falseObj);
		}
	} else {
		/* begin unPop: */
		stackPointer = stackPointer + (2 * 4);
		failSpecialPrim(4);
	}
}

int primitiveImageName(void) {
    int s;
    int sz;
    int totalLength;
    int fixedFields;
    int header;
    int sz1;
    int fmt;
    int successValue;
    int classPointer;
    int fmt1;
    int ccIndex;

	if (argumentCount == 1) {
		s = longAt(stackPointer);
		/* begin success: */
		successValue = (fetchClassOf(s)) == (longAt((specialObjectsOop + 4) + (6 * 4)));
		successFlag = successValue && successFlag;
		if (successFlag) {
			/* begin stSizeOf: */
			if (((s & 1) == 1)) {
				sz = 0;
				goto l2;
			}
			/* begin lengthOf: */
			header = longAt(s);
			if ((header & 3) == 0) {
				sz1 = (longAt(s - 8)) & 4294967292;
			} else {
				sz1 = header & 252;
			}
			fmt = (((unsigned) header) >> 8) & 15;
			if (fmt < 8) {
				totalLength = (sz1 - 4) / 4;
				goto l1;
			} else {
				totalLength = (sz1 - 4) - (fmt & 3);
				goto l1;
			}
		l1:	/* end lengthOf: */;
			/* begin fixedFieldsOf: */
			/* begin fetchClassOf: */
			if (((s & 1) == 1)) {
				classPointer = longAt((specialObjectsOop + 4) + (5 * 4));
				goto l3;
			}
			ccIndex = ((((unsigned) (longAt(s))) >> 12) & 31) - 1;
			if (ccIndex < 0) {
				classPointer = (longAt(s - 4)) & 4294967292;
				goto l3;
			} else {
				classPointer = longAt(((longAt((specialObjectsOop + 4) + (28 * 4))) + 4) + (ccIndex * 4));
				goto l3;
			}
		l3:	/* end fetchClassOf: */;
			fmt1 = (longAt((classPointer + 4) + (2 * 4))) - 1;
			fixedFields = ((((unsigned) fmt1) >> 2) & 63) - 1;
			sz = totalLength - fixedFields;
		l2:	/* end stSizeOf: */;
			imageNamePutLength(s + 4, sz);
			/* begin pop: */
			stackPointer = stackPointer - (1 * 4);
		}
	} else {
		sz = imageNameSize();
		s = instantiateClassindexableSize(longAt((specialObjectsOop + 4) + (6 * 4)), sz);
		imageNameGetLength(s + 4, sz);
		/* begin pop: */
		stackPointer = stackPointer - (1 * 4);
		/* begin push: */
		longAtput(stackPointer = stackPointer + 4, s);
	}
}

int primitiveIncrementalGC(void) {
    int integerValue;

	/* begin pop: */
	stackPointer = stackPointer - (1 * 4);
	incrementalGC();
	/* begin pushInteger: */
	integerValue = (longAt(freeBlock)) & 536870908;
	/* begin push: */
	longAtput(stackPointer = stackPointer + 4, ((integerValue << 1) | 1));
}

int primitiveIndexOf(int methodPointer) {
	return (((unsigned) (longAt((methodPointer + 4) + (0 * 4)))) >> 1) & 511;
}

int primitiveInputSemaphore(void) {
    int arg;
    int objectPointer;
    int objectPointer1;
    int valuePointer;
    int top;

	/* begin popStack */
	top = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	arg = top;
	if ((fetchClassOf(arg)) == (longAt((specialObjectsOop + 4) + (18 * 4)))) {
		/* begin storePointer:ofObject:withValue: */
		objectPointer = specialObjectsOop;
		if (objectPointer < youngStart) {
			possibleRootStoreIntovalue(objectPointer, arg);
		}
		longAtput((objectPointer + 4) + (22 * 4), arg);
	} else {
		/* begin storePointer:ofObject:withValue: */
		objectPointer1 = specialObjectsOop;
		valuePointer = nilObj;
		if (objectPointer1 < youngStart) {
			possibleRootStoreIntovalue(objectPointer1, valuePointer);
		}
		longAtput((objectPointer1 + 4) + (22 * 4), valuePointer);
	}
}

int primitiveInputWord(void) {
	/* begin pop: */
	stackPointer = stackPointer - (1 * 4);
	/* begin pushInteger: */
	/* begin push: */
	longAtput(stackPointer = stackPointer + 4, ((0 << 1) | 1));
}

int primitiveInstVarAt(void) {
    int index;
    int thisReceiver;
    int value;
    int top;
    int integerPointer;
    int top1;
    int successValue;
    int fmt;
    int byteVal;

	/* begin popInteger */
	/* begin popStack */
	top1 = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	integerPointer = top1;
	if (((integerPointer & 1) == 1)) {
		index = (integerPointer >> 1);
		goto l1;
	} else {
		successFlag = false;
		index = 1;
		goto l1;
	}
l1:	/* end popInteger */;
	/* begin popStack */
	top = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	thisReceiver = top;
	/* begin checkInstanceVariableBoundsOf:in: */
	/* begin success: */
	successFlag = (index >= 1) && successFlag;
	/* begin success: */
	successValue = index <= (lengthOf(thisReceiver));
	successFlag = successValue && successFlag;
	if (successFlag) {
		/* begin subscript:with: */
		fmt = (((unsigned) (longAt(thisReceiver))) >> 8) & 15;
		if (fmt < 4) {
			value = longAt((thisReceiver + 4) + ((index - 1) * 4));
			goto l2;
		}
		if (fmt < 8) {
			value = positive32BitIntegerFor(longAt((thisReceiver + 4) + ((index - 1) * 4)));
			goto l2;
		}
		byteVal = byteAt((thisReceiver + 4) + (index - 1));
		value = ((byteVal << 1) | 1);
	l2:	/* end subscript:with: */;
	}
	if (successFlag) {
		/* begin push: */
		longAtput(stackPointer = stackPointer + 4, value);
	} else {
		/* begin unPop: */
		stackPointer = stackPointer + (2 * 4);
	}
}

int primitiveInstVarAtPut(void) {
    int newValue;
    int index;
    int thisReceiver;
    int top;
    int top1;
    int integerPointer;
    int top2;
    int successValue;
    int fmt;
    int byte;
    int bitValue;
    int successValue1;

	/* begin popStack */
	top = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	newValue = top;
	/* begin popInteger */
	/* begin popStack */
	top2 = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	integerPointer = top2;
	if (((integerPointer & 1) == 1)) {
		index = (integerPointer >> 1);
		goto l1;
	} else {
		successFlag = false;
		index = 1;
		goto l1;
	}
l1:	/* end popInteger */;
	/* begin popStack */
	top1 = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	thisReceiver = top1;
	/* begin checkInstanceVariableBoundsOf:in: */
	/* begin success: */
	successFlag = (index >= 1) && successFlag;
	/* begin success: */
	successValue = index <= (lengthOf(thisReceiver));
	successFlag = successValue && successFlag;
	if (successFlag) {
		/* begin subscript:with:storing: */
		fmt = (((unsigned) (longAt(thisReceiver))) >> 8) & 15;
		if (fmt < 4) {
			/* begin storePointer:ofObject:withValue: */
			if (thisReceiver < youngStart) {
				possibleRootStoreIntovalue(thisReceiver, newValue);
			}
			longAtput((thisReceiver + 4) + ((index - 1) * 4), newValue);
			goto l2;
		}
		if (fmt < 8) {
			bitValue = positive32BitValueOf(newValue);
			if (successFlag) {
				longAtput((thisReceiver + 4) + ((index - 1) * 4), bitValue);
			}
			goto l2;
		}
		/* begin success: */
		successFlag = (((newValue & 1) == 1)) && successFlag;
		byte = (newValue >> 1);
		/* begin success: */
		successValue1 = (byte >= 0) && (byte <= 255);
		successFlag = successValue1 && successFlag;
		if (successFlag) {
			byteAtput((thisReceiver + 4) + (index - 1), byte);
		}
	l2:	/* end subscript:with:storing: */;
	}
	if (successFlag) {
		/* begin push: */
		longAtput(stackPointer = stackPointer + 4, newValue);
	} else {
		/* begin unPop: */
		stackPointer = stackPointer + (3 * 4);
	}
}

int primitiveInterruptSemaphore(void) {
    int arg;
    int objectPointer;
    int objectPointer1;
    int valuePointer;
    int top;

	/* begin popStack */
	top = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	arg = top;
	if ((fetchClassOf(arg)) == (longAt((specialObjectsOop + 4) + (18 * 4)))) {
		/* begin storePointer:ofObject:withValue: */
		objectPointer = specialObjectsOop;
		if (objectPointer < youngStart) {
			possibleRootStoreIntovalue(objectPointer, arg);
		}
		longAtput((objectPointer + 4) + (30 * 4), arg);
	} else {
		/* begin storePointer:ofObject:withValue: */
		objectPointer1 = specialObjectsOop;
		valuePointer = nilObj;
		if (objectPointer1 < youngStart) {
			possibleRootStoreIntovalue(objectPointer1, valuePointer);
		}
		longAtput((objectPointer1 + 4) + (30 * 4), valuePointer);
	}
}

int primitiveKbdNext(void) {
    int keystrokeWord;

	/* begin pop: */
	stackPointer = stackPointer - (1 * 4);
	keystrokeWord = ioGetKeystroke();
	if (keystrokeWord >= 0) {
		/* begin pushInteger: */
		/* begin push: */
		longAtput(stackPointer = stackPointer + 4, ((keystrokeWord << 1) | 1));
	} else {
		/* begin push: */
		longAtput(stackPointer = stackPointer + 4, nilObj);
	}
}

int primitiveKbdPeek(void) {
    int keystrokeWord;

	/* begin pop: */
	stackPointer = stackPointer - (1 * 4);
	keystrokeWord = ioPeekKeystroke();
	if (keystrokeWord >= 0) {
		/* begin pushInteger: */
		/* begin push: */
		longAtput(stackPointer = stackPointer + 4, ((keystrokeWord << 1) | 1));
	} else {
		/* begin push: */
		longAtput(stackPointer = stackPointer + 4, nilObj);
	}
}

int primitiveLessOrEqual(void) {
    int integerReceiver;
    int integerArgument;
    int integerPointer;
    int top;
    int integerPointer1;
    int top1;

	successFlag = true;
	/* begin popInteger */
	/* begin popStack */
	top = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	integerPointer = top;
	if (((integerPointer & 1) == 1)) {
		integerArgument = (integerPointer >> 1);
		goto l1;
	} else {
		successFlag = false;
		integerArgument = 1;
		goto l1;
	}
l1:	/* end popInteger */;
	/* begin popInteger */
	/* begin popStack */
	top1 = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	integerPointer1 = top1;
	if (((integerPointer1 & 1) == 1)) {
		integerReceiver = (integerPointer1 >> 1);
		goto l2;
	} else {
		successFlag = false;
		integerReceiver = 1;
		goto l2;
	}
l2:	/* end popInteger */;
	/* begin checkBooleanResult:from: */
	if (successFlag) {
		/* begin pushBool: */
		if (integerReceiver <= integerArgument) {
			/* begin push: */
			longAtput(stackPointer = stackPointer + 4, trueObj);
		} else {
			/* begin push: */
			longAtput(stackPointer = stackPointer + 4, falseObj);
		}
	} else {
		/* begin unPop: */
		stackPointer = stackPointer + (2 * 4);
		failSpecialPrim(5);
	}
}

int primitiveLessThan(void) {
    int integerReceiver;
    int integerArgument;
    int integerPointer;
    int top;
    int integerPointer1;
    int top1;

	successFlag = true;
	/* begin popInteger */
	/* begin popStack */
	top = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	integerPointer = top;
	if (((integerPointer & 1) == 1)) {
		integerArgument = (integerPointer >> 1);
		goto l1;
	} else {
		successFlag = false;
		integerArgument = 1;
		goto l1;
	}
l1:	/* end popInteger */;
	/* begin popInteger */
	/* begin popStack */
	top1 = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	integerPointer1 = top1;
	if (((integerPointer1 & 1) == 1)) {
		integerReceiver = (integerPointer1 >> 1);
		goto l2;
	} else {
		successFlag = false;
		integerReceiver = 1;
		goto l2;
	}
l2:	/* end popInteger */;
	/* begin checkBooleanResult:from: */
	if (successFlag) {
		/* begin pushBool: */
		if (integerReceiver < integerArgument) {
			/* begin push: */
			longAtput(stackPointer = stackPointer + 4, trueObj);
		} else {
			/* begin push: */
			longAtput(stackPointer = stackPointer + 4, falseObj);
		}
	} else {
		/* begin unPop: */
		stackPointer = stackPointer + (2 * 4);
		failSpecialPrim(3);
	}
}

int primitiveLowSpaceSemaphore(void) {
    int arg;
    int objectPointer;
    int objectPointer1;
    int valuePointer;
    int top;

	/* begin popStack */
	top = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	arg = top;
	if ((fetchClassOf(arg)) == (longAt((specialObjectsOop + 4) + (18 * 4)))) {
		/* begin storePointer:ofObject:withValue: */
		objectPointer = specialObjectsOop;
		if (objectPointer < youngStart) {
			possibleRootStoreIntovalue(objectPointer, arg);
		}
		longAtput((objectPointer + 4) + (17 * 4), arg);
	} else {
		/* begin storePointer:ofObject:withValue: */
		objectPointer1 = specialObjectsOop;
		valuePointer = nilObj;
		if (objectPointer1 < youngStart) {
			possibleRootStoreIntovalue(objectPointer1, valuePointer);
		}
		longAtput((objectPointer1 + 4) + (17 * 4), valuePointer);
	}
}

int primitiveMakePoint(void) {
    int integerReceiver;
    int integerArgument;
    int object;
    int integerPointer;
    int top;
    int integerPointer1;
    int top1;
    int pointResult;

	successFlag = true;
	/* begin popInteger */
	/* begin popStack */
	top = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	integerPointer = top;
	if (((integerPointer & 1) == 1)) {
		integerArgument = (integerPointer >> 1);
		goto l1;
	} else {
		successFlag = false;
		integerArgument = 1;
		goto l1;
	}
l1:	/* end popInteger */;
	/* begin popInteger */
	/* begin popStack */
	top1 = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	integerPointer1 = top1;
	if (((integerPointer1 & 1) == 1)) {
		integerReceiver = (integerPointer1 >> 1);
		goto l2;
	} else {
		successFlag = false;
		integerReceiver = 1;
		goto l2;
	}
l2:	/* end popInteger */;
	if (successFlag) {
		/* begin push: */
		/* begin makePointwithxValue:yValue: */
		pointResult = instantiateSmallClasssizeInBytesfill(longAt((specialObjectsOop + 4) + (12 * 4)), 12, nilObj);
		/* begin storePointer:ofObject:withValue: */
		if (pointResult < youngStart) {
			possibleRootStoreIntovalue(pointResult, ((integerReceiver << 1) | 1));
		}
		longAtput((pointResult + 4) + (0 * 4), ((integerReceiver << 1) | 1));
		/* begin storePointer:ofObject:withValue: */
		if (pointResult < youngStart) {
			possibleRootStoreIntovalue(pointResult, ((integerArgument << 1) | 1));
		}
		longAtput((pointResult + 4) + (1 * 4), ((integerArgument << 1) | 1));
		object = pointResult;
		longAtput(stackPointer = stackPointer + 4, object);
	} else {
		/* begin checkIntegerResult:from: */
		if (successFlag && ((0 >= -1073741824) && (0 < 1073741824))) {
			/* begin pushInteger: */
			/* begin push: */
			longAtput(stackPointer = stackPointer + 4, ((0 << 1) | 1));
		} else {
			/* begin unPop: */
			stackPointer = stackPointer + (2 * 4);
			failSpecialPrim(18);
		}
	}
}

int primitiveMillisecondClock(void) {
    int object;

	/* begin pop: */
	stackPointer = stackPointer - (1 * 4);
	/* begin push: */
	object = positive32BitIntegerFor(ioMSecs());
	longAtput(stackPointer = stackPointer + 4, object);
}

int primitiveMod(void) {
    int integerReceiver;
    int integerArgument;
    int integerResult;
    int integerPointer;
    int top;
    int integerPointer1;
    int top1;

	successFlag = true;
	/* begin popInteger */
	/* begin popStack */
	top = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	integerPointer = top;
	if (((integerPointer & 1) == 1)) {
		integerArgument = (integerPointer >> 1);
		goto l1;
	} else {
		successFlag = false;
		integerArgument = 1;
		goto l1;
	}
l1:	/* end popInteger */;
	/* begin popInteger */
	/* begin popStack */
	top1 = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	integerPointer1 = top1;
	if (((integerPointer1 & 1) == 1)) {
		integerReceiver = (integerPointer1 >> 1);
		goto l2;
	} else {
		successFlag = false;
		integerReceiver = 1;
		goto l2;
	}
l2:	/* end popInteger */;
	/* begin success: */
	successFlag = (integerArgument != 0) && successFlag;
	if (!(successFlag)) {
		integerArgument = 1;
	}
	integerResult = integerReceiver % integerArgument;
	if (integerResult < 0) {
		integerResult = integerResult + integerArgument;
	}
	/* begin checkIntegerResult:from: */
	if (successFlag && ((integerResult >= -1073741824) && (integerResult < 1073741824))) {
		/* begin pushInteger: */
		/* begin push: */
		longAtput(stackPointer = stackPointer + 4, ((integerResult << 1) | 1));
	} else {
		/* begin unPop: */
		stackPointer = stackPointer + (2 * 4);
		failSpecialPrim(11);
	}
}

int primitiveMouseButtons(void) {
    int buttonWord;

	/* begin pop: */
	stackPointer = stackPointer - (1 * 4);
	buttonWord = ioGetButtonState();
	/* begin pushInteger: */
	/* begin push: */
	longAtput(stackPointer = stackPointer + 4, ((buttonWord << 1) | 1));
}

int primitiveMousePoint(void) {
    int pointWord;
    int x;
    int y;
    int object;
    int pointResult;

	/* begin pop: */
	stackPointer = stackPointer - (1 * 4);
	pointWord = ioMousePoint();
	/* begin signExtend16: */
	if ((((((unsigned) pointWord) >> 16) & 65535) & 32768) == 0) {
		x = (((unsigned) pointWord) >> 16) & 65535;
		goto l1;
	} else {
		x = ((((unsigned) pointWord) >> 16) & 65535) - 65536;
		goto l1;
	}
l1:	/* end signExtend16: */;
	/* begin signExtend16: */
	if (((pointWord & 65535) & 32768) == 0) {
		y = pointWord & 65535;
		goto l2;
	} else {
		y = (pointWord & 65535) - 65536;
		goto l2;
	}
l2:	/* end signExtend16: */;
	/* begin push: */
	/* begin makePointwithxValue:yValue: */
	pointResult = instantiateSmallClasssizeInBytesfill(longAt((specialObjectsOop + 4) + (12 * 4)), 12, nilObj);
	/* begin storePointer:ofObject:withValue: */
	if (pointResult < youngStart) {
		possibleRootStoreIntovalue(pointResult, ((x << 1) | 1));
	}
	longAtput((pointResult + 4) + (0 * 4), ((x << 1) | 1));
	/* begin storePointer:ofObject:withValue: */
	if (pointResult < youngStart) {
		possibleRootStoreIntovalue(pointResult, ((y << 1) | 1));
	}
	longAtput((pointResult + 4) + (1 * 4), ((y << 1) | 1));
	object = pointResult;
	longAtput(stackPointer = stackPointer + 4, object);
}

int primitiveMultiply(void) {
    int rcvr;
    int arg;
    int result;
    int successValue;

	successFlag = true;
	rcvr = longAt(stackPointer - (1 * 4));
	arg = longAt(stackPointer - (0 * 4));
	if (areFloatsand(rcvr, arg)) {
		primitiveFloatMultiply();
		if (successFlag) {
			return null;
		}
	}
	/* begin pop: */
	stackPointer = stackPointer - (2 * 4);
	/* begin success: */
	successFlag = (((rcvr & arg) & 1) != 0) && successFlag;
	if (successFlag) {
		rcvr = (rcvr >> 1);
		arg = (arg >> 1);
		result = rcvr * arg;
		/* begin success: */
		successValue = (arg == 0) || ((result / arg) == rcvr);
		successFlag = successValue && successFlag;
	}
	/* begin checkIntegerResult:from: */
	if (successFlag && ((result >= -1073741824) && (result < 1073741824))) {
		/* begin pushInteger: */
		/* begin push: */
		longAtput(stackPointer = stackPointer + 4, ((result << 1) | 1));
	} else {
		/* begin unPop: */
		stackPointer = stackPointer + (2 * 4);
		failSpecialPrim(9);
	}
}

int primitiveNew(void) {
    int class;
    int spaceOkay;
    int top;
    int object;
    int format;
    int okay;
    int minFree;
    int minFree1;

	/* begin popStack */
	top = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	class = top;
	/* begin sufficientSpaceToInstantiate:indexableSize: */
	format = (((unsigned) ((longAt((class + 4) + (2 * 4))) - 1)) >> 8) & 15;
	if ((0 > 0) && (format < 2)) {
		spaceOkay = false;
		goto l3;
	}
	if (format < 8) {
		/* begin sufficientSpaceToAllocate: */
		minFree = (lowSpaceThreshold + (2500 + (0 * 4))) + 4;
		if (((longAt(freeBlock)) & 536870908) >= minFree) {
			okay = true;
			goto l1;
		} else {
			okay = sufficientSpaceAfterGC(minFree);
			goto l1;
		}
	l1:	/* end sufficientSpaceToAllocate: */;
	} else {
		/* begin sufficientSpaceToAllocate: */
		minFree1 = (lowSpaceThreshold + (2500 + 0)) + 4;
		if (((longAt(freeBlock)) & 536870908) >= minFree1) {
			okay = true;
			goto l2;
		} else {
			okay = sufficientSpaceAfterGC(minFree1);
			goto l2;
		}
	l2:	/* end sufficientSpaceToAllocate: */;
	}
	spaceOkay = okay;
l3:	/* end sufficientSpaceToInstantiate:indexableSize: */;
	/* begin success: */
	successFlag = spaceOkay && successFlag;
	if (successFlag) {
		/* begin push: */
		object = instantiateClassindexableSize(class, 0);
		longAtput(stackPointer = stackPointer + 4, object);
	} else {
		/* begin unPop: */
		stackPointer = stackPointer + (1 * 4);
	}
}

int primitiveNewMethod(void) {
    int header;
    int bytecodeCount;
    int class;
    int size;
    int theMethod;
    int literalCount;
    int i;
    int valuePointer;
    int top;
    int top1;
    int integerPointer;
    int top2;

	/* begin popStack */
	top = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	header = top;
	/* begin popInteger */
	/* begin popStack */
	top2 = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	integerPointer = top2;
	if (((integerPointer & 1) == 1)) {
		bytecodeCount = (integerPointer >> 1);
		goto l1;
	} else {
		successFlag = false;
		bytecodeCount = 1;
		goto l1;
	}
l1:	/* end popInteger */;
	/* begin success: */
	successFlag = (((header & 1) == 1)) && successFlag;
	if (!(successFlag)) {
		/* begin unPop: */
		stackPointer = stackPointer + (2 * 4);
	}
	/* begin popStack */
	top1 = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	class = top1;
	size = ((((((unsigned) header) >> 10) & 255) + 1) * 4) + bytecodeCount;
	theMethod = instantiateClassindexableSize(class, size);
	/* begin storePointer:ofObject:withValue: */
	if (theMethod < youngStart) {
		possibleRootStoreIntovalue(theMethod, header);
	}
	longAtput((theMethod + 4) + (0 * 4), header);
	literalCount = (((unsigned) header) >> 10) & 255;
	for (i = 1; i <= literalCount; i += 1) {
		/* begin storePointer:ofObject:withValue: */
		valuePointer = nilObj;
		if (theMethod < youngStart) {
			possibleRootStoreIntovalue(theMethod, valuePointer);
		}
		longAtput((theMethod + 4) + (i * 4), valuePointer);
	}
	/* begin push: */
	longAtput(stackPointer = stackPointer + 4, theMethod);
}

int primitiveNewWithArg(void) {
    int size;
    int class;
    int spaceOkay;
    int top;
    int object;
    int integerPointer;
    int top1;
    int format;
    int okay;
    int minFree;
    int minFree1;

	/* begin popInteger */
	/* begin popStack */
	top1 = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	integerPointer = top1;
	if (((integerPointer & 1) == 1)) {
		size = (integerPointer >> 1);
		goto l1;
	} else {
		successFlag = false;
		size = 1;
		goto l1;
	}
l1:	/* end popInteger */;
	/* begin popStack */
	top = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	class = top;
	/* begin success: */
	successFlag = (size >= 0) && successFlag;
	if (successFlag) {
		/* begin sufficientSpaceToInstantiate:indexableSize: */
		format = (((unsigned) ((longAt((class + 4) + (2 * 4))) - 1)) >> 8) & 15;
		if ((size > 0) && (format < 2)) {
			spaceOkay = false;
			goto l4;
		}
		if (format < 8) {
			/* begin sufficientSpaceToAllocate: */
			minFree = (lowSpaceThreshold + (2500 + (size * 4))) + 4;
			if (((longAt(freeBlock)) & 536870908) >= minFree) {
				okay = true;
				goto l3;
			} else {
				okay = sufficientSpaceAfterGC(minFree);
				goto l3;
			}
		l3:	/* end sufficientSpaceToAllocate: */;
		} else {
			/* begin sufficientSpaceToAllocate: */
			minFree1 = (lowSpaceThreshold + (2500 + size)) + 4;
			if (((longAt(freeBlock)) & 536870908) >= minFree1) {
				okay = true;
				goto l2;
			} else {
				okay = sufficientSpaceAfterGC(minFree1);
				goto l2;
			}
		l2:	/* end sufficientSpaceToAllocate: */;
		}
		spaceOkay = okay;
	l4:	/* end sufficientSpaceToInstantiate:indexableSize: */;
		/* begin success: */
		successFlag = spaceOkay && successFlag;
	}
	if (successFlag) {
		/* begin push: */
		object = instantiateClassindexableSize(class, size);
		longAtput(stackPointer = stackPointer + 4, object);
	} else {
		/* begin unPop: */
		stackPointer = stackPointer + (2 * 4);
	}
}

int primitiveNext(void) {
    int stream;
    int array;
    int index;
    int limit;
    int arrayClass;
    int result;
    int top;
    int ccIndex;
    int successValue;
    int fixedFields;
    int totalLength;
    int i;
    int successValue1;
    int header;
    int sz;
    int fmt;
    int fmt1;
    int byteVal;
    int classPointer;
    int fmt2;
    int ccIndex1;

	successFlag = true;
	/* begin popStack */
	top = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	stream = top;
	array = longAt((stream + 4) + (0 * 4));
	index = fetchIntegerofObject(1, stream);
	limit = fetchIntegerofObject(2, stream);
	/* begin fetchClassOf: */
	if (((array & 1) == 1)) {
		arrayClass = longAt((specialObjectsOop + 4) + (5 * 4));
		goto l1;
	}
	ccIndex = ((((unsigned) (longAt(array))) >> 12) & 31) - 1;
	if (ccIndex < 0) {
		arrayClass = (longAt(array - 4)) & 4294967292;
		goto l1;
	} else {
		arrayClass = longAt(((longAt((specialObjectsOop + 4) + (28 * 4))) + 4) + (ccIndex * 4));
		goto l1;
	}
l1:	/* end fetchClassOf: */;
	/* begin success: */
	successValue = (arrayClass == (longAt((specialObjectsOop + 4) + (6 * 4)))) || ((arrayClass == (longAt((specialObjectsOop + 4) + (7 * 4)))) || ((arrayClass == (longAt((specialObjectsOop + 4) + (26 * 4)))) || (arrayClass == (longAt((specialObjectsOop + 4) + (4 * 4))))));
	successFlag = successValue && successFlag;
	/* begin success: */
	successFlag = (index < limit) && successFlag;
	if (successFlag) {
		index = index + 1;
		/* begin stObject:at: */
		/* begin fixedFieldsOf: */
		/* begin fetchClassOf: */
		if (((array & 1) == 1)) {
			classPointer = longAt((specialObjectsOop + 4) + (5 * 4));
			goto l2;
		}
		ccIndex1 = ((((unsigned) (longAt(array))) >> 12) & 31) - 1;
		if (ccIndex1 < 0) {
			classPointer = (longAt(array - 4)) & 4294967292;
			goto l2;
		} else {
			classPointer = longAt(((longAt((specialObjectsOop + 4) + (28 * 4))) + 4) + (ccIndex1 * 4));
			goto l2;
		}
	l2:	/* end fetchClassOf: */;
		fmt2 = (longAt((classPointer + 4) + (2 * 4))) - 1;
		fixedFields = ((((unsigned) fmt2) >> 2) & 63) - 1;
		/* begin lengthOf: */
		header = longAt(array);
		if ((header & 3) == 0) {
			sz = (longAt(array - 8)) & 4294967292;
		} else {
			sz = header & 252;
		}
		fmt = (((unsigned) header) >> 8) & 15;
		if (fmt < 8) {
			totalLength = (sz - 4) / 4;
			goto l3;
		} else {
			totalLength = (sz - 4) - (fmt & 3);
			goto l3;
		}
	l3:	/* end lengthOf: */;
		i = index + fixedFields;
		/* begin success: */
		successValue1 = (index >= 1) && (i <= totalLength);
		successFlag = successValue1 && successFlag;
		if (successFlag) {
			/* begin subscript:with: */
			fmt1 = (((unsigned) (longAt(array))) >> 8) & 15;
			if (fmt1 < 4) {
				result = longAt((array + 4) + ((i - 1) * 4));
				goto l4;
			}
			if (fmt1 < 8) {
				result = positive32BitIntegerFor(longAt((array + 4) + ((i - 1) * 4)));
				goto l4;
			}
			byteVal = byteAt((array + 4) + (i - 1));
			result = ((byteVal << 1) | 1);
			goto l4;
		} else {
			result = nilObj;
			goto l4;
		}
	l4:	/* end stObject:at: */;
	}
	if (successFlag) {
		/* begin storeInteger:ofObject:withValue: */
		if ((index >= -1073741824) && (index < 1073741824)) {
			longAtput((stream + 4) + (1 * 4), ((index << 1) | 1));
		} else {
			primitiveFail();
		}
	}
	if (successFlag) {
		if (arrayClass == (longAt((specialObjectsOop + 4) + (6 * 4)))) {
			/* begin push: */
			longAtput(stackPointer = stackPointer + 4, longAt(((longAt((specialObjectsOop + 4) + (24 * 4))) + 4) + (((result >> 1)) * 4)));
		} else {
			/* begin push: */
			longAtput(stackPointer = stackPointer + 4, result);
		}
	} else {
		/* begin unPop: */
		stackPointer = stackPointer + (1 * 4);
	}
}

int primitiveNextInstance(void) {
    int object;
    int instance;
    int top;
    int classPointer;
    int thisObj;
    int thisClass;
    int ccIndex;
    int ccIndex1;

	/* begin popStack */
	top = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	object = top;
	/* begin instanceAfter: */
	/* begin fetchClassOf: */
	if (((object & 1) == 1)) {
		classPointer = longAt((specialObjectsOop + 4) + (5 * 4));
		goto l3;
	}
	ccIndex1 = ((((unsigned) (longAt(object))) >> 12) & 31) - 1;
	if (ccIndex1 < 0) {
		classPointer = (longAt(object - 4)) & 4294967292;
		goto l3;
	} else {
		classPointer = longAt(((longAt((specialObjectsOop + 4) + (28 * 4))) + 4) + (ccIndex1 * 4));
		goto l3;
	}
l3:	/* end fetchClassOf: */;
	thisObj = accessibleObjectAfter(object);
	while (!(thisObj == null)) {
		/* begin fetchClassOf: */
		if (((thisObj & 1) == 1)) {
			thisClass = longAt((specialObjectsOop + 4) + (5 * 4));
			goto l2;
		}
		ccIndex = ((((unsigned) (longAt(thisObj))) >> 12) & 31) - 1;
		if (ccIndex < 0) {
			thisClass = (longAt(thisObj - 4)) & 4294967292;
			goto l2;
		} else {
			thisClass = longAt(((longAt((specialObjectsOop + 4) + (28 * 4))) + 4) + (ccIndex * 4));
			goto l2;
		}
	l2:	/* end fetchClassOf: */;
		if (thisClass == classPointer) {
			instance = thisObj;
			goto l1;
		}
		thisObj = accessibleObjectAfter(thisObj);
	}
	instance = nilObj;
l1:	/* end instanceAfter: */;
	if (instance == nilObj) {
		primitiveFail();
	} else {
		/* begin push: */
		longAtput(stackPointer = stackPointer + 4, instance);
	}
}

int primitiveNextObject(void) {
    int object;
    int instance;
    int top;

	/* begin popStack */
	top = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	object = top;
	instance = accessibleObjectAfter(object);
	if (instance == null) {
		/* begin pushInteger: */
		/* begin push: */
		longAtput(stackPointer = stackPointer + 4, ((0 << 1) | 1));
	} else {
		/* begin push: */
		longAtput(stackPointer = stackPointer + 4, instance);
	}
}

int primitiveNextPut(void) {
    int value;
    int stream;
    int index;
    int limit;
    int array;
    int arrayClass;
    int storeVal;
    int top;
    int top1;
    int successValue;
    int ccIndex;
    int successValue1;
    int fixedFields;
    int totalLength;
    int i;
    int successValue2;
    int header;
    int sz;
    int fmt;
    int classPointer;
    int fmt1;
    int fmt2;
    int byte;
    int bitValue;
    int successValue11;
    int ccIndex1;

	successFlag = true;
	/* begin popStack */
	top = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	value = top;
	/* begin popStack */
	top1 = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	stream = top1;
	array = longAt((stream + 4) + (0 * 4));
	index = fetchIntegerofObject(1, stream);
	limit = fetchIntegerofObject(3, stream);
	/* begin fetchClassOf: */
	if (((array & 1) == 1)) {
		arrayClass = longAt((specialObjectsOop + 4) + (5 * 4));
		goto l1;
	}
	ccIndex = ((((unsigned) (longAt(array))) >> 12) & 31) - 1;
	if (ccIndex < 0) {
		arrayClass = (longAt(array - 4)) & 4294967292;
		goto l1;
	} else {
		arrayClass = longAt(((longAt((specialObjectsOop + 4) + (28 * 4))) + 4) + (ccIndex * 4));
		goto l1;
	}
l1:	/* end fetchClassOf: */;
	/* begin success: */
	successValue = (arrayClass == (longAt((specialObjectsOop + 4) + (6 * 4)))) || ((arrayClass == (longAt((specialObjectsOop + 4) + (7 * 4)))) || ((arrayClass == (longAt((specialObjectsOop + 4) + (26 * 4)))) || (arrayClass == (longAt((specialObjectsOop + 4) + (4 * 4))))));
	successFlag = successValue && successFlag;
	/* begin success: */
	successFlag = (index < limit) && successFlag;
	if (successFlag) {
		index = index + 1;
		if (arrayClass == (longAt((specialObjectsOop + 4) + (6 * 4)))) {
			/* begin asciiOfCharacter: */
			/* begin success: */
			successValue1 = (fetchClassOf(value)) == (longAt((specialObjectsOop + 4) + (19 * 4)));
			successFlag = successValue1 && successFlag;
			if (successFlag) {
				storeVal = longAt((value + 4) + (0 * 4));
				goto l2;
			} else {
				storeVal = 1;
				goto l2;
			}
		l2:	/* end asciiOfCharacter: */;
		} else {
			storeVal = value;
		}
		/* begin stObject:at:put: */
		/* begin fixedFieldsOf: */
		/* begin fetchClassOf: */
		if (((array & 1) == 1)) {
			classPointer = longAt((specialObjectsOop + 4) + (5 * 4));
			goto l3;
		}
		ccIndex1 = ((((unsigned) (longAt(array))) >> 12) & 31) - 1;
		if (ccIndex1 < 0) {
			classPointer = (longAt(array - 4)) & 4294967292;
			goto l3;
		} else {
			classPointer = longAt(((longAt((specialObjectsOop + 4) + (28 * 4))) + 4) + (ccIndex1 * 4));
			goto l3;
		}
	l3:	/* end fetchClassOf: */;
		fmt1 = (longAt((classPointer + 4) + (2 * 4))) - 1;
		fixedFields = ((((unsigned) fmt1) >> 2) & 63) - 1;
		/* begin lengthOf: */
		header = longAt(array);
		if ((header & 3) == 0) {
			sz = (longAt(array - 8)) & 4294967292;
		} else {
			sz = header & 252;
		}
		fmt = (((unsigned) header) >> 8) & 15;
		if (fmt < 8) {
			totalLength = (sz - 4) / 4;
			goto l4;
		} else {
			totalLength = (sz - 4) - (fmt & 3);
			goto l4;
		}
	l4:	/* end lengthOf: */;
		i = index + fixedFields;
		/* begin success: */
		successValue2 = (index >= 1) && (i <= totalLength);
		successFlag = successValue2 && successFlag;
		if (successFlag) {
			/* begin subscript:with:storing: */
			fmt2 = (((unsigned) (longAt(array))) >> 8) & 15;
			if (fmt2 < 4) {
				/* begin storePointer:ofObject:withValue: */
				if (array < youngStart) {
					possibleRootStoreIntovalue(array, storeVal);
				}
				longAtput((array + 4) + ((i - 1) * 4), storeVal);
				goto l5;
			}
			if (fmt2 < 8) {
				bitValue = positive32BitValueOf(storeVal);
				if (successFlag) {
					longAtput((array + 4) + ((i - 1) * 4), bitValue);
				}
				goto l5;
			}
			/* begin success: */
			successFlag = (((storeVal & 1) == 1)) && successFlag;
			byte = (storeVal >> 1);
			/* begin success: */
			successValue11 = (byte >= 0) && (byte <= 255);
			successFlag = successValue11 && successFlag;
			if (successFlag) {
				byteAtput((array + 4) + (i - 1), byte);
			}
		l5:	/* end subscript:with:storing: */;
		}
	}
	if (successFlag) {
		/* begin storeInteger:ofObject:withValue: */
		if ((index >= -1073741824) && (index < 1073741824)) {
			longAtput((stream + 4) + (1 * 4), ((index << 1) | 1));
		} else {
			primitiveFail();
		}
	}
	if (successFlag) {
		/* begin push: */
		longAtput(stackPointer = stackPointer + 4, value);
	} else {
		/* begin unPop: */
		stackPointer = stackPointer + (2 * 4);
		failSpecialPrim(66);
	}
}

int primitiveNoop(void) {
	/* begin pop: */
	stackPointer = stackPointer - (argumentCount * 4);
}

int primitiveNotEqual(void) {
    int integerReceiver;
    int integerArgument;
    int result;
    int top;
    int top1;

	successFlag = true;
	/* begin popStack */
	top = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	integerArgument = top;
	/* begin popStack */
	top1 = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	integerReceiver = top1;
	result = !(compare31or32Bitsequal(integerReceiver, integerArgument));
	/* begin checkBooleanResult:from: */
	if (successFlag) {
		/* begin pushBool: */
		if (result) {
			/* begin push: */
			longAtput(stackPointer = stackPointer + 4, trueObj);
		} else {
			/* begin push: */
			longAtput(stackPointer = stackPointer + 4, falseObj);
		}
	} else {
		/* begin unPop: */
		stackPointer = stackPointer + (2 * 4);
		failSpecialPrim(8);
	}
}

int primitiveObjectAt(void) {
    int thisReceiver;
    int index;
    int integerPointer;
    int top;
    int top1;

	/* begin popInteger */
	/* begin popStack */
	top = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	integerPointer = top;
	if (((integerPointer & 1) == 1)) {
		index = (integerPointer >> 1);
		goto l1;
	} else {
		successFlag = false;
		index = 1;
		goto l1;
	}
l1:	/* end popInteger */;
	/* begin popStack */
	top1 = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	thisReceiver = top1;
	/* begin success: */
	successFlag = (index > 0) && successFlag;
	/* begin success: */
	successFlag = (index <= (((((unsigned) (longAt((thisReceiver + 4) + (0 * 4)))) >> 10) & 255) + 1)) && successFlag;
	if (successFlag) {
		/* begin push: */
		longAtput(stackPointer = stackPointer + 4, longAt((thisReceiver + 4) + ((index - 1) * 4)));
	} else {
		/* begin unPop: */
		stackPointer = stackPointer + (2 * 4);
	}
}

int primitiveObjectAtPut(void) {
    int thisReceiver;
    int index;
    int newValue;
    int top;
    int integerPointer;
    int top1;
    int top2;

	/* begin popStack */
	top = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	newValue = top;
	/* begin popInteger */
	/* begin popStack */
	top1 = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	integerPointer = top1;
	if (((integerPointer & 1) == 1)) {
		index = (integerPointer >> 1);
		goto l1;
	} else {
		successFlag = false;
		index = 1;
		goto l1;
	}
l1:	/* end popInteger */;
	/* begin popStack */
	top2 = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	thisReceiver = top2;
	/* begin success: */
	successFlag = (index > 0) && successFlag;
	/* begin success: */
	successFlag = (index <= (((((unsigned) (longAt((thisReceiver + 4) + (0 * 4)))) >> 10) & 255) + 1)) && successFlag;
	if (successFlag) {
		/* begin storePointer:ofObject:withValue: */
		if (thisReceiver < youngStart) {
			possibleRootStoreIntovalue(thisReceiver, newValue);
		}
		longAtput((thisReceiver + 4) + ((index - 1) * 4), newValue);
		/* begin push: */
		longAtput(stackPointer = stackPointer + 4, newValue);
	} else {
		/* begin unPop: */
		stackPointer = stackPointer + (3 * 4);
	}
}

int primitiveObjectPointsTo(void) {
    int rcvr;
    int thang;
    int lastField;
    int i;
    int top;
    int top1;
    int fmt;
    int sz;
    int methodHeader;
    int header;
    int type;

	/* begin popStack */
	top = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	thang = top;
	/* begin popStack */
	top1 = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	rcvr = top1;
	if (((rcvr & 1) == 1)) {
		/* begin pushBool: */
		if (false) {
			/* begin push: */
			longAtput(stackPointer = stackPointer + 4, trueObj);
		} else {
			/* begin push: */
			longAtput(stackPointer = stackPointer + 4, falseObj);
		}
		return null;
	}
	/* begin lastPointerOf: */
	fmt = (((unsigned) (longAt(rcvr))) >> 8) & 15;
	if (fmt < 4) {
		/* begin sizeBitsOfSafe: */
		header = longAt(rcvr);
		/* begin rightType: */
		if ((header & 252) == 0) {
			type = 0;
			goto l2;
		} else {
			if ((header & 126976) == 0) {
				type = 1;
				goto l2;
			} else {
				type = 3;
				goto l2;
			}
		}
	l2:	/* end rightType: */;
		if (type == 0) {
			sz = (longAt(rcvr - 8)) & 4294967292;
			goto l3;
		} else {
			sz = header & 252;
			goto l3;
		}
	l3:	/* end sizeBitsOfSafe: */;
		lastField = sz - 4;
		goto l1;
	}
	if (fmt < 12) {
		lastField = 0;
		goto l1;
	}
	methodHeader = longAt(rcvr + 4);
	lastField = (((((unsigned) methodHeader) >> 10) & 255) * 4) + 4;
l1:	/* end lastPointerOf: */;
	for (i = 4; i <= lastField; i += 4) {
		if ((longAt(rcvr + i)) == thang) {
			/* begin pushBool: */
			if (true) {
				/* begin push: */
				longAtput(stackPointer = stackPointer + 4, trueObj);
			} else {
				/* begin push: */
				longAtput(stackPointer = stackPointer + 4, falseObj);
			}
			return null;
		}
	}
	/* begin pushBool: */
	if (false) {
		/* begin push: */
		longAtput(stackPointer = stackPointer + 4, trueObj);
	} else {
		/* begin push: */
		longAtput(stackPointer = stackPointer + 4, falseObj);
	}
}

int primitivePerform(void) {
    int performSelector;
    int newReceiver;
    int selectorIndex;
    int fromIndex;
    int toIndex;
    int lastFrom;

	performSelector = messageSelector;
	messageSelector = longAt(stackPointer - ((argumentCount - 1) * 4));
	newReceiver = longAt(stackPointer - (argumentCount * 4));
	lookupMethodInClass(fetchClassOf(newReceiver));
	/* begin success: */
	successFlag = (((((unsigned) (longAt((newMethod + 4) + (0 * 4)))) >> 25) & 31) == (argumentCount - 1)) && successFlag;
	if (successFlag) {
		selectorIndex = ((((stackPointer - activeContext) - 4) / 4) - argumentCount) + 1;
		/* begin transfer:fromIndex:ofObject:toIndex:ofObject: */
		fromIndex = (activeContext + 4) + ((selectorIndex + 1) * 4);
		toIndex = (activeContext + 4) + (selectorIndex * 4);
		lastFrom = fromIndex + ((argumentCount - 1) * 4);
		while (fromIndex < lastFrom) {
			longAtput(toIndex, longAt(fromIndex));
			fromIndex = fromIndex + 4;
			toIndex = toIndex + 4;
		}
		/* begin pop: */
		stackPointer = stackPointer - (1 * 4);
		argumentCount = argumentCount - 1;
		/* begin executeNewMethod */
		if ((primitiveIndex == 0) || (!(primitiveResponse()))) {
			activateNewMethod();
			/* begin quickCheckForInterrupts */
			if ((interruptCheckCounter = interruptCheckCounter - 1) <= 0) {
				interruptCheckCounter = 1000;
				checkForInterrupts();
			}
		}
		successFlag = true;
	} else {
		messageSelector = performSelector;
	}
}

int primitivePerformWithArgs(void) {
    int thisReceiver;
    int performSelector;
    int argumentArray;
    int arrayClass;
    int arraySize;
    int index;
    int cntxSize;
    int top;
    int top1;
    int ccIndex;

	/* begin popStack */
	top1 = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	argumentArray = top1;
	arraySize = fetchWordLengthOf(argumentArray);
	/* begin fetchClassOf: */
	if (((argumentArray & 1) == 1)) {
		arrayClass = longAt((specialObjectsOop + 4) + (5 * 4));
		goto l1;
	}
	ccIndex = ((((unsigned) (longAt(argumentArray))) >> 12) & 31) - 1;
	if (ccIndex < 0) {
		arrayClass = (longAt(argumentArray - 4)) & 4294967292;
		goto l1;
	} else {
		arrayClass = longAt(((longAt((specialObjectsOop + 4) + (28 * 4))) + 4) + (ccIndex * 4));
		goto l1;
	}
l1:	/* end fetchClassOf: */;
	cntxSize = fetchWordLengthOf(activeContext);
	/* begin success: */
	successFlag = (((((stackPointer - activeContext) - 4) / 4) + arraySize) < cntxSize) && successFlag;
	/* begin success: */
	successFlag = (arrayClass == (longAt((specialObjectsOop + 4) + (7 * 4)))) && successFlag;
	if (successFlag) {
		performSelector = messageSelector;
		/* begin popStack */
		top = longAt(stackPointer);
		stackPointer = stackPointer - 4;
		messageSelector = top;
		thisReceiver = longAt(stackPointer);
		argumentCount = arraySize;
		index = 1;
		while (index <= argumentCount) {
			/* begin push: */
			longAtput(stackPointer = stackPointer + 4, longAt((argumentArray + 4) + ((index - 1) * 4)));
			index = index + 1;
		}
		lookupMethodInClass(fetchClassOf(thisReceiver));
		/* begin success: */
		successFlag = (((((unsigned) (longAt((newMethod + 4) + (0 * 4)))) >> 25) & 31) == argumentCount) && successFlag;
		if (successFlag) {
			/* begin executeNewMethod */
			if ((primitiveIndex == 0) || (!(primitiveResponse()))) {
				activateNewMethod();
				/* begin quickCheckForInterrupts */
				if ((interruptCheckCounter = interruptCheckCounter - 1) <= 0) {
					interruptCheckCounter = 1000;
					checkForInterrupts();
				}
			}
			successFlag = true;
		} else {
			/* begin unPop: */
			stackPointer = stackPointer + (argumentCount * 4);
			/* begin push: */
			longAtput(stackPointer = stackPointer + 4, messageSelector);
			/* begin push: */
			longAtput(stackPointer = stackPointer + 4, argumentArray);
			argumentCount = 2;
			messageSelector = performSelector;
		}
	} else {
		/* begin unPop: */
		stackPointer = stackPointer + (1 * 4);
	}
}

int primitivePointX(void) {
    int rcvr;
    int top;
    int successValue;

	successFlag = true;
	/* begin popStack */
	top = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	rcvr = top;
	/* begin success: */
	successValue = (fetchClassOf(rcvr)) == (longAt((specialObjectsOop + 4) + (12 * 4)));
	successFlag = successValue && successFlag;
	if (successFlag) {
		/* begin push: */
		longAtput(stackPointer = stackPointer + 4, longAt((rcvr + 4) + (0 * 4)));
	} else {
		/* begin unPop: */
		stackPointer = stackPointer + (1 * 4);
		failSpecialPrim(0);
	}
}

int primitivePointY(void) {
    int rcvr;
    int top;
    int successValue;

	successFlag = true;
	/* begin popStack */
	top = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	rcvr = top;
	/* begin success: */
	successValue = (fetchClassOf(rcvr)) == (longAt((specialObjectsOop + 4) + (12 * 4)));
	successFlag = successValue && successFlag;
	if (successFlag) {
		/* begin push: */
		longAtput(stackPointer = stackPointer + 4, longAt((rcvr + 4) + (1 * 4)));
	} else {
		/* begin unPop: */
		stackPointer = stackPointer + (1 * 4);
		failSpecialPrim(0);
	}
}

int primitiveQuit(void) {
	exit(0);
	error("Execution should not continue after quit");
}

int primitiveQuo(void) {
    int rcvr;
    int arg;
    int result;
    int successValue;
    int integerPointer;
    int top;
    int integerPointer1;
    int top1;

	/* begin popInteger */
	/* begin popStack */
	top = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	integerPointer = top;
	if (((integerPointer & 1) == 1)) {
		arg = (integerPointer >> 1);
		goto l1;
	} else {
		successFlag = false;
		arg = 1;
		goto l1;
	}
l1:	/* end popInteger */;
	/* begin popInteger */
	/* begin popStack */
	top1 = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	integerPointer1 = top1;
	if (((integerPointer1 & 1) == 1)) {
		rcvr = (integerPointer1 >> 1);
		goto l2;
	} else {
		successFlag = false;
		rcvr = 1;
		goto l2;
	}
l2:	/* end popInteger */;
	/* begin success: */
	successFlag = (arg != 0) && successFlag;
	if (successFlag) {
		if (rcvr > 0) {
			if (arg > 0) {
				result = rcvr / arg;
			} else {
				result = 0 - (rcvr / (0 - arg));
			}
		} else {
			if (arg > 0) {
				result = 0 - ((0 - rcvr) / arg);
			} else {
				result = (0 - rcvr) / (0 - arg);
			}
		}
		/* begin success: */
		successValue = (result >= -1073741824) && (result < 1073741824);
		successFlag = successValue && successFlag;
	}
	if (successFlag) {
		/* begin pushInteger: */
		/* begin push: */
		longAtput(stackPointer = stackPointer + 4, ((result << 1) | 1));
	} else {
		/* begin unPop: */
		stackPointer = stackPointer + (2 * 4);
	}
}

int primitiveReadJoystick(void) {
    int index;
    int object;
    int integerPointer;

	/* begin stackIntegerValue: */
	integerPointer = longAt(stackPointer - (0 * 4));
	if (((integerPointer & 1) == 1)) {
		index = (integerPointer >> 1);
		goto l1;
	} else {
		primitiveFail();
		index = 0;
		goto l1;
	}
l1:	/* end stackIntegerValue: */;
	if (successFlag) {
		/* begin pop: */
		stackPointer = stackPointer - (2 * 4);
		/* begin push: */
		object = positive32BitIntegerFor(joystickRead(index));
		longAtput(stackPointer = stackPointer + 4, object);
	}
}

int primitiveResponse(void) {
    int thisReceiver;
    int top;

	if (primitiveIndex >= 256) {
		/* begin popStack */
		top = longAt(stackPointer);
		stackPointer = stackPointer - 4;
		thisReceiver = top;
		if (primitiveIndex < 264) {
			if (primitiveIndex == 256) {
				/* begin push: */
				longAtput(stackPointer = stackPointer + 4, thisReceiver);
			}
			if (primitiveIndex == 257) {
				/* begin push: */
				longAtput(stackPointer = stackPointer + 4, trueObj);
			}
			if (primitiveIndex == 258) {
				/* begin push: */
				longAtput(stackPointer = stackPointer + 4, falseObj);
			}
			if (primitiveIndex == 259) {
				/* begin push: */
				longAtput(stackPointer = stackPointer + 4, nilObj);
			}
			if (primitiveIndex == 260) {
				/* begin push: */
				longAtput(stackPointer = stackPointer + 4, 4294967295);
			}
			if (primitiveIndex == 261) {
				/* begin push: */
				longAtput(stackPointer = stackPointer + 4, 1);
			}
			if (primitiveIndex == 262) {
				/* begin push: */
				longAtput(stackPointer = stackPointer + 4, 3);
			}
			if (primitiveIndex == 263) {
				/* begin push: */
				longAtput(stackPointer = stackPointer + 4, 5);
			}
			return true;
		} else {
			/* begin push: */
			longAtput(stackPointer = stackPointer + 4, longAt((thisReceiver + 4) + ((primitiveIndex - 264) * 4)));
			return true;
		}
	} else {
		successFlag = true;
		switch (primitiveIndex) {
		case 0:
			primitiveFail();
			break;
		case 1:
			primitiveAdd();
			break;
		case 2:
			primitiveSubtract();
			break;
		case 3:
			primitiveLessThan();
			break;
		case 4:
			primitiveGreaterThan();
			break;
		case 5:
			primitiveLessOrEqual();
			break;
		case 6:
			primitiveGreaterOrEqual();
			break;
		case 7:
			primitiveEqual();
			break;
		case 8:
			primitiveNotEqual();
			break;
		case 9:
			primitiveMultiply();
			break;
		case 10:
			primitiveDivide();
			break;
		case 11:
			primitiveMod();
			break;
		case 12:
			primitiveDiv();
			break;
		case 13:
			primitiveQuo();
			break;
		case 14:
			primitiveBitAnd();
			break;
		case 15:
			primitiveBitOr();
			break;
		case 16:
			primitiveBitXor();
			break;
		case 17:
			primitiveBitShift();
			break;
		case 18:
			primitiveMakePoint();
			break;
		case 19:
		case 20:
		case 21:
		case 22:
		case 23:
		case 24:
		case 25:
		case 26:
		case 27:
		case 28:
		case 29:
		case 30:
		case 31:
		case 32:
		case 33:
		case 34:
		case 35:
		case 36:
		case 37:
		case 38:
		case 39:
			primitiveFail();
			break;
		case 40:
			primitiveAsFloat();
			break;
		case 41:
			primitiveFloatAdd();
			break;
		case 42:
			primitiveFloatSubtract();
			break;
		case 43:
			primitiveFloatLessThan();
			break;
		case 44:
			primitiveFloatGreaterThan();
			break;
		case 45:
			primitiveFloatLessOrEqual();
			break;
		case 46:
			primitiveFloatGreaterOrEqual();
			break;
		case 47:
			primitiveFloatEqual();
			break;
		case 48:
			primitiveFloatNotEqual();
			break;
		case 49:
			primitiveFloatMultiply();
			break;
		case 50:
			primitiveFloatDivide();
			break;
		case 51:
			primitiveTruncated();
			break;
		case 52:
			primitiveFractionalPart();
			break;
		case 53:
			primitiveExponent();
			break;
		case 54:
			primitiveTimesTwoPower();
			break;
		case 55:
		case 56:
		case 57:
		case 58:
		case 59:
			primitiveFail();
			break;
		case 60:
			primitiveAt();
			break;
		case 61:
			primitiveAtPut();
			break;
		case 62:
			primitiveSize();
			break;
		case 63:
			primitiveStringAt();
			break;
		case 64:
			primitiveStringAtPut();
			break;
		case 65:
			primitiveNext();
			break;
		case 66:
			primitiveNextPut();
			break;
		case 67:
			primitiveAtEnd();
			break;
		case 68:
			primitiveObjectAt();
			break;
		case 69:
			primitiveObjectAtPut();
			break;
		case 70:
			primitiveNew();
			break;
		case 71:
			primitiveNewWithArg();
			break;
		case 72:
			primitiveFail();
			break;
		case 73:
			primitiveInstVarAt();
			break;
		case 74:
			primitiveInstVarAtPut();
			break;
		case 75:
			primitiveAsOop();
			break;
		case 76:
			primitiveFail();
			break;
		case 77:
			primitiveSomeInstance();
			break;
		case 78:
			primitiveNextInstance();
			break;
		case 79:
			primitiveNewMethod();
			break;
		case 80:
			primitiveFail();
			break;
		case 81:
			primitiveValue();
			break;
		case 82:
			primitiveValueWithArgs();
			break;
		case 83:
			primitivePerform();
			break;
		case 84:
			primitivePerformWithArgs();
			break;
		case 85:
			primitiveSignal();
			break;
		case 86:
			primitiveWait();
			break;
		case 87:
			primitiveResume();
			break;
		case 88:
			primitiveSuspend();
			break;
		case 89:
			primitiveFlushCache();
			break;
		case 90:
			primitiveMousePoint();
			break;
		case 91:
		case 92:
			primitiveFail();
			break;
		case 93:
			primitiveInputSemaphore();
			break;
		case 94:
			primitiveFail();
			break;
		case 95:
			primitiveInputWord();
			break;
		case 96:
			primitiveCopyBits();
			break;
		case 97:
			primitiveSnapshot();
			break;
		case 98:
		case 99:
		case 100:
			primitiveFail();
			break;
		case 101:
			primitiveBeCursor();
			break;
		case 102:
			primitiveBeDisplay();
			break;
		case 103:
			primitiveScanCharacters();
			break;
		case 104:
			primitiveDrawLoop();
			break;
		case 105:
			primitiveStringReplace();
			break;
		case 106:
			primitiveScreenSize();
			break;
		case 107:
			primitiveMouseButtons();
			break;
		case 108:
			primitiveKbdNext();
			break;
		case 109:
			primitiveKbdPeek();
			break;
		case 110:
			primitiveEquivalent();
			break;
		case 111:
			primitiveClass();
			break;
		case 112:
			primitiveBytesLeft();
			break;
		case 113:
			primitiveQuit();
			break;
		case 114:
			primitiveExitToDebugger();
			break;
		case 115:
		case 116:
		case 117:
		case 118:
		case 119:
		case 120:
			primitiveFail();
			break;
		case 121:
			primitiveImageName();
			break;
		case 122:
			primitiveNoop();
			break;
		case 123:
			primitiveFail();
			break;
		case 124:
			primitiveLowSpaceSemaphore();
			break;
		case 125:
			primitiveSignalAtBytesLeft();
			break;
		case 126:
		case 127:
			primitiveFail();
			break;
		case 128:
			primitiveArrayBecome();
			break;
		case 129:
			primitiveSpecialObjectsOop();
			break;
		case 130:
			primitiveFullGC();
			break;
		case 131:
			primitiveIncrementalGC();
			break;
		case 132:
			primitiveObjectPointsTo();
			break;
		case 133:
			primitiveSetInterruptKey();
			break;
		case 134:
			primitiveInterruptSemaphore();
			break;
		case 135:
			primitiveMillisecondClock();
			break;
		case 136:
			primitiveSignalAtMilliseconds();
			break;
		case 137:
			primitiveSecondsClock();
			break;
		case 138:
			primitiveSomeObject();
			break;
		case 139:
			primitiveNextObject();
			break;
		case 140:
			primitiveBeep();
			break;
		case 141:
			primitiveClipboardText();
			break;
		case 142:
			primitiveVMPath();
			break;
		case 143:
			primitiveShortAt();
			break;
		case 144:
			primitiveShortAtPut();
			break;
		case 145:
			primitiveConstantFill();
			break;
		case 146:
			primitiveReadJoystick();
			break;
		case 147:
			primitiveWarpBits();
			break;
		case 148:
		case 149:
			primitiveFail();
			break;
		case 150:
			primitiveFileAtEnd();
			break;
		case 151:
			primitiveFileClose();
			break;
		case 152:
			primitiveFileGetPosition();
			break;
		case 153:
			primitiveFileOpen();
			break;
		case 154:
			primitiveFileRead();
			break;
		case 155:
			primitiveFileSetPosition();
			break;
		case 156:
			primitiveFileDelete();
			break;
		case 157:
			primitiveFileSize();
			break;
		case 158:
			primitiveFileWrite();
			break;
		case 159:
			primitiveFileRename();
			break;
		case 160:
			primitiveDirectoryCreate();
			break;
		case 161:
			primitiveDirectoryDelimitor();
			break;
		case 162:
			primitiveDirectoryLookup();
			break;
		case 163:
		case 164:
		case 165:
		case 166:
		case 167:
		case 168:
			primitiveFail();
			break;
		case 169:
			primitiveDirectorySetMacTypeAndCreator();
			break;
		case 170:
			primitiveSoundStart();
			break;
		case 171:
			primitiveFail();
			break;
		case 172:
			primitiveSoundStop();
			break;
		case 173:
			primitiveSoundAvailableSpace();
			break;
		case 174:
			primitiveSoundPlaySamples();
			break;
		case 175:
			primitiveSoundPlaySilence();
			break;
		case 176:
			primWaveTableSoundmixSampleCountintostartingAtpan();
			break;
		case 177:
			primFMSoundmixSampleCountintostartingAtpan();
			break;
		case 178:
			primPluckedSoundmixSampleCountintostartingAtpan();
			break;
		case 179:
		case 180:
		case 181:
		case 182:
		case 183:
		case 184:
		case 185:
		case 186:
		case 187:
		case 188:
		case 189:
		case 190:
		case 191:
		case 192:
		case 193:
		case 194:
		case 195:
		case 196:
		case 197:
		case 198:
		case 199:
		case 200:
		case 201:
		case 202:
		case 203:
		case 204:
		case 205:
		case 206:
		case 207:
		case 208:
		case 209:
		case 210:
		case 211:
		case 212:
		case 213:
		case 214:
		case 215:
		case 216:
		case 217:
		case 218:
		case 219:
		case 220:
		case 221:
		case 222:
		case 223:
		case 224:
		case 225:
		case 226:
		case 227:
		case 228:
		case 229:
		case 230:
		case 231:
		case 232:
		case 233:
		case 234:
		case 235:
		case 236:
		case 237:
		case 238:
		case 239:
		case 240:
		case 241:
		case 242:
		case 243:
		case 244:
		case 245:
		case 246:
		case 247:
		case 248:
		case 249:
			primitiveFail();
			break;
		case 250:
			clearProfile();
			break;
		case 251:
			dumpProfile();
			break;
		case 252:
			startProfiling();
			break;
		case 253:
			stopProfiling();
			break;
		case 254:
		case 255:
			primitiveFail();
			break;
		}
		return successFlag;
	}
}

int primitiveResume(void) {
    int proc;

	proc = longAt(stackPointer);
	if (successFlag) {
		resume(proc);
	}
}

int primitiveScanCharacters(void) {
    int rcvr;
    int start;
    int stop;
    int string;
    int rightX;
    int stopArray;
    int displayFlag;
    int integerPointer;
    int integerPointer1;
    int integerPointer2;
    int successValue;
    int left;
    int top;
    int lastIndex;
    int charVal;
    int ascii;
    int sourceX2;
    int nextDestX;
    int objectPointer;
    int integerValue;
    int objectPointer1;
    int objectPointer2;
    int lastIndex1;
    int objectPointer3;
    int array;
    int fixedFields;
    int totalLength;
    int i;
    int successValue1;
    int header;
    int sz;
    int fmt;
    int fmt1;
    int byteVal;
    int classPointer;
    int fmt2;
    int ccIndex;
    int array1;
    int fixedFields1;
    int totalLength1;
    int i1;
    int successValue2;
    int header1;
    int sz1;
    int fmt3;
    int fmt11;
    int byteVal1;
    int classPointer1;
    int fmt21;
    int ccIndex1;
    int array2;
    int fixedFields2;
    int totalLength2;
    int i2;
    int successValue3;
    int header2;
    int sz2;
    int fmt4;
    int fmt12;
    int byteVal2;
    int classPointer2;
    int fmt22;
    int ccIndex2;
    int array3;
    int fixedFields3;
    int totalLength3;
    int i3;
    int successValue4;
    int header3;
    int sz3;
    int fmt5;
    int fmt13;
    int byteVal3;
    int classPointer3;
    int fmt23;
    int ccIndex3;
    int array4;
    int fixedFields4;
    int totalLength4;
    int i4;
    int successValue5;
    int header4;
    int sz4;
    int fmt6;
    int fmt14;
    int byteVal4;
    int classPointer4;
    int fmt24;
    int ccIndex4;
    int array5;
    int fixedFields5;
    int totalLength5;
    int i5;
    int successValue6;
    int header5;
    int sz5;
    int fmt7;
    int fmt15;
    int byteVal5;
    int classPointer5;
    int fmt25;
    int ccIndex5;
    int array6;
    int fixedFields6;
    int totalLength6;
    int i6;
    int successValue7;
    int header6;
    int sz6;
    int fmt8;
    int fmt16;
    int byteVal6;
    int classPointer6;
    int fmt26;
    int ccIndex6;

	rcvr = longAt(stackPointer - (6 * 4));
	/* begin stackIntegerValue: */
	integerPointer = longAt(stackPointer - (5 * 4));
	if (((integerPointer & 1) == 1)) {
		start = (integerPointer >> 1);
		goto l1;
	} else {
		primitiveFail();
		start = 0;
		goto l1;
	}
l1:	/* end stackIntegerValue: */;
	/* begin stackIntegerValue: */
	integerPointer1 = longAt(stackPointer - (4 * 4));
	if (((integerPointer1 & 1) == 1)) {
		stop = (integerPointer1 >> 1);
		goto l2;
	} else {
		primitiveFail();
		stop = 0;
		goto l2;
	}
l2:	/* end stackIntegerValue: */;
	string = longAt(stackPointer - (3 * 4));
	/* begin stackIntegerValue: */
	integerPointer2 = longAt(stackPointer - (2 * 4));
	if (((integerPointer2 & 1) == 1)) {
		rightX = (integerPointer2 >> 1);
		goto l3;
	} else {
		primitiveFail();
		rightX = 0;
		goto l3;
	}
l3:	/* end stackIntegerValue: */;
	stopArray = longAt(stackPointer - (1 * 4));
	/* begin booleanValueOf: */
	if ((longAt(stackPointer - (0 * 4))) == trueObj) {
		displayFlag = true;
		goto l4;
	}
	if ((longAt(stackPointer - (0 * 4))) == falseObj) {
		displayFlag = false;
		goto l4;
	}
	successFlag = false;
	displayFlag = null;
l4:	/* end booleanValueOf: */;
	if (!(successFlag)) {
		return null;
	}
	/* begin success: */
	successValue = loadScannerFromstartstopstringrightXstopArraydisplayFlag(rcvr, start, stop, string, rightX, stopArray, displayFlag);
	successFlag = successValue && successFlag;
	if (successFlag) {
		/* begin scanCharacters */
		if (scanDisplayFlag) {
			clipRange();
			left = dx;
			top = dy;
		}
		lastIndex = scanStart;
		while (lastIndex <= scanStop) {
			/* begin stObject:at: */
			array2 = scanString;
			/* begin fixedFieldsOf: */
			/* begin fetchClassOf: */
			if (((array2 & 1) == 1)) {
				classPointer2 = longAt((specialObjectsOop + 4) + (5 * 4));
				goto l16;
			}
			ccIndex2 = ((((unsigned) (longAt(array2))) >> 12) & 31) - 1;
			if (ccIndex2 < 0) {
				classPointer2 = (longAt(array2 - 4)) & 4294967292;
				goto l16;
			} else {
				classPointer2 = longAt(((longAt((specialObjectsOop + 4) + (28 * 4))) + 4) + (ccIndex2 * 4));
				goto l16;
			}
		l16:	/* end fetchClassOf: */;
			fmt22 = (longAt((classPointer2 + 4) + (2 * 4))) - 1;
			fixedFields2 = ((((unsigned) fmt22) >> 2) & 63) - 1;
			/* begin lengthOf: */
			header2 = longAt(array2);
			if ((header2 & 3) == 0) {
				sz2 = (longAt(array2 - 8)) & 4294967292;
			} else {
				sz2 = header2 & 252;
			}
			fmt4 = (((unsigned) header2) >> 8) & 15;
			if (fmt4 < 8) {
				totalLength2 = (sz2 - 4) / 4;
				goto l15;
			} else {
				totalLength2 = (sz2 - 4) - (fmt4 & 3);
				goto l15;
			}
		l15:	/* end lengthOf: */;
			i2 = lastIndex + fixedFields2;
			/* begin success: */
			successValue3 = (lastIndex >= 1) && (i2 <= totalLength2);
			successFlag = successValue3 && successFlag;
			if (successFlag) {
				/* begin subscript:with: */
				fmt12 = (((unsigned) (longAt(array2))) >> 8) & 15;
				if (fmt12 < 4) {
					charVal = longAt((array2 + 4) + ((i2 - 1) * 4));
					goto l17;
				}
				if (fmt12 < 8) {
					charVal = positive32BitIntegerFor(longAt((array2 + 4) + ((i2 - 1) * 4)));
					goto l17;
				}
				byteVal2 = byteAt((array2 + 4) + (i2 - 1));
				charVal = ((byteVal2 << 1) | 1);
				goto l17;
			} else {
				charVal = nilObj;
				goto l17;
			}
		l17:	/* end stObject:at: */;
			ascii = (charVal >> 1);
			if (!successFlag) {
				goto l5;
			}
			/* begin stObject:at: */
			array3 = scanStopArray;
			/* begin fixedFieldsOf: */
			/* begin fetchClassOf: */
			if (((array3 & 1) == 1)) {
				classPointer3 = longAt((specialObjectsOop + 4) + (5 * 4));
				goto l19;
			}
			ccIndex3 = ((((unsigned) (longAt(array3))) >> 12) & 31) - 1;
			if (ccIndex3 < 0) {
				classPointer3 = (longAt(array3 - 4)) & 4294967292;
				goto l19;
			} else {
				classPointer3 = longAt(((longAt((specialObjectsOop + 4) + (28 * 4))) + 4) + (ccIndex3 * 4));
				goto l19;
			}
		l19:	/* end fetchClassOf: */;
			fmt23 = (longAt((classPointer3 + 4) + (2 * 4))) - 1;
			fixedFields3 = ((((unsigned) fmt23) >> 2) & 63) - 1;
			/* begin lengthOf: */
			header3 = longAt(array3);
			if ((header3 & 3) == 0) {
				sz3 = (longAt(array3 - 8)) & 4294967292;
			} else {
				sz3 = header3 & 252;
			}
			fmt5 = (((unsigned) header3) >> 8) & 15;
			if (fmt5 < 8) {
				totalLength3 = (sz3 - 4) / 4;
				goto l18;
			} else {
				totalLength3 = (sz3 - 4) - (fmt5 & 3);
				goto l18;
			}
		l18:	/* end lengthOf: */;
			i3 = (ascii + 1) + fixedFields3;
			/* begin success: */
			successValue4 = ((ascii + 1) >= 1) && (i3 <= totalLength3);
			successFlag = successValue4 && successFlag;
			if (successFlag) {
				/* begin subscript:with: */
				fmt13 = (((unsigned) (longAt(array3))) >> 8) & 15;
				if (fmt13 < 4) {
					stopCode = longAt((array3 + 4) + ((i3 - 1) * 4));
					goto l20;
				}
				if (fmt13 < 8) {
					stopCode = positive32BitIntegerFor(longAt((array3 + 4) + ((i3 - 1) * 4)));
					goto l20;
				}
				byteVal3 = byteAt((array3 + 4) + (i3 - 1));
				stopCode = ((byteVal3 << 1) | 1);
				goto l20;
			} else {
				stopCode = nilObj;
				goto l20;
			}
		l20:	/* end stObject:at: */;
			if (!successFlag) {
				goto l5;
			}
			if (!(stopCode == nilObj)) {
				/* begin returnAt:lastIndex:left:top: */
				/* begin stObject:at: */
				array = scanStopArray;
				/* begin fixedFieldsOf: */
				/* begin fetchClassOf: */
				if (((array & 1) == 1)) {
					classPointer = longAt((specialObjectsOop + 4) + (5 * 4));
					goto l10;
				}
				ccIndex = ((((unsigned) (longAt(array))) >> 12) & 31) - 1;
				if (ccIndex < 0) {
					classPointer = (longAt(array - 4)) & 4294967292;
					goto l10;
				} else {
					classPointer = longAt(((longAt((specialObjectsOop + 4) + (28 * 4))) + 4) + (ccIndex * 4));
					goto l10;
				}
			l10:	/* end fetchClassOf: */;
				fmt2 = (longAt((classPointer + 4) + (2 * 4))) - 1;
				fixedFields = ((((unsigned) fmt2) >> 2) & 63) - 1;
				/* begin lengthOf: */
				header = longAt(array);
				if ((header & 3) == 0) {
					sz = (longAt(array - 8)) & 4294967292;
				} else {
					sz = header & 252;
				}
				fmt = (((unsigned) header) >> 8) & 15;
				if (fmt < 8) {
					totalLength = (sz - 4) / 4;
					goto l9;
				} else {
					totalLength = (sz - 4) - (fmt & 3);
					goto l9;
				}
			l9:	/* end lengthOf: */;
				i = (ascii + 1) + fixedFields;
				/* begin success: */
				successValue1 = ((ascii + 1) >= 1) && (i <= totalLength);
				successFlag = successValue1 && successFlag;
				if (successFlag) {
					/* begin subscript:with: */
					fmt1 = (((unsigned) (longAt(array))) >> 8) & 15;
					if (fmt1 < 4) {
						stopCode = longAt((array + 4) + ((i - 1) * 4));
						goto l11;
					}
					if (fmt1 < 8) {
						stopCode = positive32BitIntegerFor(longAt((array + 4) + ((i - 1) * 4)));
						goto l11;
					}
					byteVal = byteAt((array + 4) + (i - 1));
					stopCode = ((byteVal << 1) | 1);
					goto l11;
				} else {
					stopCode = nilObj;
					goto l11;
				}
			l11:	/* end stObject:at: */;
				if (!successFlag) {
					goto l6;
				}
				/* begin storeInteger:ofObject:withValue: */
				objectPointer1 = bitBltOop;
				if ((lastIndex >= -1073741824) && (lastIndex < 1073741824)) {
					longAtput((objectPointer1 + 4) + (15 * 4), ((lastIndex << 1) | 1));
				} else {
					primitiveFail();
				}
				if (scanDisplayFlag) {
					affectedL = left;
					affectedR = bbW + dx;
					affectedT = top;
					affectedB = bbH + dy;
				}
			l6:	/* end returnAt:lastIndex:left:top: */;
				goto l5;
			}
			/* begin stObject:at: */
			array4 = scanXTable;
			/* begin fixedFieldsOf: */
			/* begin fetchClassOf: */
			if (((array4 & 1) == 1)) {
				classPointer4 = longAt((specialObjectsOop + 4) + (5 * 4));
				goto l22;
			}
			ccIndex4 = ((((unsigned) (longAt(array4))) >> 12) & 31) - 1;
			if (ccIndex4 < 0) {
				classPointer4 = (longAt(array4 - 4)) & 4294967292;
				goto l22;
			} else {
				classPointer4 = longAt(((longAt((specialObjectsOop + 4) + (28 * 4))) + 4) + (ccIndex4 * 4));
				goto l22;
			}
		l22:	/* end fetchClassOf: */;
			fmt24 = (longAt((classPointer4 + 4) + (2 * 4))) - 1;
			fixedFields4 = ((((unsigned) fmt24) >> 2) & 63) - 1;
			/* begin lengthOf: */
			header4 = longAt(array4);
			if ((header4 & 3) == 0) {
				sz4 = (longAt(array4 - 8)) & 4294967292;
			} else {
				sz4 = header4 & 252;
			}
			fmt6 = (((unsigned) header4) >> 8) & 15;
			if (fmt6 < 8) {
				totalLength4 = (sz4 - 4) / 4;
				goto l21;
			} else {
				totalLength4 = (sz4 - 4) - (fmt6 & 3);
				goto l21;
			}
		l21:	/* end lengthOf: */;
			i4 = (ascii + 1) + fixedFields4;
			/* begin success: */
			successValue5 = ((ascii + 1) >= 1) && (i4 <= totalLength4);
			successFlag = successValue5 && successFlag;
			if (successFlag) {
				/* begin subscript:with: */
				fmt14 = (((unsigned) (longAt(array4))) >> 8) & 15;
				if (fmt14 < 4) {
					sourceX = longAt((array4 + 4) + ((i4 - 1) * 4));
					goto l23;
				}
				if (fmt14 < 8) {
					sourceX = positive32BitIntegerFor(longAt((array4 + 4) + ((i4 - 1) * 4)));
					goto l23;
				}
				byteVal4 = byteAt((array4 + 4) + (i4 - 1));
				sourceX = ((byteVal4 << 1) | 1);
				goto l23;
			} else {
				sourceX = nilObj;
				goto l23;
			}
		l23:	/* end stObject:at: */;
			/* begin stObject:at: */
			array5 = scanXTable;
			/* begin fixedFieldsOf: */
			/* begin fetchClassOf: */
			if (((array5 & 1) == 1)) {
				classPointer5 = longAt((specialObjectsOop + 4) + (5 * 4));
				goto l25;
			}
			ccIndex5 = ((((unsigned) (longAt(array5))) >> 12) & 31) - 1;
			if (ccIndex5 < 0) {
				classPointer5 = (longAt(array5 - 4)) & 4294967292;
				goto l25;
			} else {
				classPointer5 = longAt(((longAt((specialObjectsOop + 4) + (28 * 4))) + 4) + (ccIndex5 * 4));
				goto l25;
			}
		l25:	/* end fetchClassOf: */;
			fmt25 = (longAt((classPointer5 + 4) + (2 * 4))) - 1;
			fixedFields5 = ((((unsigned) fmt25) >> 2) & 63) - 1;
			/* begin lengthOf: */
			header5 = longAt(array5);
			if ((header5 & 3) == 0) {
				sz5 = (longAt(array5 - 8)) & 4294967292;
			} else {
				sz5 = header5 & 252;
			}
			fmt7 = (((unsigned) header5) >> 8) & 15;
			if (fmt7 < 8) {
				totalLength5 = (sz5 - 4) / 4;
				goto l24;
			} else {
				totalLength5 = (sz5 - 4) - (fmt7 & 3);
				goto l24;
			}
		l24:	/* end lengthOf: */;
			i5 = (ascii + 2) + fixedFields5;
			/* begin success: */
			successValue6 = ((ascii + 2) >= 1) && (i5 <= totalLength5);
			successFlag = successValue6 && successFlag;
			if (successFlag) {
				/* begin subscript:with: */
				fmt15 = (((unsigned) (longAt(array5))) >> 8) & 15;
				if (fmt15 < 4) {
					sourceX2 = longAt((array5 + 4) + ((i5 - 1) * 4));
					goto l26;
				}
				if (fmt15 < 8) {
					sourceX2 = positive32BitIntegerFor(longAt((array5 + 4) + ((i5 - 1) * 4)));
					goto l26;
				}
				byteVal5 = byteAt((array5 + 4) + (i5 - 1));
				sourceX2 = ((byteVal5 << 1) | 1);
				goto l26;
			} else {
				sourceX2 = nilObj;
				goto l26;
			}
		l26:	/* end stObject:at: */;
			if (!successFlag) {
				goto l5;
			}
			if ((((sourceX & 1) == 1)) && (((sourceX2 & 1) == 1))) {
				sourceX = (sourceX >> 1);
				sourceX2 = (sourceX2 >> 1);
			} else {
				primitiveFail();
				goto l5;
			}
			nextDestX = destX + (width = sourceX2 - sourceX);
			if (nextDestX > scanRightX) {
				/* begin returnAt:lastIndex:left:top: */
				/* begin stObject:at: */
				array1 = scanStopArray;
				/* begin fixedFieldsOf: */
				/* begin fetchClassOf: */
				if (((array1 & 1) == 1)) {
					classPointer1 = longAt((specialObjectsOop + 4) + (5 * 4));
					goto l13;
				}
				ccIndex1 = ((((unsigned) (longAt(array1))) >> 12) & 31) - 1;
				if (ccIndex1 < 0) {
					classPointer1 = (longAt(array1 - 4)) & 4294967292;
					goto l13;
				} else {
					classPointer1 = longAt(((longAt((specialObjectsOop + 4) + (28 * 4))) + 4) + (ccIndex1 * 4));
					goto l13;
				}
			l13:	/* end fetchClassOf: */;
				fmt21 = (longAt((classPointer1 + 4) + (2 * 4))) - 1;
				fixedFields1 = ((((unsigned) fmt21) >> 2) & 63) - 1;
				/* begin lengthOf: */
				header1 = longAt(array1);
				if ((header1 & 3) == 0) {
					sz1 = (longAt(array1 - 8)) & 4294967292;
				} else {
					sz1 = header1 & 252;
				}
				fmt3 = (((unsigned) header1) >> 8) & 15;
				if (fmt3 < 8) {
					totalLength1 = (sz1 - 4) / 4;
					goto l12;
				} else {
					totalLength1 = (sz1 - 4) - (fmt3 & 3);
					goto l12;
				}
			l12:	/* end lengthOf: */;
				i1 = 258 + fixedFields1;
				/* begin success: */
				successValue2 = (258 >= 1) && (i1 <= totalLength1);
				successFlag = successValue2 && successFlag;
				if (successFlag) {
					/* begin subscript:with: */
					fmt11 = (((unsigned) (longAt(array1))) >> 8) & 15;
					if (fmt11 < 4) {
						stopCode = longAt((array1 + 4) + ((i1 - 1) * 4));
						goto l14;
					}
					if (fmt11 < 8) {
						stopCode = positive32BitIntegerFor(longAt((array1 + 4) + ((i1 - 1) * 4)));
						goto l14;
					}
					byteVal1 = byteAt((array1 + 4) + (i1 - 1));
					stopCode = ((byteVal1 << 1) | 1);
					goto l14;
				} else {
					stopCode = nilObj;
					goto l14;
				}
			l14:	/* end stObject:at: */;
				if (!successFlag) {
					goto l7;
				}
				/* begin storeInteger:ofObject:withValue: */
				objectPointer2 = bitBltOop;
				if ((lastIndex >= -1073741824) && (lastIndex < 1073741824)) {
					longAtput((objectPointer2 + 4) + (15 * 4), ((lastIndex << 1) | 1));
				} else {
					primitiveFail();
				}
				if (scanDisplayFlag) {
					affectedL = left;
					affectedR = bbW + dx;
					affectedT = top;
					affectedB = bbH + dy;
				}
			l7:	/* end returnAt:lastIndex:left:top: */;
				goto l5;
			}
			if (scanDisplayFlag) {
				copyBits();
			}
			destX = nextDestX;
			/* begin storeInteger:ofObject:withValue: */
			objectPointer = bitBltOop;
			integerValue = destX;
			if ((integerValue >= -1073741824) && (integerValue < 1073741824)) {
				longAtput((objectPointer + 4) + (4 * 4), ((integerValue << 1) | 1));
			} else {
				primitiveFail();
			}
			lastIndex = lastIndex + 1;
		}
		/* begin returnAt:lastIndex:left:top: */
		lastIndex1 = scanStop;
		/* begin stObject:at: */
		array6 = scanStopArray;
		/* begin fixedFieldsOf: */
		/* begin fetchClassOf: */
		if (((array6 & 1) == 1)) {
			classPointer6 = longAt((specialObjectsOop + 4) + (5 * 4));
			goto l28;
		}
		ccIndex6 = ((((unsigned) (longAt(array6))) >> 12) & 31) - 1;
		if (ccIndex6 < 0) {
			classPointer6 = (longAt(array6 - 4)) & 4294967292;
			goto l28;
		} else {
			classPointer6 = longAt(((longAt((specialObjectsOop + 4) + (28 * 4))) + 4) + (ccIndex6 * 4));
			goto l28;
		}
	l28:	/* end fetchClassOf: */;
		fmt26 = (longAt((classPointer6 + 4) + (2 * 4))) - 1;
		fixedFields6 = ((((unsigned) fmt26) >> 2) & 63) - 1;
		/* begin lengthOf: */
		header6 = longAt(array6);
		if ((header6 & 3) == 0) {
			sz6 = (longAt(array6 - 8)) & 4294967292;
		} else {
			sz6 = header6 & 252;
		}
		fmt8 = (((unsigned) header6) >> 8) & 15;
		if (fmt8 < 8) {
			totalLength6 = (sz6 - 4) / 4;
			goto l27;
		} else {
			totalLength6 = (sz6 - 4) - (fmt8 & 3);
			goto l27;
		}
	l27:	/* end lengthOf: */;
		i6 = 257 + fixedFields6;
		/* begin success: */
		successValue7 = (257 >= 1) && (i6 <= totalLength6);
		successFlag = successValue7 && successFlag;
		if (successFlag) {
			/* begin subscript:with: */
			fmt16 = (((unsigned) (longAt(array6))) >> 8) & 15;
			if (fmt16 < 4) {
				stopCode = longAt((array6 + 4) + ((i6 - 1) * 4));
				goto l29;
			}
			if (fmt16 < 8) {
				stopCode = positive32BitIntegerFor(longAt((array6 + 4) + ((i6 - 1) * 4)));
				goto l29;
			}
			byteVal6 = byteAt((array6 + 4) + (i6 - 1));
			stopCode = ((byteVal6 << 1) | 1);
			goto l29;
		} else {
			stopCode = nilObj;
			goto l29;
		}
	l29:	/* end stObject:at: */;
		if (!successFlag) {
			goto l8;
		}
		/* begin storeInteger:ofObject:withValue: */
		objectPointer3 = bitBltOop;
		if ((lastIndex1 >= -1073741824) && (lastIndex1 < 1073741824)) {
			longAtput((objectPointer3 + 4) + (15 * 4), ((lastIndex1 << 1) | 1));
		} else {
			primitiveFail();
		}
		if (scanDisplayFlag) {
			affectedL = left;
			affectedR = bbW + dx;
			affectedT = top;
			affectedB = bbH + dy;
		}
	l8:	/* end returnAt:lastIndex:left:top: */;
	l5:	/* end scanCharacters */;
	}
	if (successFlag) {
		if (displayFlag && (destForm == (longAt((specialObjectsOop + 4) + (14 * 4))))) {
			showDisplayBits();
		}
		/* begin pop: */
		stackPointer = stackPointer - (7 * 4);
		/* begin push: */
		longAtput(stackPointer = stackPointer + 4, stopCode);
	}
}

int primitiveScreenSize(void) {
    int pointWord;
    int object;
    int pointResult;

	/* begin pop: */
	stackPointer = stackPointer - (1 * 4);
	pointWord = ioScreenSize();
	/* begin push: */
	/* begin makePointwithxValue:yValue: */
	pointResult = instantiateSmallClasssizeInBytesfill(longAt((specialObjectsOop + 4) + (12 * 4)), 12, nilObj);
	/* begin storePointer:ofObject:withValue: */
	if (pointResult < youngStart) {
		possibleRootStoreIntovalue(pointResult, ((((((unsigned) pointWord) >> 16) & 65535) << 1) | 1));
	}
	longAtput((pointResult + 4) + (0 * 4), ((((((unsigned) pointWord) >> 16) & 65535) << 1) | 1));
	/* begin storePointer:ofObject:withValue: */
	if (pointResult < youngStart) {
		possibleRootStoreIntovalue(pointResult, (((pointWord & 65535) << 1) | 1));
	}
	longAtput((pointResult + 4) + (1 * 4), (((pointWord & 65535) << 1) | 1));
	object = pointResult;
	longAtput(stackPointer = stackPointer + 4, object);
}

int primitiveSecondsClock(void) {
    int object;

	/* begin pop: */
	stackPointer = stackPointer - (1 * 4);
	/* begin push: */
	object = positive32BitIntegerFor(ioSeconds());
	longAtput(stackPointer = stackPointer + 4, object);
}

int primitiveSetInterruptKey(void) {
    int keycode;
    int integerPointer;
    int top;

	/* begin popInteger */
	/* begin popStack */
	top = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	integerPointer = top;
	if (((integerPointer & 1) == 1)) {
		keycode = (integerPointer >> 1);
		goto l1;
	} else {
		successFlag = false;
		keycode = 1;
		goto l1;
	}
l1:	/* end popInteger */;
	if (successFlag) {
		interruptKeycode = keycode;
	} else {
		/* begin unPop: */
		stackPointer = stackPointer + (1 * 4);
	}
}

int primitiveShortAt(void) {
    int index;
    int rcvr;
    int sz;
    int addr;
    int value;
    int integerPointer;
    int successValue;
    int successValue1;

	/* begin stackIntegerValue: */
	integerPointer = longAt(stackPointer - (0 * 4));
	if (((integerPointer & 1) == 1)) {
		index = (integerPointer >> 1);
		goto l1;
	} else {
		primitiveFail();
		index = 0;
		goto l1;
	}
l1:	/* end stackIntegerValue: */;
	rcvr = longAt(stackPointer - (1 * 4));
	/* begin success: */
	successValue = (!(((rcvr & 1) == 1))) && (isWordsOrBytes(rcvr));
	successFlag = successValue && successFlag;
	if (!(successFlag)) {
		return null;
	}
	sz = ((sizeBitsOf(rcvr)) - 4) / 2;
	/* begin success: */
	successValue1 = (index >= 1) && (index <= sz);
	successFlag = successValue1 && successFlag;
	if (successFlag) {
		addr = (rcvr + 4) + (2 * (index - 1));
		value = *((short int *) addr);
		/* begin pop: */
		stackPointer = stackPointer - (2 * 4);
		/* begin pushInteger: */
		/* begin push: */
		longAtput(stackPointer = stackPointer + 4, ((value << 1) | 1));
	}
}

int primitiveShortAtPut(void) {
    int index;
    int rcvr;
    int sz;
    int addr;
    int value;
    int integerPointer;
    int integerPointer1;
    int successValue;
    int successValue1;
    int successValue2;

	/* begin stackIntegerValue: */
	integerPointer = longAt(stackPointer - (0 * 4));
	if (((integerPointer & 1) == 1)) {
		value = (integerPointer >> 1);
		goto l1;
	} else {
		primitiveFail();
		value = 0;
		goto l1;
	}
l1:	/* end stackIntegerValue: */;
	/* begin stackIntegerValue: */
	integerPointer1 = longAt(stackPointer - (1 * 4));
	if (((integerPointer1 & 1) == 1)) {
		index = (integerPointer1 >> 1);
		goto l2;
	} else {
		primitiveFail();
		index = 0;
		goto l2;
	}
l2:	/* end stackIntegerValue: */;
	rcvr = longAt(stackPointer - (2 * 4));
	/* begin success: */
	successValue = (!(((rcvr & 1) == 1))) && (isWordsOrBytes(rcvr));
	successFlag = successValue && successFlag;
	if (!(successFlag)) {
		return null;
	}
	sz = ((sizeBitsOf(rcvr)) - 4) / 2;
	/* begin success: */
	successValue1 = (index >= 1) && (index <= sz);
	successFlag = successValue1 && successFlag;
	/* begin success: */
	successValue2 = (value >= -32768) && (value <= 32767);
	successFlag = successValue2 && successFlag;
	if (successFlag) {
		addr = (rcvr + 4) + (2 * (index - 1));
		*((short int *) addr) = value;
		/* begin pop: */
		stackPointer = stackPointer - (2 * 4);
	}
}

int primitiveSignal(void) {
    int sema;
    int successValue;

	sema = longAt(stackPointer);
	/* begin success: */
	successValue = (fetchClassOf(sema)) == (longAt((specialObjectsOop + 4) + (18 * 4)));
	successFlag = successValue && successFlag;
	if (successFlag) {
		synchronousSignal(sema);
	}
}

int primitiveSignalAtBytesLeft(void) {
    int bytes;
    int integerPointer;
    int top;

	/* begin popInteger */
	/* begin popStack */
	top = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	integerPointer = top;
	if (((integerPointer & 1) == 1)) {
		bytes = (integerPointer >> 1);
		goto l1;
	} else {
		successFlag = false;
		bytes = 1;
		goto l1;
	}
l1:	/* end popInteger */;
	if (successFlag) {
		lowSpaceThreshold = bytes;
	} else {
		lowSpaceThreshold = 0;
		/* begin unPop: */
		stackPointer = stackPointer + (1 * 4);
	}
}

int primitiveSignalAtMilliseconds(void) {
    int tick;
    int sema;
    int objectPointer;
    int objectPointer1;
    int valuePointer;
    int integerPointer;
    int top;
    int top1;

	/* begin popInteger */
	/* begin popStack */
	top = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	integerPointer = top;
	if (((integerPointer & 1) == 1)) {
		tick = (integerPointer >> 1);
		goto l1;
	} else {
		successFlag = false;
		tick = 1;
		goto l1;
	}
l1:	/* end popInteger */;
	/* begin popStack */
	top1 = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	sema = top1;
	if (successFlag) {
		if ((fetchClassOf(sema)) == (longAt((specialObjectsOop + 4) + (18 * 4)))) {
			/* begin storePointer:ofObject:withValue: */
			objectPointer = specialObjectsOop;
			if (objectPointer < youngStart) {
				possibleRootStoreIntovalue(objectPointer, sema);
			}
			longAtput((objectPointer + 4) + (29 * 4), sema);
			nextWakeupTick = tick;
		} else {
			/* begin storePointer:ofObject:withValue: */
			objectPointer1 = specialObjectsOop;
			valuePointer = nilObj;
			if (objectPointer1 < youngStart) {
				possibleRootStoreIntovalue(objectPointer1, valuePointer);
			}
			longAtput((objectPointer1 + 4) + (29 * 4), valuePointer);
			nextWakeupTick = 0;
		}
	} else {
		/* begin unPop: */
		stackPointer = stackPointer + (2 * 4);
	}
}

int primitiveSize(void) {
    int array;
    int sz;
    int top;
    int totalLength;
    int fixedFields;
    int header;
    int sz1;
    int fmt;
    int classPointer;
    int fmt1;
    int ccIndex;

	/* begin popStack */
	top = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	array = top;
	/* begin stSizeOf: */
	if (((array & 1) == 1)) {
		sz = 0;
		goto l1;
	}
	/* begin lengthOf: */
	header = longAt(array);
	if ((header & 3) == 0) {
		sz1 = (longAt(array - 8)) & 4294967292;
	} else {
		sz1 = header & 252;
	}
	fmt = (((unsigned) header) >> 8) & 15;
	if (fmt < 8) {
		totalLength = (sz1 - 4) / 4;
		goto l2;
	} else {
		totalLength = (sz1 - 4) - (fmt & 3);
		goto l2;
	}
l2:	/* end lengthOf: */;
	/* begin fixedFieldsOf: */
	/* begin fetchClassOf: */
	if (((array & 1) == 1)) {
		classPointer = longAt((specialObjectsOop + 4) + (5 * 4));
		goto l3;
	}
	ccIndex = ((((unsigned) (longAt(array))) >> 12) & 31) - 1;
	if (ccIndex < 0) {
		classPointer = (longAt(array - 4)) & 4294967292;
		goto l3;
	} else {
		classPointer = longAt(((longAt((specialObjectsOop + 4) + (28 * 4))) + 4) + (ccIndex * 4));
		goto l3;
	}
l3:	/* end fetchClassOf: */;
	fmt1 = (longAt((classPointer + 4) + (2 * 4))) - 1;
	fixedFields = ((((unsigned) fmt1) >> 2) & 63) - 1;
	sz = totalLength - fixedFields;
l1:	/* end stSizeOf: */;
	if (successFlag) {
		/* begin pushInteger: */
		/* begin push: */
		longAtput(stackPointer = stackPointer + 4, ((sz << 1) | 1));
	} else {
		/* begin unPop: */
		stackPointer = stackPointer + (1 * 4);
		failSpecialPrim(62);
	}
}

int primitiveSnapshot(void) {
    int activeProc;
    int dataSize;
    int rcvr;
    int top;
    int valuePointer;

	/* begin storeContextRegisters */
	longAtput((activeContext + 4) + (1 * 4), ((((instructionPointer - method) - (4 - 2)) << 1) | 1));
	longAtput((activeContext + 4) + (2 * 4), (((((((stackPointer - activeContext) - 4) / 4) - 6) + 1) << 1) | 1));
	activeProc = longAt(((longAt(((longAt((specialObjectsOop + 4) + (3 * 4))) + 4) + (1 * 4))) + 4) + (1 * 4));
	/* begin storePointer:ofObject:withValue: */
	valuePointer = activeContext;
	if (activeProc < youngStart) {
		possibleRootStoreIntovalue(activeProc, valuePointer);
	}
	longAtput((activeProc + 4) + (1 * 4), valuePointer);
	incrementalGC();
	fullGC();
	dataSize = freeBlock - (startOfMemory());
	if (successFlag) {
		/* begin popStack */
		top = longAt(stackPointer);
		stackPointer = stackPointer - 4;
		rcvr = top;
		/* begin push: */
		longAtput(stackPointer = stackPointer + 4, trueObj);
		writeImageFile(dataSize);
		/* begin pop: */
		stackPointer = stackPointer - (1 * 4);
	}
	if (successFlag) {
		/* begin push: */
		longAtput(stackPointer = stackPointer + 4, falseObj);
	} else {
		/* begin push: */
		longAtput(stackPointer = stackPointer + 4, rcvr);
	}
}

int primitiveSomeInstance(void) {
    int class;
    int instance;
    int top;
    int thisObj;
    int thisClass;
    int ccIndex;
    int obj;
    int chunk;
    int sz;
    int header;

	/* begin popStack */
	top = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	class = top;
	/* begin initialInstanceOf: */
	/* begin firstAccessibleObject */
	/* begin oopFromChunk: */
	chunk = startOfMemory();
	obj = chunk + (extraHeaderBytes(chunk));
	while (obj < endOfMemory) {
		if (!(((longAt(obj)) & 3) == 2)) {
			thisObj = obj;
			goto l4;
		}
		/* begin objectAfter: */
		if (checkAssertions) {
			if (obj >= endOfMemory) {
				error("no objects after the end of memory");
			}
		}
		if (((longAt(obj)) & 3) == 2) {
			sz = (longAt(obj)) & 536870908;
		} else {
			/* begin sizeBitsOf: */
			header = longAt(obj);
			if ((header & 3) == 0) {
				sz = (longAt(obj - 8)) & 4294967292;
				goto l3;
			} else {
				sz = header & 252;
				goto l3;
			}
		l3:	/* end sizeBitsOf: */;
		}
		obj = (obj + sz) + (extraHeaderBytes(obj + sz));
	}
	error("heap is empty");
l4:	/* end firstAccessibleObject */;
	while (!(thisObj == null)) {
		/* begin fetchClassOf: */
		if (((thisObj & 1) == 1)) {
			thisClass = longAt((specialObjectsOop + 4) + (5 * 4));
			goto l2;
		}
		ccIndex = ((((unsigned) (longAt(thisObj))) >> 12) & 31) - 1;
		if (ccIndex < 0) {
			thisClass = (longAt(thisObj - 4)) & 4294967292;
			goto l2;
		} else {
			thisClass = longAt(((longAt((specialObjectsOop + 4) + (28 * 4))) + 4) + (ccIndex * 4));
			goto l2;
		}
	l2:	/* end fetchClassOf: */;
		if (thisClass == class) {
			instance = thisObj;
			goto l1;
		}
		thisObj = accessibleObjectAfter(thisObj);
	}
	instance = nilObj;
l1:	/* end initialInstanceOf: */;
	if (instance == nilObj) {
		primitiveFail();
	} else {
		/* begin push: */
		longAtput(stackPointer = stackPointer + 4, instance);
	}
}

int primitiveSomeObject(void) {
    int object;
    int obj;
    int chunk;
    int sz;
    int header;

	/* begin pop: */
	stackPointer = stackPointer - (1 * 4);
	/* begin push: */
	/* begin firstAccessibleObject */
	/* begin oopFromChunk: */
	chunk = startOfMemory();
	obj = chunk + (extraHeaderBytes(chunk));
	while (obj < endOfMemory) {
		if (!(((longAt(obj)) & 3) == 2)) {
			object = obj;
			goto l2;
		}
		/* begin objectAfter: */
		if (checkAssertions) {
			if (obj >= endOfMemory) {
				error("no objects after the end of memory");
			}
		}
		if (((longAt(obj)) & 3) == 2) {
			sz = (longAt(obj)) & 536870908;
		} else {
			/* begin sizeBitsOf: */
			header = longAt(obj);
			if ((header & 3) == 0) {
				sz = (longAt(obj - 8)) & 4294967292;
				goto l1;
			} else {
				sz = header & 252;
				goto l1;
			}
		l1:	/* end sizeBitsOf: */;
		}
		obj = (obj + sz) + (extraHeaderBytes(obj + sz));
	}
	error("heap is empty");
l2:	/* end firstAccessibleObject */;
	longAtput(stackPointer = stackPointer + 4, object);
}

int primitiveSoundAvailableSpace(void) {
    int frames;
    int object;

	frames = snd_AvailableSpace();
	/* begin success: */
	successFlag = (frames >= 0) && successFlag;
	if (successFlag) {
		/* begin pop: */
		stackPointer = stackPointer - (1 * 4);
		/* begin push: */
		object = positive32BitIntegerFor(frames);
		longAtput(stackPointer = stackPointer + 4, object);
	}
}

int primitiveSoundPlaySamples(void) {
    int startIndex;
    int buf;
    int frameCount;
    int framesPlayed;
    int object;
    int integerPointer;
    int integerPointer1;
    int successValue;

	/* begin stackIntegerValue: */
	integerPointer = longAt(stackPointer - (0 * 4));
	if (((integerPointer & 1) == 1)) {
		startIndex = (integerPointer >> 1);
		goto l1;
	} else {
		primitiveFail();
		startIndex = 0;
		goto l1;
	}
l1:	/* end stackIntegerValue: */;
	buf = longAt(stackPointer - (1 * 4));
	/* begin stackIntegerValue: */
	integerPointer1 = longAt(stackPointer - (2 * 4));
	if (((integerPointer1 & 1) == 1)) {
		frameCount = (integerPointer1 >> 1);
		goto l2;
	} else {
		primitiveFail();
		frameCount = 0;
		goto l2;
	}
l2:	/* end stackIntegerValue: */;
	/* begin success: */
	successFlag = (((((unsigned) (longAt(buf))) >> 8) & 15) == 6) && successFlag;
	/* begin success: */
	successValue = (startIndex >= 1) && (((startIndex + frameCount) - 1) <= (lengthOf(buf)));
	successFlag = successValue && successFlag;
	if (successFlag) {
		framesPlayed = snd_PlaySamplesFromAtLength(frameCount, buf + 4, startIndex - 1);
		/* begin success: */
		successFlag = (framesPlayed >= 0) && successFlag;
	}
	if (successFlag) {
		/* begin pop: */
		stackPointer = stackPointer - (4 * 4);
		/* begin push: */
		object = positive32BitIntegerFor(framesPlayed);
		longAtput(stackPointer = stackPointer + 4, object);
	}
}

int primitiveSoundPlaySilence(void) {
    int framesPlayed;
    int object;

	framesPlayed = snd_PlaySilence();
	/* begin success: */
	successFlag = (framesPlayed >= 0) && successFlag;
	if (successFlag) {
		/* begin pop: */
		stackPointer = stackPointer - (1 * 4);
		/* begin push: */
		object = positive32BitIntegerFor(framesPlayed);
		longAtput(stackPointer = stackPointer + 4, object);
	}
}

int primitiveSoundStart(void) {
    int stereoFlag;
    int samplesPerSec;
    int bufFrames;
    int integerPointer;
    int integerPointer1;

	/* begin booleanValueOf: */
	if ((longAt(stackPointer - (0 * 4))) == trueObj) {
		stereoFlag = true;
		goto l1;
	}
	if ((longAt(stackPointer - (0 * 4))) == falseObj) {
		stereoFlag = false;
		goto l1;
	}
	successFlag = false;
	stereoFlag = null;
l1:	/* end booleanValueOf: */;
	/* begin stackIntegerValue: */
	integerPointer = longAt(stackPointer - (1 * 4));
	if (((integerPointer & 1) == 1)) {
		samplesPerSec = (integerPointer >> 1);
		goto l2;
	} else {
		primitiveFail();
		samplesPerSec = 0;
		goto l2;
	}
l2:	/* end stackIntegerValue: */;
	/* begin stackIntegerValue: */
	integerPointer1 = longAt(stackPointer - (2 * 4));
	if (((integerPointer1 & 1) == 1)) {
		bufFrames = (integerPointer1 >> 1);
		goto l3;
	} else {
		primitiveFail();
		bufFrames = 0;
		goto l3;
	}
l3:	/* end stackIntegerValue: */;
	if (successFlag) {
		/* begin success: */
		successFlag = (snd_Start(bufFrames, samplesPerSec, stereoFlag)) && successFlag;
	}
	if (successFlag) {
		/* begin pop: */
		stackPointer = stackPointer - (3 * 4);
	}
}

int primitiveSoundStop(void) {
	snd_Stop();
}

int primitiveSpecialObjectsOop(void) {
	/* begin pop: */
	stackPointer = stackPointer - (1 * 4);
	/* begin push: */
	longAtput(stackPointer = stackPointer + 4, specialObjectsOop);
}

int primitiveStringAt(void) {
	return commonAt(true);
}

int primitiveStringAtPut(void) {
	return commonAtPut(true);
}

int primitiveStringReplace(void) {
    int array;
    int start;
    int stop;
    int replacement;
    int repStart;
    int arrayInstSize;
    int repInstSize;
    int fmt;
    int repi;
    int i;
    int integerPointer;
    int integerPointer1;
    int integerPointer2;
    int classPointer;
    int fmt1;
    int classPointer1;
    int fmt2;
    int successValue;
    int successValue1;
    int ccIndex;
    int ccIndex1;

	array = longAt(stackPointer - (4 * 4));
	/* begin stackIntegerValue: */
	integerPointer = longAt(stackPointer - (3 * 4));
	if (((integerPointer & 1) == 1)) {
		start = (integerPointer >> 1);
		goto l1;
	} else {
		primitiveFail();
		start = 0;
		goto l1;
	}
l1:	/* end stackIntegerValue: */;
	/* begin stackIntegerValue: */
	integerPointer1 = longAt(stackPointer - (2 * 4));
	if (((integerPointer1 & 1) == 1)) {
		stop = (integerPointer1 >> 1);
		goto l2;
	} else {
		primitiveFail();
		stop = 0;
		goto l2;
	}
l2:	/* end stackIntegerValue: */;
	replacement = longAt(stackPointer - (1 * 4));
	/* begin stackIntegerValue: */
	integerPointer2 = longAt(stackPointer - (0 * 4));
	if (((integerPointer2 & 1) == 1)) {
		repStart = (integerPointer2 >> 1);
		goto l3;
	} else {
		primitiveFail();
		repStart = 0;
		goto l3;
	}
l3:	/* end stackIntegerValue: */;
	if (((replacement & 1) == 1)) {
		return primitiveFail();
	}
	/* begin fixedFieldsOf: */
	/* begin fetchClassOf: */
	if (((array & 1) == 1)) {
		classPointer = longAt((specialObjectsOop + 4) + (5 * 4));
		goto l4;
	}
	ccIndex = ((((unsigned) (longAt(array))) >> 12) & 31) - 1;
	if (ccIndex < 0) {
		classPointer = (longAt(array - 4)) & 4294967292;
		goto l4;
	} else {
		classPointer = longAt(((longAt((specialObjectsOop + 4) + (28 * 4))) + 4) + (ccIndex * 4));
		goto l4;
	}
l4:	/* end fetchClassOf: */;
	fmt1 = (longAt((classPointer + 4) + (2 * 4))) - 1;
	arrayInstSize = ((((unsigned) fmt1) >> 2) & 63) - 1;
	/* begin fixedFieldsOf: */
	/* begin fetchClassOf: */
	if (((replacement & 1) == 1)) {
		classPointer1 = longAt((specialObjectsOop + 4) + (5 * 4));
		goto l5;
	}
	ccIndex1 = ((((unsigned) (longAt(replacement))) >> 12) & 31) - 1;
	if (ccIndex1 < 0) {
		classPointer1 = (longAt(replacement - 4)) & 4294967292;
		goto l5;
	} else {
		classPointer1 = longAt(((longAt((specialObjectsOop + 4) + (28 * 4))) + 4) + (ccIndex1 * 4));
		goto l5;
	}
l5:	/* end fetchClassOf: */;
	fmt2 = (longAt((classPointer1 + 4) + (2 * 4))) - 1;
	repInstSize = ((((unsigned) fmt2) >> 2) & 63) - 1;
	/* begin success: */
	successFlag = (start >= 1) && successFlag;
	/* begin success: */
	successFlag = (start <= stop) && successFlag;
	/* begin success: */
	successValue = (stop + arrayInstSize) <= (lengthOf(array));
	successFlag = successValue && successFlag;
	/* begin success: */
	successFlag = (repStart >= 1) && successFlag;
	/* begin success: */
	successValue1 = (((stop - start) + repStart) + repInstSize) <= (lengthOf(replacement));
	successFlag = successValue1 && successFlag;
	fmt = (((unsigned) (longAt(array))) >> 8) & 15;
	if (fmt < 8) {
		/* begin success: */
		successFlag = (fmt == ((((unsigned) (longAt(replacement))) >> 8) & 15)) && successFlag;
	} else {
		/* begin success: */
		successFlag = ((fmt & 12) == (((((unsigned) (longAt(replacement))) >> 8) & 15) & 12)) && successFlag;
	}
	if (!(successFlag)) {
		return primitiveFail();
	}
	repi = (repStart + repInstSize) - 1;
	for (i = ((start + arrayInstSize) - 1); i <= ((stop + arrayInstSize) - 1); i++) {
		if (fmt < 4) {
			/* begin storePointer:ofObject:withValue: */
			if (array < youngStart) {
				possibleRootStoreIntovalue(array, longAt((replacement + 4) + (repi * 4)));
			}
			longAtput((array + 4) + (i * 4), longAt((replacement + 4) + (repi * 4)));
		} else {
			if (fmt < 8) {
				longAtput((array + 4) + (i * 4), longAt((replacement + 4) + (repi * 4)));
			} else {
				byteAtput((array + 4) + i, byteAt((replacement + 4) + repi));
			}
		}
		repi = repi + 1;
	}
	/* begin pop: */
	stackPointer = stackPointer - (4 * 4);
}

int primitiveSubtract(void) {
    int integerReceiver;
    int integerArgument;
    int integerPointer;
    int top;
    int integerPointer1;
    int top1;

	successFlag = true;
	/* begin popInteger */
	/* begin popStack */
	top = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	integerPointer = top;
	if (((integerPointer & 1) == 1)) {
		integerArgument = (integerPointer >> 1);
		goto l1;
	} else {
		successFlag = false;
		integerArgument = 1;
		goto l1;
	}
l1:	/* end popInteger */;
	/* begin popInteger */
	/* begin popStack */
	top1 = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	integerPointer1 = top1;
	if (((integerPointer1 & 1) == 1)) {
		integerReceiver = (integerPointer1 >> 1);
		goto l2;
	} else {
		successFlag = false;
		integerReceiver = 1;
		goto l2;
	}
l2:	/* end popInteger */;
	/* begin checkIntegerResult:from: */
	if (successFlag && (((integerReceiver - integerArgument) >= -1073741824) && ((integerReceiver - integerArgument) < 1073741824))) {
		/* begin pushInteger: */
		/* begin push: */
		longAtput(stackPointer = stackPointer + 4, (((integerReceiver - integerArgument) << 1) | 1));
	} else {
		/* begin unPop: */
		stackPointer = stackPointer + (2 * 4);
		failSpecialPrim(2);
	}
}

int primitiveSuspend(void) {
    int activeProc;
    int newProc;
    int sched;
    int oldProc;
    int valuePointer;
    int m;

	activeProc = longAt(((longAt(((longAt((specialObjectsOop + 4) + (3 * 4))) + 4) + (1 * 4))) + 4) + (1 * 4));
	/* begin success: */
	successFlag = ((longAt(stackPointer)) == activeProc) && successFlag;
	if (successFlag) {
		/* begin pop: */
		stackPointer = stackPointer - (1 * 4);
		/* begin push: */
		longAtput(stackPointer = stackPointer + 4, nilObj);
		/* begin transferTo: */
		newProc = wakeHighestPriority();
		sched = longAt(((longAt((specialObjectsOop + 4) + (3 * 4))) + 4) + (1 * 4));
		oldProc = longAt((sched + 4) + (1 * 4));
		/* begin storePointer:ofObject:withValue: */
		valuePointer = activeContext;
		if (oldProc < youngStart) {
			possibleRootStoreIntovalue(oldProc, valuePointer);
		}
		longAtput((oldProc + 4) + (1 * 4), valuePointer);
		/* begin storePointer:ofObject:withValue: */
		if (sched < youngStart) {
			possibleRootStoreIntovalue(sched, newProc);
		}
		longAtput((sched + 4) + (1 * 4), newProc);
		/* begin newActiveContext: */
		/* begin storeContextRegisters */
		longAtput((activeContext + 4) + (1 * 4), ((((instructionPointer - method) - (4 - 2)) << 1) | 1));
		longAtput((activeContext + 4) + (2 * 4), (((((((stackPointer - activeContext) - 4) / 4) - 6) + 1) << 1) | 1));
		activeContext = longAt((newProc + 4) + (1 * 4));
		if (activeContext < youngStart) {
			beRootIfOld(activeContext);
		}
		/* begin fetchContextRegisters */
		m = longAt((activeContext + 4) + (3 * 4));
		if (((m & 1) == 1)) {
			theHomeContext = longAt((activeContext + 4) + (5 * 4));
			if (theHomeContext < youngStart) {
				beRootIfOld(theHomeContext);
			}
		} else {
			theHomeContext = activeContext;
		}
		receiver = longAt((theHomeContext + 4) + (5 * 4));
		method = longAt((theHomeContext + 4) + (3 * 4));
		instructionPointer = ((longAt((activeContext + 4) + (1 * 4))) >> 1);
		instructionPointer = ((method + instructionPointer) + 4) - 2;
		stackPointer = ((longAt((activeContext + 4) + (2 * 4))) >> 1);
		stackPointer = (activeContext + 4) + (((6 + stackPointer) - 1) * 4);
		reclaimableContextCount = 0;
	}
}

int primitiveTimesTwoPower(void) {
    double rcvr;
    int arg;
    int object;
    int integerPointer;
    int top;
    int top2;
    int top1;
    int newFloat;
    int cl;
    int ccIndex;

	/* begin popInteger */
	/* begin popStack */
	top = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	integerPointer = top;
	if (((integerPointer & 1) == 1)) {
		arg = (integerPointer >> 1);
		goto l1;
	} else {
		successFlag = false;
		arg = 1;
		goto l1;
	}
l1:	/* end popInteger */;
	/* begin popFloat */
	/* begin popStack */
	top1 = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	top2 = top1;
	/* begin floatValueOf: */
	/* begin fetchClassOf: */
	if (((top2 & 1) == 1)) {
		cl = longAt((specialObjectsOop + 4) + (5 * 4));
		goto l2;
	}
	ccIndex = ((((unsigned) (longAt(top2))) >> 12) & 31) - 1;
	if (ccIndex < 0) {
		cl = (longAt(top2 - 4)) & 4294967292;
		goto l2;
	} else {
		cl = longAt(((longAt((specialObjectsOop + 4) + (28 * 4))) + 4) + (ccIndex * 4));
		goto l2;
	}
l2:	/* end fetchClassOf: */;
	/* begin success: */
	successFlag = (cl == (longAt((specialObjectsOop + 4) + (9 * 4)))) && successFlag;
	if (successFlag) {
		rcvr = floatAt(top2 + 4);
		goto l3;
	}
	rcvr = 0.0;
l3:	/* end floatValueOf: */;
	if (successFlag) {
		/* begin pushFloat: */
		/* begin push: */
		/* begin floatObjectOf: */
		newFloat = instantiateSmallClasssizeInBytesfill(longAt((specialObjectsOop + 4) + (9 * 4)), 12, 0);
		floatAtput(newFloat + 4, ldexp(rcvr, arg));
		object = newFloat;
		longAtput(stackPointer = stackPointer + 4, object);
	} else {
		/* begin unPop: */
		stackPointer = stackPointer + (2 * 4);
	}
}

int primitiveTruncated(void) {
    double rcvr;
    double frac;
    double trunc;
    int top;
    int top1;
    int cl;
    int ccIndex;

	/* begin popFloat */
	/* begin popStack */
	top1 = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	top = top1;
	/* begin floatValueOf: */
	/* begin fetchClassOf: */
	if (((top & 1) == 1)) {
		cl = longAt((specialObjectsOop + 4) + (5 * 4));
		goto l1;
	}
	ccIndex = ((((unsigned) (longAt(top))) >> 12) & 31) - 1;
	if (ccIndex < 0) {
		cl = (longAt(top - 4)) & 4294967292;
		goto l1;
	} else {
		cl = longAt(((longAt((specialObjectsOop + 4) + (28 * 4))) + 4) + (ccIndex * 4));
		goto l1;
	}
l1:	/* end fetchClassOf: */;
	/* begin success: */
	successFlag = (cl == (longAt((specialObjectsOop + 4) + (9 * 4)))) && successFlag;
	if (successFlag) {
		rcvr = floatAt(top + 4);
		goto l2;
	}
	rcvr = 0.0;
l2:	/* end floatValueOf: */;
	if (successFlag) {
		frac = modf(rcvr, &trunc);
		success((-4294967296.0 <= trunc) && (trunc <= 4294967295.0));
	}
	if (successFlag) {
		pushInteger((int) trunc);
	} else {
		/* begin unPop: */
		stackPointer = stackPointer + (1 * 4);
	}
}

int primitiveValue(void) {
    int blockContext;
    int blockArgumentCount;
    int initialIP;
    int fromIndex;
    int toIndex;
    int lastFrom;
    int m;
    int argCount;

	blockContext = longAt(stackPointer - (argumentCount * 4));
	/* begin argumentCountOfBlock: */
	argCount = longAt((blockContext + 4) + (3 * 4));
	if (((argCount & 1) == 1)) {
		blockArgumentCount = (argCount >> 1);
		goto l1;
	} else {
		primitiveFail();
		blockArgumentCount = 0;
		goto l1;
	}
l1:	/* end argumentCountOfBlock: */;
	/* begin success: */
	successFlag = (argumentCount == blockArgumentCount) && successFlag;
	if (successFlag) {
		/* begin transfer:fromIndex:ofObject:toIndex:ofObject: */
		fromIndex = (activeContext + 4) + ((((((stackPointer - activeContext) - 4) / 4) - argumentCount) + 1) * 4);
		toIndex = (blockContext + 4) + (6 * 4);
		lastFrom = fromIndex + (argumentCount * 4);
		while (fromIndex < lastFrom) {
			longAtput(toIndex, longAt(fromIndex));
			fromIndex = fromIndex + 4;
			toIndex = toIndex + 4;
		}
		/* begin pop: */
		stackPointer = stackPointer - ((argumentCount + 1) * 4);
		initialIP = longAt((blockContext + 4) + (4 * 4));
		longAtput((blockContext + 4) + (1 * 4), initialIP);
		/* begin storeStackPointerValue:inContext: */
		longAtput((blockContext + 4) + (2 * 4), ((argumentCount << 1) | 1));
		longAtput((blockContext + 4) + (0 * 4), activeContext);
		/* begin newActiveContext: */
		/* begin storeContextRegisters */
		longAtput((activeContext + 4) + (1 * 4), ((((instructionPointer - method) - (4 - 2)) << 1) | 1));
		longAtput((activeContext + 4) + (2 * 4), (((((((stackPointer - activeContext) - 4) / 4) - 6) + 1) << 1) | 1));
		activeContext = blockContext;
		if (activeContext < youngStart) {
			beRootIfOld(activeContext);
		}
		/* begin fetchContextRegisters */
		m = longAt((activeContext + 4) + (3 * 4));
		if (((m & 1) == 1)) {
			theHomeContext = longAt((activeContext + 4) + (5 * 4));
			if (theHomeContext < youngStart) {
				beRootIfOld(theHomeContext);
			}
		} else {
			theHomeContext = activeContext;
		}
		receiver = longAt((theHomeContext + 4) + (5 * 4));
		method = longAt((theHomeContext + 4) + (3 * 4));
		instructionPointer = ((longAt((activeContext + 4) + (1 * 4))) >> 1);
		instructionPointer = ((method + instructionPointer) + 4) - 2;
		stackPointer = ((longAt((activeContext + 4) + (2 * 4))) >> 1);
		stackPointer = (activeContext + 4) + (((6 + stackPointer) - 1) * 4);
	}
}

int primitiveValueWithArgs(void) {
    int argumentArray;
    int blockContext;
    int blockArgumentCount;
    int arrayClass;
    int arrayArgumentCount;
    int initialIP;
    int fromIndex;
    int toIndex;
    int lastFrom;
    int top;
    int top1;
    int argCount;
    int m;
    int ccIndex;

	/* begin popStack */
	top = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	argumentArray = top;
	/* begin popStack */
	top1 = longAt(stackPointer);
	stackPointer = stackPointer - 4;
	blockContext = top1;
	/* begin argumentCountOfBlock: */
	argCount = longAt((blockContext + 4) + (3 * 4));
	if (((argCount & 1) == 1)) {
		blockArgumentCount = (argCount >> 1);
		goto l1;
	} else {
		primitiveFail();
		blockArgumentCount = 0;
		goto l1;
	}
l1:	/* end argumentCountOfBlock: */;
	/* begin fetchClassOf: */
	if (((argumentArray & 1) == 1)) {
		arrayClass = longAt((specialObjectsOop + 4) + (5 * 4));
		goto l2;
	}
	ccIndex = ((((unsigned) (longAt(argumentArray))) >> 12) & 31) - 1;
	if (ccIndex < 0) {
		arrayClass = (longAt(argumentArray - 4)) & 4294967292;
		goto l2;
	} else {
		arrayClass = longAt(((longAt((specialObjectsOop + 4) + (28 * 4))) + 4) + (ccIndex * 4));
		goto l2;
	}
l2:	/* end fetchClassOf: */;
	/* begin success: */
	successFlag = (arrayClass == (longAt((specialObjectsOop + 4) + (7 * 4)))) && successFlag;
	if (successFlag) {
		arrayArgumentCount = fetchWordLengthOf(argumentArray);
		/* begin success: */
		successFlag = (arrayArgumentCount == blockArgumentCount) && successFlag;
	}
	if (successFlag) {
		/* begin transfer:fromIndex:ofObject:toIndex:ofObject: */
		fromIndex = (argumentArray + 4) + (0 * 4);
		toIndex = (blockContext + 4) + (6 * 4);
		lastFrom = fromIndex + (arrayArgumentCount * 4);
		while (fromIndex < lastFrom) {
			longAtput(toIndex, longAt(fromIndex));
			fromIndex = fromIndex + 4;
			toIndex = toIndex + 4;
		}
		initialIP = longAt((blockContext + 4) + (4 * 4));
		longAtput((blockContext + 4) + (1 * 4), initialIP);
		/* begin storeStackPointerValue:inContext: */
		longAtput((blockContext + 4) + (2 * 4), ((arrayArgumentCount << 1) | 1));
		longAtput((blockContext + 4) + (0 * 4), activeContext);
		/* begin newActiveContext: */
		/* begin storeContextRegisters */
		longAtput((activeContext + 4) + (1 * 4), ((((instructionPointer - method) - (4 - 2)) << 1) | 1));
		longAtput((activeContext + 4) + (2 * 4), (((((((stackPointer - activeContext) - 4) / 4) - 6) + 1) << 1) | 1));
		activeContext = blockContext;
		if (activeContext < youngStart) {
			beRootIfOld(activeContext);
		}
		/* begin fetchContextRegisters */
		m = longAt((activeContext + 4) + (3 * 4));
		if (((m & 1) == 1)) {
			theHomeContext = longAt((activeContext + 4) + (5 * 4));
			if (theHomeContext < youngStart) {
				beRootIfOld(theHomeContext);
			}
		} else {
			theHomeContext = activeContext;
		}
		receiver = longAt((theHomeContext + 4) + (5 * 4));
		method = longAt((theHomeContext + 4) + (3 * 4));
		instructionPointer = ((longAt((activeContext + 4) + (1 * 4))) >> 1);
		instructionPointer = ((method + instructionPointer) + 4) - 2;
		stackPointer = ((longAt((activeContext + 4) + (2 * 4))) >> 1);
		stackPointer = (activeContext + 4) + (((6 + stackPointer) - 1) * 4);
	} else {
		/* begin unPop: */
		stackPointer = stackPointer + (2 * 4);
	}
}

int primitiveVMPath(void) {
    int s;
    int sz;

	sz = vmPathSize();
	s = instantiateClassindexableSize(longAt((specialObjectsOop + 4) + (6 * 4)), sz);
	vmPathGetLength(s + 4, sz);
	/* begin pop: */
	stackPointer = stackPointer - (1 * 4);
	/* begin push: */
	longAtput(stackPointer = stackPointer + 4, s);
}

int primitiveWait(void) {
    int sema;
    int excessSignals;
    int activeProc;
    int lastLink;
    int newProc;
    int sched;
    int oldProc;
    int valuePointer;
    int m;
    int successValue;

	sema = longAt(stackPointer);
	/* begin success: */
	successValue = (fetchClassOf(sema)) == (longAt((specialObjectsOop + 4) + (18 * 4)));
	successFlag = successValue && successFlag;
	if (successFlag) {
		excessSignals = fetchIntegerofObject(2, sema);
		if (excessSignals > 0) {
			/* begin storeInteger:ofObject:withValue: */
			if (((excessSignals - 1) >= -1073741824) && ((excessSignals - 1) < 1073741824)) {
				longAtput((sema + 4) + (2 * 4), (((excessSignals - 1) << 1) | 1));
			} else {
				primitiveFail();
			}
		} else {
			activeProc = longAt(((longAt(((longAt((specialObjectsOop + 4) + (3 * 4))) + 4) + (1 * 4))) + 4) + (1 * 4));
			/* begin addLastLink:toList: */
			if ((longAt((sema + 4) + (0 * 4))) == nilObj) {
				/* begin storePointer:ofObject:withValue: */
				if (sema < youngStart) {
					possibleRootStoreIntovalue(sema, activeProc);
				}
				longAtput((sema + 4) + (0 * 4), activeProc);
			} else {
				lastLink = longAt((sema + 4) + (1 * 4));
				/* begin storePointer:ofObject:withValue: */
				if (lastLink < youngStart) {
					possibleRootStoreIntovalue(lastLink, activeProc);
				}
				longAtput((lastLink + 4) + (0 * 4), activeProc);
			}
			/* begin storePointer:ofObject:withValue: */
			if (sema < youngStart) {
				possibleRootStoreIntovalue(sema, activeProc);
			}
			longAtput((sema + 4) + (1 * 4), activeProc);
			/* begin storePointer:ofObject:withValue: */
			if (activeProc < youngStart) {
				possibleRootStoreIntovalue(activeProc, sema);
			}
			longAtput((activeProc + 4) + (3 * 4), sema);
			/* begin transferTo: */
			newProc = wakeHighestPriority();
			sched = longAt(((longAt((specialObjectsOop + 4) + (3 * 4))) + 4) + (1 * 4));
			oldProc = longAt((sched + 4) + (1 * 4));
			/* begin storePointer:ofObject:withValue: */
			valuePointer = activeContext;
			if (oldProc < youngStart) {
				possibleRootStoreIntovalue(oldProc, valuePointer);
			}
			longAtput((oldProc + 4) + (1 * 4), valuePointer);
			/* begin storePointer:ofObject:withValue: */
			if (sched < youngStart) {
				possibleRootStoreIntovalue(sched, newProc);
			}
			longAtput((sched + 4) + (1 * 4), newProc);
			/* begin newActiveContext: */
			/* begin storeContextRegisters */
			longAtput((activeContext + 4) + (1 * 4), ((((instructionPointer - method) - (4 - 2)) << 1) | 1));
			longAtput((activeContext + 4) + (2 * 4), (((((((stackPointer - activeContext) - 4) / 4) - 6) + 1) << 1) | 1));
			activeContext = longAt((newProc + 4) + (1 * 4));
			if (activeContext < youngStart) {
				beRootIfOld(activeContext);
			}
			/* begin fetchContextRegisters */
			m = longAt((activeContext + 4) + (3 * 4));
			if (((m & 1) == 1)) {
				theHomeContext = longAt((activeContext + 4) + (5 * 4));
				if (theHomeContext < youngStart) {
					beRootIfOld(theHomeContext);
				}
			} else {
				theHomeContext = activeContext;
			}
			receiver = longAt((theHomeContext + 4) + (5 * 4));
			method = longAt((theHomeContext + 4) + (3 * 4));
			instructionPointer = ((longAt((activeContext + 4) + (1 * 4))) >> 1);
			instructionPointer = ((method + instructionPointer) + 4) - 2;
			stackPointer = ((longAt((activeContext + 4) + (2 * 4))) >> 1);
			stackPointer = (activeContext + 4) + (((6 + stackPointer) - 1) * 4);
			reclaimableContextCount = 0;
		}
	}
}

int primitiveWarpBits(void) {
    int rcvr;
    int ns;
    int successValue;
    int skewWord;
    int halftoneWord;
    int mergeWord;
    int i;
    int word;
    int destMask;
    int startBits;
    int deltaP12x;
    int deltaP12y;
    int deltaP43x;
    int deltaP43y;
    int pAx;
    int pAy;
    int xDelta;
    int yDelta;
    int pBx;
    int pBy;
    int smoothingCount;
    int sourceMapOop;
    int nSteps;
    int integerPointer;
    int destinationWord;
    int delta;
    int delta1;
    int x2;
    int delta2;
    int x21;
    int delta3;
    int x22;
    int delta4;
    int x23;
    int delta5;

	rcvr = longAt(stackPointer - (argumentCount * 4));
	/* begin success: */
	successValue = loadBitBltFrom(rcvr);
	successFlag = successValue && successFlag;
	if (successFlag) {
		/* begin warpBits */
		ns = noSource;
		noSource = true;
		clipRange();
		noSource = ns;
		if (noSource || ((bbW <= 0) || (bbH <= 0))) {
			affectedL = affectedR = affectedT = affectedB = 0;
			goto l1;
		}
		destMaskAndPointerInit();
		/* begin warpLoop */
		if (!((fetchWordLengthOf(bitBltOop)) >= (15 + 12))) {
			primitiveFail();
			goto l10;
		}
		nSteps = height - 1;
		if (nSteps <= 0) {
			nSteps = 1;
		}
		pAx = fetchIntegerofObject(15, bitBltOop);
		/* begin deltaFrom:to:nSteps: */
		x2 = fetchIntegerofObject(15 + 3, bitBltOop);
		delta2 = x2 - pAx;
		if (delta2 > 0) {
			deltaP12x = (delta2 - 1) / nSteps;
			goto l5;
		} else {
			if (delta2 == 0) {
				deltaP12x = 0;
				goto l5;
			} else {
				deltaP12x = (delta2 + 2) / nSteps;
				goto l5;
			}
		}
	l5:	/* end deltaFrom:to:nSteps: */;
		if (deltaP12x < 0) {
			pAx = pAx - 1;
		}
		pAy = fetchIntegerofObject(15 + 1, bitBltOop);
		/* begin deltaFrom:to:nSteps: */
		x21 = fetchIntegerofObject(15 + 4, bitBltOop);
		delta3 = x21 - pAy;
		if (delta3 > 0) {
			deltaP12y = (delta3 - 1) / nSteps;
			goto l6;
		} else {
			if (delta3 == 0) {
				deltaP12y = 0;
				goto l6;
			} else {
				deltaP12y = (delta3 + 2) / nSteps;
				goto l6;
			}
		}
	l6:	/* end deltaFrom:to:nSteps: */;
		if (deltaP12y < 0) {
			pAy = pAy - 1;
		}
		pBx = fetchIntegerofObject(15 + 9, bitBltOop);
		/* begin deltaFrom:to:nSteps: */
		x22 = fetchIntegerofObject(15 + 6, bitBltOop);
		delta4 = x22 - pBx;
		if (delta4 > 0) {
			deltaP43x = (delta4 - 1) / nSteps;
			goto l7;
		} else {
			if (delta4 == 0) {
				deltaP43x = 0;
				goto l7;
			} else {
				deltaP43x = (delta4 + 2) / nSteps;
				goto l7;
			}
		}
	l7:	/* end deltaFrom:to:nSteps: */;
		if (deltaP43x < 0) {
			pBx = pBx - 1;
		}
		pBy = fetchIntegerofObject(15 + 10, bitBltOop);
		/* begin deltaFrom:to:nSteps: */
		x23 = fetchIntegerofObject(15 + 7, bitBltOop);
		delta5 = x23 - pBy;
		if (delta5 > 0) {
			deltaP43y = (delta5 - 1) / nSteps;
			goto l8;
		} else {
			if (delta5 == 0) {
				deltaP43y = 0;
				goto l8;
			} else {
				deltaP43y = (delta5 + 2) / nSteps;
				goto l8;
			}
		}
	l8:	/* end deltaFrom:to:nSteps: */;
		if (deltaP43y < 0) {
			pBy = pBy - 1;
		}
		if (!successFlag) {
			goto l10;
		}
		if (argumentCount == 2) {
			/* begin stackIntegerValue: */
			integerPointer = longAt(stackPointer - (1 * 4));
			if (((integerPointer & 1) == 1)) {
				smoothingCount = (integerPointer >> 1);
				goto l9;
			} else {
				primitiveFail();
				smoothingCount = 0;
				goto l9;
			}
		l9:	/* end stackIntegerValue: */;
			sourceMapOop = longAt(stackPointer - (0 * 4));
			if (sourceMapOop == nilObj) {
				if (destPixSize < 16) {
					primitiveFail();
					goto l10;
				}
			} else {
				if ((fetchWordLengthOf(sourceMapOop)) < (1 << sourcePixSize)) {
					primitiveFail();
					goto l10;
				}
			}
		} else {
			smoothingCount = 1;
			sourceMapOop = nilObj;
		}
		startBits = pixPerWord - (dx & (pixPerWord - 1));
		nSteps = width - 1;
		if (nSteps <= 0) {
			nSteps = 1;
		}
		for (i = 1; i <= bbH; i += 1) {
			/* begin deltaFrom:to:nSteps: */
			delta = pBx - pAx;
			if (delta > 0) {
				xDelta = (delta - 1) / nSteps;
				goto l3;
			} else {
				if (delta == 0) {
					xDelta = 0;
					goto l3;
				} else {
					xDelta = (delta + 2) / nSteps;
					goto l3;
				}
			}
		l3:	/* end deltaFrom:to:nSteps: */;
			if (xDelta >= 0) {
				sx = pAx;
			} else {
				sx = pAx - 1;
			}
			/* begin deltaFrom:to:nSteps: */
			delta1 = pBy - pAy;
			if (delta1 > 0) {
				yDelta = (delta1 - 1) / nSteps;
				goto l4;
			} else {
				if (delta1 == 0) {
					yDelta = 0;
					goto l4;
				} else {
					yDelta = (delta1 + 2) / nSteps;
					goto l4;
				}
			}
		l4:	/* end deltaFrom:to:nSteps: */;
			if (yDelta >= 0) {
				sy = pAy;
			} else {
				sy = pAy - 1;
			}
			if (noHalftone) {
				halftoneWord = 4294967295;
			} else {
				halftoneWord = longAt(halftoneBase + ((((dy + i) - 1) % halftoneHeight) * 4));
			}
			destMask = mask1;
			if (bbW < startBits) {
				skewWord = warpSourcePixelsxDeltahyDeltahxDeltavyDeltavsmoothingsourceMap(bbW, xDelta, yDelta, deltaP12x, deltaP12y, smoothingCount, sourceMapOop);
				skewWord = ((((startBits - bbW) * destPixSize) < 0) ? ((unsigned) skewWord >> -((startBits - bbW) * destPixSize)) : ((unsigned) skewWord << ((startBits - bbW) * destPixSize)));
			} else {
				skewWord = warpSourcePixelsxDeltahyDeltahxDeltavyDeltavsmoothingsourceMap(startBits, xDelta, yDelta, deltaP12x, deltaP12y, smoothingCount, sourceMapOop);
			}
			for (word = 1; word <= nWords; word += 1) {
				/* begin merge:with: */
				destinationWord = (longAt(destIndex)) & destMask;
				if (combinationRule < 16) {
					if (combinationRule < 8) {
						if (combinationRule < 4) {
							if (combinationRule < 2) {
								if (combinationRule < 1) {
									mergeWord = 0;
									goto l2;
								} else {
									mergeWord = (skewWord & halftoneWord) & destinationWord;
									goto l2;
								}
							} else {
								if (combinationRule < 3) {
									mergeWord = (skewWord & halftoneWord) & (~destinationWord);
									goto l2;
								} else {
									mergeWord = skewWord & halftoneWord;
									goto l2;
								}
							}
						} else {
							if (combinationRule < 6) {
								if (combinationRule < 5) {
									mergeWord = (~(skewWord & halftoneWord)) & destinationWord;
									goto l2;
								} else {
									mergeWord = destinationWord;
									goto l2;
								}
							} else {
								if (combinationRule < 7) {
									mergeWord = (skewWord & halftoneWord) ^ destinationWord;
									goto l2;
								} else {
									mergeWord = (skewWord & halftoneWord) | destinationWord;
									goto l2;
								}
							}
						}
					} else {
						if (combinationRule < 12) {
							if (combinationRule < 10) {
								if (combinationRule < 9) {
									mergeWord = (~(skewWord & halftoneWord)) & (~destinationWord);
									goto l2;
								} else {
									mergeWord = (~(skewWord & halftoneWord)) ^ destinationWord;
									goto l2;
								}
							} else {
								if (combinationRule < 11) {
									mergeWord = ~destinationWord;
									goto l2;
								} else {
									mergeWord = (skewWord & halftoneWord) | (~destinationWord);
									goto l2;
								}
							}
						} else {
							if (combinationRule < 14) {
								if (combinationRule < 13) {
									mergeWord = ~(skewWord & halftoneWord);
									goto l2;
								} else {
									mergeWord = (~(skewWord & halftoneWord)) | destinationWord;
									goto l2;
								}
							} else {
								if (combinationRule < 15) {
									mergeWord = (~(skewWord & halftoneWord)) | (~destinationWord);
									goto l2;
								} else {
									mergeWord = destinationWord;
									goto l2;
								}
							}
						}
					}
				} else {
					if (combinationRule < 24) {
						if (combinationRule < 20) {
							if (combinationRule < 18) {
								if (combinationRule < 17) {
									mergeWord = destinationWord;
									goto l2;
								} else {
									mergeWord = destinationWord;
									goto l2;
								}
							} else {
								if (combinationRule < 19) {
									mergeWord = (skewWord & halftoneWord) + destinationWord;
									goto l2;
								} else {
									mergeWord = (skewWord & halftoneWord) - destinationWord;
									goto l2;
								}
							}
						} else {
							if (combinationRule < 22) {
								if (combinationRule < 21) {
									mergeWord = rgbAddwith(skewWord & halftoneWord, destinationWord);
									goto l2;
								} else {
									mergeWord = rgbSubwith(skewWord & halftoneWord, destinationWord);
									goto l2;
								}
							} else {
								if (combinationRule < 23) {
									mergeWord = rgbDiffwith(skewWord & halftoneWord, destinationWord);
									goto l2;
								} else {
									mergeWord = tallyIntoMap(destinationWord);
									goto l2;
								}
							}
						}
					} else {
						if (combinationRule < 28) {
							if (combinationRule < 26) {
								if (combinationRule < 25) {
									mergeWord = alphaBlendwith(skewWord & halftoneWord, destinationWord);
									goto l2;
								} else {
									mergeWord = pixPaintwith(skewWord & halftoneWord, destinationWord);
									goto l2;
								}
							} else {
								if (combinationRule < 27) {
									mergeWord = pixMaskwith(skewWord & halftoneWord, destinationWord);
									goto l2;
								} else {
									mergeWord = destinationWord;
									goto l2;
								}
							}
						} else {
							if (combinationRule < 30) {
								if (combinationRule < 29) {
									mergeWord = destinationWord;
									goto l2;
								} else {
									mergeWord = destinationWord;
									goto l2;
								}
							} else {
								if (combinationRule < 31) {
									mergeWord = destinationWord;
									goto l2;
								} else {
									mergeWord = destinationWord;
									goto l2;
								}
							}
						}
					}
				}
			l2:	/* end merge:with: */;
				longAtput(destIndex, (destMask & mergeWord) | ((~destMask) & (longAt(destIndex))));
				destIndex = destIndex + 4;
				if (word >= (nWords - 1)) {
					if (!(word == nWords)) {
						destMask = mask2;
						skewWord = warpSourcePixelsxDeltahyDeltahxDeltavyDeltavsmoothingsourceMap(pixPerWord, xDelta, yDelta, deltaP12x, deltaP12y, smoothingCount, sourceMapOop);
					}
				} else {
					destMask = 4294967295;
					skewWord = warpSourcePixelsxDeltahyDeltahxDeltavyDeltavsmoothingsourceMap(pixPerWord, xDelta, yDelta, deltaP12x, deltaP12y, smoothingCount, sourceMapOop);
				}
			}
			pAx = pAx + deltaP12x;
			pAy = pAy + deltaP12y;
			pBx = pBx + deltaP43x;
			pBy = pBy + deltaP43y;
			destIndex = destIndex + destDelta;
		}
	l10:	/* end warpLoop */;
		if (hDir > 0) {
			affectedL = dx;
			affectedR = dx + bbW;
		} else {
			affectedL = dx - bbW;
			affectedR = dx;
		}
		if (vDir > 0) {
			affectedT = dy;
			affectedB = dy + bbH;
		} else {
			affectedT = dy - bbH;
			affectedB = dy;
		}
	l1:	/* end warpBits */;
		if (destForm == (longAt((specialObjectsOop + 4) + (14 * 4)))) {
			showDisplayBits();
		}
	}
}

int print(char *s) {
	printf("%s", s);
}

int printCallStack(void) {
    int ctxt;
    int home;
    int methodClass;
    int methodSel;
    int currClass;
    int classDict;
    int classDictSize;
    int methodArray;
    int i;
    int done;
    int currClass1;
    int done1;
    int classDict1;
    int classDictSize1;
    int methodArray1;
    int i1;
    int ccIndex;
    int ccIndex1;
    int ccIndex2;

	ctxt = activeContext;
	while (!(ctxt == nilObj)) {
		if ((fetchClassOf(ctxt)) == (longAt((specialObjectsOop + 4) + (11 * 4)))) {
			home = longAt((ctxt + 4) + (5 * 4));
		} else {
			home = ctxt;
		}
		/* begin findClassOfMethod:forReceiver: */
		/* begin fetchClassOf: */
		if ((((longAt((home + 4) + (5 * 4))) & 1) == 1)) {
			currClass = longAt((specialObjectsOop + 4) + (5 * 4));
			goto l3;
		}
		ccIndex = ((((unsigned) (longAt(longAt((home + 4) + (5 * 4))))) >> 12) & 31) - 1;
		if (ccIndex < 0) {
			currClass = (longAt((longAt((home + 4) + (5 * 4))) - 4)) & 4294967292;
			goto l3;
		} else {
			currClass = longAt(((longAt((specialObjectsOop + 4) + (28 * 4))) + 4) + (ccIndex * 4));
			goto l3;
		}
	l3:	/* end fetchClassOf: */;
		done = false;
		while (!(done)) {
			classDict = longAt((currClass + 4) + (1 * 4));
			classDictSize = fetchWordLengthOf(classDict);
			methodArray = longAt((classDict + 4) + (1 * 4));
			i = 0;
			while (i < (classDictSize - 2)) {
				if ((longAt((home + 4) + (3 * 4))) == (longAt((methodArray + 4) + (i * 4)))) {
					methodClass = currClass;
					goto l1;
				}
				i = i + 1;
			}
			currClass = longAt((currClass + 4) + (0 * 4));
			done = currClass == nilObj;
		}
		/* begin fetchClassOf: */
		if ((((longAt((home + 4) + (5 * 4))) & 1) == 1)) {
			methodClass = longAt((specialObjectsOop + 4) + (5 * 4));
			goto l4;
		}
		ccIndex1 = ((((unsigned) (longAt(longAt((home + 4) + (5 * 4))))) >> 12) & 31) - 1;
		if (ccIndex1 < 0) {
			methodClass = (longAt((longAt((home + 4) + (5 * 4))) - 4)) & 4294967292;
			goto l4;
		} else {
			methodClass = longAt(((longAt((specialObjectsOop + 4) + (28 * 4))) + 4) + (ccIndex1 * 4));
			goto l4;
		}
	l4:	/* end fetchClassOf: */;
	l1:	/* end findClassOfMethod:forReceiver: */;
		/* begin findSelectorOfMethod:forReceiver: */
		/* begin fetchClassOf: */
		if ((((longAt((home + 4) + (5 * 4))) & 1) == 1)) {
			currClass1 = longAt((specialObjectsOop + 4) + (5 * 4));
			goto l5;
		}
		ccIndex2 = ((((unsigned) (longAt(longAt((home + 4) + (5 * 4))))) >> 12) & 31) - 1;
		if (ccIndex2 < 0) {
			currClass1 = (longAt((longAt((home + 4) + (5 * 4))) - 4)) & 4294967292;
			goto l5;
		} else {
			currClass1 = longAt(((longAt((specialObjectsOop + 4) + (28 * 4))) + 4) + (ccIndex2 * 4));
			goto l5;
		}
	l5:	/* end fetchClassOf: */;
		done1 = false;
		while (!(done1)) {
			classDict1 = longAt((currClass1 + 4) + (1 * 4));
			classDictSize1 = fetchWordLengthOf(classDict1);
			methodArray1 = longAt((classDict1 + 4) + (1 * 4));
			i1 = 0;
			while (i1 <= (classDictSize1 - 2)) {
				if ((longAt((home + 4) + (3 * 4))) == (longAt((methodArray1 + 4) + (i1 * 4)))) {
					methodSel = longAt((classDict1 + 4) + ((i1 + 2) * 4));
					goto l2;
				}
				i1 = i1 + 1;
			}
			currClass1 = longAt((currClass1 + 4) + (0 * 4));
			done1 = currClass1 == nilObj;
		}
		methodSel = longAt((specialObjectsOop + 4) + (20 * 4));
	l2:	/* end findSelectorOfMethod:forReceiver: */;
		printNum(ctxt);
		print(" ");
		if (!(ctxt == home)) {
			print("[] in ");
		}
		printNameOfClasscount(methodClass, 5);
		print(">");
		printStringOf(methodSel);
		/* begin cr */
		printf("\n");
		ctxt = longAt((ctxt + 4) + (0 * 4));
	}
}

int printChar(int aByte) {
	putchar(aByte);
}

int printNameOfClasscount(int classOop, int cnt) {
	if (cnt <= 0) {
		return print("bad class");
	}
	if ((sizeBitsOf(classOop)) == 32) {
		printNameOfClasscount(longAt((classOop + 4) + (6 * 4)), cnt - 1);
		print(" class");
	} else {
		printStringOf(longAt((classOop + 4) + (6 * 4)));
	}
}

int printNum(int n) {
	printf("%ld", (long) n);
}

int printStringOf(int oop) {
    int fmt;
    int cnt;
    int i;

	fmt = (((unsigned) (longAt(oop))) >> 8) & 15;
	if (fmt < 8) {
		return null;
	}
	cnt = ((100 < (lengthOf(oop))) ? 100 : (lengthOf(oop)));
	i = 0;
	while (i < cnt) {
		/* begin printChar: */
		putchar(byteAt((oop + 4) + i));
		i = i + 1;
	}
}

int push(int object) {
	longAtput(stackPointer = stackPointer + 4, object);
}

int pushBool(int trueOrFalse) {
	if (trueOrFalse) {
		/* begin push: */
		longAtput(stackPointer = stackPointer + 4, trueObj);
	} else {
		/* begin push: */
		longAtput(stackPointer = stackPointer + 4, falseObj);
	}
}

int pushFloat(int f) {
    int object;
    int newFloat;

	/* begin push: */
	/* begin floatObjectOf: */
	newFloat = instantiateSmallClasssizeInBytesfill(longAt((specialObjectsOop + 4) + (9 * 4)), 12, 0);
	floatAtput(newFloat + 4, f);
	object = newFloat;
	longAtput(stackPointer = stackPointer + 4, object);
}

int pushInteger(int integerValue) {
	/* begin push: */
	longAtput(stackPointer = stackPointer + 4, ((integerValue << 1) | 1));
}

int pushRemappableOop(int oop) {
	remapBuffer[remapBufferCount = remapBufferCount + 1] = oop;
}

int putToSleep(int aProcess) {
    int priority;
    int processLists;
    int processList;
    int lastLink;

	priority = ((longAt((aProcess + 4) + (2 * 4))) >> 1);
	processLists = longAt(((longAt(((longAt((specialObjectsOop + 4) + (3 * 4))) + 4) + (1 * 4))) + 4) + (0 * 4));
	processList = longAt((processLists + 4) + ((priority - 1) * 4));
	/* begin addLastLink:toList: */
	if ((longAt((processList + 4) + (0 * 4))) == nilObj) {
		/* begin storePointer:ofObject:withValue: */
		if (processList < youngStart) {
			possibleRootStoreIntovalue(processList, aProcess);
		}
		longAtput((processList + 4) + (0 * 4), aProcess);
	} else {
		lastLink = longAt((processList + 4) + (1 * 4));
		/* begin storePointer:ofObject:withValue: */
		if (lastLink < youngStart) {
			possibleRootStoreIntovalue(lastLink, aProcess);
		}
		longAtput((lastLink + 4) + (0 * 4), aProcess);
	}
	/* begin storePointer:ofObject:withValue: */
	if (processList < youngStart) {
		possibleRootStoreIntovalue(processList, aProcess);
	}
	longAtput((processList + 4) + (1 * 4), aProcess);
	/* begin storePointer:ofObject:withValue: */
	if (aProcess < youngStart) {
		possibleRootStoreIntovalue(aProcess, processList);
	}
	longAtput((aProcess + 4) + (3 * 4), processList);
}

int quickCheckForInterrupts(void) {
	if ((interruptCheckCounter = interruptCheckCounter - 1) <= 0) {
		interruptCheckCounter = 1000;
		checkForInterrupts();
	}
}

int quickFetchIntegerofObject(int fieldIndex, int objectPointer) {
	return ((longAt((objectPointer + 4) + (fieldIndex * 4))) >> 1);
}

int recycleContextIfPossible(int contextOop) {
    int sz;
    int header;

	if (!(contextOop >= youngStart)) {
		return null;
	}
	/* begin sizeBitsOf: */
	header = longAt(contextOop);
	if ((header & 3) == 0) {
		sz = (longAt(contextOop - 8)) & 4294967292;
		goto l1;
	} else {
		sz = header & 252;
		goto l1;
	}
l1:	/* end sizeBitsOf: */;
	if (sz == 76) {
		longAtput((contextOop + 4) + (0 * 4), freeSmallContexts);
		freeSmallContexts = contextOop;
	} else {
		longAtput((contextOop + 4) + (0 * 4), freeLargeContexts);
		freeLargeContexts = contextOop;
	}
}

int remap(int oop) {
    int fwdBlock;

	if (((oop & 1) == 0) && (((longAt(oop)) & 2147483648) != 0)) {
		fwdBlock = (longAt(oop)) & 2147483644;
		if (checkAssertions) {
			/* begin fwdBlockValidate: */
			if (!((fwdBlock > endOfMemory) && ((fwdBlock <= fwdTableNext) && ((fwdBlock & 3) == 0)))) {
				error("invalid fwd table entry");
			}
		}
		return longAt(fwdBlock);
	}
	return oop;
}

int remapClassOf(int oop) {
    int classHeader;
    int classOop;
    int fwdBlock;
    int newClassOop;
    int newClassHeader;

	if (((longAt(oop)) & 3) == 3) {
		return null;
	}
	classHeader = longAt(oop - 4);
	classOop = classHeader & 4294967292;
	if (((classOop & 1) == 0) && (((longAt(classOop)) & 2147483648) != 0)) {
		fwdBlock = (longAt(classOop)) & 2147483644;
		if (checkAssertions) {
			/* begin fwdBlockValidate: */
			if (!((fwdBlock > endOfMemory) && ((fwdBlock <= fwdTableNext) && ((fwdBlock & 3) == 0)))) {
				error("invalid fwd table entry");
			}
		}
		newClassOop = longAt(fwdBlock);
		newClassHeader = newClassOop | (classHeader & 3);
		longAtput(oop - 4, newClassHeader);
		if ((oop < youngStart) && (newClassOop >= youngStart)) {
			beRootWhileForwarding(oop);
		}
	}
}

int remapFieldsAndClassOf(int oop) {
    int fieldOffset;
    int fieldOop;
    int fwdBlock;
    int newOop;
    int header;
    int fwdBlock1;
    int fmt;
    int size;
    int methodHeader;
    int classHeader;
    int classOop;
    int fwdBlock2;
    int newClassOop;
    int newClassHeader;

	/* begin lastPointerWhileForwarding: */
	header = longAt(oop);
	if ((header & 2147483648) != 0) {
		fwdBlock1 = header & 2147483644;
		if (checkAssertions) {
			/* begin fwdBlockValidate: */
			if (!((fwdBlock1 > endOfMemory) && ((fwdBlock1 <= fwdTableNext) && ((fwdBlock1 & 3) == 0)))) {
				error("invalid fwd table entry");
			}
		}
		header = longAt(fwdBlock1 + 4);
	}
	fmt = (((unsigned) header) >> 8) & 15;
	if (fmt < 4) {
		if ((header & 3) == 0) {
			size = (longAt(oop - 8)) & 268435452;
		} else {
			size = header & 252;
		}
		fieldOffset = size - 4;
		goto l1;
	}
	if (fmt < 12) {
		fieldOffset = 0;
		goto l1;
	}
	methodHeader = longAt(oop + 4);
	fieldOffset = (((((unsigned) methodHeader) >> 10) & 255) * 4) + 4;
l1:	/* end lastPointerWhileForwarding: */;
	while (fieldOffset >= 4) {
		fieldOop = longAt(oop + fieldOffset);
		if (((fieldOop & 1) == 0) && (((longAt(fieldOop)) & 2147483648) != 0)) {
			fwdBlock = (longAt(fieldOop)) & 2147483644;
			if (checkAssertions) {
				/* begin fwdBlockValidate: */
				if (!((fwdBlock > endOfMemory) && ((fwdBlock <= fwdTableNext) && ((fwdBlock & 3) == 0)))) {
					error("invalid fwd table entry");
				}
			}
			newOop = longAt(fwdBlock);
			longAtput(oop + fieldOffset, newOop);
			if ((oop < youngStart) && (newOop >= youngStart)) {
				beRootWhileForwarding(oop);
			}
		}
		fieldOffset = fieldOffset - 4;
	}
	/* begin remapClassOf: */
	if (((longAt(oop)) & 3) == 3) {
		goto l2;
	}
	classHeader = longAt(oop - 4);
	classOop = classHeader & 4294967292;
	if (((classOop & 1) == 0) && (((longAt(classOop)) & 2147483648) != 0)) {
		fwdBlock2 = (longAt(classOop)) & 2147483644;
		if (checkAssertions) {
			/* begin fwdBlockValidate: */
			if (!((fwdBlock2 > endOfMemory) && ((fwdBlock2 <= fwdTableNext) && ((fwdBlock2 & 3) == 0)))) {
				error("invalid fwd table entry");
			}
		}
		newClassOop = longAt(fwdBlock2);
		newClassHeader = newClassOop | (classHeader & 3);
		longAtput(oop - 4, newClassHeader);
		if ((oop < youngStart) && (newClassOop >= youngStart)) {
			beRootWhileForwarding(oop);
		}
	}
l2:	/* end remapClassOf: */;
}

int removeFirstLinkOfList(int aList) {
    int first;
    int last;
    int next;
    int valuePointer;
    int valuePointer1;
    int valuePointer2;

	first = longAt((aList + 4) + (0 * 4));
	last = longAt((aList + 4) + (1 * 4));
	if (first == last) {
		/* begin storePointer:ofObject:withValue: */
		valuePointer = nilObj;
		if (aList < youngStart) {
			possibleRootStoreIntovalue(aList, valuePointer);
		}
		longAtput((aList + 4) + (0 * 4), valuePointer);
		/* begin storePointer:ofObject:withValue: */
		valuePointer1 = nilObj;
		if (aList < youngStart) {
			possibleRootStoreIntovalue(aList, valuePointer1);
		}
		longAtput((aList + 4) + (1 * 4), valuePointer1);
	} else {
		next = longAt((first + 4) + (0 * 4));
		/* begin storePointer:ofObject:withValue: */
		if (aList < youngStart) {
			possibleRootStoreIntovalue(aList, next);
		}
		longAtput((aList + 4) + (0 * 4), next);
	}
	/* begin storePointer:ofObject:withValue: */
	valuePointer2 = nilObj;
	if (first < youngStart) {
		possibleRootStoreIntovalue(first, valuePointer2);
	}
	longAtput((first + 4) + (0 * 4), valuePointer2);
	return first;
}

int reportContexts(void) {
    int cntxt;
    int big;
    int small;

	big = 0;
	cntxt = freeLargeContexts;
	while (!(cntxt == 1)) {
		big = big + 1;
		cntxt = longAt((cntxt + 4) + (0 * 4));
	}
	small = 0;
	cntxt = freeSmallContexts;
	while (!(cntxt == 1)) {
		small = small + 1;
		cntxt = longAt((cntxt + 4) + (0 * 4));
	}
	print("Recycled contexts: ");
	printNum(small);
	print(" small, ");
	printNum(big);
	print(" large (");
	printNum((big * 156) + (small * 76));
	print(" bytes)");
	/* begin cr */
	printf("\n");
}

int restoreHeaderOf(int oop) {
    int fwdHeader;
    int fwdBlock;

	fwdHeader = longAt(oop);
	fwdBlock = fwdHeader & 2147483644;
	if (checkAssertions) {
		if ((fwdHeader & 2147483648) == 0) {
			error("attempting to restore the header of an object that has no forwarding block");
		}
		/* begin fwdBlockValidate: */
		if (!((fwdBlock > endOfMemory) && ((fwdBlock <= fwdTableNext) && ((fwdBlock & 3) == 0)))) {
			error("invalid fwd table entry");
		}
	}
	longAtput(oop, longAt(fwdBlock + 4));
}

int restoreHeadersAfterBecomingwith(int list1, int list2) {
    int fieldOffset;
    int oop1;
    int oop2;
    int fwdHeader;
    int fwdBlock;
    int fwdHeader1;
    int fwdBlock1;
    int hdr1;
    int hdr2;
    int fmt;
    int sz;
    int methodHeader;
    int header;
    int type;

	/* begin lastPointerOf: */
	fmt = (((unsigned) (longAt(list1))) >> 8) & 15;
	if (fmt < 4) {
		/* begin sizeBitsOfSafe: */
		header = longAt(list1);
		/* begin rightType: */
		if ((header & 252) == 0) {
			type = 0;
			goto l2;
		} else {
			if ((header & 126976) == 0) {
				type = 1;
				goto l2;
			} else {
				type = 3;
				goto l2;
			}
		}
	l2:	/* end rightType: */;
		if (type == 0) {
			sz = (longAt(list1 - 8)) & 4294967292;
			goto l3;
		} else {
			sz = header & 252;
			goto l3;
		}
	l3:	/* end sizeBitsOfSafe: */;
		fieldOffset = sz - 4;
		goto l1;
	}
	if (fmt < 12) {
		fieldOffset = 0;
		goto l1;
	}
	methodHeader = longAt(list1 + 4);
	fieldOffset = (((((unsigned) methodHeader) >> 10) & 255) * 4) + 4;
l1:	/* end lastPointerOf: */;
	while (fieldOffset >= 4) {
		oop1 = longAt(list1 + fieldOffset);
		oop2 = longAt(list2 + fieldOffset);
		/* begin restoreHeaderOf: */
		fwdHeader = longAt(oop1);
		fwdBlock = fwdHeader & 2147483644;
		if (checkAssertions) {
			if ((fwdHeader & 2147483648) == 0) {
				error("attempting to restore the header of an object that has no forwarding block");
			}
			/* begin fwdBlockValidate: */
			if (!((fwdBlock > endOfMemory) && ((fwdBlock <= fwdTableNext) && ((fwdBlock & 3) == 0)))) {
				error("invalid fwd table entry");
			}
		}
		longAtput(oop1, longAt(fwdBlock + 4));
		/* begin restoreHeaderOf: */
		fwdHeader1 = longAt(oop2);
		fwdBlock1 = fwdHeader1 & 2147483644;
		if (checkAssertions) {
			if ((fwdHeader1 & 2147483648) == 0) {
				error("attempting to restore the header of an object that has no forwarding block");
			}
			/* begin fwdBlockValidate: */
			if (!((fwdBlock1 > endOfMemory) && ((fwdBlock1 <= fwdTableNext) && ((fwdBlock1 & 3) == 0)))) {
				error("invalid fwd table entry");
			}
		}
		longAtput(oop2, longAt(fwdBlock1 + 4));
		/* begin exchangeHashBits:with: */
		hdr1 = longAt(oop1);
		hdr2 = longAt(oop2);
		longAtput(oop1, (hdr1 & 3758227455) | (hdr2 & 536739840));
		longAtput(oop2, (hdr2 & 3758227455) | (hdr1 & 536739840));
		fieldOffset = fieldOffset - 4;
	}
}

int resume(int aProcess) {
    int activeProc;
    int activePriority;
    int newPriority;
    int sched;
    int oldProc;
    int valuePointer;
    int m;
    int priority;
    int processLists;
    int processList;
    int lastLink;
    int priority1;
    int processLists1;
    int processList1;
    int lastLink1;

	activeProc = longAt(((longAt(((longAt((specialObjectsOop + 4) + (3 * 4))) + 4) + (1 * 4))) + 4) + (1 * 4));
	activePriority = ((longAt((activeProc + 4) + (2 * 4))) >> 1);
	newPriority = ((longAt((aProcess + 4) + (2 * 4))) >> 1);
	if (newPriority > activePriority) {
		/* begin putToSleep: */
		priority = ((longAt((activeProc + 4) + (2 * 4))) >> 1);
		processLists = longAt(((longAt(((longAt((specialObjectsOop + 4) + (3 * 4))) + 4) + (1 * 4))) + 4) + (0 * 4));
		processList = longAt((processLists + 4) + ((priority - 1) * 4));
		/* begin addLastLink:toList: */
		if ((longAt((processList + 4) + (0 * 4))) == nilObj) {
			/* begin storePointer:ofObject:withValue: */
			if (processList < youngStart) {
				possibleRootStoreIntovalue(processList, activeProc);
			}
			longAtput((processList + 4) + (0 * 4), activeProc);
		} else {
			lastLink = longAt((processList + 4) + (1 * 4));
			/* begin storePointer:ofObject:withValue: */
			if (lastLink < youngStart) {
				possibleRootStoreIntovalue(lastLink, activeProc);
			}
			longAtput((lastLink + 4) + (0 * 4), activeProc);
		}
		/* begin storePointer:ofObject:withValue: */
		if (processList < youngStart) {
			possibleRootStoreIntovalue(processList, activeProc);
		}
		longAtput((processList + 4) + (1 * 4), activeProc);
		/* begin storePointer:ofObject:withValue: */
		if (activeProc < youngStart) {
			possibleRootStoreIntovalue(activeProc, processList);
		}
		longAtput((activeProc + 4) + (3 * 4), processList);
		/* begin transferTo: */
		sched = longAt(((longAt((specialObjectsOop + 4) + (3 * 4))) + 4) + (1 * 4));
		oldProc = longAt((sched + 4) + (1 * 4));
		/* begin storePointer:ofObject:withValue: */
		valuePointer = activeContext;
		if (oldProc < youngStart) {
			possibleRootStoreIntovalue(oldProc, valuePointer);
		}
		longAtput((oldProc + 4) + (1 * 4), valuePointer);
		/* begin storePointer:ofObject:withValue: */
		if (sched < youngStart) {
			possibleRootStoreIntovalue(sched, aProcess);
		}
		longAtput((sched + 4) + (1 * 4), aProcess);
		/* begin newActiveContext: */
		/* begin storeContextRegisters */
		longAtput((activeContext + 4) + (1 * 4), ((((instructionPointer - method) - (4 - 2)) << 1) | 1));
		longAtput((activeContext + 4) + (2 * 4), (((((((stackPointer - activeContext) - 4) / 4) - 6) + 1) << 1) | 1));
		activeContext = longAt((aProcess + 4) + (1 * 4));
		if (activeContext < youngStart) {
			beRootIfOld(activeContext);
		}
		/* begin fetchContextRegisters */
		m = longAt((activeContext + 4) + (3 * 4));
		if (((m & 1) == 1)) {
			theHomeContext = longAt((activeContext + 4) + (5 * 4));
			if (theHomeContext < youngStart) {
				beRootIfOld(theHomeContext);
			}
		} else {
			theHomeContext = activeContext;
		}
		receiver = longAt((theHomeContext + 4) + (5 * 4));
		method = longAt((theHomeContext + 4) + (3 * 4));
		instructionPointer = ((longAt((activeContext + 4) + (1 * 4))) >> 1);
		instructionPointer = ((method + instructionPointer) + 4) - 2;
		stackPointer = ((longAt((activeContext + 4) + (2 * 4))) >> 1);
		stackPointer = (activeContext + 4) + (((6 + stackPointer) - 1) * 4);
		reclaimableContextCount = 0;
	} else {
		/* begin putToSleep: */
		priority1 = ((longAt((aProcess + 4) + (2 * 4))) >> 1);
		processLists1 = longAt(((longAt(((longAt((specialObjectsOop + 4) + (3 * 4))) + 4) + (1 * 4))) + 4) + (0 * 4));
		processList1 = longAt((processLists1 + 4) + ((priority1 - 1) * 4));
		/* begin addLastLink:toList: */
		if ((longAt((processList1 + 4) + (0 * 4))) == nilObj) {
			/* begin storePointer:ofObject:withValue: */
			if (processList1 < youngStart) {
				possibleRootStoreIntovalue(processList1, aProcess);
			}
			longAtput((processList1 + 4) + (0 * 4), aProcess);
		} else {
			lastLink1 = longAt((processList1 + 4) + (1 * 4));
			/* begin storePointer:ofObject:withValue: */
			if (lastLink1 < youngStart) {
				possibleRootStoreIntovalue(lastLink1, aProcess);
			}
			longAtput((lastLink1 + 4) + (0 * 4), aProcess);
		}
		/* begin storePointer:ofObject:withValue: */
		if (processList1 < youngStart) {
			possibleRootStoreIntovalue(processList1, aProcess);
		}
		longAtput((processList1 + 4) + (1 * 4), aProcess);
		/* begin storePointer:ofObject:withValue: */
		if (aProcess < youngStart) {
			possibleRootStoreIntovalue(aProcess, processList1);
		}
		longAtput((aProcess + 4) + (3 * 4), processList1);
	}
}

int returnAtlastIndexlefttop(int stopIndex, int lastIndex, int left, int top) {
    int objectPointer;
    int array;
    int fixedFields;
    int totalLength;
    int i;
    int successValue;
    int header;
    int sz;
    int fmt;
    int fmt1;
    int byteVal;
    int classPointer;
    int fmt2;
    int ccIndex;

	/* begin stObject:at: */
	array = scanStopArray;
	/* begin fixedFieldsOf: */
	/* begin fetchClassOf: */
	if (((array & 1) == 1)) {
		classPointer = longAt((specialObjectsOop + 4) + (5 * 4));
		goto l2;
	}
	ccIndex = ((((unsigned) (longAt(array))) >> 12) & 31) - 1;
	if (ccIndex < 0) {
		classPointer = (longAt(array - 4)) & 4294967292;
		goto l2;
	} else {
		classPointer = longAt(((longAt((specialObjectsOop + 4) + (28 * 4))) + 4) + (ccIndex * 4));
		goto l2;
	}
l2:	/* end fetchClassOf: */;
	fmt2 = (longAt((classPointer + 4) + (2 * 4))) - 1;
	fixedFields = ((((unsigned) fmt2) >> 2) & 63) - 1;
	/* begin lengthOf: */
	header = longAt(array);
	if ((header & 3) == 0) {
		sz = (longAt(array - 8)) & 4294967292;
	} else {
		sz = header & 252;
	}
	fmt = (((unsigned) header) >> 8) & 15;
	if (fmt < 8) {
		totalLength = (sz - 4) / 4;
		goto l1;
	} else {
		totalLength = (sz - 4) - (fmt & 3);
		goto l1;
	}
l1:	/* end lengthOf: */;
	i = stopIndex + fixedFields;
	/* begin success: */
	successValue = (stopIndex >= 1) && (i <= totalLength);
	successFlag = successValue && successFlag;
	if (successFlag) {
		/* begin subscript:with: */
		fmt1 = (((unsigned) (longAt(array))) >> 8) & 15;
		if (fmt1 < 4) {
			stopCode = longAt((array + 4) + ((i - 1) * 4));
			goto l3;
		}
		if (fmt1 < 8) {
			stopCode = positive32BitIntegerFor(longAt((array + 4) + ((i - 1) * 4)));
			goto l3;
		}
		byteVal = byteAt((array + 4) + (i - 1));
		stopCode = ((byteVal << 1) | 1);
		goto l3;
	} else {
		stopCode = nilObj;
		goto l3;
	}
l3:	/* end stObject:at: */;
	if (!successFlag) {
		return null;
	}
	/* begin storeInteger:ofObject:withValue: */
	objectPointer = bitBltOop;
	if ((lastIndex >= -1073741824) && (lastIndex < 1073741824)) {
		longAtput((objectPointer + 4) + (15 * 4), ((lastIndex << 1) | 1));
	} else {
		primitiveFail();
	}
	if (scanDisplayFlag) {
		affectedL = left;
		affectedR = bbW + dx;
		affectedT = top;
		affectedB = bbH + dy;
	}
}

int returnToActiveContext(int returnContext) {
    int methodContextClass;
    int contextOfCaller;
    int thisCntxClass;
    int sz;
    int header;
    int m;
    int ccIndex;

	methodContextClass = longAt((specialObjectsOop + 4) + (10 * 4));
	while (!(activeContext == returnContext)) {
		contextOfCaller = longAt((activeContext + 4) + (0 * 4));
		/* begin nilContextFields */
		longAtput((activeContext + 4) + (0 * 4), nilObj);
		longAtput((activeContext + 4) + (1 * 4), nilObj);
		if (reclaimableContextCount > 0) {
			/* begin fetchClassOf: */
			if (((activeContext & 1) == 1)) {
				thisCntxClass = longAt((specialObjectsOop + 4) + (5 * 4));
				goto l3;
			}
			ccIndex = ((((unsigned) (longAt(activeContext))) >> 12) & 31) - 1;
			if (ccIndex < 0) {
				thisCntxClass = (longAt(activeContext - 4)) & 4294967292;
				goto l3;
			} else {
				thisCntxClass = longAt(((longAt((specialObjectsOop + 4) + (28 * 4))) + 4) + (ccIndex * 4));
				goto l3;
			}
		l3:	/* end fetchClassOf: */;
			if (thisCntxClass == methodContextClass) {
				reclaimableContextCount = reclaimableContextCount - 1;
				/* begin recycleContextIfPossible: */
				if (!(activeContext >= youngStart)) {
					goto l2;
				}
				/* begin sizeBitsOf: */
				header = longAt(activeContext);
				if ((header & 3) == 0) {
					sz = (longAt(activeContext - 8)) & 4294967292;
					goto l1;
				} else {
					sz = header & 252;
					goto l1;
				}
			l1:	/* end sizeBitsOf: */;
				if (sz == 76) {
					longAtput((activeContext + 4) + (0 * 4), freeSmallContexts);
					freeSmallContexts = activeContext;
				} else {
					longAtput((activeContext + 4) + (0 * 4), freeLargeContexts);
					freeLargeContexts = activeContext;
				}
			l2:	/* end recycleContextIfPossible: */;
			}
		}
		activeContext = contextOfCaller;
	}
	if (activeContext < youngStart) {
		beRootIfOld(activeContext);
	}
	/* begin fetchContextRegisters */
	m = longAt((activeContext + 4) + (3 * 4));
	if (((m & 1) == 1)) {
		theHomeContext = longAt((activeContext + 4) + (5 * 4));
		if (theHomeContext < youngStart) {
			beRootIfOld(theHomeContext);
		}
	} else {
		theHomeContext = activeContext;
	}
	receiver = longAt((theHomeContext + 4) + (5 * 4));
	method = longAt((theHomeContext + 4) + (3 * 4));
	instructionPointer = ((longAt((activeContext + 4) + (1 * 4))) >> 1);
	instructionPointer = ((method + instructionPointer) + 4) - 2;
	stackPointer = ((longAt((activeContext + 4) + (2 * 4))) >> 1);
	stackPointer = (activeContext + 4) + (((6 + stackPointer) - 1) * 4);
}

int returnValueto(int resultObj, int contextPointer) {
    int sendersIP;
    int methodContextClass;
    int contextOfCaller;
    int thisCntxClass;
    int sz;
    int header;
    int m;
    int ccIndex;

	if (contextPointer == nilObj) {
		/* begin push: */
		longAtput(stackPointer = stackPointer + 4, activeContext);
		/* begin push: */
		longAtput(stackPointer = stackPointer + 4, resultObj);
		return externalSendSelectorargumentCount(longAt((specialObjectsOop + 4) + (21 * 4)), 1);
	}
	sendersIP = longAt((contextPointer + 4) + (1 * 4));
	if (sendersIP == nilObj) {
		/* begin push: */
		longAtput(stackPointer = stackPointer + 4, activeContext);
		/* begin push: */
		longAtput(stackPointer = stackPointer + 4, resultObj);
		return externalSendSelectorargumentCount(longAt((specialObjectsOop + 4) + (21 * 4)), 1);
	}
	/* begin returnToActiveContext: */
	methodContextClass = longAt((specialObjectsOop + 4) + (10 * 4));
	while (!(activeContext == contextPointer)) {
		contextOfCaller = longAt((activeContext + 4) + (0 * 4));
		/* begin nilContextFields */
		longAtput((activeContext + 4) + (0 * 4), nilObj);
		longAtput((activeContext + 4) + (1 * 4), nilObj);
		if (reclaimableContextCount > 0) {
			/* begin fetchClassOf: */
			if (((activeContext & 1) == 1)) {
				thisCntxClass = longAt((specialObjectsOop + 4) + (5 * 4));
				goto l3;
			}
			ccIndex = ((((unsigned) (longAt(activeContext))) >> 12) & 31) - 1;
			if (ccIndex < 0) {
				thisCntxClass = (longAt(activeContext - 4)) & 4294967292;
				goto l3;
			} else {
				thisCntxClass = longAt(((longAt((specialObjectsOop + 4) + (28 * 4))) + 4) + (ccIndex * 4));
				goto l3;
			}
		l3:	/* end fetchClassOf: */;
			if (thisCntxClass == methodContextClass) {
				reclaimableContextCount = reclaimableContextCount - 1;
				/* begin recycleContextIfPossible: */
				if (!(activeContext >= youngStart)) {
					goto l2;
				}
				/* begin sizeBitsOf: */
				header = longAt(activeContext);
				if ((header & 3) == 0) {
					sz = (longAt(activeContext - 8)) & 4294967292;
					goto l1;
				} else {
					sz = header & 252;
					goto l1;
				}
			l1:	/* end sizeBitsOf: */;
				if (sz == 76) {
					longAtput((activeContext + 4) + (0 * 4), freeSmallContexts);
					freeSmallContexts = activeContext;
				} else {
					longAtput((activeContext + 4) + (0 * 4), freeLargeContexts);
					freeLargeContexts = activeContext;
				}
			l2:	/* end recycleContextIfPossible: */;
			}
		}
		activeContext = contextOfCaller;
	}
	if (activeContext < youngStart) {
		beRootIfOld(activeContext);
	}
	/* begin fetchContextRegisters */
	m = longAt((activeContext + 4) + (3 * 4));
	if (((m & 1) == 1)) {
		theHomeContext = longAt((activeContext + 4) + (5 * 4));
		if (theHomeContext < youngStart) {
			beRootIfOld(theHomeContext);
		}
	} else {
		theHomeContext = activeContext;
	}
	receiver = longAt((theHomeContext + 4) + (5 * 4));
	method = longAt((theHomeContext + 4) + (3 * 4));
	instructionPointer = ((longAt((activeContext + 4) + (1 * 4))) >> 1);
	instructionPointer = ((method + instructionPointer) + 4) - 2;
	stackPointer = ((longAt((activeContext + 4) + (2 * 4))) >> 1);
	stackPointer = (activeContext + 4) + (((6 + stackPointer) - 1) * 4);
	/* begin push: */
	longAtput(stackPointer = stackPointer + 4, resultObj);
	/* begin quickCheckForInterrupts */
	if ((interruptCheckCounter = interruptCheckCounter - 1) <= 0) {
		interruptCheckCounter = 1000;
		checkForInterrupts();
	}
}

int rgbAddwith(int sourceWord, int destinationWord) {
	if (destPixSize < 16) {
		return partitionedAddtonBitsnPartitions(sourceWord, destinationWord, destPixSize, pixPerWord);
	}
	if (destPixSize == 16) {
		return (partitionedAddtonBitsnPartitions(sourceWord, destinationWord, 5, 3)) + ((partitionedAddtonBitsnPartitions(((unsigned) sourceWord) >> 16, ((unsigned) destinationWord) >> 16, 5, 3)) << 16);
	} else {
		return partitionedAddtonBitsnPartitions(sourceWord, destinationWord, 8, 3);
	}
}

int rgbDiffwith(int sourceWord, int destinationWord) {
    int diff;
    int pixMask;

	if (destPixSize < 16) {
		diff = sourceWord ^ destinationWord;
		pixMask = (((destPixSize < 0) ? ((unsigned) 1 >> -destPixSize) : ((unsigned) 1 << destPixSize))) - 1;
		while (!(diff == 0)) {
			if ((diff & pixMask) != 0) {
				bitCount = bitCount + 1;
			}
			diff = ((unsigned) diff) >> destPixSize;
		}
		return destinationWord;
	}
	if (destPixSize == 16) {
		diff = partitionedSubfromnBitsnPartitions(sourceWord, destinationWord, 5, 3);
		bitCount = ((bitCount + (diff & 31)) + ((((unsigned) diff) >> 5) & 31)) + ((((unsigned) diff) >> 10) & 31);
		diff = partitionedSubfromnBitsnPartitions(((unsigned) sourceWord) >> 16, ((unsigned) destinationWord) >> 16, 5, 3);
		bitCount = ((bitCount + (diff & 31)) + ((((unsigned) diff) >> 5) & 31)) + ((((unsigned) diff) >> 10) & 31);
	} else {
		diff = partitionedSubfromnBitsnPartitions(sourceWord, destinationWord, 8, 3);
		bitCount = ((bitCount + (diff & 255)) + ((((unsigned) diff) >> 8) & 255)) + ((((unsigned) diff) >> 16) & 255);
	}
	return destinationWord;
}

int rgbMapfromto(int sourcePixel, int nBitsIn, int nBitsOut) {
    int mask;
    int d;
    int srcPix;
    int destPix;

	if ((d = nBitsOut - nBitsIn) > 0) {
		mask = (1 << nBitsIn) - 1;
		srcPix = sourcePixel << d;
		mask = mask << d;
		destPix = srcPix & mask;
		mask = mask << nBitsOut;
		srcPix = srcPix << d;
		return (destPix + (srcPix & mask)) + ((srcPix << d) & (mask << nBitsOut));
	} else {
		if (d == 0) {
			return sourcePixel;
		}
		d = nBitsIn - nBitsOut;
		mask = (1 << nBitsOut) - 1;
		srcPix = ((unsigned) sourcePixel) >> d;
		destPix = srcPix & mask;
		mask = mask << nBitsOut;
		srcPix = ((unsigned) srcPix) >> d;
		return (destPix + (srcPix & mask)) + ((((unsigned) srcPix) >> d) & (mask << nBitsOut));
	}
}

int rgbSubwith(int sourceWord, int destinationWord) {
	if (destPixSize < 16) {
		return partitionedSubfromnBitsnPartitions(sourceWord, destinationWord, destPixSize, pixPerWord);
	}
	if (destPixSize == 16) {
		return (partitionedSubfromnBitsnPartitions(sourceWord, destinationWord, 5, 3)) + ((partitionedSubfromnBitsnPartitions(((unsigned) sourceWord) >> 16, ((unsigned) destinationWord) >> 16, 5, 3)) << 16);
	} else {
		return partitionedSubfromnBitsnPartitions(sourceWord, destinationWord, 8, 3);
	}
}

int rightType(int headerWord) {
	if ((headerWord & 252) == 0) {
		return 0;
	} else {
		if ((headerWord & 126976) == 0) {
			return 1;
		} else {
			return 3;
		}
	}
}

int scanCharacters(void) {
    int left;
    int top;
    int lastIndex;
    int charVal;
    int ascii;
    int sourceX2;
    int nextDestX;
    int objectPointer;
    int integerValue;
    int objectPointer1;
    int objectPointer2;
    int lastIndex1;
    int objectPointer3;
    int array;
    int fixedFields;
    int totalLength;
    int i;
    int successValue;
    int header;
    int sz;
    int fmt;
    int fmt1;
    int byteVal;
    int classPointer;
    int fmt2;
    int ccIndex;
    int array1;
    int fixedFields1;
    int totalLength1;
    int i1;
    int successValue1;
    int header1;
    int sz1;
    int fmt3;
    int fmt11;
    int byteVal1;
    int classPointer1;
    int fmt21;
    int ccIndex1;
    int array2;
    int fixedFields2;
    int totalLength2;
    int i2;
    int successValue2;
    int header2;
    int sz2;
    int fmt4;
    int fmt12;
    int byteVal2;
    int classPointer2;
    int fmt22;
    int ccIndex2;
    int array3;
    int fixedFields3;
    int totalLength3;
    int i3;
    int successValue3;
    int header3;
    int sz3;
    int fmt5;
    int fmt13;
    int byteVal3;
    int classPointer3;
    int fmt23;
    int ccIndex3;
    int array4;
    int fixedFields4;
    int totalLength4;
    int i4;
    int successValue4;
    int header4;
    int sz4;
    int fmt6;
    int fmt14;
    int byteVal4;
    int classPointer4;
    int fmt24;
    int ccIndex4;
    int array5;
    int fixedFields5;
    int totalLength5;
    int i5;
    int successValue5;
    int header5;
    int sz5;
    int fmt7;
    int fmt15;
    int byteVal5;
    int classPointer5;
    int fmt25;
    int ccIndex5;
    int array6;
    int fixedFields6;
    int totalLength6;
    int i6;
    int successValue6;
    int header6;
    int sz6;
    int fmt8;
    int fmt16;
    int byteVal6;
    int classPointer6;
    int fmt26;
    int ccIndex6;

	if (scanDisplayFlag) {
		clipRange();
		left = dx;
		top = dy;
	}
	lastIndex = scanStart;
	while (lastIndex <= scanStop) {
		/* begin stObject:at: */
		array2 = scanString;
		/* begin fixedFieldsOf: */
		/* begin fetchClassOf: */
		if (((array2 & 1) == 1)) {
			classPointer2 = longAt((specialObjectsOop + 4) + (5 * 4));
			goto l9;
		}
		ccIndex2 = ((((unsigned) (longAt(array2))) >> 12) & 31) - 1;
		if (ccIndex2 < 0) {
			classPointer2 = (longAt(array2 - 4)) & 4294967292;
			goto l9;
		} else {
			classPointer2 = longAt(((longAt((specialObjectsOop + 4) + (28 * 4))) + 4) + (ccIndex2 * 4));
			goto l9;
		}
	l9:	/* end fetchClassOf: */;
		fmt22 = (longAt((classPointer2 + 4) + (2 * 4))) - 1;
		fixedFields2 = ((((unsigned) fmt22) >> 2) & 63) - 1;
		/* begin lengthOf: */
		header2 = longAt(array2);
		if ((header2 & 3) == 0) {
			sz2 = (longAt(array2 - 8)) & 4294967292;
		} else {
			sz2 = header2 & 252;
		}
		fmt4 = (((unsigned) header2) >> 8) & 15;
		if (fmt4 < 8) {
			totalLength2 = (sz2 - 4) / 4;
			goto l8;
		} else {
			totalLength2 = (sz2 - 4) - (fmt4 & 3);
			goto l8;
		}
	l8:	/* end lengthOf: */;
		i2 = lastIndex + fixedFields2;
		/* begin success: */
		successValue2 = (lastIndex >= 1) && (i2 <= totalLength2);
		successFlag = successValue2 && successFlag;
		if (successFlag) {
			/* begin subscript:with: */
			fmt12 = (((unsigned) (longAt(array2))) >> 8) & 15;
			if (fmt12 < 4) {
				charVal = longAt((array2 + 4) + ((i2 - 1) * 4));
				goto l10;
			}
			if (fmt12 < 8) {
				charVal = positive32BitIntegerFor(longAt((array2 + 4) + ((i2 - 1) * 4)));
				goto l10;
			}
			byteVal2 = byteAt((array2 + 4) + (i2 - 1));
			charVal = ((byteVal2 << 1) | 1);
			goto l10;
		} else {
			charVal = nilObj;
			goto l10;
		}
	l10:	/* end stObject:at: */;
		ascii = (charVal >> 1);
		if (!successFlag) {
			return null;
		}
		/* begin stObject:at: */
		array3 = scanStopArray;
		/* begin fixedFieldsOf: */
		/* begin fetchClassOf: */
		if (((array3 & 1) == 1)) {
			classPointer3 = longAt((specialObjectsOop + 4) + (5 * 4));
			goto l12;
		}
		ccIndex3 = ((((unsigned) (longAt(array3))) >> 12) & 31) - 1;
		if (ccIndex3 < 0) {
			classPointer3 = (longAt(array3 - 4)) & 4294967292;
			goto l12;
		} else {
			classPointer3 = longAt(((longAt((specialObjectsOop + 4) + (28 * 4))) + 4) + (ccIndex3 * 4));
			goto l12;
		}
	l12:	/* end fetchClassOf: */;
		fmt23 = (longAt((classPointer3 + 4) + (2 * 4))) - 1;
		fixedFields3 = ((((unsigned) fmt23) >> 2) & 63) - 1;
		/* begin lengthOf: */
		header3 = longAt(array3);
		if ((header3 & 3) == 0) {
			sz3 = (longAt(array3 - 8)) & 4294967292;
		} else {
			sz3 = header3 & 252;
		}
		fmt5 = (((unsigned) header3) >> 8) & 15;
		if (fmt5 < 8) {
			totalLength3 = (sz3 - 4) / 4;
			goto l11;
		} else {
			totalLength3 = (sz3 - 4) - (fmt5 & 3);
			goto l11;
		}
	l11:	/* end lengthOf: */;
		i3 = (ascii + 1) + fixedFields3;
		/* begin success: */
		successValue3 = ((ascii + 1) >= 1) && (i3 <= totalLength3);
		successFlag = successValue3 && successFlag;
		if (successFlag) {
			/* begin subscript:with: */
			fmt13 = (((unsigned) (longAt(array3))) >> 8) & 15;
			if (fmt13 < 4) {
				stopCode = longAt((array3 + 4) + ((i3 - 1) * 4));
				goto l13;
			}
			if (fmt13 < 8) {
				stopCode = positive32BitIntegerFor(longAt((array3 + 4) + ((i3 - 1) * 4)));
				goto l13;
			}
			byteVal3 = byteAt((array3 + 4) + (i3 - 1));
			stopCode = ((byteVal3 << 1) | 1);
			goto l13;
		} else {
			stopCode = nilObj;
			goto l13;
		}
	l13:	/* end stObject:at: */;
		if (!successFlag) {
			return null;
		}
		if (!(stopCode == nilObj)) {
			/* begin returnAt:lastIndex:left:top: */
			/* begin stObject:at: */
			array = scanStopArray;
			/* begin fixedFieldsOf: */
			/* begin fetchClassOf: */
			if (((array & 1) == 1)) {
				classPointer = longAt((specialObjectsOop + 4) + (5 * 4));
				goto l2;
			}
			ccIndex = ((((unsigned) (longAt(array))) >> 12) & 31) - 1;
			if (ccIndex < 0) {
				classPointer = (longAt(array - 4)) & 4294967292;
				goto l2;
			} else {
				classPointer = longAt(((longAt((specialObjectsOop + 4) + (28 * 4))) + 4) + (ccIndex * 4));
				goto l2;
			}
		l2:	/* end fetchClassOf: */;
			fmt2 = (longAt((classPointer + 4) + (2 * 4))) - 1;
			fixedFields = ((((unsigned) fmt2) >> 2) & 63) - 1;
			/* begin lengthOf: */
			header = longAt(array);
			if ((header & 3) == 0) {
				sz = (longAt(array - 8)) & 4294967292;
			} else {
				sz = header & 252;
			}
			fmt = (((unsigned) header) >> 8) & 15;
			if (fmt < 8) {
				totalLength = (sz - 4) / 4;
				goto l3;
			} else {
				totalLength = (sz - 4) - (fmt & 3);
				goto l3;
			}
		l3:	/* end lengthOf: */;
			i = (ascii + 1) + fixedFields;
			/* begin success: */
			successValue = ((ascii + 1) >= 1) && (i <= totalLength);
			successFlag = successValue && successFlag;
			if (successFlag) {
				/* begin subscript:with: */
				fmt1 = (((unsigned) (longAt(array))) >> 8) & 15;
				if (fmt1 < 4) {
					stopCode = longAt((array + 4) + ((i - 1) * 4));
					goto l4;
				}
				if (fmt1 < 8) {
					stopCode = positive32BitIntegerFor(longAt((array + 4) + ((i - 1) * 4)));
					goto l4;
				}
				byteVal = byteAt((array + 4) + (i - 1));
				stopCode = ((byteVal << 1) | 1);
				goto l4;
			} else {
				stopCode = nilObj;
				goto l4;
			}
		l4:	/* end stObject:at: */;
			if (!successFlag) {
				return null;
			}
			/* begin storeInteger:ofObject:withValue: */
			objectPointer1 = bitBltOop;
			if ((lastIndex >= -1073741824) && (lastIndex < 1073741824)) {
				longAtput((objectPointer1 + 4) + (15 * 4), ((lastIndex << 1) | 1));
			} else {
				primitiveFail();
			}
			if (scanDisplayFlag) {
				affectedL = left;
				affectedR = bbW + dx;
				affectedT = top;
				affectedB = bbH + dy;
			}
			return null;
		}
		/* begin stObject:at: */
		array4 = scanXTable;
		/* begin fixedFieldsOf: */
		/* begin fetchClassOf: */
		if (((array4 & 1) == 1)) {
			classPointer4 = longAt((specialObjectsOop + 4) + (5 * 4));
			goto l15;
		}
		ccIndex4 = ((((unsigned) (longAt(array4))) >> 12) & 31) - 1;
		if (ccIndex4 < 0) {
			classPointer4 = (longAt(array4 - 4)) & 4294967292;
			goto l15;
		} else {
			classPointer4 = longAt(((longAt((specialObjectsOop + 4) + (28 * 4))) + 4) + (ccIndex4 * 4));
			goto l15;
		}
	l15:	/* end fetchClassOf: */;
		fmt24 = (longAt((classPointer4 + 4) + (2 * 4))) - 1;
		fixedFields4 = ((((unsigned) fmt24) >> 2) & 63) - 1;
		/* begin lengthOf: */
		header4 = longAt(array4);
		if ((header4 & 3) == 0) {
			sz4 = (longAt(array4 - 8)) & 4294967292;
		} else {
			sz4 = header4 & 252;
		}
		fmt6 = (((unsigned) header4) >> 8) & 15;
		if (fmt6 < 8) {
			totalLength4 = (sz4 - 4) / 4;
			goto l14;
		} else {
			totalLength4 = (sz4 - 4) - (fmt6 & 3);
			goto l14;
		}
	l14:	/* end lengthOf: */;
		i4 = (ascii + 1) + fixedFields4;
		/* begin success: */
		successValue4 = ((ascii + 1) >= 1) && (i4 <= totalLength4);
		successFlag = successValue4 && successFlag;
		if (successFlag) {
			/* begin subscript:with: */
			fmt14 = (((unsigned) (longAt(array4))) >> 8) & 15;
			if (fmt14 < 4) {
				sourceX = longAt((array4 + 4) + ((i4 - 1) * 4));
				goto l16;
			}
			if (fmt14 < 8) {
				sourceX = positive32BitIntegerFor(longAt((array4 + 4) + ((i4 - 1) * 4)));
				goto l16;
			}
			byteVal4 = byteAt((array4 + 4) + (i4 - 1));
			sourceX = ((byteVal4 << 1) | 1);
			goto l16;
		} else {
			sourceX = nilObj;
			goto l16;
		}
	l16:	/* end stObject:at: */;
		/* begin stObject:at: */
		array5 = scanXTable;
		/* begin fixedFieldsOf: */
		/* begin fetchClassOf: */
		if (((array5 & 1) == 1)) {
			classPointer5 = longAt((specialObjectsOop + 4) + (5 * 4));
			goto l18;
		}
		ccIndex5 = ((((unsigned) (longAt(array5))) >> 12) & 31) - 1;
		if (ccIndex5 < 0) {
			classPointer5 = (longAt(array5 - 4)) & 4294967292;
			goto l18;
		} else {
			classPointer5 = longAt(((longAt((specialObjectsOop + 4) + (28 * 4))) + 4) + (ccIndex5 * 4));
			goto l18;
		}
	l18:	/* end fetchClassOf: */;
		fmt25 = (longAt((classPointer5 + 4) + (2 * 4))) - 1;
		fixedFields5 = ((((unsigned) fmt25) >> 2) & 63) - 1;
		/* begin lengthOf: */
		header5 = longAt(array5);
		if ((header5 & 3) == 0) {
			sz5 = (longAt(array5 - 8)) & 4294967292;
		} else {
			sz5 = header5 & 252;
		}
		fmt7 = (((unsigned) header5) >> 8) & 15;
		if (fmt7 < 8) {
			totalLength5 = (sz5 - 4) / 4;
			goto l17;
		} else {
			totalLength5 = (sz5 - 4) - (fmt7 & 3);
			goto l17;
		}
	l17:	/* end lengthOf: */;
		i5 = (ascii + 2) + fixedFields5;
		/* begin success: */
		successValue5 = ((ascii + 2) >= 1) && (i5 <= totalLength5);
		successFlag = successValue5 && successFlag;
		if (successFlag) {
			/* begin subscript:with: */
			fmt15 = (((unsigned) (longAt(array5))) >> 8) & 15;
			if (fmt15 < 4) {
				sourceX2 = longAt((array5 + 4) + ((i5 - 1) * 4));
				goto l19;
			}
			if (fmt15 < 8) {
				sourceX2 = positive32BitIntegerFor(longAt((array5 + 4) + ((i5 - 1) * 4)));
				goto l19;
			}
			byteVal5 = byteAt((array5 + 4) + (i5 - 1));
			sourceX2 = ((byteVal5 << 1) | 1);
			goto l19;
		} else {
			sourceX2 = nilObj;
			goto l19;
		}
	l19:	/* end stObject:at: */;
		if (!successFlag) {
			return null;
		}
		if ((((sourceX & 1) == 1)) && (((sourceX2 & 1) == 1))) {
			sourceX = (sourceX >> 1);
			sourceX2 = (sourceX2 >> 1);
		} else {
			primitiveFail();
			return null;
		}
		nextDestX = destX + (width = sourceX2 - sourceX);
		if (nextDestX > scanRightX) {
			/* begin returnAt:lastIndex:left:top: */
			/* begin stObject:at: */
			array1 = scanStopArray;
			/* begin fixedFieldsOf: */
			/* begin fetchClassOf: */
			if (((array1 & 1) == 1)) {
				classPointer1 = longAt((specialObjectsOop + 4) + (5 * 4));
				goto l6;
			}
			ccIndex1 = ((((unsigned) (longAt(array1))) >> 12) & 31) - 1;
			if (ccIndex1 < 0) {
				classPointer1 = (longAt(array1 - 4)) & 4294967292;
				goto l6;
			} else {
				classPointer1 = longAt(((longAt((specialObjectsOop + 4) + (28 * 4))) + 4) + (ccIndex1 * 4));
				goto l6;
			}
		l6:	/* end fetchClassOf: */;
			fmt21 = (longAt((classPointer1 + 4) + (2 * 4))) - 1;
			fixedFields1 = ((((unsigned) fmt21) >> 2) & 63) - 1;
			/* begin lengthOf: */
			header1 = longAt(array1);
			if ((header1 & 3) == 0) {
				sz1 = (longAt(array1 - 8)) & 4294967292;
			} else {
				sz1 = header1 & 252;
			}
			fmt3 = (((unsigned) header1) >> 8) & 15;
			if (fmt3 < 8) {
				totalLength1 = (sz1 - 4) / 4;
				goto l5;
			} else {
				totalLength1 = (sz1 - 4) - (fmt3 & 3);
				goto l5;
			}
		l5:	/* end lengthOf: */;
			i1 = 258 + fixedFields1;
			/* begin success: */
			successValue1 = (258 >= 1) && (i1 <= totalLength1);
			successFlag = successValue1 && successFlag;
			if (successFlag) {
				/* begin subscript:with: */
				fmt11 = (((unsigned) (longAt(array1))) >> 8) & 15;
				if (fmt11 < 4) {
					stopCode = longAt((array1 + 4) + ((i1 - 1) * 4));
					goto l7;
				}
				if (fmt11 < 8) {
					stopCode = positive32BitIntegerFor(longAt((array1 + 4) + ((i1 - 1) * 4)));
					goto l7;
				}
				byteVal1 = byteAt((array1 + 4) + (i1 - 1));
				stopCode = ((byteVal1 << 1) | 1);
				goto l7;
			} else {
				stopCode = nilObj;
				goto l7;
			}
		l7:	/* end stObject:at: */;
			if (!successFlag) {
				return null;
			}
			/* begin storeInteger:ofObject:withValue: */
			objectPointer2 = bitBltOop;
			if ((lastIndex >= -1073741824) && (lastIndex < 1073741824)) {
				longAtput((objectPointer2 + 4) + (15 * 4), ((lastIndex << 1) | 1));
			} else {
				primitiveFail();
			}
			if (scanDisplayFlag) {
				affectedL = left;
				affectedR = bbW + dx;
				affectedT = top;
				affectedB = bbH + dy;
			}
			return null;
		}
		if (scanDisplayFlag) {
			copyBits();
		}
		destX = nextDestX;
		/* begin storeInteger:ofObject:withValue: */
		objectPointer = bitBltOop;
		integerValue = destX;
		if ((integerValue >= -1073741824) && (integerValue < 1073741824)) {
			longAtput((objectPointer + 4) + (4 * 4), ((integerValue << 1) | 1));
		} else {
			primitiveFail();
		}
		lastIndex = lastIndex + 1;
	}
	/* begin returnAt:lastIndex:left:top: */
	lastIndex1 = scanStop;
	/* begin stObject:at: */
	array6 = scanStopArray;
	/* begin fixedFieldsOf: */
	/* begin fetchClassOf: */
	if (((array6 & 1) == 1)) {
		classPointer6 = longAt((specialObjectsOop + 4) + (5 * 4));
		goto l21;
	}
	ccIndex6 = ((((unsigned) (longAt(array6))) >> 12) & 31) - 1;
	if (ccIndex6 < 0) {
		classPointer6 = (longAt(array6 - 4)) & 4294967292;
		goto l21;
	} else {
		classPointer6 = longAt(((longAt((specialObjectsOop + 4) + (28 * 4))) + 4) + (ccIndex6 * 4));
		goto l21;
	}
l21:	/* end fetchClassOf: */;
	fmt26 = (longAt((classPointer6 + 4) + (2 * 4))) - 1;
	fixedFields6 = ((((unsigned) fmt26) >> 2) & 63) - 1;
	/* begin lengthOf: */
	header6 = longAt(array6);
	if ((header6 & 3) == 0) {
		sz6 = (longAt(array6 - 8)) & 4294967292;
	} else {
		sz6 = header6 & 252;
	}
	fmt8 = (((unsigned) header6) >> 8) & 15;
	if (fmt8 < 8) {
		totalLength6 = (sz6 - 4) / 4;
		goto l20;
	} else {
		totalLength6 = (sz6 - 4) - (fmt8 & 3);
		goto l20;
	}
l20:	/* end lengthOf: */;
	i6 = 257 + fixedFields6;
	/* begin success: */
	successValue6 = (257 >= 1) && (i6 <= totalLength6);
	successFlag = successValue6 && successFlag;
	if (successFlag) {
		/* begin subscript:with: */
		fmt16 = (((unsigned) (longAt(array6))) >> 8) & 15;
		if (fmt16 < 4) {
			stopCode = longAt((array6 + 4) + ((i6 - 1) * 4));
			goto l22;
		}
		if (fmt16 < 8) {
			stopCode = positive32BitIntegerFor(longAt((array6 + 4) + ((i6 - 1) * 4)));
			goto l22;
		}
		byteVal6 = byteAt((array6 + 4) + (i6 - 1));
		stopCode = ((byteVal6 << 1) | 1);
		goto l22;
	} else {
		stopCode = nilObj;
		goto l22;
	}
l22:	/* end stObject:at: */;
	if (!successFlag) {
		goto l1;
	}
	/* begin storeInteger:ofObject:withValue: */
	objectPointer3 = bitBltOop;
	if ((lastIndex1 >= -1073741824) && (lastIndex1 < 1073741824)) {
		longAtput((objectPointer3 + 4) + (15 * 4), ((lastIndex1 << 1) | 1));
	} else {
		primitiveFail();
	}
	if (scanDisplayFlag) {
		affectedL = left;
		affectedR = bbW + dx;
		affectedT = top;
		affectedB = bbH + dy;
	}
l1:	/* end returnAt:lastIndex:left:top: */;
}

int schedulerPointer(void) {
	return longAt(((longAt((specialObjectsOop + 4) + (3 * 4))) + 4) + (1 * 4));
}

int sender(void) {
	return longAt((theHomeContext + 4) + (0 * 4));
}

int sendSelectorToClass(int classPointer) {
    int hash;
    int probe;
    int p;

	/* begin findNewMethodInClass: */
	hash = ((unsigned) (messageSelector ^ classPointer)) >> 2;
	for (p = 0; p <= (3 - 1); p += 1) {
		probe = ((((unsigned) hash) >> p) & 511) + 1;
		if (((methodCache[probe]) == messageSelector) && ((methodCache[probe + 512]) == classPointer)) {
			newMethod = methodCache[(probe + 512) + 512];
			primitiveIndex = (((unsigned) (longAt((newMethod + 4) + (0 * 4)))) >> 1) & 511;
			goto l1;
		}
	}
	lookupMethodInClass(classPointer);
	mcProbe = (mcProbe + 1) % 3;
	probe = ((((unsigned) hash) >> (mcProbe * 3)) & 511) + 1;
	methodCache[probe] = messageSelector;
	methodCache[probe + 512] = classPointer;
	methodCache[(probe + 512) + 512] = newMethod;
l1:	/* end findNewMethodInClass: */;
	/* begin executeNewMethod */
	if ((primitiveIndex == 0) || (!(primitiveResponse()))) {
		activateNewMethod();
		/* begin quickCheckForInterrupts */
		if ((interruptCheckCounter = interruptCheckCounter - 1) <= 0) {
			interruptCheckCounter = 1000;
			checkForInterrupts();
		}
	}
}

int setInterpreter(int anInterpreter) {
	interpreterProxy = anInterpreter;
}

int setSizeOfFreeto(int chunk, int byteSize) {
	longAtput(chunk, (byteSize & 536870908) | 2);
}

int showDisplayBits(void) {
    int displayObj;
    int dispBits;
    int w;
    int h;
    int affectedRectL;
    int affectedRectR;
    int affectedRectT;
    int affectedRectB;
    int dispBitsIndex;
    int d;
    int successValue;

	displayObj = longAt((specialObjectsOop + 4) + (14 * 4));
	/* begin success: */
	successValue = (((((unsigned) (longAt(displayObj))) >> 8) & 15) <= 4) && ((lengthOf(displayObj)) >= 4);
	successFlag = successValue && successFlag;
	if (successFlag) {
		dispBits = longAt((displayObj + 4) + (0 * 4));
		w = fetchIntegerofObject(1, displayObj);
		h = fetchIntegerofObject(2, displayObj);
		d = fetchIntegerofObject(3, displayObj);
	}
	if (successFlag) {
		affectedRectL = affectedL;
		affectedRectR = affectedR;
		affectedRectT = affectedT;
		affectedRectB = affectedB;
		dispBitsIndex = dispBits + 4;
		ioShowDisplay(dispBitsIndex, w, h, d, affectedRectL, affectedRectR, affectedRectT, affectedRectB);
	}
}

int signExtend16(int int16) {
	if ((int16 & 32768) == 0) {
		return int16;
	} else {
		return int16 - 65536;
	}
}

int sizeBitsOf(int oop) {
    int header;

	header = longAt(oop);
	if ((header & 3) == 0) {
		return (longAt(oop - 8)) & 4294967292;
	} else {
		return header & 252;
	}
}

int sizeBitsOfSafe(int oop) {
    int header;
    int type;

	header = longAt(oop);
	/* begin rightType: */
	if ((header & 252) == 0) {
		type = 0;
		goto l1;
	} else {
		if ((header & 126976) == 0) {
			type = 1;
			goto l1;
		} else {
			type = 3;
			goto l1;
		}
	}
l1:	/* end rightType: */;
	if (type == 0) {
		return (longAt(oop - 8)) & 4294967292;
	} else {
		return header & 252;
	}
}

int sizeHeader(int oop) {
	return longAt(oop - 8);
}

int sizeOfFree(int oop) {
	return (longAt(oop)) & 536870908;
}

int smoothPixatXfyfdxhdyhdxvdyvpixPerWordpixelMasksourceMap(int n, int xf, int yf, int dxh, int dyh, int dxv, int dyv, int srcPixPerWord, int sourcePixMask, int sourceMap) {
    int sourcePix;
    int i;
    int j;
    int r;
    int g;
    int b;
    int x;
    int y;
    int rgb;
    int bitsPerColor;
    int d;
    int nPix;
    int mask;
    int d1;
    int srcPix;
    int destPix;

	r = g = b = 0;
	nPix = n * n;
	x = xf - (((dxh + dxv) * (n - 1)) / 2);
	y = yf - (((dyh + dyv) * (n - 1)) / 2);
	for (i = 0; i <= (n - 1); i += 1) {
		for (j = 0; j <= (n - 1); j += 1) {
			sourcePix = (sourcePixAtXypixPerWord(((unsigned) ((x + (dxh * i)) + (dxv * j))) >> 14, ((unsigned) ((y + (dyh * i)) + (dyv * j))) >> 14, srcPixPerWord)) & sourcePixMask;
			if (sourcePixSize < 16) {
				rgb = (longAt((sourceMap + 4) + (sourcePix * 4))) & 16777215;
			} else {
				if (sourcePixSize == 32) {
					rgb = sourcePix & 16777215;
				} else {
					/* begin rgbMap:from:to: */
					if ((d1 = 8 - 5) > 0) {
						mask = (1 << 5) - 1;
						srcPix = sourcePix << d1;
						mask = mask << d1;
						destPix = srcPix & mask;
						mask = mask << 8;
						srcPix = srcPix << d1;
						rgb = (destPix + (srcPix & mask)) + ((srcPix << d1) & (mask << 8));
						goto l1;
					} else {
						if (d1 == 0) {
							rgb = sourcePix;
							goto l1;
						}
						d1 = 5 - 8;
						mask = (1 << 8) - 1;
						srcPix = ((unsigned) sourcePix) >> d1;
						destPix = srcPix & mask;
						mask = mask << 8;
						srcPix = ((unsigned) srcPix) >> d1;
						rgb = (destPix + (srcPix & mask)) + ((((unsigned) srcPix) >> d1) & (mask << 8));
						goto l1;
					}
				l1:	/* end rgbMap:from:to: */;
				}
			}
			r = r + ((((unsigned) rgb) >> 16) & 255);
			g = g + ((((unsigned) rgb) >> 8) & 255);
			b = b + (rgb & 255);
		}
	}
	if (colorMap != nilObj) {
		bitsPerColor = cmBitsPerColor;
	} else {
		if (destPixSize == 16) {
			bitsPerColor = 5;
		}
		if (destPixSize == 32) {
			bitsPerColor = 8;
		}
	}
	d = 8 - bitsPerColor;
	rgb = (((((unsigned) (r / nPix)) >> d) << (bitsPerColor * 2)) + ((((unsigned) (g / nPix)) >> d) << bitsPerColor)) + (((unsigned) (b / nPix)) >> d);
	if (colorMap != nilObj) {
		return longAt((colorMap + 4) + (rgb * 4));
	} else {
		return rgb;
	}
}

int sourcePixAtXypixPerWord(int x, int y, int srcPixPerWord) {
    int sourceWord;
    int index;

	if ((x < 0) || (x >= srcWidth)) {
		return 0;
	}
	if ((y < 0) || (y >= srcHeight)) {
		return 0;
	}
	index = ((y * sourceRaster) + (x / srcPixPerWord)) * 4;
	sourceWord = longAt((sourceBits + 4) + index);
	return ((unsigned) sourceWord) >> ((32 - sourcePixSize) - ((x % srcPixPerWord) * sourcePixSize));
}

int sourceSkewAndPointerInit(void) {
    int dWid;
    int sxLowBits;
    int dxLowBits;
    int pixPerM1;

	pixPerM1 = pixPerWord - 1;
	sxLowBits = sx & pixPerM1;
	dxLowBits = dx & pixPerM1;
	if (hDir > 0) {
		dWid = ((bbW < (pixPerWord - dxLowBits)) ? bbW : (pixPerWord - dxLowBits));
		preload = (sxLowBits + dWid) > pixPerM1;
	} else {
		dWid = ((bbW < (dxLowBits + 1)) ? bbW : (dxLowBits + 1));
		preload = ((sxLowBits - dWid) + 1) < 0;
	}
	skew = (sxLowBits - dxLowBits) * destPixSize;
	if (preload) {
		if (skew < 0) {
			skew = skew + 32;
		} else {
			skew = skew - 32;
		}
	}
	sourceIndex = (sourceBits + 4) + (((sy * sourceRaster) + (sx / (32 / sourcePixSize))) * 4);
	sourceDelta = 4 * ((sourceRaster * vDir) - (nWords * hDir));
	if (preload) {
		sourceDelta = sourceDelta - (4 * hDir);
	}
}

int splObj(int index) {
	return longAt((specialObjectsOop + 4) + (index * 4));
}

int stackIntegerValue(int offset) {
    int integerPointer;

	integerPointer = longAt(stackPointer - (offset * 4));
	if (((integerPointer & 1) == 1)) {
		return (integerPointer >> 1);
	} else {
		primitiveFail();
		return 0;
	}
}

int stackPointerIndex(void) {
	return ((stackPointer - activeContext) - 4) / 4;
}

int stackTop(void) {
	return longAt(stackPointer);
}

int stackValue(int offset) {
	return longAt(stackPointer - (offset * 4));
}

int startField(void) {
    int typeBits;
    int childType;

	child = longAt(field);
	typeBits = child & 3;
	if ((typeBits & 1) == 1) {
		field = field - 4;
		return 1;
	}
	if (typeBits == 0) {
		longAtput(field, parentField);
		parentField = field;
		return 2;
	}
	if (typeBits == 2) {
		if ((child & 126976) != 0) {
			child = child & 4294967292;
			/* begin rightType: */
			if ((child & 252) == 0) {
				childType = 0;
				goto l1;
			} else {
				if ((child & 126976) == 0) {
					childType = 1;
					goto l1;
				} else {
					childType = 3;
					goto l1;
				}
			}
		l1:	/* end rightType: */;
			longAtput(field, child | childType);
			return 3;
		} else {
			child = longAt(field - 4);
			child = child & 4294967292;
			longAtput(field - 4, parentField);
			parentField = (field - 4) | 1;
			return 2;
		}
	}
}

int startObj(void) {
    int oop;
    int header;
    int lastFieldOffset;
    int fmt;
    int sz;
    int methodHeader;
    int header1;
    int type;

	oop = child;
	if (oop < youngStart) {
		field = oop;
		return 3;
	}
	header = longAt(oop);
	if ((header & 2147483648) == 0) {
		header = header & 4294967292;
		header = (header | 2147483648) | 2;
		longAtput(oop, header);
		/* begin lastPointerOf: */
		fmt = (((unsigned) (longAt(oop))) >> 8) & 15;
		if (fmt < 4) {
			/* begin sizeBitsOfSafe: */
			header1 = longAt(oop);
			/* begin rightType: */
			if ((header1 & 252) == 0) {
				type = 0;
				goto l2;
			} else {
				if ((header1 & 126976) == 0) {
					type = 1;
					goto l2;
				} else {
					type = 3;
					goto l2;
				}
			}
		l2:	/* end rightType: */;
			if (type == 0) {
				sz = (longAt(oop - 8)) & 4294967292;
				goto l3;
			} else {
				sz = header1 & 252;
				goto l3;
			}
		l3:	/* end sizeBitsOfSafe: */;
			lastFieldOffset = sz - 4;
			goto l1;
		}
		if (fmt < 12) {
			lastFieldOffset = 0;
			goto l1;
		}
		methodHeader = longAt(oop + 4);
		lastFieldOffset = (((((unsigned) methodHeader) >> 10) & 255) * 4) + 4;
	l1:	/* end lastPointerOf: */;
		field = oop + lastFieldOffset;
		return 1;
	} else {
		field = oop;
		return 3;
	}
}

int startOfMemory(void) {
	return (int) memory;
}

int stObjectat(int array, int index) {
    int fixedFields;
    int totalLength;
    int i;
    int successValue;
    int header;
    int sz;
    int fmt;
    int fmt1;
    int byteVal;
    int classPointer;
    int fmt2;
    int ccIndex;

	/* begin fixedFieldsOf: */
	/* begin fetchClassOf: */
	if (((array & 1) == 1)) {
		classPointer = longAt((specialObjectsOop + 4) + (5 * 4));
		goto l2;
	}
	ccIndex = ((((unsigned) (longAt(array))) >> 12) & 31) - 1;
	if (ccIndex < 0) {
		classPointer = (longAt(array - 4)) & 4294967292;
		goto l2;
	} else {
		classPointer = longAt(((longAt((specialObjectsOop + 4) + (28 * 4))) + 4) + (ccIndex * 4));
		goto l2;
	}
l2:	/* end fetchClassOf: */;
	fmt2 = (longAt((classPointer + 4) + (2 * 4))) - 1;
	fixedFields = ((((unsigned) fmt2) >> 2) & 63) - 1;
	/* begin lengthOf: */
	header = longAt(array);
	if ((header & 3) == 0) {
		sz = (longAt(array - 8)) & 4294967292;
	} else {
		sz = header & 252;
	}
	fmt = (((unsigned) header) >> 8) & 15;
	if (fmt < 8) {
		totalLength = (sz - 4) / 4;
		goto l1;
	} else {
		totalLength = (sz - 4) - (fmt & 3);
		goto l1;
	}
l1:	/* end lengthOf: */;
	i = index + fixedFields;
	/* begin success: */
	successValue = (index >= 1) && (i <= totalLength);
	successFlag = successValue && successFlag;
	if (successFlag) {
		/* begin subscript:with: */
		fmt1 = (((unsigned) (longAt(array))) >> 8) & 15;
		if (fmt1 < 4) {
			return longAt((array + 4) + ((i - 1) * 4));
		}
		if (fmt1 < 8) {
			return positive32BitIntegerFor(longAt((array + 4) + ((i - 1) * 4)));
		}
		byteVal = byteAt((array + 4) + (i - 1));
		return ((byteVal << 1) | 1);
	} else {
		return nilObj;
	}
}

int stObjectatput(int array, int index, int value) {
    int fixedFields;
    int totalLength;
    int i;
    int successValue;
    int header;
    int sz;
    int fmt;
    int classPointer;
    int fmt1;
    int fmt2;
    int byte;
    int bitValue;
    int successValue1;
    int ccIndex;

	/* begin fixedFieldsOf: */
	/* begin fetchClassOf: */
	if (((array & 1) == 1)) {
		classPointer = longAt((specialObjectsOop + 4) + (5 * 4));
		goto l3;
	}
	ccIndex = ((((unsigned) (longAt(array))) >> 12) & 31) - 1;
	if (ccIndex < 0) {
		classPointer = (longAt(array - 4)) & 4294967292;
		goto l3;
	} else {
		classPointer = longAt(((longAt((specialObjectsOop + 4) + (28 * 4))) + 4) + (ccIndex * 4));
		goto l3;
	}
l3:	/* end fetchClassOf: */;
	fmt1 = (longAt((classPointer + 4) + (2 * 4))) - 1;
	fixedFields = ((((unsigned) fmt1) >> 2) & 63) - 1;
	/* begin lengthOf: */
	header = longAt(array);
	if ((header & 3) == 0) {
		sz = (longAt(array - 8)) & 4294967292;
	} else {
		sz = header & 252;
	}
	fmt = (((unsigned) header) >> 8) & 15;
	if (fmt < 8) {
		totalLength = (sz - 4) / 4;
		goto l1;
	} else {
		totalLength = (sz - 4) - (fmt & 3);
		goto l1;
	}
l1:	/* end lengthOf: */;
	i = index + fixedFields;
	/* begin success: */
	successValue = (index >= 1) && (i <= totalLength);
	successFlag = successValue && successFlag;
	if (successFlag) {
		/* begin subscript:with:storing: */
		fmt2 = (((unsigned) (longAt(array))) >> 8) & 15;
		if (fmt2 < 4) {
			/* begin storePointer:ofObject:withValue: */
			if (array < youngStart) {
				possibleRootStoreIntovalue(array, value);
			}
			longAtput((array + 4) + ((i - 1) * 4), value);
			goto l2;
		}
		if (fmt2 < 8) {
			bitValue = positive32BitValueOf(value);
			if (successFlag) {
				longAtput((array + 4) + ((i - 1) * 4), bitValue);
			}
			goto l2;
		}
		/* begin success: */
		successFlag = (((value & 1) == 1)) && successFlag;
		byte = (value >> 1);
		/* begin success: */
		successValue1 = (byte >= 0) && (byte <= 255);
		successFlag = successValue1 && successFlag;
		if (successFlag) {
			byteAtput((array + 4) + (i - 1), byte);
		}
	l2:	/* end subscript:with:storing: */;
	}
}

int stopReason(void) {
	return stopCode;
}

int storeByteofObjectwithValue(int byteIndex, int objectPointer, int valueByte) {
	return byteAtput((objectPointer + 4) + byteIndex, valueByte);
}

int storeContextRegisters(void) {
	longAtput((activeContext + 4) + (1 * 4), ((((instructionPointer - method) - (4 - 2)) << 1) | 1));
	longAtput((activeContext + 4) + (2 * 4), (((((((stackPointer - activeContext) - 4) / 4) - 6) + 1) << 1) | 1));
}

int storeInstructionPointerValueinContext(int value, int contextPointer) {
	longAtput((contextPointer + 4) + (1 * 4), ((value << 1) | 1));
}

int storeIntegerofObjectwithValue(int fieldIndex, int objectPointer, int integerValue) {
	if ((integerValue >= -1073741824) && (integerValue < 1073741824)) {
		longAtput((objectPointer + 4) + (fieldIndex * 4), ((integerValue << 1) | 1));
	} else {
		primitiveFail();
	}
}

int storePointerofObjectwithValue(int fieldIndex, int objectPointer, int valuePointer) {
	if (objectPointer < youngStart) {
		possibleRootStoreIntovalue(objectPointer, valuePointer);
	}
	return longAtput((objectPointer + 4) + (fieldIndex * 4), valuePointer);
}

int storePointerUncheckedofObjectwithValue(int wordIndex, int objectPointer, int valuePointer) {
	return longAtput((objectPointer + 4) + (wordIndex * 4), valuePointer);
}

int storeStackPointerValueinContext(int value, int contextPointer) {
	longAtput((contextPointer + 4) + (2 * 4), ((value << 1) | 1));
}

int storeWordofObjectwithValue(int wordIndex, int objectPointer, int valueWord) {
	return longAtput((objectPointer + 4) + (wordIndex * 4), valueWord);
}

int stSizeOf(int oop) {
    int totalLength;
    int fixedFields;
    int header;
    int sz;
    int fmt;
    int classPointer;
    int fmt1;
    int ccIndex;

	if (((oop & 1) == 1)) {
		return 0;
	}
	/* begin lengthOf: */
	header = longAt(oop);
	if ((header & 3) == 0) {
		sz = (longAt(oop - 8)) & 4294967292;
	} else {
		sz = header & 252;
	}
	fmt = (((unsigned) header) >> 8) & 15;
	if (fmt < 8) {
		totalLength = (sz - 4) / 4;
		goto l1;
	} else {
		totalLength = (sz - 4) - (fmt & 3);
		goto l1;
	}
l1:	/* end lengthOf: */;
	/* begin fixedFieldsOf: */
	/* begin fetchClassOf: */
	if (((oop & 1) == 1)) {
		classPointer = longAt((specialObjectsOop + 4) + (5 * 4));
		goto l2;
	}
	ccIndex = ((((unsigned) (longAt(oop))) >> 12) & 31) - 1;
	if (ccIndex < 0) {
		classPointer = (longAt(oop - 4)) & 4294967292;
		goto l2;
	} else {
		classPointer = longAt(((longAt((specialObjectsOop + 4) + (28 * 4))) + 4) + (ccIndex * 4));
		goto l2;
	}
l2:	/* end fetchClassOf: */;
	fmt1 = (longAt((classPointer + 4) + (2 * 4))) - 1;
	fixedFields = ((((unsigned) fmt1) >> 2) & 63) - 1;
	return totalLength - fixedFields;
}

int subscriptwith(int array, int index) {
    int fmt;
    int byteVal;

	fmt = (((unsigned) (longAt(array))) >> 8) & 15;
	if (fmt < 4) {
		return longAt((array + 4) + ((index - 1) * 4));
	}
	if (fmt < 8) {
		return positive32BitIntegerFor(longAt((array + 4) + ((index - 1) * 4)));
	}
	byteVal = byteAt((array + 4) + (index - 1));
	return ((byteVal << 1) | 1);
}

int subscriptwithstoring(int array, int index, int value) {
    int fmt;
    int byte;
    int bitValue;
    int successValue;

	fmt = (((unsigned) (longAt(array))) >> 8) & 15;
	if (fmt < 4) {
		/* begin storePointer:ofObject:withValue: */
		if (array < youngStart) {
			possibleRootStoreIntovalue(array, value);
		}
		longAtput((array + 4) + ((index - 1) * 4), value);
		return null;
	}
	if (fmt < 8) {
		bitValue = positive32BitValueOf(value);
		if (successFlag) {
			longAtput((array + 4) + ((index - 1) * 4), bitValue);
		}
		return null;
	}
	/* begin success: */
	successFlag = (((value & 1) == 1)) && successFlag;
	byte = (value >> 1);
	/* begin success: */
	successValue = (byte >= 0) && (byte <= 255);
	successFlag = successValue && successFlag;
	if (successFlag) {
		byteAtput((array + 4) + (index - 1), byte);
	}
}

int success(int successValue) {
	successFlag = successValue && successFlag;
}

int sufficientSpaceAfterGC(int minFree) {
	incrementalGC();
	if (((longAt(freeBlock)) & 536870908) < minFree) {
		if (signalLowSpace) {
			return false;
		}
		fullGC();
		if (((longAt(freeBlock)) & 536870908) < (minFree + 15000)) {
			return false;
		}
	}
	return true;
}

int sufficientSpaceToAllocate(int bytes) {
    int minFree;

	minFree = (lowSpaceThreshold + bytes) + 4;
	if (((longAt(freeBlock)) & 536870908) >= minFree) {
		return true;
	} else {
		return sufficientSpaceAfterGC(minFree);
	}
}

int sufficientSpaceToInstantiateindexableSize(int classOop, int size) {
    int format;
    int okay;
    int minFree;
    int minFree1;

	format = (((unsigned) ((longAt((classOop + 4) + (2 * 4))) - 1)) >> 8) & 15;
	if ((size > 0) && (format < 2)) {
		return false;
	}
	if (format < 8) {
		/* begin sufficientSpaceToAllocate: */
		minFree = (lowSpaceThreshold + (2500 + (size * 4))) + 4;
		if (((longAt(freeBlock)) & 536870908) >= minFree) {
			okay = true;
			goto l1;
		} else {
			okay = sufficientSpaceAfterGC(minFree);
			goto l1;
		}
	l1:	/* end sufficientSpaceToAllocate: */;
	} else {
		/* begin sufficientSpaceToAllocate: */
		minFree1 = (lowSpaceThreshold + (2500 + size)) + 4;
		if (((longAt(freeBlock)) & 536870908) >= minFree1) {
			okay = true;
			goto l2;
		} else {
			okay = sufficientSpaceAfterGC(minFree1);
			goto l2;
		}
	l2:	/* end sufficientSpaceToAllocate: */;
	}
	return okay;
}

int superclassOf(int classPointer) {
	return longAt((classPointer + 4) + (0 * 4));
}

int sweepPhase(void) {
    int entriesAvailable;
    int survivors;
    int freeChunk;
    int oop;
    int oopHeader;
    int oopHeaderType;
    int oopSize;
    int freeChunkSize;
    int chunk;

	entriesAvailable = fwdTableInit();
	survivors = 0;
	freeChunk = null;
	compStart = null;
	/* begin oopFromChunk: */
	chunk = youngStart;
	oop = chunk + (extraHeaderBytes(chunk));
	while (oop < endOfMemory) {
		oopHeader = longAt(oop);
		oopHeaderType = oopHeader & 3;
		if (oopHeaderType == 2) {
			oopSize = oopHeader & 536870908;
		} else {
			if (oopHeaderType == 0) {
				oopSize = (longAt(oop - 8)) & 4294967292;
			} else {
				oopSize = oopHeader & 252;
			}
		}
		if ((oopHeader & 2147483648) == 0) {
			if (freeChunk != null) {
				freeChunkSize = (freeChunkSize + oopSize) + (extraHeaderBytes(oop));
			} else {
				freeChunk = oop - (extraHeaderBytes(oop));
				freeChunkSize = oopSize + (oop - freeChunk);
				if (compStart == null) {
					compStart = freeChunk;
				}
			}
		} else {
			longAtput(oop, oopHeader & 2147483647);
			if (entriesAvailable > 0) {
				entriesAvailable = entriesAvailable - 1;
			} else {
				compStart = freeChunk;
			}
			if (freeChunk != null) {
				longAtput(freeChunk, (freeChunkSize & 536870908) | 2);
			}
			freeChunk = null;
			survivors = survivors + 1;
		}
		oop = (oop + oopSize) + (extraHeaderBytes(oop + oopSize));
	}
	if (freeChunk != null) {
		longAtput(freeChunk, (freeChunkSize & 536870908) | 2);
	}
	if (!(oop == endOfMemory)) {
		error("sweep failed to find exact end of memory");
	}
	if (compStart == null) {
		error("expected to find at least one free object");
	}
	return survivors;
}

int synchronousSignal(int aSemaphore) {
    int excessSignals;

	if ((longAt((aSemaphore + 4) + (0 * 4))) == nilObj) {
		excessSignals = fetchIntegerofObject(2, aSemaphore);
		/* begin storeInteger:ofObject:withValue: */
		if (((excessSignals + 1) >= -1073741824) && ((excessSignals + 1) < 1073741824)) {
			longAtput((aSemaphore + 4) + (2 * 4), (((excessSignals + 1) << 1) | 1));
		} else {
			primitiveFail();
		}
	} else {
		resume(removeFirstLinkOfList(aSemaphore));
	}
}

int tallyIntoMap(int destinationWord) {
    int mapIndex;
    int pixMask;
    int shiftWord;
    int i;
    int mask;
    int d;
    int srcPix;
    int destPix;
    int mask3;
    int d1;
    int srcPix1;
    int destPix1;
    int mask4;
    int d2;
    int srcPix2;
    int destPix2;

	if (colorMap == nilObj) {
		return destinationWord;
	}
	if (destPixSize < 16) {
		pixMask = (1 << destPixSize) - 1;
		shiftWord = destinationWord;
		for (i = 1; i <= pixPerWord; i += 1) {
			mapIndex = shiftWord & pixMask;
			longAtput((colorMap + 4) + (mapIndex * 4), (longAt((colorMap + 4) + (mapIndex * 4))) + 1);
			shiftWord = ((unsigned) shiftWord) >> destPixSize;
		}
		return destinationWord;
	}
	if (destPixSize == 16) {
		/* begin rgbMap:from:to: */
		if ((d = cmBitsPerColor - 5) > 0) {
			mask = (1 << 5) - 1;
			srcPix = destinationWord << d;
			mask = mask << d;
			destPix = srcPix & mask;
			mask = mask << cmBitsPerColor;
			srcPix = srcPix << d;
			mapIndex = (destPix + (srcPix & mask)) + ((srcPix << d) & (mask << cmBitsPerColor));
			goto l1;
		} else {
			if (d == 0) {
				mapIndex = destinationWord;
				goto l1;
			}
			d = 5 - cmBitsPerColor;
			mask = (1 << cmBitsPerColor) - 1;
			srcPix = ((unsigned) destinationWord) >> d;
			destPix = srcPix & mask;
			mask = mask << cmBitsPerColor;
			srcPix = ((unsigned) srcPix) >> d;
			mapIndex = (destPix + (srcPix & mask)) + ((((unsigned) srcPix) >> d) & (mask << cmBitsPerColor));
			goto l1;
		}
	l1:	/* end rgbMap:from:to: */;
		longAtput((colorMap + 4) + (mapIndex * 4), (longAt((colorMap + 4) + (mapIndex * 4))) + 1);
		/* begin rgbMap:from:to: */
		if ((d1 = cmBitsPerColor - 5) > 0) {
			mask3 = (1 << 5) - 1;
			srcPix1 = (((unsigned) destinationWord) >> 16) << d1;
			mask3 = mask3 << d1;
			destPix1 = srcPix1 & mask3;
			mask3 = mask3 << cmBitsPerColor;
			srcPix1 = srcPix1 << d1;
			mapIndex = (destPix1 + (srcPix1 & mask3)) + ((srcPix1 << d1) & (mask3 << cmBitsPerColor));
			goto l2;
		} else {
			if (d1 == 0) {
				mapIndex = ((unsigned) destinationWord) >> 16;
				goto l2;
			}
			d1 = 5 - cmBitsPerColor;
			mask3 = (1 << cmBitsPerColor) - 1;
			srcPix1 = ((unsigned) (((unsigned) destinationWord) >> 16)) >> d1;
			destPix1 = srcPix1 & mask3;
			mask3 = mask3 << cmBitsPerColor;
			srcPix1 = ((unsigned) srcPix1) >> d1;
			mapIndex = (destPix1 + (srcPix1 & mask3)) + ((((unsigned) srcPix1) >> d1) & (mask3 << cmBitsPerColor));
			goto l2;
		}
	l2:	/* end rgbMap:from:to: */;
		longAtput((colorMap + 4) + (mapIndex * 4), (longAt((colorMap + 4) + (mapIndex * 4))) + 1);
	} else {
		/* begin rgbMap:from:to: */
		if ((d2 = cmBitsPerColor - 8) > 0) {
			mask4 = (1 << 8) - 1;
			srcPix2 = destinationWord << d2;
			mask4 = mask4 << d2;
			destPix2 = srcPix2 & mask4;
			mask4 = mask4 << cmBitsPerColor;
			srcPix2 = srcPix2 << d2;
			mapIndex = (destPix2 + (srcPix2 & mask4)) + ((srcPix2 << d2) & (mask4 << cmBitsPerColor));
			goto l3;
		} else {
			if (d2 == 0) {
				mapIndex = destinationWord;
				goto l3;
			}
			d2 = 8 - cmBitsPerColor;
			mask4 = (1 << cmBitsPerColor) - 1;
			srcPix2 = ((unsigned) destinationWord) >> d2;
			destPix2 = srcPix2 & mask4;
			mask4 = mask4 << cmBitsPerColor;
			srcPix2 = ((unsigned) srcPix2) >> d2;
			mapIndex = (destPix2 + (srcPix2 & mask4)) + ((((unsigned) srcPix2) >> d2) & (mask4 << cmBitsPerColor));
			goto l3;
		}
	l3:	/* end rgbMap:from:to: */;
		longAtput((colorMap + 4) + (mapIndex * 4), (longAt((colorMap + 4) + (mapIndex * 4))) + 1);
	}
	return destinationWord;
}

int targetForm(void) {
	return destForm;
}

int temporary(int offset) {
	return longAt((theHomeContext + 4) + ((offset + 6) * 4));
}

int transferfromIndexofObjecttoIndexofObject(int count, int firstFrom, int fromOop, int firstTo, int toOop) {
    int fromIndex;
    int toIndex;
    int lastFrom;

	fromIndex = (fromOop + 4) + (firstFrom * 4);
	toIndex = (toOop + 4) + (firstTo * 4);
	lastFrom = fromIndex + (count * 4);
	while (fromIndex < lastFrom) {
		longAtput(toIndex, longAt(fromIndex));
		fromIndex = fromIndex + 4;
		toIndex = toIndex + 4;
	}
}

int transferTo(int newProc) {
    int sched;
    int oldProc;
    int valuePointer;
    int m;

	sched = longAt(((longAt((specialObjectsOop + 4) + (3 * 4))) + 4) + (1 * 4));
	oldProc = longAt((sched + 4) + (1 * 4));
	/* begin storePointer:ofObject:withValue: */
	valuePointer = activeContext;
	if (oldProc < youngStart) {
		possibleRootStoreIntovalue(oldProc, valuePointer);
	}
	longAtput((oldProc + 4) + (1 * 4), valuePointer);
	/* begin storePointer:ofObject:withValue: */
	if (sched < youngStart) {
		possibleRootStoreIntovalue(sched, newProc);
	}
	longAtput((sched + 4) + (1 * 4), newProc);
	/* begin newActiveContext: */
	/* begin storeContextRegisters */
	longAtput((activeContext + 4) + (1 * 4), ((((instructionPointer - method) - (4 - 2)) << 1) | 1));
	longAtput((activeContext + 4) + (2 * 4), (((((((stackPointer - activeContext) - 4) / 4) - 6) + 1) << 1) | 1));
	activeContext = longAt((newProc + 4) + (1 * 4));
	if (activeContext < youngStart) {
		beRootIfOld(activeContext);
	}
	/* begin fetchContextRegisters */
	m = longAt((activeContext + 4) + (3 * 4));
	if (((m & 1) == 1)) {
		theHomeContext = longAt((activeContext + 4) + (5 * 4));
		if (theHomeContext < youngStart) {
			beRootIfOld(theHomeContext);
		}
	} else {
		theHomeContext = activeContext;
	}
	receiver = longAt((theHomeContext + 4) + (5 * 4));
	method = longAt((theHomeContext + 4) + (3 * 4));
	instructionPointer = ((longAt((activeContext + 4) + (1 * 4))) >> 1);
	instructionPointer = ((method + instructionPointer) + 4) - 2;
	stackPointer = ((longAt((activeContext + 4) + (2 * 4))) >> 1);
	stackPointer = (activeContext + 4) + (((6 + stackPointer) - 1) * 4);
	reclaimableContextCount = 0;
}

int unknownBytecode(void) {
	error("Unknown bytecode");
}

int unPop(int nItems) {
	stackPointer = stackPointer + (nItems * 4);
}

int upward(void) {
    int type;
    int header;

	if ((parentField & 1) == 1) {
		if (parentField == 3) {
			header = (longAt(field)) & 4294967292;
			/* begin rightType: */
			if ((header & 252) == 0) {
				type = 0;
				goto l1;
			} else {
				if ((header & 126976) == 0) {
					type = 1;
					goto l1;
				} else {
					type = 3;
					goto l1;
				}
			}
		l1:	/* end rightType: */;
			longAtput(field, header + type);
			return 4;
		} else {
			child = field;
			field = parentField - 1;
			parentField = longAt(field);
			header = longAt(field + 4);
			/* begin rightType: */
			if ((header & 252) == 0) {
				type = 0;
				goto l2;
			} else {
				if ((header & 126976) == 0) {
					type = 1;
					goto l2;
				} else {
					type = 3;
					goto l2;
				}
			}
		l2:	/* end rightType: */;
			longAtput(field, child + type);
			field = field + 4;
			header = header & 4294967292;
			longAtput(field, header + type);
			return 3;
		}
	} else {
		child = field;
		field = parentField;
		parentField = longAt(field);
		longAtput(field, child);
		field = field - 4;
		return 1;
	}
}

int wakeHighestPriority(void) {
    int schedLists;
    int p;
    int processList;

	schedLists = longAt(((longAt(((longAt((specialObjectsOop + 4) + (3 * 4))) + 4) + (1 * 4))) + 4) + (0 * 4));
	p = fetchWordLengthOf(schedLists);
	p = p - 1;
	processList = longAt((schedLists + 4) + (p * 4));
	while ((longAt((processList + 4) + (0 * 4))) == nilObj) {
		p = p - 1;
		if (p < 0) {
			error("scheduler could not find a runnable process");
		}
		processList = longAt((schedLists + 4) + (p * 4));
	}
	return removeFirstLinkOfList(processList);
}

int warpBits(void) {
    int ns;
    int skewWord;
    int halftoneWord;
    int mergeWord;
    int i;
    int word;
    int destMask;
    int startBits;
    int deltaP12x;
    int deltaP12y;
    int deltaP43x;
    int deltaP43y;
    int pAx;
    int pAy;
    int xDelta;
    int yDelta;
    int pBx;
    int pBy;
    int smoothingCount;
    int sourceMapOop;
    int nSteps;
    int integerPointer;
    int destinationWord;
    int delta;
    int delta1;
    int x2;
    int delta2;
    int x21;
    int delta3;
    int x22;
    int delta4;
    int x23;
    int delta5;

	ns = noSource;
	noSource = true;
	clipRange();
	noSource = ns;
	if (noSource || ((bbW <= 0) || (bbH <= 0))) {
		affectedL = affectedR = affectedT = affectedB = 0;
		return null;
	}
	destMaskAndPointerInit();
	/* begin warpLoop */
	if (!((fetchWordLengthOf(bitBltOop)) >= (15 + 12))) {
		primitiveFail();
		goto l9;
	}
	nSteps = height - 1;
	if (nSteps <= 0) {
		nSteps = 1;
	}
	pAx = fetchIntegerofObject(15, bitBltOop);
	/* begin deltaFrom:to:nSteps: */
	x2 = fetchIntegerofObject(15 + 3, bitBltOop);
	delta2 = x2 - pAx;
	if (delta2 > 0) {
		deltaP12x = (delta2 - 1) / nSteps;
		goto l5;
	} else {
		if (delta2 == 0) {
			deltaP12x = 0;
			goto l5;
		} else {
			deltaP12x = (delta2 + 2) / nSteps;
			goto l5;
		}
	}
l5:	/* end deltaFrom:to:nSteps: */;
	if (deltaP12x < 0) {
		pAx = pAx - 1;
	}
	pAy = fetchIntegerofObject(15 + 1, bitBltOop);
	/* begin deltaFrom:to:nSteps: */
	x21 = fetchIntegerofObject(15 + 4, bitBltOop);
	delta3 = x21 - pAy;
	if (delta3 > 0) {
		deltaP12y = (delta3 - 1) / nSteps;
		goto l6;
	} else {
		if (delta3 == 0) {
			deltaP12y = 0;
			goto l6;
		} else {
			deltaP12y = (delta3 + 2) / nSteps;
			goto l6;
		}
	}
l6:	/* end deltaFrom:to:nSteps: */;
	if (deltaP12y < 0) {
		pAy = pAy - 1;
	}
	pBx = fetchIntegerofObject(15 + 9, bitBltOop);
	/* begin deltaFrom:to:nSteps: */
	x22 = fetchIntegerofObject(15 + 6, bitBltOop);
	delta4 = x22 - pBx;
	if (delta4 > 0) {
		deltaP43x = (delta4 - 1) / nSteps;
		goto l7;
	} else {
		if (delta4 == 0) {
			deltaP43x = 0;
			goto l7;
		} else {
			deltaP43x = (delta4 + 2) / nSteps;
			goto l7;
		}
	}
l7:	/* end deltaFrom:to:nSteps: */;
	if (deltaP43x < 0) {
		pBx = pBx - 1;
	}
	pBy = fetchIntegerofObject(15 + 10, bitBltOop);
	/* begin deltaFrom:to:nSteps: */
	x23 = fetchIntegerofObject(15 + 7, bitBltOop);
	delta5 = x23 - pBy;
	if (delta5 > 0) {
		deltaP43y = (delta5 - 1) / nSteps;
		goto l8;
	} else {
		if (delta5 == 0) {
			deltaP43y = 0;
			goto l8;
		} else {
			deltaP43y = (delta5 + 2) / nSteps;
			goto l8;
		}
	}
l8:	/* end deltaFrom:to:nSteps: */;
	if (deltaP43y < 0) {
		pBy = pBy - 1;
	}
	if (!successFlag) {
		goto l9;
	}
	if (argumentCount == 2) {
		/* begin stackIntegerValue: */
		integerPointer = longAt(stackPointer - (1 * 4));
		if (((integerPointer & 1) == 1)) {
			smoothingCount = (integerPointer >> 1);
			goto l1;
		} else {
			primitiveFail();
			smoothingCount = 0;
			goto l1;
		}
	l1:	/* end stackIntegerValue: */;
		sourceMapOop = longAt(stackPointer - (0 * 4));
		if (sourceMapOop == nilObj) {
			if (destPixSize < 16) {
				primitiveFail();
				goto l9;
			}
		} else {
			if ((fetchWordLengthOf(sourceMapOop)) < (1 << sourcePixSize)) {
				primitiveFail();
				goto l9;
			}
		}
	} else {
		smoothingCount = 1;
		sourceMapOop = nilObj;
	}
	startBits = pixPerWord - (dx & (pixPerWord - 1));
	nSteps = width - 1;
	if (nSteps <= 0) {
		nSteps = 1;
	}
	for (i = 1; i <= bbH; i += 1) {
		/* begin deltaFrom:to:nSteps: */
		delta = pBx - pAx;
		if (delta > 0) {
			xDelta = (delta - 1) / nSteps;
			goto l3;
		} else {
			if (delta == 0) {
				xDelta = 0;
				goto l3;
			} else {
				xDelta = (delta + 2) / nSteps;
				goto l3;
			}
		}
	l3:	/* end deltaFrom:to:nSteps: */;
		if (xDelta >= 0) {
			sx = pAx;
		} else {
			sx = pAx - 1;
		}
		/* begin deltaFrom:to:nSteps: */
		delta1 = pBy - pAy;
		if (delta1 > 0) {
			yDelta = (delta1 - 1) / nSteps;
			goto l4;
		} else {
			if (delta1 == 0) {
				yDelta = 0;
				goto l4;
			} else {
				yDelta = (delta1 + 2) / nSteps;
				goto l4;
			}
		}
	l4:	/* end deltaFrom:to:nSteps: */;
		if (yDelta >= 0) {
			sy = pAy;
		} else {
			sy = pAy - 1;
		}
		if (noHalftone) {
			halftoneWord = 4294967295;
		} else {
			halftoneWord = longAt(halftoneBase + ((((dy + i) - 1) % halftoneHeight) * 4));
		}
		destMask = mask1;
		if (bbW < startBits) {
			skewWord = warpSourcePixelsxDeltahyDeltahxDeltavyDeltavsmoothingsourceMap(bbW, xDelta, yDelta, deltaP12x, deltaP12y, smoothingCount, sourceMapOop);
			skewWord = ((((startBits - bbW) * destPixSize) < 0) ? ((unsigned) skewWord >> -((startBits - bbW) * destPixSize)) : ((unsigned) skewWord << ((startBits - bbW) * destPixSize)));
		} else {
			skewWord = warpSourcePixelsxDeltahyDeltahxDeltavyDeltavsmoothingsourceMap(startBits, xDelta, yDelta, deltaP12x, deltaP12y, smoothingCount, sourceMapOop);
		}
		for (word = 1; word <= nWords; word += 1) {
			/* begin merge:with: */
			destinationWord = (longAt(destIndex)) & destMask;
			if (combinationRule < 16) {
				if (combinationRule < 8) {
					if (combinationRule < 4) {
						if (combinationRule < 2) {
							if (combinationRule < 1) {
								mergeWord = 0;
								goto l2;
							} else {
								mergeWord = (skewWord & halftoneWord) & destinationWord;
								goto l2;
							}
						} else {
							if (combinationRule < 3) {
								mergeWord = (skewWord & halftoneWord) & (~destinationWord);
								goto l2;
							} else {
								mergeWord = skewWord & halftoneWord;
								goto l2;
							}
						}
					} else {
						if (combinationRule < 6) {
							if (combinationRule < 5) {
								mergeWord = (~(skewWord & halftoneWord)) & destinationWord;
								goto l2;
							} else {
								mergeWord = destinationWord;
								goto l2;
							}
						} else {
							if (combinationRule < 7) {
								mergeWord = (skewWord & halftoneWord) ^ destinationWord;
								goto l2;
							} else {
								mergeWord = (skewWord & halftoneWord) | destinationWord;
								goto l2;
							}
						}
					}
				} else {
					if (combinationRule < 12) {
						if (combinationRule < 10) {
							if (combinationRule < 9) {
								mergeWord = (~(skewWord & halftoneWord)) & (~destinationWord);
								goto l2;
							} else {
								mergeWord = (~(skewWord & halftoneWord)) ^ destinationWord;
								goto l2;
							}
						} else {
							if (combinationRule < 11) {
								mergeWord = ~destinationWord;
								goto l2;
							} else {
								mergeWord = (skewWord & halftoneWord) | (~destinationWord);
								goto l2;
							}
						}
					} else {
						if (combinationRule < 14) {
							if (combinationRule < 13) {
								mergeWord = ~(skewWord & halftoneWord);
								goto l2;
							} else {
								mergeWord = (~(skewWord & halftoneWord)) | destinationWord;
								goto l2;
							}
						} else {
							if (combinationRule < 15) {
								mergeWord = (~(skewWord & halftoneWord)) | (~destinationWord);
								goto l2;
							} else {
								mergeWord = destinationWord;
								goto l2;
							}
						}
					}
				}
			} else {
				if (combinationRule < 24) {
					if (combinationRule < 20) {
						if (combinationRule < 18) {
							if (combinationRule < 17) {
								mergeWord = destinationWord;
								goto l2;
							} else {
								mergeWord = destinationWord;
								goto l2;
							}
						} else {
							if (combinationRule < 19) {
								mergeWord = (skewWord & halftoneWord) + destinationWord;
								goto l2;
							} else {
								mergeWord = (skewWord & halftoneWord) - destinationWord;
								goto l2;
							}
						}
					} else {
						if (combinationRule < 22) {
							if (combinationRule < 21) {
								mergeWord = rgbAddwith(skewWord & halftoneWord, destinationWord);
								goto l2;
							} else {
								mergeWord = rgbSubwith(skewWord & halftoneWord, destinationWord);
								goto l2;
							}
						} else {
							if (combinationRule < 23) {
								mergeWord = rgbDiffwith(skewWord & halftoneWord, destinationWord);
								goto l2;
							} else {
								mergeWord = tallyIntoMap(destinationWord);
								goto l2;
							}
						}
					}
				} else {
					if (combinationRule < 28) {
						if (combinationRule < 26) {
							if (combinationRule < 25) {
								mergeWord = alphaBlendwith(skewWord & halftoneWord, destinationWord);
								goto l2;
							} else {
								mergeWord = pixPaintwith(skewWord & halftoneWord, destinationWord);
								goto l2;
							}
						} else {
							if (combinationRule < 27) {
								mergeWord = pixMaskwith(skewWord & halftoneWord, destinationWord);
								goto l2;
							} else {
								mergeWord = destinationWord;
								goto l2;
							}
						}
					} else {
						if (combinationRule < 30) {
							if (combinationRule < 29) {
								mergeWord = destinationWord;
								goto l2;
							} else {
								mergeWord = destinationWord;
								goto l2;
							}
						} else {
							if (combinationRule < 31) {
								mergeWord = destinationWord;
								goto l2;
							} else {
								mergeWord = destinationWord;
								goto l2;
							}
						}
					}
				}
			}
		l2:	/* end merge:with: */;
			longAtput(destIndex, (destMask & mergeWord) | ((~destMask) & (longAt(destIndex))));
			destIndex = destIndex + 4;
			if (word >= (nWords - 1)) {
				if (!(word == nWords)) {
					destMask = mask2;
					skewWord = warpSourcePixelsxDeltahyDeltahxDeltavyDeltavsmoothingsourceMap(pixPerWord, xDelta, yDelta, deltaP12x, deltaP12y, smoothingCount, sourceMapOop);
				}
			} else {
				destMask = 4294967295;
				skewWord = warpSourcePixelsxDeltahyDeltahxDeltavyDeltavsmoothingsourceMap(pixPerWord, xDelta, yDelta, deltaP12x, deltaP12y, smoothingCount, sourceMapOop);
			}
		}
		pAx = pAx + deltaP12x;
		pAy = pAy + deltaP12y;
		pBx = pBx + deltaP43x;
		pBy = pBy + deltaP43y;
		destIndex = destIndex + destDelta;
	}
l9:	/* end warpLoop */;
	if (hDir > 0) {
		affectedL = dx;
		affectedR = dx + bbW;
	} else {
		affectedL = dx - bbW;
		affectedR = dx;
	}
	if (vDir > 0) {
		affectedT = dy;
		affectedB = dy + bbH;
	} else {
		affectedT = dy - bbH;
		affectedB = dy;
	}
}

int warpLoop(void) {
    int skewWord;
    int halftoneWord;
    int mergeWord;
    int i;
    int word;
    int destMask;
    int startBits;
    int deltaP12x;
    int deltaP12y;
    int deltaP43x;
    int deltaP43y;
    int pAx;
    int pAy;
    int xDelta;
    int yDelta;
    int pBx;
    int pBy;
    int smoothingCount;
    int sourceMapOop;
    int nSteps;
    int integerPointer;
    int destinationWord;
    int delta;
    int delta1;
    int x2;
    int delta2;
    int x21;
    int delta3;
    int x22;
    int delta4;
    int x23;
    int delta5;

	if (!((fetchWordLengthOf(bitBltOop)) >= (15 + 12))) {
		return primitiveFail();
	}
	nSteps = height - 1;
	if (nSteps <= 0) {
		nSteps = 1;
	}
	pAx = fetchIntegerofObject(15, bitBltOop);
	/* begin deltaFrom:to:nSteps: */
	x2 = fetchIntegerofObject(15 + 3, bitBltOop);
	delta2 = x2 - pAx;
	if (delta2 > 0) {
		deltaP12x = (delta2 - 1) / nSteps;
		goto l5;
	} else {
		if (delta2 == 0) {
			deltaP12x = 0;
			goto l5;
		} else {
			deltaP12x = (delta2 + 2) / nSteps;
			goto l5;
		}
	}
l5:	/* end deltaFrom:to:nSteps: */;
	if (deltaP12x < 0) {
		pAx = pAx - 1;
	}
	pAy = fetchIntegerofObject(15 + 1, bitBltOop);
	/* begin deltaFrom:to:nSteps: */
	x21 = fetchIntegerofObject(15 + 4, bitBltOop);
	delta3 = x21 - pAy;
	if (delta3 > 0) {
		deltaP12y = (delta3 - 1) / nSteps;
		goto l6;
	} else {
		if (delta3 == 0) {
			deltaP12y = 0;
			goto l6;
		} else {
			deltaP12y = (delta3 + 2) / nSteps;
			goto l6;
		}
	}
l6:	/* end deltaFrom:to:nSteps: */;
	if (deltaP12y < 0) {
		pAy = pAy - 1;
	}
	pBx = fetchIntegerofObject(15 + 9, bitBltOop);
	/* begin deltaFrom:to:nSteps: */
	x22 = fetchIntegerofObject(15 + 6, bitBltOop);
	delta4 = x22 - pBx;
	if (delta4 > 0) {
		deltaP43x = (delta4 - 1) / nSteps;
		goto l7;
	} else {
		if (delta4 == 0) {
			deltaP43x = 0;
			goto l7;
		} else {
			deltaP43x = (delta4 + 2) / nSteps;
			goto l7;
		}
	}
l7:	/* end deltaFrom:to:nSteps: */;
	if (deltaP43x < 0) {
		pBx = pBx - 1;
	}
	pBy = fetchIntegerofObject(15 + 10, bitBltOop);
	/* begin deltaFrom:to:nSteps: */
	x23 = fetchIntegerofObject(15 + 7, bitBltOop);
	delta5 = x23 - pBy;
	if (delta5 > 0) {
		deltaP43y = (delta5 - 1) / nSteps;
		goto l8;
	} else {
		if (delta5 == 0) {
			deltaP43y = 0;
			goto l8;
		} else {
			deltaP43y = (delta5 + 2) / nSteps;
			goto l8;
		}
	}
l8:	/* end deltaFrom:to:nSteps: */;
	if (deltaP43y < 0) {
		pBy = pBy - 1;
	}
	if (!successFlag) {
		return false;
	}
	if (argumentCount == 2) {
		/* begin stackIntegerValue: */
		integerPointer = longAt(stackPointer - (1 * 4));
		if (((integerPointer & 1) == 1)) {
			smoothingCount = (integerPointer >> 1);
			goto l1;
		} else {
			primitiveFail();
			smoothingCount = 0;
			goto l1;
		}
	l1:	/* end stackIntegerValue: */;
		sourceMapOop = longAt(stackPointer - (0 * 4));
		if (sourceMapOop == nilObj) {
			if (destPixSize < 16) {
				return primitiveFail();
			}
		} else {
			if ((fetchWordLengthOf(sourceMapOop)) < (1 << sourcePixSize)) {
				return primitiveFail();
			}
		}
	} else {
		smoothingCount = 1;
		sourceMapOop = nilObj;
	}
	startBits = pixPerWord - (dx & (pixPerWord - 1));
	nSteps = width - 1;
	if (nSteps <= 0) {
		nSteps = 1;
	}
	for (i = 1; i <= bbH; i += 1) {
		/* begin deltaFrom:to:nSteps: */
		delta = pBx - pAx;
		if (delta > 0) {
			xDelta = (delta - 1) / nSteps;
			goto l3;
		} else {
			if (delta == 0) {
				xDelta = 0;
				goto l3;
			} else {
				xDelta = (delta + 2) / nSteps;
				goto l3;
			}
		}
	l3:	/* end deltaFrom:to:nSteps: */;
		if (xDelta >= 0) {
			sx = pAx;
		} else {
			sx = pAx - 1;
		}
		/* begin deltaFrom:to:nSteps: */
		delta1 = pBy - pAy;
		if (delta1 > 0) {
			yDelta = (delta1 - 1) / nSteps;
			goto l4;
		} else {
			if (delta1 == 0) {
				yDelta = 0;
				goto l4;
			} else {
				yDelta = (delta1 + 2) / nSteps;
				goto l4;
			}
		}
	l4:	/* end deltaFrom:to:nSteps: */;
		if (yDelta >= 0) {
			sy = pAy;
		} else {
			sy = pAy - 1;
		}
		if (noHalftone) {
			halftoneWord = 4294967295;
		} else {
			halftoneWord = longAt(halftoneBase + ((((dy + i) - 1) % halftoneHeight) * 4));
		}
		destMask = mask1;
		if (bbW < startBits) {
			skewWord = warpSourcePixelsxDeltahyDeltahxDeltavyDeltavsmoothingsourceMap(bbW, xDelta, yDelta, deltaP12x, deltaP12y, smoothingCount, sourceMapOop);
			skewWord = ((((startBits - bbW) * destPixSize) < 0) ? ((unsigned) skewWord >> -((startBits - bbW) * destPixSize)) : ((unsigned) skewWord << ((startBits - bbW) * destPixSize)));
		} else {
			skewWord = warpSourcePixelsxDeltahyDeltahxDeltavyDeltavsmoothingsourceMap(startBits, xDelta, yDelta, deltaP12x, deltaP12y, smoothingCount, sourceMapOop);
		}
		for (word = 1; word <= nWords; word += 1) {
			/* begin merge:with: */
			destinationWord = (longAt(destIndex)) & destMask;
			if (combinationRule < 16) {
				if (combinationRule < 8) {
					if (combinationRule < 4) {
						if (combinationRule < 2) {
							if (combinationRule < 1) {
								mergeWord = 0;
								goto l2;
							} else {
								mergeWord = (skewWord & halftoneWord) & destinationWord;
								goto l2;
							}
						} else {
							if (combinationRule < 3) {
								mergeWord = (skewWord & halftoneWord) & (~destinationWord);
								goto l2;
							} else {
								mergeWord = skewWord & halftoneWord;
								goto l2;
							}
						}
					} else {
						if (combinationRule < 6) {
							if (combinationRule < 5) {
								mergeWord = (~(skewWord & halftoneWord)) & destinationWord;
								goto l2;
							} else {
								mergeWord = destinationWord;
								goto l2;
							}
						} else {
							if (combinationRule < 7) {
								mergeWord = (skewWord & halftoneWord) ^ destinationWord;
								goto l2;
							} else {
								mergeWord = (skewWord & halftoneWord) | destinationWord;
								goto l2;
							}
						}
					}
				} else {
					if (combinationRule < 12) {
						if (combinationRule < 10) {
							if (combinationRule < 9) {
								mergeWord = (~(skewWord & halftoneWord)) & (~destinationWord);
								goto l2;
							} else {
								mergeWord = (~(skewWord & halftoneWord)) ^ destinationWord;
								goto l2;
							}
						} else {
							if (combinationRule < 11) {
								mergeWord = ~destinationWord;
								goto l2;
							} else {
								mergeWord = (skewWord & halftoneWord) | (~destinationWord);
								goto l2;
							}
						}
					} else {
						if (combinationRule < 14) {
							if (combinationRule < 13) {
								mergeWord = ~(skewWord & halftoneWord);
								goto l2;
							} else {
								mergeWord = (~(skewWord & halftoneWord)) | destinationWord;
								goto l2;
							}
						} else {
							if (combinationRule < 15) {
								mergeWord = (~(skewWord & halftoneWord)) | (~destinationWord);
								goto l2;
							} else {
								mergeWord = destinationWord;
								goto l2;
							}
						}
					}
				}
			} else {
				if (combinationRule < 24) {
					if (combinationRule < 20) {
						if (combinationRule < 18) {
							if (combinationRule < 17) {
								mergeWord = destinationWord;
								goto l2;
							} else {
								mergeWord = destinationWord;
								goto l2;
							}
						} else {
							if (combinationRule < 19) {
								mergeWord = (skewWord & halftoneWord) + destinationWord;
								goto l2;
							} else {
								mergeWord = (skewWord & halftoneWord) - destinationWord;
								goto l2;
							}
						}
					} else {
						if (combinationRule < 22) {
							if (combinationRule < 21) {
								mergeWord = rgbAddwith(skewWord & halftoneWord, destinationWord);
								goto l2;
							} else {
								mergeWord = rgbSubwith(skewWord & halftoneWord, destinationWord);
								goto l2;
							}
						} else {
							if (combinationRule < 23) {
								mergeWord = rgbDiffwith(skewWord & halftoneWord, destinationWord);
								goto l2;
							} else {
								mergeWord = tallyIntoMap(destinationWord);
								goto l2;
							}
						}
					}
				} else {
					if (combinationRule < 28) {
						if (combinationRule < 26) {
							if (combinationRule < 25) {
								mergeWord = alphaBlendwith(skewWord & halftoneWord, destinationWord);
								goto l2;
							} else {
								mergeWord = pixPaintwith(skewWord & halftoneWord, destinationWord);
								goto l2;
							}
						} else {
							if (combinationRule < 27) {
								mergeWord = pixMaskwith(skewWord & halftoneWord, destinationWord);
								goto l2;
							} else {
								mergeWord = destinationWord;
								goto l2;
							}
						}
					} else {
						if (combinationRule < 30) {
							if (combinationRule < 29) {
								mergeWord = destinationWord;
								goto l2;
							} else {
								mergeWord = destinationWord;
								goto l2;
							}
						} else {
							if (combinationRule < 31) {
								mergeWord = destinationWord;
								goto l2;
							} else {
								mergeWord = destinationWord;
								goto l2;
							}
						}
					}
				}
			}
		l2:	/* end merge:with: */;
			longAtput(destIndex, (destMask & mergeWord) | ((~destMask) & (longAt(destIndex))));
			destIndex = destIndex + 4;
			if (word >= (nWords - 1)) {
				if (!(word == nWords)) {
					destMask = mask2;
					skewWord = warpSourcePixelsxDeltahyDeltahxDeltavyDeltavsmoothingsourceMap(pixPerWord, xDelta, yDelta, deltaP12x, deltaP12y, smoothingCount, sourceMapOop);
				}
			} else {
				destMask = 4294967295;
				skewWord = warpSourcePixelsxDeltahyDeltahxDeltavyDeltavsmoothingsourceMap(pixPerWord, xDelta, yDelta, deltaP12x, deltaP12y, smoothingCount, sourceMapOop);
			}
		}
		pAx = pAx + deltaP12x;
		pAy = pAy + deltaP12y;
		pBx = pBx + deltaP43x;
		pBy = pBy + deltaP43y;
		destIndex = destIndex + destDelta;
	}
}

int warpSourcePixelsxDeltahyDeltahxDeltavyDeltavsmoothingsourceMap(int nPix, int xDeltah, int yDeltah, int xDeltav, int yDeltav, int n, int sourceMapOop) {
    int destWord;
    int sourcePix;
    int i;
    int sourcePixMask;
    int destPixMask;
    int srcPixPerWord;
    int destPix;
    int mask;
    int d;
    int srcPix;
    int destPix1;
    int mask3;
    int d1;
    int srcPix1;
    int destPix2;
    int mask4;
    int d2;
    int srcPix2;
    int destPix3;
    int mask5;
    int d3;
    int srcPix3;
    int destPix4;

	sourcePixMask = (1 << sourcePixSize) - 1;
	srcPixPerWord = 32 / sourcePixSize;
	destPixMask = (1 << destPixSize) - 1;
	destWord = 0;
	for (i = 1; i <= nPix; i += 1) {
		if (n > 1) {
			destPix = (smoothPixatXfyfdxhdyhdxvdyvpixPerWordpixelMasksourceMap(n, sx, sy, xDeltah / n, yDeltah / n, xDeltav / n, yDeltav / n, srcPixPerWord, sourcePixMask, sourceMapOop)) & destPixMask;
		} else {
			sourcePix = (sourcePixAtXypixPerWord(((unsigned) sx) >> 14, ((unsigned) sy) >> 14, srcPixPerWord)) & sourcePixMask;
			if (colorMap == nilObj) {
				if (destPixSize == sourcePixSize) {
					destPix = sourcePix;
				} else {
					if (sourcePixSize >= 16) {
						if (sourcePixSize == 16) {
							/* begin rgbMap:from:to: */
							if ((d = 8 - 5) > 0) {
								mask = (1 << 5) - 1;
								srcPix = sourcePix << d;
								mask = mask << d;
								destPix1 = srcPix & mask;
								mask = mask << 8;
								srcPix = srcPix << d;
								destPix = (destPix1 + (srcPix & mask)) + ((srcPix << d) & (mask << 8));
								goto l1;
							} else {
								if (d == 0) {
									destPix = sourcePix;
									goto l1;
								}
								d = 5 - 8;
								mask = (1 << 8) - 1;
								srcPix = ((unsigned) sourcePix) >> d;
								destPix1 = srcPix & mask;
								mask = mask << 8;
								srcPix = ((unsigned) srcPix) >> d;
								destPix = (destPix1 + (srcPix & mask)) + ((((unsigned) srcPix) >> d) & (mask << 8));
								goto l1;
							}
						l1:	/* end rgbMap:from:to: */;
						} else {
							/* begin rgbMap:from:to: */
							if ((d1 = 5 - 8) > 0) {
								mask3 = (1 << 8) - 1;
								srcPix1 = sourcePix << d1;
								mask3 = mask3 << d1;
								destPix2 = srcPix1 & mask3;
								mask3 = mask3 << 5;
								srcPix1 = srcPix1 << d1;
								destPix = (destPix2 + (srcPix1 & mask3)) + ((srcPix1 << d1) & (mask3 << 5));
								goto l2;
							} else {
								if (d1 == 0) {
									destPix = sourcePix;
									goto l2;
								}
								d1 = 8 - 5;
								mask3 = (1 << 5) - 1;
								srcPix1 = ((unsigned) sourcePix) >> d1;
								destPix2 = srcPix1 & mask3;
								mask3 = mask3 << 5;
								srcPix1 = ((unsigned) srcPix1) >> d1;
								destPix = (destPix2 + (srcPix1 & mask3)) + ((((unsigned) srcPix1) >> d1) & (mask3 << 5));
								goto l2;
							}
						l2:	/* end rgbMap:from:to: */;
						}
					} else {
						destPix = sourcePix & destPixMask;
					}
				}
			} else {
				if (sourcePixSize >= 16) {
					if (sourcePixSize == 16) {
						/* begin rgbMap:from:to: */
						if ((d2 = cmBitsPerColor - 5) > 0) {
							mask4 = (1 << 5) - 1;
							srcPix2 = sourcePix << d2;
							mask4 = mask4 << d2;
							destPix3 = srcPix2 & mask4;
							mask4 = mask4 << cmBitsPerColor;
							srcPix2 = srcPix2 << d2;
							sourcePix = (destPix3 + (srcPix2 & mask4)) + ((srcPix2 << d2) & (mask4 << cmBitsPerColor));
							goto l3;
						} else {
							if (d2 == 0) {
								sourcePix = sourcePix;
								goto l3;
							}
							d2 = 5 - cmBitsPerColor;
							mask4 = (1 << cmBitsPerColor) - 1;
							srcPix2 = ((unsigned) sourcePix) >> d2;
							destPix3 = srcPix2 & mask4;
							mask4 = mask4 << cmBitsPerColor;
							srcPix2 = ((unsigned) srcPix2) >> d2;
							sourcePix = (destPix3 + (srcPix2 & mask4)) + ((((unsigned) srcPix2) >> d2) & (mask4 << cmBitsPerColor));
							goto l3;
						}
					l3:	/* end rgbMap:from:to: */;
					} else {
						/* begin rgbMap:from:to: */
						if ((d3 = cmBitsPerColor - 8) > 0) {
							mask5 = (1 << 8) - 1;
							srcPix3 = sourcePix << d3;
							mask5 = mask5 << d3;
							destPix4 = srcPix3 & mask5;
							mask5 = mask5 << cmBitsPerColor;
							srcPix3 = srcPix3 << d3;
							sourcePix = (destPix4 + (srcPix3 & mask5)) + ((srcPix3 << d3) & (mask5 << cmBitsPerColor));
							goto l4;
						} else {
							if (d3 == 0) {
								sourcePix = sourcePix;
								goto l4;
							}
							d3 = 8 - cmBitsPerColor;
							mask5 = (1 << cmBitsPerColor) - 1;
							srcPix3 = ((unsigned) sourcePix) >> d3;
							destPix4 = srcPix3 & mask5;
							mask5 = mask5 << cmBitsPerColor;
							srcPix3 = ((unsigned) srcPix3) >> d3;
							sourcePix = (destPix4 + (srcPix3 & mask5)) + ((((unsigned) srcPix3) >> d3) & (mask5 << cmBitsPerColor));
							goto l4;
						}
					l4:	/* end rgbMap:from:to: */;
					}
				}
				destPix = (longAt((colorMap + 4) + (sourcePix * 4))) & destPixMask;
			}
		}
		destWord = (destWord << destPixSize) | destPix;
		sx = sx + xDeltah;
		sy = sy + yDeltah;
	}
	return destWord;
}
